suppressPackageStartupMessages(library(kernelshap))
suppressPackageStartupMessages(library(jsonlite))
stopifnot(identical(as.character(packageVersion('kernelshap')), '0.9.1'))
outdir <- '/tmp/padml-kernelshap-init-profile-20260929'
p <- 17L
m <- 2L * p
deg <- 1L
seed <- 780000001L
h <- c(6L, 12L, 24L, 36L)
names_out <- paste0('t', h)
selected <- paste0('F', seq_len(p))
# Input construction and prediction are completely deterministic; no fit or clinical data.
bg <- as.data.frame(outer(seq_len(9L), seq_len(p), function(i,j) {
  sin(i * (j + 1) / 7) + 0.3*cos((i + 2) * j / 11)
}))
names(bg) <- selected
X <- bg
prediction_calls <- 0L
predict_deterministic <- function(object, newdata) {
  before <- get('.Random.seed', envir=.GlobalEnv)
  z <- as.matrix(newdata)
  score <- 0.5 + 0.12 * z[,1L] - 0.09 * z[,3L] + 0.07*z[,9L] +
    0.11*sin(z[,2L]*z[,5L]) + 0.08*z[,6L]*z[,7L] +
    0.09*cos(z[,4L]+z[,8L]) + 0.07*z[,10L]*z[,11L]*z[,12L]
  risk <- exp(score)
  value <- vapply(c(0.12, 0.2, 0.38, 0.55), function(a) exp(-a*risk), numeric(nrow(z)))
  value <- matrix(value, nrow=nrow(z), ncol=4L, dimnames=list(NULL,names_out))
  stopifnot(identical(before, get('.Random.seed',envir=.GlobalEnv)),
            all(is.finite(value)), all(value >= 0 & value <= 1))
  prediction_calls <<- prediction_calls+1L
  value
}
run <- function(x, cap, rng_seed=NULL) kernelshap(
  object=NULL, X=x, bg_X=bg, pred_fun=predict_deterministic,
  feature_names=selected, bg_w=NULL, bg_n=nrow(bg), exact=FALSE,
  hybrid_degree=deg, m=m, tol=0.005, max_iter=as.integer(cap),
  parallel=FALSE, verbose=FALSE, seed=rng_seed)
bytes <- function(x) writeBin(as.double(x),raw(),size=8L,endian='little')
num_equal <- function(a,b) identical(dim(a),dim(b)) && identical(bytes(a),bytes(b))
check_row <- function(batch,i,row) {
  checks <- c(
    S=all(vapply(names_out,function(n)num_equal(batch$S[[n]][i,,drop=FALSE],row$S[[n]]),logical(1))),
    SE=all(vapply(names_out,function(n)num_equal(batch$SE[[n]][i,,drop=FALSE],row$SE[[n]]),logical(1))),
    baseline=num_equal(batch$baseline,row$baseline),
    predictions=num_equal(batch$predictions[i,,drop=FALSE],row$predictions),
    n_iter=identical(batch$n_iter[[i]],row$n_iter[[1L]]),
    converged=identical(batch$converged[[i]],row$converged[[1L]]))
  stopifnot(all(checks)); checks
}
state_pin <- function(state) {
  # Exact states remain in the isolated RDS evidence; no hash is used to compare them.
  list(length=length(state), first=state[[1L]])
}

# One short warmup; then one measured batch and one measured sequence of 9 rows.
# No production code, installed source, model, or scientific algorithm is modified.
invisible(run(X[1L,,drop=FALSE],2L,seed))
.padml_init_profile <- new.env(parent=emptyenv())
reset <- function(){
  .padml_init_profile$in_row<-FALSE
  .padml_init_profile$outer_prediction_index<-0L
  .padml_init_profile$row_masked_prediction_index<-0L
  .padml_init_profile$seconds<-setNames(numeric(6L),c('background_prediction','foreground_prediction','fixed_input_preparation','patient_solver_inclusive','patient_exact_prediction','patient_sampling_prediction'))
  .padml_init_profile$counts<-setNames(integer(6L),names(.padml_init_profile$seconds))
}
clock <- function()as.numeric(Sys.time())
record_time <- function(name,seconds){
  .padml_init_profile$seconds[[name]]<-.padml_init_profile$seconds[[name]]+seconds
  .padml_init_profile$counts[[name]]<-.padml_init_profile$counts[[name]]+1L
}
reset()
ns<-asNamespace('kernelshap')
trace('kernelshap_one',where=ns,print=FALSE,
  tracer=quote({.padml_init_profile$in_row<-TRUE;.padml_init_profile$row_masked_prediction_index<-0L;.padml_profile_start<-clock()}),
  exit=quote({record_time('patient_solver_inclusive',clock()-.padml_profile_start);.padml_init_profile$in_row<-FALSE}))
for(n in c('input_partly_exact','rep_rows','rep_each')) {
  trace(n,where=ns,print=FALSE,
    tracer=quote({.padml_profile_is_init<-!.padml_init_profile$in_row;.padml_profile_start<-clock()}),
    exit=quote({if(.padml_profile_is_init)record_time('fixed_input_preparation',clock()-.padml_profile_start)}))
}
timed_prediction<-function(object,newdata){
  if(.padml_init_profile$in_row){
    .padml_init_profile$row_masked_prediction_index<-.padml_init_profile$row_masked_prediction_index+1L
    category<-if(.padml_init_profile$row_masked_prediction_index==1L)'patient_exact_prediction' else 'patient_sampling_prediction'
  } else {
    .padml_init_profile$outer_prediction_index<-.padml_init_profile$outer_prediction_index+1L
    category<-if(.padml_init_profile$outer_prediction_index==1L)'background_prediction' else 'foreground_prediction'
  }
  begin<-clock();value<-predict_deterministic(object,newdata)
  record_time(category,clock()-begin);value
}
profiled_call<-function(value,rng_seed=NULL){
  .padml_init_profile$outer_prediction_index<-0L
  kernelshap(object=NULL,X=value,bg_X=bg,pred_fun=timed_prediction,
    feature_names=selected,bg_w=NULL,bg_n=nrow(bg),exact=FALSE,hybrid_degree=deg,m=m,
    tol=.005,max_iter=2000L,parallel=FALSE,verbose=FALSE,seed=rng_seed)
}
snapshot<-function(wall){
  vals<-.padml_init_profile$seconds
  init<-sum(vals[c('background_prediction','foreground_prediction','fixed_input_preparation')])
  list(wall_seconds=wall,calls=as.list(.padml_init_profile$counts),seconds=as.list(vals),
    measured_initialization_seconds=init,
    measured_initialization_fraction=init/wall,
    solver_inclusive_fraction=vals[['patient_solver_inclusive']]/wall,
    wrapper_and_trace_residual_seconds=wall-init-vals[['patient_solver_inclusive']])
}
reset();begin<-clock();batch<-profiled_call(X,seed);batch_wall<-clock()-begin;batch_rng<-.Random.seed
batch_profile<-snapshot(batch_wall)
reset();set.seed(seed);row_results<-vector('list',nrow(X));begin<-clock()
for(i in seq_len(nrow(X)))row_results[[i]]<-profiled_call(X[i,,drop=FALSE],NULL)
row_wall<-clock()-begin;row_profile<-snapshot(row_wall)
row_rng<-.Random.seed
checks<-lapply(seq_len(nrow(X)),function(i)check_row(batch,i,row_results[[i]]))
stopifnot(identical(batch_rng,row_rng))
for(n in c('kernelshap_one','input_partly_exact','rep_rows','rep_each'))untrace(n,where=ns)
report<-list(scope='One bounded in-memory trace timing; same p17/four-output/9-background deterministic unfitted fixture; no clinical/remote/fit/production source changes. Timers include instrumentation; no production speedup claim.',
  versions=list(R=as.character(getRversion()),kernelshap=as.character(packageVersion('kernelshap')),
    kernelshap_path=find.package('kernelshap')),
  fixture=list(p=p,background_rows=nrow(bg),patients=nrow(X),seed=seed,max_iter=2000L,n_iter=as.list(batch$n_iter)),
  warmup='One row with max_iter2, discarded, before timers',
  batch=batch_profile,individual_rows=row_profile,
  row_bytes_and_rng_equal=TRUE,
  source_reference=list(archive='/Users/liuningyuan/Desktop/PAD/PADML_F2_V1_Runtime/build/f45-engineering.lKLxgL/kernelshap_0.9.1.tar.gz',
    kernelshap_default_background_prediction='R/kernelshap.R:213-222',
    fixed_template_preparation='R/kernelshap.R:237-259',
    private_row_solver='R/kernelshap.R:291-308',
    patient_specific_exact_terms='R/utils_kernelshap.R:24-43'))
writeLines(jsonlite::toJSON(report,auto_unbox=TRUE,pretty=TRUE,digits=17),file.path(outdir,'result.json'))
cat(jsonlite::toJSON(report,auto_unbox=TRUE,pretty=TRUE,digits=17),'\n')
