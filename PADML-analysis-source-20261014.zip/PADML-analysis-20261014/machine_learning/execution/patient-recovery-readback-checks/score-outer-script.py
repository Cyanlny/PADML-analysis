import ast, hashlib, json, os, sys, tempfile, time, traceback, warnings, zipfile
from pathlib import Path
ROOT=Path('/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD')
sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
import pytest
import test_f45_score_reuse as case
from padml import f5, runtime, nested_loco as n
from padml.bundle import ContractError
EVIDENCE=Path(tempfile.mkdtemp(prefix='padml-score-readback-review-',dir='/tmp')).resolve()
print(str(EVIDENCE),flush=True)
NAMES={'_F45ReusedScoreInputs','_f45_score_reuse_read_job','_prepare_f45_score_reuse','_full_data_locked_score_program'}
def source_pins():
    raw=(ROOT/'padml/f5.py').read_bytes()
    return {'file':hashlib.sha256(raw).hexdigest(),'ast':{x.name:hashlib.sha256(ast.dump(x,include_attributes=False).encode()).hexdigest() for x in ast.parse(raw).body if isinstance(x,(ast.FunctionDef,ast.ClassDef)) and x.name in NAMES}}
def policy():
    return {'configured_worker_ceiling':runtime.CPU_MINUS_8,'memory_bytes_per_worker':2*1024**3,'memory_reserve_bytes':4*1024**3,'scratch_bytes_per_worker':1,'scratch_reserve_bytes':0,'transfer_archive_worker_ceiling':24}
report={'runtime':sys.version,'source_start':source_pins(),'scope':'Synthetic existing consumer tests; run authority and native-health leaves mocked; pool transports pickled inline; no native fitting or whole-unit science acceptance.','cases':[]}
original_prepare=f5._prepare_f45_score_reuse
original_fixture=case.fixture
for scope,family in [('OUTER','FPM_TVC_SET_A'),('FULL_DATA','GBM_COX')]:
    row={'scope':scope,'family':family,'groups':[],'guards':0,'pending_without_owner_rejected':False,'duplicate_index_rejected':False}
    root=EVIDENCE/(scope+'-'+family); root.mkdir()
    start=time.perf_counter()
    with pytest.MonkeyPatch.context() as mp:
        # A transitional test fixture may omit this helper/new explicit keyword.
        mp.setattr(case,'_policy',policy,raising=False)
        original_canonical=n._read_canonical
        def fixture_canonical(path,*args,**kwargs):
            if Path(path)==ROOT/'science-decision.json':return n.science_decision_template(24)
            return original_canonical(path,*args,**kwargs)
        mp.setattr(n,'_read_canonical',fixture_canonical)
        row['fixture_adaptation']='Only top-level old science fixture read uses unchanged h6/12/24 template; validators unchanged. Explicit resource_policy passed by harness.'
        guard=n._validate_fresh_score_component_numbers
        def observed_guard(*args,**kwargs):
            row['guards']+=1
            return guard(*args,**kwargs)
        mp.setattr(n,'_validate_fresh_score_component_numbers',observed_guard)
        def fixture(*args,**kwargs):
            result=original_fixture(*args,**kwargs)
            reader=runtime._readback_ordered
            def observed_readback(fn,items,**kw):
                if fn is f5._f45_score_reuse_read_job:
                    sizes=[len(item['jobs']) for item in items]
                    assert all(1<=size<=20 for size in sizes)
                    assert all(len({(job['score_evidence']['record']['family'],job['score_evidence']['record']['repeat'],job['score_evidence']['record']['inner_fold']) for _,job in item['jobs']})==1 for item in items)
                    row['groups'].append({'count':len(items),'sizes':sizes,'per_worker_bytes':kw['per_worker_bytes'],'retained_bytes':kw['retained_bytes']})
                return reader(fn,items,**kw)
            mp.setattr(runtime,'_readback_ordered',observed_readback)
            row['_fixture']=result
            return result
        mp.setattr(case,'fixture',fixture)
        def prepare(request,work,jobs,candidates,**kwargs):
            kwargs.setdefault('resource_policy',policy())
            pending=list((work/'score-reuse').glob('*/components/score/*/*.zip'))
            evidence=list((work/'score-evidence').glob('*/*.json'))
            if pending and not evidence and not row['pending_without_owner_rejected']:
                try: original_prepare(request,work,jobs,[],**kwargs)
                except ContractError as exc:
                    assert 'F45_SCORE_REUSE_PENDING_ORIGINAL_EVIDENCE_REQUIRED' in str(exc),str(exc)
                    row['pending_without_owner_rejected']=True
                else: raise AssertionError('Pending coordinate could enter fresh-fit without original producer')
            return original_prepare(request,work,jobs,candidates,**kwargs)
        mp.setattr(f5,'_prepare_f45_score_reuse',prepare)
        try:
            case.test_mixed_original_inputs_rescore_current_horizon_and_roundtrip(root,mp,scope,family)
            request,work,fresh,jobs,candidate,old_score=row.pop('_fixture')
            if scope=='OUTER':
                unit=Path(candidate['root']).name
                path=work/'score-reuse'/unit/'source.json'
                sources={unit:{'path':path.relative_to(work).as_posix(),'sha256':n.sha256_file(path),'size_bytes':path.stat().st_size}}
                duplicate=root/'duplicate-index'; duplicate.mkdir()
                import shutil
                for filename in ('input.zip','result.zip'):shutil.copyfile(Path(candidate['root'])/filename,duplicate/filename)
                with warnings.catch_warnings():
                    warnings.simplefilter('ignore',UserWarning)
                    with zipfile.ZipFile(duplicate/'input.zip','a') as z:
                        z.writestr('UNFITTED_UNUSED_DUPLICATE',b'a');z.writestr('UNFITTED_UNUSED_DUPLICATE',b'b')
                first=request['component_records'][0]['path']
                item=dict(request=request,root=work,unit=unit,sources=sources,expanded=1024**2,retained=1024**2,replay=False,jobs=[(first,jobs[0])],candidate=duplicate,originals={})
                try:f5._f45_score_reuse_read_job(item)
                except ContractError as exc:
                    assert 'F45_SCORE_REUSE_MEMBER_INVALID' in str(exc),str(exc)
                    row['duplicate_index_rejected']=True
                else:raise AssertionError('Duplicate ZIP member accepted')
            row['status']='PASS'
        except BaseException:
            row.pop('_fixture',None)
            row['status']='FAIL';row['traceback']=traceback.format_exc()
    row['seconds']=time.perf_counter()-start
    report['cases'].append(row)
    print(json.dumps({k:v for k,v in row.items() if k!='groups'}),flush=True)
    (EVIDENCE/'result.json').write_text(json.dumps(report,indent=2))
    if row['status']!='PASS':break
report['source_end']=source_pins()
report['status']='PASS' if len(report['cases'])==2 and all(x['status']=='PASS' for x in report['cases']) else 'FAIL'
(EVIDENCE/'result.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'status':report['status'],'evidence':str(EVIDENCE)}),flush=True)
