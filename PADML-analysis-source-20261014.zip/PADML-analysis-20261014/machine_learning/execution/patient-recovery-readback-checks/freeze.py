"""Freeze one reviewed package with the original source compiler and consumers."""
import ast
import io
import json
import os
import subprocess
import sys
import zipfile
from pathlib import Path
from padml import f4
from padml.bundle import canonical_json_bytes as enc, sha256_bytes as sha, sha256_file, write_deterministic_zip

assert sys.version_info[:2] == (3, 12)
repo = Path(__file__).resolve().parents[2]
base, checks = repo / 'execution', Path(__file__).resolve().parent
previous = base / 'release-final-reuse-hash-release/PADML_F45_REBUILD_20260929_FINAL_REUSE_HASH_RELEASE.zip'
assert sha256_file(previous) == '3073b169f033e8bfa5464b397d25130846507dc5b401cf6039aebcd6051db30a'
pins = f4._f45_source_member_sha256()
identity = sha(enc(pins))
qualification = json.loads((checks / 'qualification.json').read_bytes())
tests = json.loads((checks / 'focused-tests.json').read_bytes())
assert qualification['source_identity'] == identity
assert len(qualification['checks']['predecessors']) == 20
assert tests['python_unique_cases_passed'] == 16 and tests['latest_case_failures'] == 0
assert tests['score_cases_passed'] == 2 and tests['r_cases_passed'] == 7
assert tests['current_source_pins'] == pins
for name, digest in tests['test_pins'].items():
    assert sha256_file(repo / name) == digest
review = json.loads((checks / 'reviewed-source-ast.json').read_bytes())
for name, functions in review['function_revisions'].items():
    observed = {node.name: sha(ast.dump(node, include_attributes=False).encode())
        for node in ast.parse((repo / name).read_bytes()).body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
    for function, revisions in functions.items():
        if function == '_f45_shap_dependency_repair':
            assert function not in observed
        else:
            assert observed[function] == revisions[-1]
for name, digest in review['raw_revisions'].items():
    assert pins[name] == digest
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--name-only', 'HEAD', '--', *f4.F45_SOURCE_MEMBERS], cwd=repo)
for name in f4.F45_SOURCE_MEMBERS:
    assert subprocess.check_output(['git', 'show', head + ':' + name], cwd=repo) == (repo / name).read_bytes()
with zipfile.ZipFile(previous) as archive:
    members = {name: archive.read(name) for name in archive.namelist() if name != 'release.json'}
    with zipfile.ZipFile(io.BytesIO(members['source.zip'])) as source:
        changed = [name for name in f4.F45_SOURCE_MEMBERS if source.read(name) != (repo / name).read_bytes()]
assert set(changed) == {'AGENTS.md', 'NESTED_LOCO_PROTOCOL.md', 'padml/f5.py', 'padml/f5_sensitivity.py',
    'padml/runtime.py', 'padml/run.py', 'padml/kernels/f5_shap.R'}
out = base / 'release-patient-recovery-readback'
out.mkdir()
compiled = f4.compile_f45_source_bundle(out / 'source.zip')
prefix = 'patient-recovery-readback-predecessor'
members[prefix + '/run.json'] = members['run.json']
members[prefix + '/source.zip'] = members['source.zip']
old = json.loads(members['run.json'])
members['source.zip'] = (out / 'source.zip').read_bytes()
members['source.compile.json'] = enc(compiled)
run = {**old, 'source_identity': identity, 'source_bundle_sha256': compiled['sha256'],
    'unit_predecessor': {'run_path': old['run_root'] + '/' + prefix + '/run.json',
        'run_sha256': sha(members[prefix + '/run.json']),
        'source_path': old['run_root'] + '/' + prefix + '/source.zip',
        'source_sha256': sha(members[prefix + '/source.zip'])}}
run['identity'] = sha(enc({k: v for k, v in run.items() if k != 'identity'}))
assert run['units'] == old['units'] and len(run['units']) == 56
assert run['science_decision'] == old['science_decision']
members['run.json'] = enc(run)
evidence = {p.name: p for p in checks.iterdir() if p.is_file()
    and p.suffix in {'.py', '.json', '.log', '.xml', '.R'}
    and p.name not in {'readback-review-snapshot.json'}}
for name in tests['test_pins']:
    evidence[name] = repo / name
write_deterministic_zip(out / 'patient-recovery-readback-checks.zip', evidence)
members['patient-recovery-readback-checks.zip'] = (out / 'patient-recovery-readback-checks.zip').read_bytes()
# The same bounded pilot and exact CLI are directly usable after unpacking.
members['patient-recovery-readback-checks/pilot.py'] = (checks / 'pilot.py').read_bytes()
members['HISTORICAL_FINAL_REUSE_HASH_RELEASE_COMPILE.md'] = members['COMPILE_REPORT.md']
for name in ('AGENTS.md', 'NESTED_LOCO_PROTOCOL.md'):
    members[name] = (repo / name).read_bytes()
report = (f'Frozen Git: {head}. Source: {identity}. Run: {run["identity"]}.\n\n'
    + (base / 'PATIENT_RECOVERY_READBACK_COMPILE.md').read_text()).encode()
members['README.md'] = members['COMPILE_REPORT.md'] = members['EXECUTION_HANDOFF.md'] = report
summary = {'head': head, 'source_identity': identity, 'run_identity': run['identity'], 'source': compiled,
    'changed_source_members': changed, 'source_member_count': len(f4.F45_SOURCE_MEMBERS),
    'units': len(run['units']), 'predecessors': 20,
    'python_focused_cases': 16, 'score_cases': 2, 'r_cases': 7,
    'previous_package_sha256': sha256_file(previous), 'development_science_unchanged': True,
    'shap_recovery_policy': 'ORIGINAL_500_PATIENT_START; tol0.005; finite_max2000; patient checkpoints',
    'qualification_sha256': sha256_file(checks / 'qualification.json'),
    'deployed': False, 'compiler_clinical_calls': 0, 'compiler_remote_operations': 0,
    'clinical_completion_claimed': False, 'pilot_clinical_status': 'NOT_RUN_IN_COMPILER'}
members['compile-summary.json'] = enc(summary)
with zipfile.ZipFile(previous) as archive:
    for name in archive.namelist():
        if name in {'science-decision.json', 'dependencies.json', 'shared/bootstrap.zip', 'shared/bootstrap-preparation.json'} \
                or name.endswith(('/run.json', '/source.zip', '-checks.zip')):
            assert members[name] == archive.read(name)
release = {'kind': 'PADML_F45_PATIENT_RECOVERY_READBACK_RELEASE', 'head': head,
    'run_identity': run['identity'], 'source_identity': identity,
    'members': {name: {'sha256': sha(raw), 'size_bytes': len(raw)} for name, raw in members.items()}}
members['release.json'] = enc(release)
target = out / 'PADML_F45_REBUILD_20260929_PATIENT_RECOVERY_READBACK.zip'
write_deterministic_zip(target, members)
completed = subprocess.run([sys.executable, '-B', str(checks / 'frozen-reader.py'), str(target)],
    cwd=repo, check=True, capture_output=True, text=True,
    env={**os.environ, 'PYTHONPATH': str(repo), 'PYTHONDONTWRITEBYTECODE': '1'})
(out / 'frozen-reader.log').write_text(completed.stdout)
summary.update(package=str(target), sha256=sha256_file(target), size_bytes=target.stat().st_size)
(out / 'compile-summary.json').write_bytes(enc(summary))
print(json.dumps(summary))
