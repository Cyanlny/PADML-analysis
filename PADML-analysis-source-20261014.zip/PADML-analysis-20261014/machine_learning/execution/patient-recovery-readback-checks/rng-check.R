suppressPackageStartupMessages(library(kernelshap))
suppressPackageStartupMessages(library(jsonlite))
stopifnot(identical(as.character(packageVersion('kernelshap')), '0.9.1'))
outdir <- '/tmp/padml-kernelshap-row-rng-20260929'
p <- 17L
m <- 2L * p
deg <- 1L
seed <- 780000001L
h <- c(6L, 12L, 24L, 36L)
names_out <- paste0('t', h)
selected <- paste0('F', seq_len(p))
# Input construction and prediction are completely deterministic; no fit or clinical data.
bg <- as.data.frame(outer(seq_len(9L), seq_len(p), function(i,j) {
  sin(i * (j + 1) / 7) + 0.3*cos((i + 2) * j / 11)
}))
names(bg) <- selected
X <- bg[c(1L, 3L, 6L, 9L), , drop=FALSE]
prediction_calls <- 0L
predict_deterministic <- function(object, newdata) {
  before <- get('.Random.seed', envir=.GlobalEnv)
  z <- as.matrix(newdata)
  score <- 0.5 + 0.12 * z[,1L] - 0.09 * z[,3L] + 0.07*z[,9L] +
    0.11*sin(z[,2L]*z[,5L]) + 0.08*z[,6L]*z[,7L] +
    0.09*cos(z[,4L]+z[,8L]) + 0.07*z[,10L]*z[,11L]*z[,12L]
  risk <- exp(score)
  value <- vapply(c(0.12, 0.2, 0.38, 0.55), function(a) exp(-a*risk), numeric(nrow(z)))
  value <- matrix(value, nrow=nrow(z), ncol=4L, dimnames=list(NULL,names_out))
  stopifnot(identical(before, get('.Random.seed',envir=.GlobalEnv)),
            all(is.finite(value)), all(value >= 0 & value <= 1))
  prediction_calls <<- prediction_calls+1L
  value
}
run <- function(x, cap, rng_seed=NULL) kernelshap(
  object=NULL, X=x, bg_X=bg, pred_fun=predict_deterministic,
  feature_names=selected, bg_w=NULL, bg_n=nrow(bg), exact=FALSE,
  hybrid_degree=deg, m=m, tol=0.005, max_iter=as.integer(cap),
  parallel=FALSE, verbose=FALSE, seed=rng_seed)
bytes <- function(x) writeBin(as.double(x),raw(),size=8L,endian='little')
num_equal <- function(a,b) identical(dim(a),dim(b)) && identical(bytes(a),bytes(b))
check_row <- function(batch,i,row) {
  checks <- c(
    S=all(vapply(names_out,function(n)num_equal(batch$S[[n]][i,,drop=FALSE],row$S[[n]]),logical(1))),
    SE=all(vapply(names_out,function(n)num_equal(batch$SE[[n]][i,,drop=FALSE],row$SE[[n]]),logical(1))),
    baseline=num_equal(batch$baseline,row$baseline),
    predictions=num_equal(batch$predictions[i,,drop=FALSE],row$predictions),
    n_iter=identical(batch$n_iter[[i]],row$n_iter[[1L]]),
    converged=identical(batch$converged[[i]],row$converged[[1L]]))
  stopifnot(all(checks)); checks
}
state_pin <- function(state) {
  # Exact states remain in the isolated RDS evidence; no hash is used to compare them.
  list(length=length(state), first=state[[1L]])
}
start <- proc.time()[['elapsed']]
full <- run(X,500L,seed)
full_after <- get('.Random.seed',envir=.GlobalEnv)
set.seed(seed)
row_before <- row_after <- vector('list',nrow(X))
row_results <- vector('list',nrow(X))
checks <- vector('list',nrow(X))
for (i in seq_len(nrow(X))) {
  row_before[[i]] <- get('.Random.seed',envir=.GlobalEnv)
  row_results[[i]] <- run(X[i,,drop=FALSE],500L,NULL)
  row_after[[i]] <- get('.Random.seed',envir=.GlobalEnv)
  checks[[i]] <- check_row(full,i,row_results[[i]])
}
stopifnot(identical(full_after,get('.Random.seed',envir=.GlobalEnv)))
sample_step <- getFromNamespace('input_sampling','kernelshap')
shadow <- function(counts) {
  set.seed(seed)
  before <- after <- vector('list',length(counts))
  calls_before <- prediction_calls
  for (i in seq_along(counts)) {
    before[[i]] <- get('.Random.seed',envir=.GlobalEnv)
    for (j in seq_len(counts[[i]])) {
      sample_step(p=p,m=m,deg=deg,feature_names=selected)
    }
    after[[i]] <- get('.Random.seed',envir=.GlobalEnv)
  }
  stopifnot(prediction_calls==calls_before)
  list(before=before,after=after,prediction_calls=0L)
}
anchors <- shadow(full$n_iter)
stopifnot(identical(anchors$before,row_before), identical(anchors$after,row_after),
          identical(anchors$after[[nrow(X)]],full_after))

# One bounded budget-expansion analogy only; 2 -> 7 is NOT an H0 budget result.
small <- run(X,2L,seed)
small_anchors <- shadow(small$n_iter)
failed <- which(!small$converged)
i <- failed[failed<nrow(X)][[1L]]
j <- i+1L
assign('.Random.seed',small_anchors$before[[i]],envir=.GlobalEnv)
extended <- run(X[i,,drop=FALSE],7L,NULL)
extended_after <- get('.Random.seed',envir=.GlobalEnv)
stopifnot(extended$n_iter[[1L]]>small$n_iter[[i]],
          !identical(extended_after,small_anchors$after[[i]]))
# Use the fixed original anchor, never the extra draws produced by the extended row.
assign('.Random.seed',small_anchors$before[[j]],envir=.GlobalEnv)
next_original <- run(X[j,,drop=FALSE],2L,NULL)
next_check <- check_row(small,j,next_original)
stopifnot(identical(get('.Random.seed',envir=.GlobalEnv),small_anchors$after[[j]]))
# Naive carry-forward demonstrably changes the later start and can change numerical output.
assign('.Random.seed',extended_after,envir=.GlobalEnv)
next_naive <- run(X[j,,drop=FALSE],2L,NULL)
naive_shap_changed <- any(vapply(names_out,function(n) {
  !identical(bytes(next_naive$S[[n]]),bytes(small$S[[n]][j,,drop=FALSE]))
},logical(1)))
stopifnot(naive_shap_changed)

report <- list(
  scope='UNFITTED SYNTHETIC ENGINEERING ONLY; no clinical inputs, remote, training, or H0 pilot; no production convergence claim',
  versions=list(R=as.character(getRversion()),kernelshap=as.character(packageVersion('kernelshap')),
                kernelshap_path=find.package('kernelshap'),platform=R.version$platform),
  rng_kind=as.list(RNGkind()), seed=seed, p=p, outputs=as.list(names_out),
  background_rows=nrow(bg),explanation_rows=nrow(X),hybrid_degree=deg,m=m,tol=0.005,
  original500=list(n_iter=as.list(full$n_iter),converged=as.list(full$converged),
    per_row_checks=lapply(checks,as.list),whole_vs_rows_final_rng_identical=TRUE),
  reconstruction=list(before_each_row_identical=TRUE,after_each_row_identical=TRUE,
    original_final_rng_identical=TRUE,prediction_calls=0L,
    method='exact original input_sampling once per retained n_iter'),
  expansion_analogy=list(original_cap=2L,expanded_cap=7L,row=i,next_row=j,
    old_n_iter=small$n_iter[[i]],expanded_n_iter=extended$n_iter[[1L]],
    expanded_converged=extended$converged[[1L]],
    expanded_rng_different_from_original_row_end=TRUE,
    next_original_anchor_preserved=TRUE,next_row_checks=as.list(next_check),
    next_original_after_rng_identical=TRUE,naive_carry_changes_next_shap=naive_shap_changed),
  prediction_rng_unchanged_on_every_call=TRUE,prediction_calls=prediction_calls,
  elapsed_seconds=proc.time()[['elapsed']]-start)
saveRDS(list(full500=full,row500=row_results,anchors500=anchors,
             small2=small,anchors2=small_anchors,extended7=extended,extended_after=extended_after,
             next_original=next_original,next_naive=next_naive),file.path(outdir,'evidence.rds'))
writeLines(toJSON(report,auto_unbox=TRUE,pretty=TRUE,digits=17),file.path(outdir,'result.json'))
cat(toJSON(report,auto_unbox=TRUE,pretty=TRUE,digits=17),'\n')
