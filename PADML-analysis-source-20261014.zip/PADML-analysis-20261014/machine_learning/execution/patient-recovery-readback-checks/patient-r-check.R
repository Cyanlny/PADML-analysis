suppressPackageStartupMessages(library(kernelshap))
suppressPackageStartupMessages(library(jsonlite))
stopifnot(identical(as.character(packageVersion('kernelshap')), '0.9.1'))
outdir <- '/tmp/padml-kernelshap-patient-check-20260929'
p <- 17L
m <- 2L * p
deg <- 1L
seed <- 780000001L
h <- c(6L, 12L, 24L, 36L)
names_out <- paste0('t', h)
selected <- paste0('F', seq_len(p))
# Input construction and prediction are completely deterministic; no fit or clinical data.
bg <- as.data.frame(outer(seq_len(9L), seq_len(p), function(i,j) {
  sin(i * (j + 1) / 7) + 0.3*cos((i + 2) * j / 11)
}))
names(bg) <- selected
X <- bg
prediction_calls <- 0L
predict_deterministic <- function(object, newdata) {
  before <- get('.Random.seed', envir=.GlobalEnv)
  z <- as.matrix(newdata)
  score <- 0.5 + 0.12 * z[,1L] - 0.09 * z[,3L] + 0.07*z[,9L] +
    0.11*sin(z[,2L]*z[,5L]) + 0.08*z[,6L]*z[,7L] +
    0.09*cos(z[,4L]+z[,8L]) + 0.07*z[,10L]*z[,11L]*z[,12L]
  risk <- exp(score)
  value <- vapply(c(0.12, 0.2, 0.38, 0.55), function(a) exp(-a*risk), numeric(nrow(z)))
  value <- matrix(value, nrow=nrow(z), ncol=4L, dimnames=list(NULL,names_out))
  stopifnot(identical(before, get('.Random.seed',envir=.GlobalEnv)),
            all(is.finite(value)), all(value >= 0 & value <= 1))
  prediction_calls <<- prediction_calls+1L
  value
}
run <- function(x, cap, rng_seed=NULL) kernelshap(
  object=NULL, X=x, bg_X=bg, pred_fun=predict_deterministic,
  feature_names=selected, bg_w=NULL, bg_n=nrow(bg), exact=FALSE,
  hybrid_degree=deg, m=m, tol=0.005, max_iter=as.integer(cap),
  parallel=FALSE, verbose=FALSE, seed=rng_seed)
bytes <- function(x) writeBin(as.double(x),raw(),size=8L,endian='little')
num_equal <- function(a,b) identical(dim(a),dim(b)) && identical(bytes(a),bytes(b))
check_row <- function(batch,i,row) {
  checks <- c(
    S=all(vapply(names_out,function(n)num_equal(batch$S[[n]][i,,drop=FALSE],row$S[[n]]),logical(1))),
    SE=all(vapply(names_out,function(n)num_equal(batch$SE[[n]][i,,drop=FALSE],row$SE[[n]]),logical(1))),
    baseline=num_equal(batch$baseline,row$baseline),
    predictions=num_equal(batch$predictions[i,,drop=FALSE],row$predictions),
    n_iter=identical(batch$n_iter[[i]],row$n_iter[[1L]]),
    converged=identical(batch$converged[[i]],row$converged[[1L]]))
  stopifnot(all(checks)); checks
}
state_pin <- function(state) {
  # Exact states remain in the isolated RDS evidence; no hash is used to compare them.
  list(length=length(state), first=state[[1L]])
}

suppressPackageStartupMessages(library(digest))
source_file <- file.path(outdir, 'f5_shap.snapshot.R')
env <- new.env(parent=globalenv())
sys.source(source_file, envir=env)
need <- function(condition, message) if (!isTRUE(condition)) stop(message, call.=FALSE)
ids <- paste0('SYNTHETIC-P', seq_len(nrow(X)))
model_sha <- paste(rep('a',64L),collapse='')
legacy_spec <- charToRaw('{"scope":"UNFITTED_SYNTHETIC","max_iter":500}')
new_spec <- charToRaw('{"scope":"UNFITTED_SYNTHETIC","max_iter":2000,"rng_policy":"ORIGINAL_500_PATIENT_START"}')
writeBin(legacy_spec,file.path(outdir,'legacy-spec.json'))
start <- proc.time()[['elapsed']]
full <- run(X,500L,seed)
need(all(full$converged), 'SYNTHETIC_LEGACY_REQUIRES_ALL_CONVERGED')
full_after <- .Random.seed
saveRDS(list(spec=legacy_spec,result=full),file.path(outdir,'legacy.rds'))
recovery <- list(spec_path=file.path(outdir,'legacy-spec.json'),
  spec_sha256=digest(file.path(outdir,'legacy-spec.json'),algo='sha256',file=TRUE,serialize=FALSE),
  raw_path=file.path(outdir,'legacy.rds'),
  raw_sha256=digest(file.path(outdir,'legacy.rds'),algo='sha256',file=TRUE,serialize=FALSE))
set.seed(seed)
expected <- predict_deterministic(NULL,X)
sample_step <- getFromNamespace('input_sampling','kernelshap')
advance <- function(before,count) {
  assign('.Random.seed',before,envir=.GlobalEnv)
  for (j in seq_len(count)) sample_step(p=p,m=m,deg=deg,feature_names=selected)
  .Random.seed
}
part <- function(value,i) {
  ans <- list(S=lapply(value$S,function(x)x[i,,drop=FALSE]),baseline=value$baseline,
    predictions=value$predictions[i,,drop=FALSE],algorithm='kernelshap',
    SE=lapply(value$SE,function(x)x[i,,drop=FALSE]),n_iter=value$n_iter[i],
    converged=value$converged[i])
  class(ans)<-'kernelshap'; ans
}
whole_equal <- function(a,b) {
  checks <- c(S=all(vapply(names_out,function(n)num_equal(a$S[[n]],b$S[[n]]),logical(1))),
    SE=all(vapply(names_out,function(n)num_equal(a$SE[[n]],b$SE[[n]]),logical(1))),
    baseline=num_equal(a$baseline,b$baseline), predictions=num_equal(a$predictions,b$predictions),
    n_iter=identical(a$n_iter,b$n_iter),converged=identical(a$converged,b$converged))
  need(all(checks),'NUMERICAL_BYTES_DIFFER'); as.list(checks)
}
mkroot <- function(name) {target<-tempfile(pattern=paste0(name,'-'),tmpdir=outdir);dir.create(target);target}
patient_call <- function(root, rec=recovery, leaf, spec=new_spec, pilot=NULL) {
  env$padml_shap_patients(run=leaf,data=X,ids=ids,selected=selected,seed=seed,exact=FALSE,
    degree=deg,need=need,root=root,spec=spec,recovery=rec,pilot=pilot,
    family='XGBOOST_COX',imputation=1L,model_sha256=model_sha,expected=expected)
}
results <- list()
case <- function(name, scope, fn) {
  value <- tryCatch(list(pass=TRUE,detail=fn()),error=function(e) list(pass=FALSE,error=conditionMessage(e)))
  value$scope<-scope;results[[name]]<<-value
  cat(name,if(value$pass)'PASS'else'FAIL',if(!value$pass)value$error else '', '\n')
}
error_is <- function(expr, expected_error) {
  value<-tryCatch({force(expr);'NO_ERROR'},error=function(e)conditionMessage(e))
  need(identical(value,expected_error),paste('EXPECTED',expected_error,'GOT',value));value
}
blocked_leaf <- function(...)stop('UNEXPECTED_PREDICTION',call.=FALSE)
legacy_root <- mkroot('legacy-all-valid')
case('real_legacy_all_rows_and_resume','REAL kernelshap 0.9.1 full max500 return; no recompute during import',function(){
  calls<-prediction_calls
  a<-patient_call(legacy_root,leaf=blocked_leaf)
  b<-patient_call(legacy_root,leaf=blocked_leaf)
  need(identical(calls,prediction_calls),'LEGACY_CALLED_PREDICTOR')
  need(all(vapply(a$patient_execution$rows,function(r)r$producer$max_iter==500L,logical(1))), 'PRODUCER_NOT_LEGACY')
  list(first=whole_equal(full,a$result),resume=whole_equal(full,b$result),prediction_calls=0L)
})
case('real_fresh_rows_and_resume','REAL kernelshap 0.9.1 max2000; all rows happen to converge below500',function(){
  calls<-0L
  leaf<-function(value){calls<<-calls+1L;run(value,2000L,NULL)}
  root<-mkroot('fresh-valid')
  a<-patient_call(root,rec=NULL,leaf=leaf)
  b<-patient_call(root,rec=NULL,leaf=blocked_leaf)
  need(calls==nrow(X),'WRONG_NATIVE_ROW_COUNT')
  need(identical(.Random.seed,full_after),'FRESH_SHADOW_DRIFT')
  list(first=whole_equal(full,a$result),resume=whole_equal(full,b$result),native_calls=calls,
       rng_policy=a$patient_execution$rng_policy)
})
case('mock_interruption_preserves_saved_patient','MOCK leaf returns real numerical row; second-row interruption is injected',function(){
  root<-mkroot('interrupted'); seen<-integer(nrow(X));interrupt<-TRUE
  leaf<-function(value){i<-as.integer(rownames(value));seen[[i]]<<-seen[[i]]+1L
    if(interrupt && i==2L)stop('INJECTED_INTERRUPTION',call.=FALSE)
    part(full,i)}
  error_is(patient_call(root,rec=NULL,leaf=leaf),'INJECTED_INTERRUPTION')
  first_path<-file.path(root,'patients','P00001.rds')
  first_sha<-digest(first_path,algo='sha256',file=TRUE,serialize=FALSE)
  need(file.exists(first_path) && !file.exists(file.path(root,'patients','P00002.rds')),'CHECKPOINT_BOUNDARY_INVALID')
  interrupt<-FALSE
  a<-patient_call(root,rec=NULL,leaf=leaf)
  need(seen[[1L]]==1L && seen[[2L]]==2L && all(seen[-c(1L,2L)]==1L),'EXISTING_ROW_RECOMPUTED')
  need(identical(first_sha,digest(first_path,algo='sha256',file=TRUE,serialize=FALSE)),'CHECKPOINT_REWRITTEN')
  list(result=whole_equal(full,a$result),leaf_calls_by_row=as.list(seen),first_checkpoint_unchanged=TRUE)
})
case('mock_legacy_mixed_extension_preserves_original_anchors','MOCK old failed row/600-iteration extended row; real input_sampling replay, no claim of actual convergence',function(){
  old<-full; old$n_iter[[2L]]<-500L;old$converged[[2L]]<-FALSE
  old$SE<-lapply(old$SE,function(x){x[2L,]<-1;x})
  file<-file.path(outdir,'legacy-mixed-mock.rds');saveRDS(list(spec=legacy_spec,result=old),file)
  rec<-recovery;rec$raw_path<-file;rec$raw_sha256<-digest(file,algo='sha256',file=TRUE,serialize=FALSE)
  root<-mkroot('mixed-mock');calls<-0L;actual_before<-actual_after<-NULL
  leaf<-function(value){i<-as.integer(rownames(value));need(i==2L,'LEGACY_VALID_ROW_RECOMPUTED')
    calls<<-calls+1L;actual_before<<-.Random.seed
    actual_after<<-advance(actual_before,600L)
    out<-part(full,i);out$n_iter<-600L;out}
  a<-patient_call(root,rec=rec,leaf=leaf)
  b<-patient_call(root,rec=rec,leaf=blocked_leaf)
  first<-readRDS(file.path(root,'patients','P00001.rds'))
  second<-readRDS(file.path(root,'patients','P00002.rds'))
  third<-readRDS(file.path(root,'patients','P00003.rds'))
  correct_third<-advance(second$rng_before,500L)
  need(calls==1L && identical(second$rng_before,actual_before),'WRONG_EXTENDED_ROW')
  need(identical(third$rng_before,correct_third) && !identical(third$rng_before,actual_after),'EXTENSION_MOVED_ORIGINAL_ANCHOR')
  need(first$producer$max_iter==500L && second$producer$max_iter==2000L && third$producer$max_iter==500L,'MIXED_PRODUCER_INVALID')
  list(extended_leaf_calls=calls,extended_n_iter=600L,shadow_n_iter=500L,
    following_original_anchor_preserved=TRUE,resume=whole_equal(a$result,b$result))
})
case('mock_budget_exhaustion_component_resume_zero_recompute','MOCK first patient returns n_iter2000/convergedFALSE; actual component guards/raw/checkpoints',function(){
  root<-mkroot('budget-exhausted');calls<-0L
  env$kernelshap<-function(object,X,bg_X,pred_fun,feature_names,bg_w,bg_n,exact,hybrid_degree,m,tol,max_iter,parallel,verbose,seed){
    calls<<-calls+1L;i<-as.integer(rownames(X));out<-part(full,i)
    if(i==1L){out$n_iter<-2000L;out$converged<-FALSE;out$SE<-lapply(out$SE,function(x){x[,]<-1;x})}
    out}
  on.exit(rm('kernelshap',envir=env),add=TRUE)
  component<-function()env$padml_kernelshap_component(family='XGBOOST_COX',imputation=1L,
    model_sha256=model_sha,selected=selected,patient_ids=ids,parent_data=X,
    predict_survival=function(value)predict_deterministic(NULL,value),seed=seed,need=need,
    diagnostic_root=root,spec_binding=new_spec)
  error_is(component(),'F5_SHAP_BUDGET_EXHAUSTED')
  first_calls<-calls
  need(file.exists(file.path(root,'kernelshap-return.rds')),'RAW_NOT_PRESERVED')
  error_is(component(),'F5_SHAP_BUDGET_EXHAUSTED')
  need(calls==first_calls && calls==nrow(X),'EXHAUSTED_RETURN_RECOMPUTED')
  list(first_leaf_calls=first_calls,resume_leaf_calls=0L,status='BUDGET_EXHAUSTED')
})
case('wrong_spec_raw_and_rng_rejected','Direct patient reader negative cases; no native calls',function(){
  wrong_spec<-charToRaw('{"scope":"DIFFERENT_UNFITTED_SPEC"}')
  e1<-error_is(patient_call(legacy_root,leaf=blocked_leaf,spec=wrong_spec),'F5_SHAP_PATIENT_BINDING_INVALID')
  bad_rec<-recovery;bad_rec$raw_sha256<-paste(rep('0',64L),collapse='')
  e2<-error_is(patient_call(legacy_root,rec=bad_rec,leaf=blocked_leaf),'F5_SHAP_RAW_BINDING_INVALID')
  path<-file.path(legacy_root,'patients','P00001.rds'); original<-readRDS(path)
  changed<-original;changed$rng_before[[2L]]<-changed$rng_before[[2L]]+1L;saveRDS(changed,path)
  e3<-error_is(patient_call(legacy_root,leaf=blocked_leaf),'F5_SHAP_PATIENT_BINDING_INVALID')
  saveRDS(original,path)
  changed<-original;changed$producer$source_sha256<-paste(rep('0',64L),collapse='');saveRDS(changed,path)
  e4<-error_is(patient_call(legacy_root,leaf=blocked_leaf),'F5_SHAP_PATIENT_BINDING_INVALID')
  saveRDS(original,path)
  list(wrong_spec=e1,wrong_raw=e2,wrong_rng=e3,wrong_producer=e4)
})
case('malformed_native_return_rejected_before_projection','MOCK wrong native class/algorithm; original diagnostic must reject before any projection',function(){
  leaf<-function(value){i<-as.integer(rownames(value));out<-part(full,i)
    out$algorithm<-'WRONG_NATIVE_ALGORITHM';class(out)<-'WRONG_NATIVE_CLASS';out}
  error_is(patient_call(mkroot('malformed-native'),rec=NULL,leaf=leaf),'F5_SHAP_KERNEL_RESULT_INVALID')
})
report<-list(scope='ISOLATED SYNTHETIC ENGINEERING ONLY; no clinical inputs/fit/remote/environment installation; native and mocked cases explicitly separated',
  source=list(path=source_file,sha256=digest(source_file,algo='sha256',file=TRUE,serialize=FALSE)),
  versions=list(R=as.character(getRversion()),kernelshap=as.character(packageVersion('kernelshap')),
    kernelshap_path=find.package('kernelshap'),platform=R.version$platform),
  definition='Unified ORIGINAL_500_PATIENT_START for both legacy and fresh rows; not a normal full2000 batch',
  fixture=list(p=p,outputs=as.list(names_out),background_rows=nrow(bg),patients=nrow(X),seed=seed,
    native_full500_n_iter=as.list(full$n_iter),native_full500_converged=as.list(full$converged)),
  cases=results,elapsed_seconds=proc.time()[['elapsed']]-start,
  all_passed=all(vapply(results,function(x)x$pass,logical(1))))
writeLines(toJSON(report,auto_unbox=TRUE,pretty=TRUE,digits=17),file.path(outdir,'result.json'))
cat(toJSON(report,auto_unbox=TRUE,pretty=TRUE,digits=17),'\n')
quit(status=if(report$all_passed)0L else 1L)
