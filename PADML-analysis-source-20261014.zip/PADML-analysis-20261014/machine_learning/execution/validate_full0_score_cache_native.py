"""Frozen repair consumes the real H0 request's original producer binding; zero fits."""
from contextlib import ExitStack
import copy
import hashlib
import json
import os
from pathlib import Path
import sys
import time
from unittest.mock import patch

root=Path("/root/autodl-tmp/PADML_V22/f45-rebuild-20260925")
sys.path.insert(0,str(root))
import deploy_full0_score_cache as helper
helper.require_idle(root)
members=helper.release_members(root/helper.NEW_NAME,helper.NEW_SHA)
stage=root/"engineering-full0-score-cache-20260926"
compiled=stage/"compiled"
compiled.mkdir(parents=True)
for name,raw in members.items():
    p=compiled/name
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_bytes(raw)
sys.path.insert(0,str(compiled/"source"))
os.environ["PADML_F45_RUN_PATH"]=str(compiled/"run.json")
from padml import run as r, f4, f5, nested_loco as n
from padml.bundle import canonical_json_bytes as encode,sha256_file
def locate(value):
    value=str(value)
    for prefix in ("cache-predecessor/","final-predecessor/","score-predecessor/",
                   "reuse-predecessor/","unit-predecessor/","resource-baseline/","resource-executor/"):
        start=str(root)+"/"+prefix
        if value.startswith(start):return compiled/(prefix+value[len(start):])
    return Path(value)
original_loader=f4.load_f45_source_bundle
def located(path):return original_loader(locate(path))
source=root/"units/FULL0-H06/score/request/full-score-input.json"
stat=source.stat()
before={"sha256":sha256_file(source),"size":stat.st_size,"inode":stat.st_ino,"mtime_ns":stat.st_mtime_ns}
request=json.loads(source.read_bytes())
old=request["development"]
with ExitStack() as stack:
    stack.enter_context(patch.object(r,"Path",locate))
    stack.enter_context(patch.object(f4,"load_f45_source_bundle",located))
    run=r.load_f45_run(compiled/"run.json")
    keys={*f5._final_search_sources(),*("padml/"+name for name in (
        "nested_loco.py","runtime.py","f2_validation.py","kernels/f5_final_refit.R",
        "kernels/f5_design.R","kernels/f4_learning_selector.R","kernels/f4_learning_recipe.R"))}
    current_members=f4._f45_source_member_sha256()
    program=n._sha({k:current_members[k] for k in keys})
    context=n._sealed({**{k:v for k,v in old["training_context"].items() if k!="identity_sha256"},
        "modeling_program_sha256":program,"preprocessing_program_sha256":program})
    current=n._sealed({**{k:v for k,v in old.items() if k!="identity_sha256"},"training_context":context})
    assert program!=old["training_context"]["modeling_program_sha256"]
    accepted=f5._full_score_resume_development(current,source)
    assert accepted==old
    helper.require_idle(root)
stat=source.stat()
after={"sha256":sha256_file(source),"size":stat.st_size,"inode":stat.st_ino,"mtime_ns":stat.st_mtime_ns}
assert before==after
result={"status":"PASS","at_utc":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),
    "scope":"REAL_EXISTING_REQUEST_PRODUCER_BINDING_ONLY_NOT_FULL_INPUT_RECOMPILE",
    "package_sha256":helper.NEW_SHA,"source_identity":run["source_identity"],"run_identity":run["identity"],
    "request_identity":request["identity_sha256"],
    "original_program_identity":old["training_context"]["modeling_program_sha256"],
    "new_executor_program_identity":program,"request_before":before,"request_after":after,
    "new_model_fits":0,"new_mice":0,"native_model_replay":0,"production_source_changed":False}
(stage/"validation.json").write_bytes(encode(result))
print(json.dumps(result),flush=True)
