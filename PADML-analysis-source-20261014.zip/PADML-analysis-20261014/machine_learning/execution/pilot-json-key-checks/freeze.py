"""Reseal only the pilot adapter; immutable scientific source/run are reused."""
import json, os, subprocess, sys, zipfile
from pathlib import Path
from padml.bundle import canonical_json_bytes as enc, sha256_bytes as sha, sha256_file, write_deterministic_zip
from padml import f4

repo = Path(__file__).resolve().parents[2]
checks = Path(__file__).resolve().parent
previous = repo / 'execution/release-patient-recovery-readback/PADML_F45_REBUILD_20260929_PATIENT_RECOVERY_READBACK.zip'
assert sha256_file(previous) == '9eaf5ab4e2d4ff11911735e12589bc2bff6ed3eb76520041b39a5f4e59c39efc'
verified = json.loads((checks / 'result.json').read_bytes())
assert verified['before_error'] == 'JSON_OBJECT_KEY_NOT_STRING' and verified['after_passed'] == 1
pilot = 'execution/patient-recovery-readback-checks/pilot.py'
assert sha256_file(repo / pilot) == verified['fixed_pilot_sha256']
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
for name in (*f4.F45_SOURCE_MEMBERS, pilot, 'tests/test_f45_final_full0_reuse.py'):
    assert subprocess.check_output(['git','show',head+':'+name],cwd=repo) == (repo/name).read_bytes()
with zipfile.ZipFile(previous) as archive:
    members = {name: archive.read(name) for name in archive.namelist() if name != 'release.json'}
    old_release = json.loads(archive.read('release.json'))
    for name, value in members.items():
        assert sha(value) == old_release['members'][name]['sha256']
old = json.loads(members['compile-summary.json'])
assert sha(enc(f4._f45_source_member_sha256())) == old['source_identity']
changed = 'patient-recovery-readback-checks/pilot.py'
assert sha(members[changed]) == verified['old_pilot_sha256']
members[changed] = (repo / pilot).read_bytes()
out = repo / 'execution/release-pilot-json-key'
out.mkdir()
evidence = {p.name:p for p in checks.iterdir() if p.is_file() and p.suffix in {'.py','.json','.log','.xml'}}
evidence['tests/test_f45_final_full0_reuse.py'] = repo / 'tests/test_f45_final_full0_reuse.py'
evidence['pilot.py'] = repo / pilot
write_deterministic_zip(out / 'pilot-json-key-checks.zip', evidence)
members['pilot-json-key-checks.zip'] = (out / 'pilot-json-key-checks.zip').read_bytes()
members['HISTORICAL_PATIENT_RECOVERY_READBACK_COMPILE.md'] = members['COMPILE_REPORT.md']
report = (f'Frozen Git: {head}. Science source: {old["source_identity"]}. Run: {old["run_identity"]}.\n\n'
    + (repo / 'execution/PILOT_JSON_KEY_REPAIR.md').read_text()).encode()
for name in ('README.md','COMPILE_REPORT.md','EXECUTION_HANDOFF.md'):
    members[name] = report
summary = {'head':head, 'scientific_source_head':old['head'], 'source_identity':old['source_identity'],
    'run_identity':old['run_identity'], 'source':old['source'], 'source_member_count':51,'predecessors':20,'units':56,
    'changed_source_members':[], 'changed_execution_entry':changed,
    'pilot_sha256':sha(members[changed]), 'pilot_size_bytes':len(members[changed]),
    'previous_package_sha256':sha256_file(previous), 'same_source_zip_and_run_json':True,
    'pilot_regression_passed':1,'compiler_clinical_calls':0,'compiler_remote_operations':0,
    'clinical_completion_claimed':False}
members['compile-summary.json'] = enc(summary)
with zipfile.ZipFile(previous) as archive:
    for name in archive.namelist():
        if name not in {changed,'release.json','compile-summary.json','README.md','COMPILE_REPORT.md','EXECUTION_HANDOFF.md'}:
            assert members[name] == archive.read(name)
release = {'kind':'PADML_F45_PILOT_JSON_KEY_REPAIR','head':head,
    'source_identity':old['source_identity'],'run_identity':old['run_identity'],
    'members':{name:{'sha256':sha(value),'size_bytes':len(value)} for name,value in members.items()}}
members['release.json'] = enc(release)
target = out / 'PADML_F45_REBUILD_20260929_PILOT_JSON_KEY.zip'
write_deterministic_zip(target,members)
reader = repo / 'execution/patient-recovery-readback-checks/frozen-reader.py'
completed = subprocess.run([sys.executable,'-B',str(reader),str(target)],cwd=repo,check=True,capture_output=True,text=True,
    env={**os.environ,'PYTHONPATH':str(repo),'PYTHONDONTWRITEBYTECODE':'1'})
(out/'frozen-reader.log').write_text(completed.stdout)
summary.update(package=str(target),sha256=sha256_file(target),size_bytes=target.stat().st_size)
(out/'compile-summary.json').write_bytes(enc(summary))
print(json.dumps(summary))
