"""Same-run pinned executor admission; no clinical calculations or deployment."""
import ast
import copy
import json
import os
import tempfile
import zipfile
from pathlib import Path
from unittest.mock import patch

from padml import f4, run as r
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, sha256_file, strict_json_bytes

base = Path(__file__).resolve().parent
release = base / "release-score-reuse/PADML_F45_REBUILD_20260926_SCORE_REUSE.zip"
assert sha256_file(release) == "8a7fa4d65acb987638c7aa227cf2ab4e9615ebf42da2cc8354fc011fabdae40a"
checks = {}
with tempfile.TemporaryDirectory(prefix="padml-reuse-source-") as tmp:
    root = Path(tmp).resolve()
    with zipfile.ZipFile(release) as archive:
        for name in ("run.json", "source.zip", "resource-baseline/run.json", "resource-baseline/source.zip",
                     "unit-predecessor/run.json", "unit-predecessor/source.zip",
                     "reuse-predecessor/run.json", "reuse-predecessor/source.zip",
                     "score-predecessor/run.json", "score-predecessor/source.zip"):
            path = root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(archive.read(name))
    original = strict_json_bytes((root / "run.json").read_bytes())
    resource_release = base / "release-stage-resources/PADML_F45_REBUILD_20260925_STAGE_RESOURCES.zip"
    assert sha256_file(resource_release) == "60eaa1c0f8da13c7295e80a219c4dcd7e0c82291fdcd93f27c75884f299c5ffa"
    with zipfile.ZipFile(resource_release) as archive:
        for name in ("run.json", "source.zip"):
            path = root / "resource-executor" / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(archive.read(name))
    remote = original["run_root"]
    def local_path(value):
        value = str(value)
        return Path(str(root) + value[len(remote):]) if value.startswith(remote + "/") else Path(value)
    value = {**original, "source_identity": sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256())),
        "source_bundle_sha256": "d" * 64,  # Current executor boundary only; not a compiled-package claim.
        "unit_predecessor": {"run_path": str(root / "run.json"), "run_sha256": sha256_file(root / "run.json"),
            "source_path": str(root / "source.zip"), "source_sha256": sha256_file(root / "source.zip")},
        "unit_source_predecessors": [{
            "run_path": str(root / "resource-executor/run.json"),
            "run_sha256": sha256_file(root / "resource-executor/run.json"),
            "source_path": str(root / "resource-executor/source.zip"),
            "source_sha256": sha256_file(root / "resource-executor/source.zip")}]}
    value["identity"] = sha256_bytes(canonical_json_bytes({k: v for k, v in value.items() if k != "identity"}))
    with patch.object(r, "Path", local_path), patch.object(f4, "Path", local_path):
        revisions = r.f45_unit_predecessors(value)
        assert [row["identity"] for row in revisions] == [original["identity"],
            "66c67b37bf25a365e95a8748927bea4782128f892d204735fef4c5cacd2c3e24",
            "edf9df2afa86dc8e2e38516bd94f821feba51485f26c590946f0ef3ab6994338",
            "2d7929461468f78347133b036f93fd1ea57c187777b74801b47015a8dcf78419",
            "096b856d4f3aedb609e7e15b8898144ec565f037db7ddf3e79e3957a0e64f723"]
        baseline = r.validate_f45_resource_revision(value)
        assert sha256_bytes(canonical_json_bytes(baseline)) == "25190343ea52b20014b6cb38eae518b4fe77621e02c8eb24a5b3f66fc5047c50"
        checks["original_reuse_aar_primary_and_resource_receipts_admitted"] = [row["identity"] for row in revisions]
        checks["original_numerical_baseline_admitted"] = True
        checks["resource_executor_source_admitted"] = revisions[-1]["source_identity"]
        (root / "current-run.json").write_bytes(canonical_json_bytes(value))
        with patch.dict(os.environ, {"PADML_F45_RUN_PATH": str(root / "current-run.json")}):
            actual = f4._f45_same_run_source(revisions[-1]["source_identity"])
        assert sha256_bytes(canonical_json_bytes(actual)) == revisions[-1]["source_identity"]
        checks["actual_same_run_source_reader_retains_resource_producer"] = True
        for name, mutate in {
            "source_pin": lambda row: row["unit_predecessor"].update(source_sha256="f" * 64),
            "science": lambda row: row["budgets"].update(retained_bytes_per_view=1),
        }.items():
            damaged = copy.deepcopy(value)
            mutate(damaged)
            try:
                r.f45_unit_predecessors(damaged)
            except ContractError as exc:
                checks[name + "_rejected"] = str(exc)
            else:
                raise AssertionError(name)
        real_read = Path.read_bytes
        for module, before, after in (
            ("padml/f4.py", 'seed = _f4_model_seed(family, coordinates)', 'seed = 0'),
            ("padml/f5.py", 'body["aar_branch"] = spec["current_q"]["aar_branch"]', 'body["aar_branch"] = "WRONG_BRANCH"'),
            ("padml/f5_sensitivity.py", 'engine_threads=1,', 'engine_threads=2,'),
        ):
            current = Path(f4.__file__).parents[1] / module
            raw = real_read(current)
            assert before.encode() in raw
            changed = raw.replace(before.encode(), after.encode(), 1)
            with patch.object(Path, "read_bytes", lambda path, c=current, b=changed: b if path == c else real_read(path)):
                for label, validator in (("predecessor", r.f45_unit_predecessors), ("baseline", r.validate_f45_resource_revision)):
                    try:
                        validator(value)
                    except ContractError as exc:
                        checks[module + ":" + label + ":mutation_rejected"] = str(exc)
                    else:
                        raise AssertionError((module, label))
        with patch.object(r, "f45_unit_predecessor", lambda _: value):
            try:
                r.f45_unit_predecessors(value)
            except ContractError as exc:
                checks["cycle_rejected"] = str(exc)
            else:
                raise AssertionError("cycle")
        from padml import f5
        with patch.dict(os.environ, {"PADML_F45_RUN_PATH": str(root / "current-run.json")}):
            executors, sources = f5._f45_score_reuse_authorities()
        assert set(executors) == {value["identity"], *(row["identity"] for row in revisions)}
        assert all(sha256_bytes(canonical_json_bytes(members)) == identity for identity, members in sources.items())
        checks["actual_score_executors_and_input_producers_separately_qualified"] = sorted(sources)
        for name, before, after in (
            ("padml/f5.py", '"registered_model_seed": task["registered_model_seed"], "model_seed": task["model_seed"]',
             '"registered_model_seed": 0, "model_seed": task["model_seed"]'),
            ("padml/nested_loco.py", '"new_model_fit_count": 300 - reused_count',
             '"new_model_fit_count": 299 - reused_count'),
        ):
            current = base.parent / name
            raw = current.read_bytes()
            function = "_f45_score_component_numerics" if name == "padml/f5.py" else "_score_fresh_family"
            node, = [n for n in ast.parse(raw).body if isinstance(n, ast.FunctionDef) and n.name == function]
            lines = raw.splitlines(keepends=True)
            body = b"".join(lines[node.lineno - 1:node.end_lineno])
            assert body.count(before.encode()) == 1
            changed = b"".join(lines[:node.lineno - 1]) + body.replace(before.encode(), after.encode(), 1) + b"".join(lines[node.end_lineno:])
            with patch.object(Path, "read_bytes", lambda path, c=current, b=changed: b if path == c else real_read(path)):
                for label, validator in (("predecessor", r.f45_unit_predecessors), ("baseline", r.validate_f45_resource_revision)):
                    try:
                        validator(value)
                    except ContractError as exc:
                        checks[name + ":" + label + ":new_score_mutation_rejected"] = str(exc)
                    else:
                        raise AssertionError((name, label))
        # Exact C/E changes are reviewed individually; arbitrary changes inside
        # their new bodies are rejected by both original source authorities.
        for module, function, before, after in (
            ("padml/f2_kernel.py", "_engine_registered_partitions", 'row.get("kind") == "OUTER"', 'True'),
            ("padml/f5_sensitivity.py", "_a12_elastic_reuse", 'prior["source"]["branch"] == branch', 'True'),
            ("padml/f5.py", "_execute_paired_diagnostic", '"physical_final_models": 20 -', '"physical_final_models": 19 -'),
            ("padml/f5_application.py", "predict_completed_application", 'producer_task', 'task'),
            ("padml/f5_sensitivity.py", "_load_a12_outer_archive", '_f45_score_reuse_authorities()[0].values()', '_f45_score_reuse_authorities()[1]'),
        ):
            current = base.parent / module
            raw = real_read(current)
            node, = [n for n in ast.parse(raw).body if isinstance(n, ast.FunctionDef) and n.name == function]
            lines = raw.splitlines(keepends=True)
            body = b"".join(lines[node.lineno - 1:node.end_lineno])
            assert before.encode() in body, (module, function)
            altered = body.replace(before.encode(), after.encode(), 1)
            changed = b"".join(lines[:node.lineno - 1]) + altered + b"".join(lines[node.end_lineno:])
            with patch.object(Path, "read_bytes", lambda path, c=current, b=changed: b if path == c else real_read(path)):
                for label, validator in (("predecessor", r.f45_unit_predecessors), ("baseline", r.validate_f45_resource_revision)):
                    try:
                        validator(value)
                    except ContractError as exc:
                        checks[module + ":" + function + ":" + label + ":mutation_rejected"] = str(exc)
                    else:
                        raise AssertionError((module, function, label))
        current = base.parent / "NESTED_LOCO_PROTOCOL.md"
        changed = real_read(current) + b"\nUNAUTHORIZED_PROTOCOL_CHANGE\n"
        with patch.object(Path, "read_bytes", lambda path: changed if path == current else real_read(path)):
            for label, validator in (("predecessor", r.f45_unit_predecessors), ("baseline", r.validate_f45_resource_revision)):
                try:
                    validator(value)
                except ContractError as exc:
                    checks["protocol:" + label + ":unknown_text_rejected"] = str(exc)
                else:
                    raise AssertionError(("protocol", label))
    assert (root / "run.json").read_bytes() == canonical_json_bytes(original)
    checks["original_manifest_unchanged"] = True
result = {"checks": checks, "clinical_calls": 0, "production_mutations": 0,
    "current_package_compiled": False, "source_identity": value["source_identity"]}
(base / "final-reuse-source-validation.json").write_bytes(canonical_json_bytes(result))
print(json.dumps(result))
