"""Original source qualification for the finite H36 Q member capacity repair."""
import ast, copy, json, os, tempfile, zipfile
from pathlib import Path
from unittest.mock import patch
from padml import f4, f5, run
from padml.bundle import ContractError, canonical_json_bytes as enc, sha256_bytes as sha, sha256_file

repo = Path(__file__).resolve().parents[2]
checks = Path(__file__).resolve().parent
previous = repo / 'execution/release-equivalent-hotpaths/PADML_F45_REBUILD_20260928_EQUIVALENT_HOTPATHS.zip'
assert sha256_file(previous) == '2a9f2b281ca79a1d522d67a04ac14cff35ee0a3271217e3898f2678c6587b149'
current_members = f4._f45_source_member_sha256()
results = {}
with tempfile.TemporaryDirectory(prefix='q-capacity-source-') as temporary:
    base = Path(temporary).resolve()
    with zipfile.ZipFile(previous) as archive:
        for name in archive.namelist():
            if name in ('run.json', 'source.zip') or name.endswith(('/run.json', '/source.zip')):
                target = base / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.read(name))
    with zipfile.ZipFile(base / 'source.zip') as source:
        old_members = {name: sha(source.read(name)) for name in f4.F45_SOURCE_MEMBERS}
    assert {name for name in current_members if current_members[name] != old_members[name]} == {
        'padml/f4_compact.py', 'padml/run.py'}
    original = json.loads((base / 'run.json').read_bytes())
    value = {**original, 'source_identity': sha(enc(current_members)), 'source_bundle_sha256': 'd'*64,
        'unit_predecessor': {'run_path': str(base / 'run.json'), 'run_sha256': sha256_file(base / 'run.json'),
            'source_path': str(base / 'source.zip'), 'source_sha256': sha256_file(base / 'source.zip')}}
    value['identity'] = sha(enc({k: v for k, v in value.items() if k != 'identity'}))
    (base / 'current-run.json').write_bytes(enc(value))
    remote = original['run_root']
    def mapped(location):
        location = str(location)
        return Path(str(base) + location[len(remote):]) if location.startswith(remote + '/') else Path(location)
    with patch.object(run, 'Path', mapped), patch.object(f4, 'Path', mapped):
        predecessors = run.f45_unit_predecessors(value)
        prior = json.loads((repo / 'execution/gbm-breslow-checks/qualification.json').read_bytes())
        assert [p['identity'] for p in predecessors] == [original['identity'], *prior['checks']['predecessors']]
        assert len(predecessors) == 17
        baseline = run.validate_f45_resource_revision(value)
        assert sha(enc(baseline)) == '25190343ea52b20014b6cb38eae518b4fe77621e02c8eb24a5b3f66fc5047c50'
        with patch.dict(os.environ, {'PADML_F45_RUN_PATH': str(base / 'current-run.json')}):
            with patch.object(run, 'f45_unit_predecessors', return_value=predecessors):
                executors, sources = f5._f45_score_reuse_authorities()
        h9_run = 'd5cba0b5837fb53f87f0e70e76099daefc0f7208a6393f394f36935d92b7feed'
        h9_source = '1198a8acdd36c129369a23078758c0f3e49d2ac1a609f87aeb51897ae3c13082'
        assert executors[h9_run] == h9_source and h9_source in sources
        results.update(predecessors=[p['identity'] for p in predecessors], h9_producer_run=h9_run,
            h9_producer_source=h9_source, original_fit_producer_baseline_qualified=True)
        current = repo / 'padml/f4_compact.py'
        raw, actual_read = current.read_bytes(), Path.read_bytes
        changes = {
            'unknown_capacity_change': (b'member_limit = 1300 * (11 + 8) + 3', b'member_limit = 999999'),
            'unknown_member_sha_bypass': (
                b'and member.stat().st_size == record["size_bytes"] and sha256_file(member) == record["sha256"],',
                b'and member.stat().st_size == record["size_bytes"],'),
        }
        for label, (before, after) in changes.items():
            assert raw.count(before) == 1
            altered = raw.replace(before, after, 1)
            with patch.object(Path, 'read_bytes', lambda path: altered if path == current else actual_read(path)):
                for name, validator in [('predecessor', run.f45_unit_predecessors),
                                        ('baseline', run.validate_f45_resource_revision)]:
                    try:
                        validator(value)
                    except ContractError as error:
                        results[name + '_' + label + '_rejected'] = str(error)
                    else:
                        raise AssertionError(name + ':' + label)
        damaged = copy.deepcopy(value)
        damaged['unit_predecessor']['source_sha256'] = 'f'*64
        try:
            run.f45_unit_predecessors(damaged)
        except ContractError as error:
            results['unknown_source_pin_rejected'] = str(error)
        else:
            raise AssertionError('unknown predecessor source')
    assert (base / 'run.json').read_bytes() == enc(original)
    assert value['science_decision'] == original['science_decision']
    results['all_other_scientific_and_runtime_sources_unchanged'] = True
record = {'source_identity': sha(enc(current_members)), 'checks': results,
    'clinical_calls': 0, 'remote_operations': 0}
(checks / 'qualification.json').write_bytes(enc(record))
print(json.dumps(record))
