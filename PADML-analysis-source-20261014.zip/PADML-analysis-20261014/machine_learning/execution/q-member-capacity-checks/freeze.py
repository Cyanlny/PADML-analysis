"""Freeze the bounded Q member repair through the existing source compiler."""
import ast, io, json, os, subprocess, sys, zipfile
from pathlib import Path
from padml import f4
from padml.bundle import canonical_json_bytes as enc, sha256_bytes as sha, sha256_file, write_deterministic_zip

assert sys.version_info[:2] == (3, 12)
repo = Path(__file__).resolve().parents[2]
base, checks = repo / 'execution', Path(__file__).resolve().parent
previous = base / 'release-equivalent-hotpaths/PADML_F45_REBUILD_20260928_EQUIVALENT_HOTPATHS.zip'
assert sha256_file(previous) == '2a9f2b281ca79a1d522d67a04ac14cff35ee0a3271217e3898f2678c6587b149'
pins = f4._f45_source_member_sha256()
identity = sha(enc(pins))
qualification = json.loads((checks / 'qualification.json').read_bytes())
tests = json.loads((checks / 'focused-tests.json').read_bytes())
assert qualification['source_identity'] == identity
assert len(qualification['checks']['predecessors']) == 17
assert tests['existing_cases_passed'] == 5 and tests['existing_exit_code'] == 0
assert tests['new_regression_cases_passed'] == 1 and tests['new_regression_exit_code'] == 0
assert tests['tested_compact_sha256'] == pins['padml/f4_compact.py']
assert tests['unchanged_f5_sha256'] == pins['padml/f5.py']
assert tests['test_sha256'] == sha256_file(repo / 'tests/test_q_batch_metadata_boundary.py')
function = next(n for n in ast.parse((repo / 'padml/f4_compact.py').read_bytes()).body
    if isinstance(n, ast.FunctionDef) and n.name == '_full_pipeline_q_numerical_members')
assert sha(ast.dump(function, include_attributes=False).encode()) == tests['tested_function_ast_sha256']
metadata = json.loads((checks / 'member-metadata-summary.json').read_bytes())
assert metadata['merged_transported_reference_count'] == 22102
assert metadata['merged_final_reference_count_if_published'] == 22103
assert metadata['native_tree_inventory']['regular_files'] < 40000
assert metadata['numbers_canonical_shape_bytes_without_newline'] + 1 < 16 * 1024**2
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--name-only', 'HEAD', '--', *f4.F45_SOURCE_MEMBERS], cwd=repo)
for name in f4.F45_SOURCE_MEMBERS:
    assert subprocess.check_output(['git', 'show', head + ':' + name], cwd=repo) == (repo / name).read_bytes()
with zipfile.ZipFile(previous) as archive:
    members = {name: archive.read(name) for name in archive.namelist() if name != 'release.json'}
    with zipfile.ZipFile(io.BytesIO(members['source.zip'])) as source:
        changed = [name for name in f4.F45_SOURCE_MEMBERS if source.read(name) != (repo / name).read_bytes()]
assert set(changed) == {'padml/f4_compact.py', 'padml/run.py'}
out = base / 'release-q-member-capacity'
out.mkdir()
compiled = f4.compile_f45_source_bundle(out / 'source.zip')
prefix = 'q-member-capacity-predecessor'
members[prefix + '/run.json'] = members['run.json']
members[prefix + '/source.zip'] = members['source.zip']
old = json.loads(members['run.json'])
members['source.zip'] = (out / 'source.zip').read_bytes()
members['source.compile.json'] = enc(compiled)
run = {**old, 'source_identity': identity, 'source_bundle_sha256': compiled['sha256'],
    'unit_predecessor': {'run_path': old['run_root'] + '/' + prefix + '/run.json',
        'run_sha256': sha(members[prefix + '/run.json']),
        'source_path': old['run_root'] + '/' + prefix + '/source.zip',
        'source_sha256': sha(members[prefix + '/source.zip'])}}
run['identity'] = sha(enc({k: v for k, v in run.items() if k != 'identity'}))
assert run['units'] == old['units'] and len(run['units']) == 56
assert run['science_decision'] == old['science_decision']
members['run.json'] = enc(run)
evidence = {p.name: p for p in checks.iterdir() if p.is_file() and p.suffix in {'.py', '.json', '.log'}}
evidence['tests/test_q_batch_metadata_boundary.py'] = repo / 'tests/test_q_batch_metadata_boundary.py'
evidence['tests/test_f45_q_branch.py'] = repo / 'tests/test_f45_q_branch.py'
write_deterministic_zip(out / 'q-member-capacity-checks.zip', evidence)
members['q-member-capacity-checks.zip'] = (out / 'q-member-capacity-checks.zip').read_bytes()
members['HISTORICAL_EQUIVALENT_HOTPATHS_COMPILE.md'] = members['COMPILE_REPORT.md']
report = (f'Frozen Git: {head}. Source: {identity}. Run: {run["identity"]}.\n\n'
    + (base / 'Q_MEMBER_CAPACITY_COMPILE.md').read_text()).encode()
members['README.md'] = members['COMPILE_REPORT.md'] = report
members['EXECUTION_HANDOFF.md'] = report
summary = {'head': head, 'source_identity': identity, 'run_identity': run['identity'], 'source': compiled,
    'changed_source_members': changed, 'source_member_count': len(f4.F45_SOURCE_MEMBERS),
    'units': len(run['units']), 'predecessors': 17, 'focused_cases': 6,
    'previous_package_sha256': sha256_file(previous), 'science_unchanged_from_previous_package': True,
    'qualification_sha256': sha256_file(checks / 'qualification.json'),
    'deployed': False, 'compiler_clinical_calls': 0, 'compiler_remote_operations': 0,
    'clinical_completion_claimed': False}
members['compile-summary.json'] = enc(summary)
with zipfile.ZipFile(previous) as archive:
    for name in archive.namelist():
        if name in {'science-decision.json', 'dependencies.json', 'AGENTS.md', 'NESTED_LOCO_PROTOCOL.md',
                    'shared/bootstrap.zip', 'shared/bootstrap-preparation.json', 'h36-shap500-checks.zip',
                    'aar-reader-admission-checks.zip', 'equivalent-hotpaths-checks.zip'} \
                or name.endswith(('/run.json', '/source.zip')):
            assert members[name] == archive.read(name)
release = {'kind': 'PADML_F45_Q_MEMBER_CAPACITY_RELEASE', 'head': head,
    'run_identity': run['identity'], 'source_identity': identity,
    'members': {name: {'sha256': sha(raw), 'size_bytes': len(raw)} for name, raw in members.items()}}
members['release.json'] = enc(release)
target = out / 'PADML_F45_REBUILD_20260929_Q_MEMBER_CAPACITY.zip'
write_deterministic_zip(target, members)
completed = subprocess.run([sys.executable, '-B', str(checks / 'frozen-reader.py'), str(target)],
    cwd=repo, check=True, capture_output=True, text=True,
    env={**os.environ, 'PYTHONPATH': str(repo), 'PYTHONDONTWRITEBYTECODE': '1'})
(out / 'frozen-reader.log').write_text(completed.stdout)
summary.update(package=str(target), sha256=sha256_file(target), size_bytes=target.stat().st_size)
(out / 'compile-summary.json').write_bytes(enc(summary))
print(json.dumps(summary))
