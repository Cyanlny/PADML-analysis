"""Freeze the Q first-batch and completed-readback cache boundary repair; no deployment or scientific execution."""
import ast, io, json, subprocess, sys, zipfile
from pathlib import Path
from padml.bundle import canonical_json_bytes as enc, sha256_bytes, sha256_file, write_deterministic_zip
from padml.f4 import compile_f45_source_bundle, _f45_source_member_sha256, F45_SOURCE_MEMBERS
assert sys.version_info[:2] == (3,12)
base=Path(__file__).resolve().parent; repo=base.parent
previous=base/'release-readback-unified/PADML_F45_REBUILD_20260927_READBACK_UNIFIED.zip'
assert sha256_file(previous)=='4a403c7a64437eedb104662e6308ab0a31677027ab41b1e207d7f0153c3ea7c7'
identity=sha256_bytes(enc(_f45_source_member_sha256()))
validation=json.loads((base/'aar-readback-admission-validation.json').read_bytes())
assert validation['source_identity']==identity and validation['checks']['original_numerical_baseline_unchanged']
assert len(validation['checks']['same_run_predecessors'])==12
log=base/'step-cache-shap-checks/q-readback-cache-boundary-312.log'
assert 'Ran 13 tests' in log.read_text() and log.read_text().rstrip().endswith('OK')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--',*F45_SOURCE_MEMBERS],cwd=repo)
for name in F45_SOURCE_MEMBERS:
 assert subprocess.check_output(['git','show',head+':'+name],cwd=repo)==(repo/name).read_bytes()
with zipfile.ZipFile(previous) as z:
 members={name:z.read(name) for name in z.namelist() if name!='release.json'}
 with zipfile.ZipFile(io.BytesIO(members['source.zip'])) as s:
  changed=[name for name in F45_SOURCE_MEMBERS if s.read(name)!=(repo/name).read_bytes()]
assert set(changed)=={'padml/f5_sensitivity.py','padml/run.py','padml/f5.py','padml/runtime.py'}
out=base/'release-q-readback-cache-boundary';out.mkdir(exist_ok=True)
compiled=compile_f45_source_bundle(out/'source.zip')
prefix='q-cache-predecessor'
members[prefix+'/run.json']=members['run.json']
members[prefix+'/source.zip']=members['source.zip']
old=json.loads(members['run.json'])
members['source.zip']=(out/'source.zip').read_bytes()
members['source.compile.json']=enc(compiled)
run={**old,'source_identity':identity,'source_bundle_sha256':compiled['sha256'],
 'unit_predecessor':{'run_path':old['run_root']+'/'+prefix+'/run.json',
  'run_sha256':sha256_bytes(members[prefix+'/run.json']),
  'source_path':old['run_root']+'/'+prefix+'/source.zip',
  'source_sha256':sha256_bytes(members[prefix+'/source.zip'])}}
run['identity']=sha256_bytes(enc({k:v for k,v in run.items() if k!='identity'}))
members['run.json']=enc(run)
proof=json.loads((base/'aar-readback-admission-surgical-proof.json').read_bytes())
assert proof['source_identity']==identity and proof['status']=='COMPILE_CHECKS_PASS'
evidence={name:base/name for name in ('aar-readback-admission-surgical-proof.json',
 'aar-readback-admission-validation.json','validate_aar_readback_admission.py',
 'compile_aar_readback_admission.py','AAR_READBACK_ADMISSION_REPAIR.md')}
for name,pin in proof['evidence'].items():
 path=base/'step-cache-shap-checks'/name
 assert sha256_file(path)==pin['sha256'] and path.stat().st_size==pin['size_bytes']
 evidence['checks/'+name]=path
write_deterministic_zip(out/'q-cache-boundary-checks.zip',evidence)
members['q-cache-boundary-checks.zip']=(out/'q-cache-boundary-checks.zip').read_bytes()
for name in ('AGENTS.md','NESTED_LOCO_PROTOCOL.md'):
 members[name]=(repo/name).read_bytes()
report=(f'Frozen Git: {head}. Source: {identity}. Run: {run["identity"]}.\n\n'
 +(base/'AAR_READBACK_ADMISSION_REPAIR.md').read_text()).encode()
members['README.md']=members['COMPILE_REPORT.md']=report
members['EXECUTION_HANDOFF.md']=(f"# Q and readback cache-boundary package\n\nGit: {head}\nSource: {identity}\nRun: {run['identity']}\n\n"
 "Execution owner: 01a0e04f-b009-71d3-af35-7ae22fe25f9a. User resumed all seven instances and future whole units at 2026-09-27 12:09 Asia/Shanghai. Preserve all accepted current-run coordinates and F1/F2; do not repeat historical deletion.\n\n"
 "Use the owner's current host map and existing atomic release procedure, with run.json applied last. Only switch an instance after its previous owner and all registered process groups have exited; UNKNOWN is not idle. H1 is draining its current TOTAL Q batch and H0 is awaiting its next original recoverable consumer boundary; the executing owner must recheck their actual process identities. Do not stop unrelated live units for this compiler handoff. Never access retired ports 14303 or 27869. Do not hot-edit any live source. No new execution task, dispatcher, acceptance layer or recovery ledger.\n\n"
 "Keep the existing sealed Python environment and exact whole-unit entry: python -m padml.worker f45 /root/autodl-tmp/PADML_V22/f45-rebuild-20260925/run.json UNIT_ID. Preserve its existing environment and launch wrapper; select UNIT_ID through the original 56-unit manifest/dependencies. Only the executing owner performs the original direct reader/cutover checks.\n\n"
 "source.zip and run.json are the new generation; q-cache-predecessor holds the immediately prior frozen generation. Carry all earlier pinned predecessor paths unchanged. The source/run original loaders and all twelve same-run predecessors are tested locally against exact package bytes; real Linux readback and resource observations belong to the execution owner. No production result, cleanup, remote cache release or deployment is claimed by compilation.\n").encode()
release={'kind':'PADML_F45_Q_READBACK_CACHE_BOUNDARY_RELEASE','head':head,'run_identity':run['identity'],
 'source_identity':identity,'members':{n:{'sha256':sha256_bytes(v),'size_bytes':len(v)} for n,v in members.items()}}
members['release.json']=enc(release)
target=out/'PADML_F45_REBUILD_20260927_Q_READBACK_CACHE_BOUNDARY.zip'
write_deterministic_zip(target,members)
with zipfile.ZipFile(target) as z:assert {n:z.read(n) for n in z.namelist()}==members
with zipfile.ZipFile(previous) as z:
 for name in ('shared/bootstrap.zip','shared/bootstrap-preparation.json','science-decision.json','dependencies.json'):
  assert members[name]==z.read(name)
summary={'head':head,'package':str(target),'sha256':sha256_file(target),'size_bytes':target.stat().st_size,
 'source_identity':identity,'run_identity':run['identity'],'source':compiled,
 'changed_source_members':changed,'cache_predecessor_cases':13,'readback_cases':proof['readback_cases'],'numerical_baseline_unchanged':True,
 'deployed':False,'clinical_completion_claimed':False}
(out/'compile-summary.json').write_bytes(enc(summary)); print(json.dumps(summary))
