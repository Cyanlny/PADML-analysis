"""Original source qualification for the final-reuse artifact hash release repair."""
import ast, copy, json, os, tempfile, zipfile
from pathlib import Path
from unittest.mock import patch
from padml import f4, f5, run
from padml.bundle import ContractError, canonical_json_bytes as enc, sha256_bytes as sha, sha256_file

repo = Path(__file__).resolve().parents[2]
checks = Path(__file__).resolve().parent
previous = repo / 'execution/release-projected-input-release/PADML_F45_REBUILD_20260929_PROJECTED_INPUT_RELEASE.zip'
assert sha256_file(previous) == 'c841c90a4e258d458d7a4ffe3d7b837dbf74292235fcd0185ef1026af02c144e'
current_members = f4._f45_source_member_sha256()
results = {}
with tempfile.TemporaryDirectory(prefix='final-reuse-hash-source-') as temporary:
    base = Path(temporary).resolve()
    with zipfile.ZipFile(previous) as archive:
        for name in archive.namelist():
            if name in ('run.json', 'source.zip') or name.endswith(('/run.json', '/source.zip')):
                target = base / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.read(name))
    with zipfile.ZipFile(base / 'source.zip') as source:
        old_members = {name: sha(source.read(name)) for name in f4.F45_SOURCE_MEMBERS}
    assert {name for name in current_members if current_members[name] != old_members[name]} == {
        'padml/f5_sensitivity.py', 'padml/run.py'}
    original = json.loads((base / 'run.json').read_bytes())
    value = {**original, 'source_identity': sha(enc(current_members)), 'source_bundle_sha256': 'd'*64,
        'unit_predecessor': {'run_path': str(base / 'run.json'), 'run_sha256': sha256_file(base / 'run.json'),
            'source_path': str(base / 'source.zip'), 'source_sha256': sha256_file(base / 'source.zip')}}
    value['identity'] = sha(enc({k: v for k, v in value.items() if k != 'identity'}))
    (base / 'current-run.json').write_bytes(enc(value))
    remote = original['run_root']
    def mapped(location):
        location = str(location)
        return Path(str(base) + location[len(remote):]) if location.startswith(remote + '/') else Path(location)
    with patch.object(run, 'Path', mapped), patch.object(f4, 'Path', mapped):
        predecessors = run.f45_unit_predecessors(value)
        prior = json.loads((repo / 'execution/projected-input-release-checks/qualification.json').read_bytes())
        assert [p['identity'] for p in predecessors] == [original['identity'], *prior['checks']['predecessors']]
        assert len(predecessors) == 19
        baseline = run.validate_f45_resource_revision(value)
        assert sha(enc(baseline)) == '25190343ea52b20014b6cb38eae518b4fe77621e02c8eb24a5b3f66fc5047c50'
        with patch.dict(os.environ, {'PADML_F45_RUN_PATH': str(base / 'current-run.json')}):
            with patch.object(run, 'f45_unit_predecessors', return_value=predecessors):
                executors, sources = f5._f45_score_reuse_authorities()
        h5_run = 'bc244c0c81406760f125f5e581af8be3b1f10bbb355b6dd8d5da597b1d8a29da'
        h5_source = '8919e79e8d2d1020e97d1799cc9904f87ae51f46f1fc8cd01f282b73bd4e0377'
        assert executors[h5_run] == h5_source and h5_source in sources
        results.update(predecessors=[p['identity'] for p in predecessors], h5_producer_run=h5_run,
            h5_producer_source=h5_source, original_fit_producer_baseline_qualified=True)
        current = repo / 'padml/f5_sensitivity.py'
        raw, actual_read = current.read_bytes(), Path.read_bytes
        changes = {
            'unknown_release_change': (b'owner="AAR_FINAL_REUSE_HASHED_INPUTS"', b'owner="UNREVIEWED"'),
            'unknown_reuse_change': (b'if _f45_final_component_numerics(original) != _f45_final_component_numerics(job["entries"]):', b'if False:'),
        }
        for label, (before, after) in changes.items():
            assert raw.count(before) == 1
            altered = raw.replace(before, after, 1)
            with patch.object(Path, 'read_bytes', lambda path: altered if path == current else actual_read(path)):
                for name, validator in [('predecessor', run.f45_unit_predecessors),
                                        ('baseline', run.validate_f45_resource_revision)]:
                    try:
                        validator(value)
                    except ContractError as error:
                        results[name + '_' + label + '_rejected'] = str(error)
                    else:
                        raise AssertionError(name + ':' + label)
        damaged = copy.deepcopy(value)
        damaged['unit_predecessor']['source_sha256'] = 'f'*64
        try:
            run.f45_unit_predecessors(damaged)
        except ContractError as error:
            results['unknown_source_pin_rejected'] = str(error)
        else:
            raise AssertionError('unknown predecessor source')
    assert (base / 'run.json').read_bytes() == enc(original)
    assert value['science_decision'] == original['science_decision']
    results['all_other_scientific_and_runtime_sources_unchanged'] = True
record = {'source_identity': sha(enc(current_members)), 'checks': results,
    'clinical_calls': 0, 'remote_operations': 0}
(checks / 'qualification.json').write_bytes(enc(record))
print(json.dumps(record))
