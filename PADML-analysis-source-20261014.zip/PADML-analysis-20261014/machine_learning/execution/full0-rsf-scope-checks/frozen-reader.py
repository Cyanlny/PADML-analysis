"""Exact same-run readback qualification and frozen-package consumption; no clinical work."""
import ast, copy, io, json, os, tempfile, zipfile, subprocess, sys
from pathlib import Path
from unittest.mock import patch
from padml import f4, run as r, f5
from padml.bundle import ContractError, canonical_json_bytes as encode, sha256_bytes, sha256_file, strict_json_bytes

if len(sys.argv) == 2:
 package=Path(sys.argv[1]).resolve(strict=True)
 with tempfile.TemporaryDirectory(prefix='padml-frozen-readback-reader-') as tmp:
  unpacked=Path(tmp).resolve()
  with zipfile.ZipFile(package) as archive:
   release=json.loads(archive.read('release.json'))
   assert set(archive.namelist())=={'release.json',*release['members']} and len(archive.namelist())==len(release['members'])+1
   for name,pin in release['members'].items():
    raw=archive.read(name)
    assert sha256_bytes(raw)==pin['sha256'] and len(raw)==pin['size_bytes']
    if name in ('run.json','source.zip') or name.endswith(('/run.json','/source.zip')):
     assert not Path(name).is_absolute() and '..' not in Path(name).parts
     path=unpacked/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
  with zipfile.ZipFile(unpacked/'source.zip') as source:
   for name in source.namelist():
    assert not Path(name).is_absolute() and '..' not in Path(name).parts
    path=unpacked/'source'/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(source.read(name))
  reader=r'''
import json,sys
from pathlib import Path
from unittest.mock import patch
from padml import f4,run
from padml.bundle import sha256_file,sha256_bytes,canonical_json_bytes as enc
base=Path(sys.argv[1]);original=json.loads((base/'run.json').read_bytes());remote=original['run_root']
assert Path(f4.__file__).is_relative_to(base/'source')
def mapped(value):
 value=str(value)
 return Path(str(base)+value[len(remote):]) if value.startswith(remote+'/') else Path(value)
with patch.object(f4,'Path',mapped),patch.object(run,'Path',mapped):
 manifest=f4.load_f45_source_bundle(base/'source.zip')
 actual=run.load_f45_run(base/'run.json')
 predecessors=run.f45_unit_predecessors(actual)
 assert actual==original and len(predecessors)==22
 assert actual['source_bundle_sha256']==sha256_file(base/'source.zip')
 assert actual['source_identity']==sha256_bytes(enc(f4._f45_source_member_sha256()))
 print(json.dumps(dict(status='PASS',run_identity=actual['identity'],source_identity=actual['source_identity'],
  source_bundle_sha256=actual['source_bundle_sha256'],source_member_count=len(manifest['members']),
  predecessor_count=len(predecessors),units=len(actual['units']),reader_module=f4.__file__,
  fresh_process=True,original_loader=True,clinical_calls=0)))
'''
  child=subprocess.check_output([sys.executable,'-B','-c',reader,str(unpacked)],
   env={**os.environ,'PYTHONPATH':str(unpacked/'source'),'PYTHONDONTWRITEBYTECODE':'1'},
   cwd=unpacked,text=True)
  result={**json.loads(child),'package':str(package),'package_sha256':sha256_file(package),
   'package_size_bytes':package.stat().st_size,'git':release['head']}
  (package.parent/'frozen-reader-validation.json').write_bytes(encode(result))
  print(json.dumps(result))
 sys.exit(0)
