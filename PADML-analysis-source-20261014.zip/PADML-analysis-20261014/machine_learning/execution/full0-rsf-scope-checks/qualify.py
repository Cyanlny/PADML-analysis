"""Qualify the exact FULL0 RSF native scope correction; no clinical execution."""
import copy, json, os, tempfile, zipfile
from pathlib import Path
from unittest.mock import patch
from padml import f4, nested_loco as nested, run
from padml.bundle import ContractError, canonical_json_bytes as enc, sha256_bytes as sha, sha256_file

repo = Path(__file__).resolve().parents[2]
checks = Path(__file__).resolve().parent
previous = repo / 'execution/release-aar-primary-selector/PADML_F45_REBUILD_20260929_AAR_PRIMARY_SELECTOR.zip'
assert sha256_file(previous) == '5d4d4ed32916354644d8c32200026684b1f577bc434601c6a75b519d15c7f7de'
current_members = f4._f45_source_member_sha256()
results = {}
with tempfile.TemporaryDirectory(prefix='full0-rsf-scope-source-') as temporary:
    base = Path(temporary).resolve()
    with zipfile.ZipFile(previous) as archive:
        for name in archive.namelist():
            if name in ('run.json', 'source.zip') or name.endswith(('/run.json', '/source.zip')):
                target = base / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.read(name))
    with zipfile.ZipFile(base / 'source.zip') as source:
        old_members = {name: sha(source.read(name)) for name in f4.F45_SOURCE_MEMBERS}
    assert {name for name in current_members if current_members[name] != old_members[name]} == {
        'padml/f4.py', 'padml/run.py'}
    original = json.loads((base / 'run.json').read_bytes())
    value = {**original, 'source_identity': sha(enc(current_members)), 'source_bundle_sha256': 'd'*64,
        'unit_predecessor': {'run_path': str(base / 'run.json'), 'run_sha256': sha256_file(base / 'run.json'),
            'source_path': str(base / 'source.zip'), 'source_sha256': sha256_file(base / 'source.zip')}}
    value['identity'] = sha(enc({k: v for k, v in value.items() if k != 'identity'}))
    remote = original['run_root']
    def mapped(location):
        location = str(location)
        return Path(str(base) + location[len(remote):]) if location.startswith(remote + '/') else Path(location)
    with patch.object(run, 'Path', mapped), patch.object(f4, 'Path', mapped):
        predecessors = run.f45_unit_predecessors(value)
        prior = json.loads((repo / 'execution/aar-primary-selector-checks/qualification.json').read_bytes())
        assert [p['identity'] for p in predecessors] == [original['identity'], *prior['checks']['predecessors']]
        assert len(predecessors) == 22
        baseline = run.validate_f45_resource_revision(value)
        assert sha(enc(baseline)) == '25190343ea52b20014b6cb38eae518b4fe77621e02c8eb24a5b3f66fc5047c50'
        results.update(predecessors=[p['identity'] for p in predecessors], original_baseline_qualified=True)
        current = repo / 'padml/f4.py'
        raw, actual_read = current.read_bytes(), Path.read_bytes
        before = b'if twelve_rsf and not rescore and "producer_execution" in spec["final_search_source"]:'
        assert raw.count(before) == 1
        altered = raw.replace(before, b'if False:')
        with patch.object(Path, 'read_bytes', lambda path: altered if path == current else actual_read(path)):
            for name, validator in [('predecessor', run.f45_unit_predecessors),
                                    ('baseline', run.validate_f45_resource_revision)]:
                try:
                    validator(value)
                except ContractError as error:
                    results[name + '_unknown_scope_edit_rejected'] = str(error)
                else:
                    raise AssertionError(name + ': unknown scope edit accepted')
        damaged = copy.deepcopy(value)
        damaged['unit_predecessor']['source_sha256'] = 'f'*64
        try:
            run.f45_unit_predecessors(damaged)
        except ContractError as error:
            results['unknown_source_pin_rejected'] = str(error)
        else:
            raise AssertionError('unknown predecessor source')
    assert value['science_decision'] == original['science_decision']

evidence = repo / 'execution/step-cache-shap-checks/heartbeat-20260929T1541/H0-failed-atom-child-spec-identity.json'
observed = json.loads(evidence.read_bytes())['child_spec']
assert observed['execution_scope'] == 'F5_FULL_DEVELOPMENT_SEARCH'
assert observed['family'] == 'RSF' and observed['selection_horizon_months'] == 12
assert observed['producer_execution_present'] is False
assert 'producer_execution' not in observed['final_search_source_keys']
assert observed['producer_tasks'] == [{'imputation': 1, 'partition_id': 'F5_R03_K01',
    'seed': 330101, 'task_id': 'S3A_T003_P01_M01'}]
assert all(not observed['legacy_markers'][name]['present'] for name in (
    'full0_rsf_s1s2_rescore', 'full0_rsf_s3b1_reuse', 'native_search_numbers'))
assert observed['legacy_markers']['native_search_replay']['present'] is True
results['real_h0_metadata'] = {'evidence_sha256': sha256_file(evidence),
    'original_child_spec_sha256': observed['sha256'],
    'actual_coordinate': observed['producer_tasks'][0],
    'current_canonical_source_without_historical_producer_execution': True,
    'projection_only_not_independent_scientific_completion': True}
record = {'source_identity': sha(enc(current_members)), 'checks': results,
    'clinical_calls': 0, 'remote_operations': 0, 'science_decision_unchanged': True,
    'all_other_scientific_sources_unchanged': True}
(checks / 'qualification.json').write_bytes(enc(record))
print(json.dumps(record))
