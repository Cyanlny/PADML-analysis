# 敏感性分析引擎：复用冻结模型与每套插补对比，不改变主合同。

read_sensitivity_registry <- function(root = ".") {
  path <- file.path(root, "config", "sensitivity_registry.csv")
  registry <- utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE)
  required_columns <- c("sensitivity_id", "tier", "name", "base_model", "required", "primary_comparison", "implementation_lock")
  if (!identical(names(registry), required_columns)) {
    stop("Sensitivity registry schema mismatch", call. = FALSE)
  }
  if (anyDuplicated(registry$sensitivity_id)) {
    stop("Duplicate sensitivity_id in sensitivity registry", call. = FALSE)
  }
  registry$required <- as.logical(registry$required)
  if (anyNA(registry$required)) {
    stop("Invalid required flag in sensitivity registry", call. = FALSE)
  }
  registry
}

sensitivity_required_ids <- function(root = ".") {
  registry <- read_sensitivity_registry(root)
  registry$sensitivity_id[registry$required]
}

read_sensitivity_parameters <- function(root = ".") {
  path <- file.path(root, "config", "sensitivity_parameter_registry.csv")
  parameters <- utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE)
  required_columns <- c("sensitivity_id", "parameter_id", "value", "value_type", "decision_source", "required_action")
  if (!identical(names(parameters), required_columns)) {
    stop("Sensitivity parameter registry schema mismatch", call. = FALSE)
  }
  key <- paste(parameters$sensitivity_id, parameters$parameter_id, sep = "::")
  if (anyDuplicated(key)) {
    stop("Duplicate sensitivity parameter key", call. = FALSE)
  }
  if (!all(parameters$sensitivity_id %in% read_sensitivity_registry(root)$sensitivity_id)) {
    stop("Sensitivity parameter references an unknown sensitivity_id", call. = FALSE)
  }
  parameters
}

parse_registered_parameter <- function(value, value_type) {
  switch(
    value_type,
    string = as.character(value),
    numeric = {
      parsed <- suppressWarnings(as.numeric(value))
      if (!is.finite(parsed)) stop("Invalid numeric sensitivity parameter", call. = FALSE)
      parsed
    },
    integer = {
      parsed <- suppressWarnings(as.integer(value))
      if (is.na(parsed) || as.character(parsed) != as.character(value)) {
        stop("Invalid integer sensitivity parameter", call. = FALSE)
      }
      parsed
    },
    logical = {
      normalized <- toupper(as.character(value))
      if (!normalized %in% c("TRUE", "FALSE")) stop("Invalid logical sensitivity parameter", call. = FALSE)
      identical(normalized, "TRUE")
    },
    string_vector = {
      if (!nzchar(value)) character() else strsplit(as.character(value), "|", fixed = TRUE)[[1L]]
    },
    numeric_vector = {
      parsed <- suppressWarnings(as.numeric(strsplit(as.character(value), "|", fixed = TRUE)[[1L]]))
      if (!length(parsed) || any(!is.finite(parsed))) stop("Invalid numeric-vector sensitivity parameter", call. = FALSE)
      parsed
    },
    stop("Unsupported sensitivity parameter type: ", value_type, call. = FALSE)
  )
}

sensitivity_parameter <- function(parameters, sensitivity_id, parameter_id, expected_type = NULL) {
  row <- parameters[
    parameters$sensitivity_id == sensitivity_id & parameters$parameter_id == parameter_id,
    ,
    drop = FALSE
  ]
  if (nrow(row) != 1L) {
    stop("Expected one sensitivity parameter: ", sensitivity_id, "/", parameter_id, call. = FALSE)
  }
  if (!is.null(expected_type) && !identical(row$value_type[[1L]], expected_type)) {
    stop("Sensitivity parameter type mismatch: ", sensitivity_id, "/", parameter_id, call. = FALSE)
  }
  parse_registered_parameter(row$value[[1L]], row$value_type[[1L]])
}

build_component_formula_text <- function(endpoint_row, root = ".") {
  covariates <- split_registry_terms(read_model_spec("M5", root)$covariates[[1L]])
  sprintf(
    "survival::Surv(%s, %s) ~ %s",
    endpoint_row$time_variable[[1L]],
    endpoint_row$event_variable[[1L]],
    paste(c("log2_AST", "log2_ALT", covariates), collapse = " + ")
  )
}

raw_ratio_effect_multiplier <- function(reference_ratio, raw_delta = 1) {
  if (length(reference_ratio) != 1L || length(raw_delta) != 1L ||
      !is.finite(reference_ratio) || !is.finite(raw_delta) ||
      reference_ratio <= 0 || reference_ratio + raw_delta <= 0) {
    stop("Raw-ratio contrast requires positive finite reference and shifted values", call. = FALSE)
  }
  log2((reference_ratio + raw_delta) / reference_ratio)
}

define_sensitivity_patient_ids <- function(sensitivity_id, imp0, missing_mask, endpoint_row, root = ".") {
  if (!is.data.frame(imp0) || !"Patient_ID" %in% names(imp0)) {
    stop("imp0 must be a data frame with Patient_ID", call. = FALSE)
  }
  if (!is.null(missing_mask)) {
    missing_mask <- as.matrix(missing_mask)
    if (nrow(missing_mask) != nrow(imp0) || is.null(colnames(missing_mask))) {
      stop("Missingness mask is not aligned with imp0", call. = FALSE)
    }
  }
  parameters <- read_sensitivity_parameters(root)
  required_variables <- switch(
    sensitivity_id,
    A04 = c(
      "AST", "ALT",
      endpoint_row$event_variable[[1L]],
      endpoint_row$time_variable[[1L]],
      split_registry_terms(read_model_spec("M5", root)$covariates[[1L]])
    ),
    A05 = sensitivity_parameter(parameters, "A05", "observed_qc_variables", "string_vector"),
    B02 = c("AST", "ALT"),
    stop("No patient-set rule registered for sensitivity: ", sensitivity_id, call. = FALSE)
  )
  missing_variables <- setdiff(required_variables, names(imp0))
  if (length(missing_variables)) {
    stop("Patient-set variables missing: ", paste(missing_variables, collapse = ", "), call. = FALSE)
  }
  observed <- stats::complete.cases(imp0[required_variables])
  mask_variables <- intersect(required_variables, colnames(missing_mask))
  if (!is.null(missing_mask) && length(mask_variables)) {
    observed <- observed & rowSums(missing_mask[, mask_variables, drop = FALSE]) == 0L
  }
  if (identical(sensitivity_id, "B02")) {
    ast_max <- sensitivity_parameter(parameters, "B02", "AST_max_U_L", "numeric")
    alt_max <- sensitivity_parameter(parameters, "B02", "ALT_max_U_L", "numeric")
    observed <- observed & imp0$AST > 0 & imp0$ALT > 0 & imp0$AST <= ast_max & imp0$ALT <= alt_max
  } else if (identical(sensitivity_id, "A04")) {
    observed <- observed & imp0$AST > 0 & imp0$ALT > 0
  }
  as.character(imp0$Patient_ID[observed])
}

validate_sensitivity_coverage <- function(results, root = ".") {
  if (!is.data.frame(results) || !all(c("sensitivity_id", "analysis_status") %in% names(results))) {
    stop("Sensitivity coverage input schema mismatch", call. = FALSE)
  }
  registry <- read_sensitivity_registry(root)
  unknown <- setdiff(unique(as.character(results$sensitivity_id)), registry$sensitivity_id)
  rows <- lapply(seq_len(nrow(registry)), function(i) {
    id <- registry$sensitivity_id[[i]]
    subset <- results[as.character(results$sensitivity_id) == id, , drop = FALSE]
    present <- nrow(subset) > 0L
    data.frame(
      sensitivity_id = id,
      required = registry$required[[i]],
      result_row_n = nrow(subset),
      analysis_statuses = paste(sort(unique(as.character(subset$analysis_status))), collapse = "|"),
      status = ifelse(!registry$required[[i]] || present, "PASS", "FAIL"),
      reason_code = ifelse(!registry$required[[i]] || present, "", "REQUIRED_SENSITIVITY_MISSING"),
      stringsAsFactors = FALSE
    )
  })
  if (length(unknown)) {
    rows[[length(rows) + 1L]] <- data.frame(
      sensitivity_id = sort(unknown),
      required = FALSE,
      result_row_n = vapply(sort(unknown), function(id) sum(as.character(results$sensitivity_id) == id), integer(1)),
      analysis_statuses = vapply(sort(unknown), function(id) {
        paste(sort(unique(as.character(results$analysis_status[as.character(results$sensitivity_id) == id]))), collapse = "|")
      }, character(1)),
      status = "FAIL",
      reason_code = "UNREGISTERED_SENSITIVITY_ID",
      stringsAsFactors = FALSE
    )
  }
  do.call(rbind, rows)
}

bind_rows_fill <- function(frames) {
  frames <- Filter(function(x) is.data.frame(x) && nrow(x), frames)
  if (!length(frames)) return(data.frame())
  columns <- unique(unlist(lapply(frames, names), use.names = FALSE))
  frames <- lapply(frames, function(frame) {
    missing <- setdiff(columns, names(frame))
    for (column in missing) frame[[column]] <- NA
    frame[columns]
  })
  output <- do.call(rbind, frames)
  rownames(output) <- NULL
  output
}

sensitivity_p_display <- function(p) {
  ifelse(is.na(p), "", ifelse(p < 0.001, "<0.001", sprintf("%.3f", p)))
}

sensitivity_significance_symbol <- function(p) {
  ifelse(is.na(p), "", ifelse(p < 0.001, "***", ifelse(p < 0.01, "**", ifelse(p < 0.05, "*", ""))))
}

decorate_sensitivity_results <- function(data) {
  if (!nrow(data)) return(data)
  if (!"analysis_variant" %in% names(data)) {
    stop("Sensitivity canonical rows require analysis_variant", call. = FALSE)
  }
  if (!"analysis_id" %in% names(data)) data$analysis_id <- as.character(data$analysis_variant)
  if (!"analysis_status" %in% names(data)) {
    data$analysis_status <- if ("estimate_status" %in% names(data)) as.character(data$estimate_status) else "ESTIMABLE"
  }
  if (!"estimate_status" %in% names(data)) data$estimate_status <- as.character(data$analysis_status)
  if (!"reason_code" %in% names(data)) {
    data$reason_code <- if ("not_estimable_reason_code" %in% names(data)) as.character(data$not_estimable_reason_code) else ""
  }
  if (!"not_estimable_reason_code" %in% names(data)) data$not_estimable_reason_code <- as.character(data$reason_code)
  if (!"p_value" %in% names(data)) data$p_value <- NA_real_
  if (!"p_display" %in% names(data)) data$p_display <- sensitivity_p_display(data$p_value)
  data$annotation_p <- data$p_value
  data$annotation_p_display <- sensitivity_p_display(data$annotation_p)
  data$annotation_p_type <- ifelse(is.finite(data$annotation_p), "contrast_specific_pooled_wald", "not_applicable")
  data$significance_symbol <- sensitivity_significance_symbol(data$annotation_p)
  sort_columns <- intersect(
    c("sensitivity_id", "analysis_variant", "endpoint", "model_id", "exposure_form", "contrast", "time_month", "interval_index", "omitted_imputation", "omitted_center"),
    names(data)
  )
  if (length(sort_columns)) {
    ordering <- do.call(order, c(lapply(data[sort_columns], function(x) ifelse(is.na(x), "", as.character(x))), list(method = "radix")))
    data <- data[ordering, , drop = FALSE]
  }
  rownames(data) <- NULL
  data
}

canonical_to_sensitivity <- function(data, sensitivity_id, analysis_variant) {
  if (!is.data.frame(data) || !nrow(data)) return(data.frame())
  data$sensitivity_id <- sensitivity_id
  data$analysis_variant <- analysis_variant
  if (!"exposure_form" %in% names(data) && "exposure_parameterization" %in% names(data)) {
    data$exposure_form <- data$exposure_parameterization
  }
  decorate_sensitivity_results(data)
}

rescale_canonical_row <- function(row, multiplier, contrast) {
  row$beta <- row$beta * multiplier
  row$se <- row$se * abs(multiplier)
  row$hr <- exp(row$beta)
  row$lower_95_ci <- exp(row$beta - 1.96 * row$se)
  row$upper_95_ci <- exp(row$beta + 1.96 * row$se)
  row$contrast <- contrast
  row
}

subset_completed_by_ids <- function(completed, patient_ids) {
  lapply(completed, function(data) {
    index <- match(patient_ids, as.character(data$Patient_ID))
    if (anyNA(index)) stop("Frozen sensitivity patient set is absent from a completed dataset", call. = FALSE)
    data[index, , drop = FALSE]
  })
}

fit_formula_across_imputations <- function(completed, formula_text, retain_diagnostics = FALSE) {
  formula <- stats::as.formula(formula_text)
  fits <- vector("list", length(completed))
  failures <- character(length(completed))
  for (imputation in seq_along(completed)) {
    data <- normalize_cox_factor_levels(completed[[imputation]])
    missing <- setdiff(all.vars(formula), names(data))
    if (length(missing)) {
      failures[[imputation]] <- paste("missing variables", paste(missing, collapse = "|"))
      next
    }
    fits[[imputation]] <- tryCatch({
      # 加载 survival 包并拟合当前预注册敏感性 Cox 模型。
      if (!requireNamespace("survival", quietly = TRUE)) stop("survival is required", call. = FALSE)
      survival::coxph(
        formula, data = data, ties = "efron", na.action = stats::na.fail,
        x = isTRUE(retain_diagnostics), y = isTRUE(retain_diagnostics),
        model = isTRUE(retain_diagnostics)
      )
    }, error = function(error) {
      failures[[imputation]] <<- conditionMessage(error)
      NULL
    })
  }
  list(fits = fits, failures = failures, formula_text = formula_text)
}

sensitivity_model_signature <- function(endpoint, population, exposure_form, formula_text, contrast, time_function = "fixed") {
  model_signature_sha256(
    endpoint = endpoint,
    population = population,
    exposure = "AST_ALT",
    exposure_scale = exposure_form,
    formula_text = formula_text,
    factor_references = c("AST_ALT_Tertile=T1"),
    ties_method = "efron",
    time_origin = "baseline",
    time_function = time_function,
    tve_terms = character(),
    contrast = contrast,
    pooling_method = "Rubin_scalar",
    confidence_level = 0.95,
    scientific_config_revision = "r04"
  )
}

a06_rcs_sensitivity_model_signature_sha256 <- function(
    endpoint_row, rcs_spec, analysis_variant, root = ".") {
  if (!requireNamespace("digest", quietly = TRUE)) stop("digest is required", call. = FALSE)
  if (!exists("normalize_formula_terms", mode = "function")) {
    source(file.path(root, "R", "model_signature.R"))
  }
  covariates <- split_registry_terms(read_model_spec("M5", root)$covariates[[1L]])
  basis_names <- c(
    "rcs_linear", paste0("rcs_nonlinear", seq_len(length(rcs_spec$knots) - 2L))
  )
  formula_text <- sprintf(
    "survival::Surv(%s, %s) ~ %s",
    endpoint_row$time_variable[[1L]], endpoint_row$event_variable[[1L]],
    paste(c(basis_names, covariates), collapse = " + ")
  )
  payload <- c(
    signature_schema = "A06_RCS_SENSITIVITY_MODEL_SIGNATURE_V1",
    endpoint = endpoint_row$event_variable[[1L]], model_id = "M5",
    analysis_variant = analysis_variant,
    formula = normalize_formula_terms(formula_text),
    knots = paste(format(as.numeric(rcs_spec$knots), digits = 17, scientific = FALSE),
      collapse = "|"),
    reference = format(as.numeric(rcs_spec$reference), digits = 17, scientific = FALSE),
    grid_sha256 = digest::digest(
      paste(format(as.numeric(rcs_spec$grid), digits = 17, scientific = FALSE),
        collapse = "|"),
      algo = "sha256", serialize = FALSE
    ),
    quantile_type = as.character(rcs_spec$quantile_type), ties_method = "efron",
    pooling_method = "RUBIN_LINEAR_CONTRAST", scientific_config_revision = "r04"
  )
  digest::digest(
    paste(names(payload), payload, sep = "=", collapse = "\n"),
    algo = "sha256", serialize = FALSE
  )
}

pool_sensitivity_terms <- function(
    collection, term_specs, sensitivity_id, analysis_variant, endpoint_row,
    model_id, exposure_form, population = "MAIN_EXPOSURE_ELIGIBLE", time_month = NA_real_,
    time_function = "fixed") {
  valid_fit_n <- sum(!vapply(collection$fits, is.null, logical(1)))
  valid_indices <- which(!vapply(collection$fits, is.null, logical(1)))
  first <- if (length(valid_indices)) collection$fits[[valid_indices[[1L]]]] else NULL
  rows <- lapply(seq_len(nrow(term_specs)), function(i) {
    term <- term_specs$term[[i]]
    multiplier <- term_specs$multiplier[[i]]
    estimates <- vapply(collection$fits, function(fit) {
      if (is.null(fit) || !term %in% names(stats::coef(fit))) NA_real_ else stats::coef(fit)[[term]] * multiplier
    }, numeric(1))
    variances <- vapply(collection$fits, function(fit) {
      if (is.null(fit) || !term %in% rownames(stats::vcov(fit))) NA_real_ else stats::vcov(fit)[term, term] * multiplier^2
    }, numeric(1))
    # 对20套冻结插补执行 Rubin pooling；少于20套时显式保留不可估计状态。
    pooled <- if (sum(is.finite(estimates) & is.finite(variances)) == length(collection$fits)) {
      tryCatch(pool_scalar_rubin(estimates, variances), error = function(error) NULL)
    } else {
      NULL
    }
    p <- if (is.null(pooled)) NA_real_ else pooled$p_value[[1L]]
    data.frame(
      sensitivity_id = sensitivity_id,
      analysis_variant = analysis_variant,
      endpoint = endpoint_row$event_variable[[1L]],
      model_id = model_id,
      model_signature_sha256 = sensitivity_model_signature(
        endpoint_row$event_variable[[1L]], population, exposure_form,
        collection$formula_text, term_specs$contrast[[i]], time_function
      ),
      exposure_form = exposure_form,
      contrast = term_specs$contrast[[i]],
      time_month = time_month,
      n = if (is.null(first)) NA_integer_ else first$n,
      events = if (is.null(first)) NA_integer_ else first$nevent,
      beta = if (is.null(pooled)) NA_real_ else pooled$pooled_estimate[[1L]],
      se = if (is.null(pooled)) NA_real_ else pooled$se[[1L]],
      hr = if (is.null(pooled)) NA_real_ else exp(pooled$pooled_estimate[[1L]]),
      lower_95_ci = if (is.null(pooled)) NA_real_ else exp(pooled$lower[[1L]]),
      upper_95_ci = if (is.null(pooled)) NA_real_ else exp(pooled$upper[[1L]]),
      p_value = p,
      valid_imputation_n = if (is.null(pooled)) valid_fit_n else pooled$valid_imputation_n[[1L]],
      analysis_status = ifelse(is.null(pooled), "NOT_ESTIMABLE", "ESTIMABLE"),
      reason_code = ifelse(is.null(pooled), "NE_NOT_ALL_20_IMPUTATIONS_ESTIMABLE", ""),
      stringsAsFactors = FALSE
    )
  })
  decorate_sensitivity_results(do.call(rbind, rows))
}

fixed_term_specs <- function(exposure_form, exposure_scale) {
  if (identical(exposure_form, "log2_AST_ALT")) {
    data.frame(
      term = "log2_AST_ALT",
      contrast = c("per_doubling", "per_1_SD", "per_IQR"),
      multiplier = c(1, exposure_scale$log2_sd[[1L]], exposure_scale$log2_iqr[[1L]]),
      stringsAsFactors = FALSE
    )
  } else {
    data.frame(
      term = c("AST_ALT_TertileT2", "AST_ALT_TertileT3"),
      contrast = c("T2_vs_T1", "T3_vs_T1"),
      multiplier = 1,
      stringsAsFactors = FALSE
    )
  }
}

local_riskset <- function(data, endpoint_row) {
  times <- c(6, 12, 24, 36)
  data.frame(
    endpoint = endpoint_row$event_variable[[1L]],
    time_month = times,
    at_risk_n = vapply(times, function(time) sum(data[[endpoint_row$time_variable[[1L]]]] >= time, na.rm = TRUE), integer(1)),
    stringsAsFactors = FALSE
  )
}

run_primary_model_variant <- function(
    completed, endpoint_row, exposure_scale, sensitivity_id, analysis_variant,
    model_id = "M5", covariates = NULL, include_tve = TRUE,
    population = "MAIN_EXPOSURE_ELIGIBLE", root = ".") {
  if (is.null(covariates)) covariates <- split_registry_terms(read_model_spec(model_id, root)$covariates[[1L]])
  fixed_rows <- list()
  tve_rows <- list()
  for (form in c("AST_ALT_Tertile", "log2_AST_ALT")) {
    formula_text <- sprintf(
      "survival::Surv(%s, %s) ~ %s",
      endpoint_row$time_variable[[1L]],
      endpoint_row$event_variable[[1L]],
      paste(c(form, covariates), collapse = " + ")
    )
    fixed_collection <- fit_formula_across_imputations(completed, formula_text)
    fixed_rows[[form]] <- pool_sensitivity_terms(
      fixed_collection, fixed_term_specs(form, exposure_scale),
      sensitivity_id, paste0(analysis_variant, "__FIXED"), endpoint_row,
      model_id, form, population
    )
    if (include_tve) {
      tve_collection <- fit_tve_collection(
        completed, model_id, endpoint_row, form, root,
        covariates_override = covariates,
        include_rutherford_tve = "Rutherford_cat" %in% covariates,
        scientific_config_revision = "r04"
      )
      # 对冻结 TVE 对比执行统一 pooling，不建立另一条统计路径。
      tve <- pool_tve_collection(tve_collection, exposure_scale, local_riskset(completed[[1L]], endpoint_row), root)$canonical
      tve_rows[[form]] <- canonical_to_sensitivity(tve, sensitivity_id, paste0(analysis_variant, "__G12_TVE"))
    }
  }
  decorate_sensitivity_results(bind_rows_fill(c(fixed_rows, tve_rows)))
}

pool_loio_contrasts <- function(per_imputation, root = ".") {
  if (!nrow(per_imputation)) return(data.frame())
  parameters <- read_sensitivity_parameters(root)
  retained_n <- sensitivity_parameter(parameters, "A06", "retained_imputation_n", "integer")
  total_n <- retained_n + 1L
  keys <- unique(per_imputation[c("endpoint", "model_id", "exposure_form", "contrast", "time_month")])
  rows <- list()
  index <- 1L
  for (key_index in seq_len(nrow(keys))) {
    key <- keys[key_index, , drop = FALSE]
    subset <- per_imputation[
      per_imputation$endpoint == key$endpoint &
        per_imputation$model_id == key$model_id &
        per_imputation$exposure_form == key$exposure_form &
        per_imputation$contrast == key$contrast &
        per_imputation$time_month == key$time_month,
      ,
      drop = FALSE
    ]
    for (omitted in seq_len(total_n)) {
      retained <- subset[subset$imputation != omitted, , drop = FALSE]
      valid <- is.finite(retained$estimate) & is.finite(retained$variance)
      pooled <- if (sum(valid) == retained_n) {
        tryCatch(pool_scalar_rubin(retained$estimate, retained$variance), error = function(error) NULL)
      } else {
        NULL
      }
      rows[[index]] <- data.frame(
        sensitivity_id = "A06",
        analysis_variant = "LEAVE_ONE_IMPUTATION_OUT",
        omitted_imputation = omitted,
        endpoint = key$endpoint,
        model_id = key$model_id,
        exposure_form = key$exposure_form,
        contrast = key$contrast,
        time_month = key$time_month,
        beta = if (is.null(pooled)) NA_real_ else pooled$pooled_estimate[[1L]],
        se = if (is.null(pooled)) NA_real_ else pooled$se[[1L]],
        hr = if (is.null(pooled)) NA_real_ else exp(pooled$pooled_estimate[[1L]]),
        lower_95_ci = if (is.null(pooled)) NA_real_ else exp(pooled$lower[[1L]]),
        upper_95_ci = if (is.null(pooled)) NA_real_ else exp(pooled$upper[[1L]]),
        p_value = if (is.null(pooled)) NA_real_ else pooled$p_value[[1L]],
        valid_imputation_n = if (is.null(pooled)) sum(valid) else pooled$valid_imputation_n[[1L]],
        analysis_status = ifelse(is.null(pooled), "NOT_ESTIMABLE", "ESTIMABLE"),
        reason_code = ifelse(is.null(pooled), "NE_LOIO_NOT_EXACTLY_19_VALID", ""),
        stringsAsFactors = FALSE
      )
      index <- index + 1L
    }
  }
  decorate_sensitivity_results(do.call(rbind, rows))
}

split_piecewise_data <- function(data, endpoint_row, cuts) {
  # 加载 survival 包并将每名受试者展开为冻结时间区间。
  if (!requireNamespace("survival", quietly = TRUE)) stop("survival is required", call. = FALSE)
  formula <- stats::as.formula(sprintf(
    "Surv(%s, %s) ~ .",
    endpoint_row$time_variable[[1L]], endpoint_row$event_variable[[1L]]
  ), env = asNamespace("survival"))
  split <- survival::survSplit(
    formula, data = data, cut = cuts,
    start = ".piece_start", end = endpoint_row$time_variable[[1L]],
    event = endpoint_row$event_variable[[1L]], episode = ".piece_interval"
  )
  interval_n <- length(cuts) + 1L
  for (interval in seq_len(interval_n)) {
    split[[paste0("log2_AST_ALT_I", interval)]] <- ifelse(split$.piece_interval == interval, split$log2_AST_ALT, 0)
  }
  split
}

run_piecewise_sensitivity <- function(completed, endpoint_row, root = ".") {
  parameters <- read_sensitivity_parameters(root)
  cuts <- sensitivity_parameter(parameters, "A02", "piecewise_cut_months", "numeric_vector")
  prepared <- lapply(completed, split_piecewise_data, endpoint_row = endpoint_row, cuts = cuts)
  terms <- paste0("log2_AST_ALT_I", seq_len(length(cuts) + 1L))
  covariates <- split_registry_terms(read_model_spec("M5", root)$covariates[[1L]])
  formula_text <- sprintf(
    "survival::Surv(.piece_start, %s, %s) ~ %s",
    endpoint_row$time_variable[[1L]],
    endpoint_row$event_variable[[1L]],
    paste(c(terms, covariates, "strata(.piece_interval)"), collapse = " + ")
  )
  collection <- fit_formula_across_imputations(prepared, formula_text)
  labels <- c(
    paste0("0-", cuts[[1L]]),
    if (length(cuts) > 1L) paste0(cuts[-length(cuts)], "-", cuts[-1L]) else character(),
    paste0(">", cuts[[length(cuts)]])
  )
  term_specs <- data.frame(term = terms, contrast = paste0("INTERVAL_", labels), multiplier = 1, stringsAsFactors = FALSE)
  rows <- pool_sensitivity_terms(
    collection, term_specs, "A02", "PIECEWISE_TIME_INTERVAL", endpoint_row,
    "M5", "log2_AST_ALT", time_month = NA_real_, time_function = "piecewise_0_6_12_24_36_inf"
  )
  rows$interval_index <- seq_len(nrow(rows))
  rows$interval_label <- labels
  rows$cut_months <- paste(cuts, collapse = "|")
  decorate_sensitivity_results(rows)
}

build_multiscale_reuse <- function(fixed_canonical, tve_canonical, exposure_scale) {
  fixed <- fixed_canonical[fixed_canonical$model_id == "M5", , drop = FALSE]
  tve <- tve_canonical[tve_canonical$model_id == "M5", , drop = FALSE]
  fixed_rows <- canonical_to_sensitivity(fixed, "A03", "REUSED_FIXED_M5")
  tve_rows <- canonical_to_sensitivity(tve, "A03", "REUSED_G12_TVE_M5")
  fixed_continuous <- fixed[fixed$exposure_parameterization == "log2_AST_ALT" & fixed$contrast == "per_doubling", , drop = FALSE]
  derived <- list()
  if (nrow(fixed_continuous)) {
    derived[[1L]] <- rescale_canonical_row(fixed_continuous, exposure_scale$log2_sd[[1L]], "per_1_SD")
    derived[[2L]] <- rescale_canonical_row(fixed_continuous, exposure_scale$log2_iqr[[1L]], "per_IQR")
  }
  reference_ratio <- 2^exposure_scale$reference_median[[1L]]
  raw_multiplier <- raw_ratio_effect_multiplier(reference_ratio, 1)
  fixed_raw <- if (nrow(fixed_continuous)) rescale_canonical_row(fixed_continuous, raw_multiplier, "per_plus_1_raw_ratio_at_frozen_median") else data.frame()
  tve_doubling <- tve[tve$exposure_parameterization == "log2_AST_ALT" & tve$contrast == "per_doubling", , drop = FALSE]
  tve_raw <- if (nrow(tve_doubling)) rescale_canonical_row(tve_doubling, raw_multiplier, "per_plus_1_raw_ratio_at_frozen_median") else data.frame()
  decorate_sensitivity_results(bind_rows_fill(c(
    list(fixed_rows, tve_rows),
    lapply(derived, canonical_to_sensitivity, sensitivity_id = "A03", analysis_variant = "DERIVED_FROM_REUSED_FIXED_M5"),
    list(
      canonical_to_sensitivity(fixed_raw, "A03", "DERIVED_FROM_REUSED_FIXED_M5"),
      canonical_to_sensitivity(tve_raw, "A03", "DERIVED_FROM_REUSED_G12_TVE_M5")
    )
  )))
}

run_loco_sensitivity <- function(completed, endpoint_row, exposure_scale, root = ".") {
  if (!"Center" %in% names(completed[[1L]])) return(data.frame())
  centers <- sort(unique(as.character(completed[[1L]]$Center)), method = "radix")
  rows <- lapply(centers, function(center) {
    subset <- lapply(completed, function(data) data[as.character(data$Center) != center, , drop = FALSE])
    collection <- fit_tve_collection(
      subset, "M5", endpoint_row, "log2_AST_ALT", root,
      covariates_override = split_registry_terms(read_model_spec("M5", root)$covariates[[1L]]),
      include_rutherford_tve = TRUE, scientific_config_revision = "r04"
    )
    # 对逐中心排除模型执行统一 TVE pooling。
    pooled <- pool_tve_collection(collection, exposure_scale, local_riskset(subset[[1L]], endpoint_row), root)$canonical
    pooled <- canonical_to_sensitivity(pooled[pooled$contrast == "per_1_SD", , drop = FALSE], "A08", "LEAVE_ONE_CENTER_OUT")
    pooled$omitted_center <- center
    pooled$remaining_n <- nrow(subset[[1L]])
    pooled$remaining_events <- sum(subset[[1L]][[endpoint_row$event_variable[[1L]]]] == 1L)
    pooled
  })
  decorate_sensitivity_results(bind_rows_fill(rows))
}

run_rcs_shape_sensitivity <- function(completed, imp0, missing_mask, endpoint_row, exposure_scale, approved_rcs, root = ".") {
  complete_ids <- define_sensitivity_patient_ids("A04", imp0, missing_mask, endpoint_row, root)
  p_bounds <- stats::quantile(imp0$AST / imp0$ALT, c(0.01, 0.99), type = 7, na.rm = TRUE, names = FALSE)
  p_ids <- as.character(imp0$Patient_ID[
    is.finite(imp0$AST / imp0$ALT) &
      imp0$AST / imp0$ALT >= p_bounds[[1L]] &
      imp0$AST / imp0$ALT <= p_bounds[[2L]]
  ])
  complete_collection <- fit_rcs_collections(
    subset_completed_by_ids(completed, complete_ids), endpoint_row, approved_rcs$spec, root
  )
  p1_p99_collection <- fit_rcs_collections(
    subset_completed_by_ids(completed, p_ids), endpoint_row, approved_rcs$spec, root
  )
  variants <- list(
    MI_FULL = list(curve = approved_rcs$curve, cutoff = approved_rcs$cutoff),
    COMPLETE_CASE = list(
      curve = pool_rcs_grid(complete_collection, approved_rcs$spec, root),
      cutoff = derive_rcs_turning_point(
        complete_collection$fits$full, approved_rcs$spec, complete_collection$basis_names,
        minimum_root_imputations = 16L, maximum_iqr_fraction = 0.10
      )
    ),
    P1_P99_RESTRICTED = list(
      curve = pool_rcs_grid(p1_p99_collection, approved_rcs$spec, root),
      cutoff = derive_rcs_turning_point(
        p1_p99_collection$fits$full, approved_rcs$spec, p1_p99_collection$basis_names,
        minimum_root_imputations = 16L, maximum_iqr_fraction = 0.10
      )
    )
  )
  variant_signatures <- vapply(names(variants), function(variant) {
    a06_rcs_sensitivity_model_signature_sha256(
      endpoint_row, approved_rcs$spec, variant, root
    )
  }, character(1))
  curves <- bind_rows_fill(lapply(names(variants), function(variant) {
    curve <- variants[[variant]]$curve
    curve$model_signature_sha256 <- variant_signatures[[variant]]
    curve$sensitivity_id <- "A09"
    curve$analysis_variant <- variant
    curve$analysis_status <- curve$estimate_status
    curve$reason_code <- ifelse(curve$estimate_status == "ESTIMABLE", "", "NE_RCS_NUMERIC_FAILURE")
    curve
  }))
  full <- variants$MI_FULL$curve
  summary <- lapply(names(variants), function(variant) {
    curve <- variants[[variant]]$curve
    difference <- if (identical(variant, "MI_FULL")) {
      0
    } else if (nrow(curve) == nrow(full) && all(is.finite(curve$beta)) && all(is.finite(full$beta))) {
      max(abs(curve$beta - full$beta))
    } else {
      NA_real_
    }
    data.frame(
      sensitivity_id = "A09", analysis_variant = variant,
      endpoint = endpoint_row$event_variable[[1L]], model_id = "M5",
      model_signature_sha256 = variant_signatures[[variant]],
      exposure_form = "RCS_LOG2_AST_ALT", contrast = "MAX_ABS_LOG_HR_DIFFERENCE_VS_MI_FULL",
      time_month = NA_real_, n = if (identical(variant, "MI_FULL")) nrow(completed[[1L]]) else if (identical(variant, "COMPLETE_CASE")) length(complete_ids) else length(p_ids),
      events = NA_integer_, beta = difference, se = NA_real_, hr = NA_real_,
      lower_95_ci = NA_real_, upper_95_ci = NA_real_, p_value = NA_real_,
      valid_imputation_n = ifelse(identical(variant, "COMPLETE_CASE"), length(completed), length(completed)),
      analysis_status = ifelse(is.finite(difference), "ESTIMABLE", "NOT_ESTIMABLE"),
      reason_code = ifelse(is.finite(difference), "", "NE_RCS_NUMERIC_FAILURE"),
      scientific_difference_action = "REPORT_NONBLOCKING",
      stringsAsFactors = FALSE
    )
  })
  cutoff_rows <- bind_rows_fill(lapply(names(variants), function(variant) {
    candidate <- variants[[variant]]$cutoff$candidate
    candidate$analysis_variant <- variant
    candidate
  }))
  list(
    standard = decorate_sensitivity_results(do.call(rbind, summary)),
    rcs = decorate_sensitivity_results(curves),
    rcs_cutoff = cutoff_rows,
    diagnostics = data.frame(
      sensitivity_id = "A09",
      metric = c("complete_case_n", "p1_p99_n", "frozen_knot_n", "common_grid_n"),
      value = c(length(complete_ids), length(p_ids), length(approved_rcs$spec$knots), length(approved_rcs$spec$grid)),
      status = c(
        ifelse(length(complete_ids) > 0L, "PASS", "FAIL"),
        ifelse(length(p_ids) > 0L, "PASS", "FAIL"),
        ifelse(length(approved_rcs$spec$knots) == 4L, "PASS", "FAIL"),
        ifelse(length(approved_rcs$spec$grid) == 200L, "PASS", "FAIL")
      ),
      stringsAsFactors = FALSE
    )
  )
}

run_component_sensitivity <- function(completed, endpoint_row, root = ".") {
  prepared <- lapply(completed, function(data) {
    data$log2_AST <- log2(data$AST)
    data$log2_ALT <- log2(data$ALT)
    data
  })
  full_text <- build_component_formula_text(endpoint_row, root)
  covariates <- split_registry_terms(read_model_spec("M5", root)$covariates[[1L]])
  reduced_text <- sprintf(
    "survival::Surv(%s, %s) ~ %s",
    endpoint_row$time_variable[[1L]], endpoint_row$event_variable[[1L]], paste(covariates, collapse = " + ")
  )
  full <- fit_formula_across_imputations(prepared, full_text, retain_diagnostics = TRUE)
  reduced <- fit_formula_across_imputations(prepared, reduced_text)
  conditional <- pool_sensitivity_terms(
    full,
    data.frame(
      term = c("log2_AST", "log2_ALT"),
      contrast = c("AST_CONDITIONAL_PER_DOUBLING", "ALT_CONDITIONAL_PER_DOUBLING"),
      multiplier = 1,
      stringsAsFactors = FALSE
    ),
    "B03", "JOINT_LOG2_AST_LOG2_ALT", endpoint_row, "M5", "JOINT_LOG2_AST_LOG2_ALT"
  )
  # 对 AST 与 ALT 两参数联合假设执行锁定的 D1 pooling。
  joint <- tryCatch(run_locked_d1(full$fits, reduced$fits, "component_joint_test", root), error = function(error) NULL)
  if (!exists("model_signature_sha256", mode = "function")) {
    source(file.path(root, "R", "model_signature.R"))
  }
  joint_signature <- model_signature_sha256(
    endpoint = endpoint_row$event_variable[[1L]], population = "MAIN_EXPOSURE_ELIGIBLE",
    exposure = "AST_ALT", exposure_scale = "JOINT_LOG2_AST_LOG2_ALT",
    formula_text = full_text, factor_references = character(), ties_method = "efron",
    time_origin = "baseline", time_function = "fixed", tve_terms = character(),
    contrast = "AST_ALT_JOINT_D1", pooling_method = "D1_JOINT_WALD",
    confidence_level = 0.95, scientific_config_revision = "r04"
  )
  joint_row <- data.frame(
    sensitivity_id = "B03", analysis_variant = "JOINT_LOG2_AST_LOG2_ALT",
    endpoint = endpoint_row$event_variable[[1L]], model_id = "M5",
    model_signature_sha256 = joint_signature,
    exposure_form = "JOINT_LOG2_AST_LOG2_ALT", contrast = "AST_ALT_JOINT_D1",
    time_month = NA_real_, n = if (nrow(conditional)) conditional$n[[1L]] else NA_integer_,
    events = if (nrow(conditional)) conditional$events[[1L]] else NA_integer_,
    beta = NA_real_, se = NA_real_, hr = NA_real_, lower_95_ci = NA_real_, upper_95_ci = NA_real_,
    p_value = if (is.null(joint)) NA_real_ else joint$p_value[[1L]],
    valid_imputation_n = if (is.null(joint)) sum(!vapply(full$fits, is.null, logical(1))) else joint$valid_imputation_n[[1L]],
    analysis_status = ifelse(is.null(joint), "NOT_ESTIMABLE", "ESTIMABLE"),
    reason_code = ifelse(is.null(joint), "NE_COMPONENT_D1_FAILURE", ""),
    joint_statistic = if (is.null(joint)) NA_real_ else joint$statistic[[1L]],
    joint_df1 = if (is.null(joint)) NA_real_ else joint$numerator_df[[1L]],
    joint_df2 = if (is.null(joint)) NA_real_ else joint$denominator_df[[1L]],
    stringsAsFactors = FALSE
  )
  schoenfeld <- run_component_schoenfeld_extensions(full$fits, root)
  list(
    standard = decorate_sensitivity_results(bind_rows_fill(list(conditional, joint_row))),
    schoenfeld = schoenfeld,
    fit_receipt = data.frame(
      metric = c("B03_FULL_INITIAL_FIT_N", "B03_REDUCED_INITIAL_FIT_N", "B03_SCHOENFELD_ADDITIONAL_FIT_N"),
      value = c(length(full$fits), length(reduced$fits), schoenfeld$fit_count_added),
      expected = c(20L, 20L, 0L), stringsAsFactors = FALSE
    )
  )
}

run_mi_information_sensitivity <- function(per_imputation, canonical) {
  subset <- per_imputation[per_imputation$model_id == "M5", , drop = FALSE]
  if (!nrow(subset)) return(data.frame())
  if (!is.data.frame(canonical) ||
      !all(c("endpoint", "model_id", "exposure_parameterization", "contrast",
        "time_month", "model_signature_sha256") %in% names(canonical))) {
    stop("A13_MODEL_SIGNATURE_SOURCE_INVALID", call. = FALSE)
  }
  keys <- unique(subset[c("endpoint", "model_id", "exposure_form", "contrast", "time_month")])
  rows <- lapply(seq_len(nrow(keys)), function(index) {
    key <- keys[index, , drop = FALSE]
    data <- subset[
      subset$endpoint == key$endpoint &
        subset$model_id == key$model_id &
        subset$exposure_form == key$exposure_form &
        subset$contrast == key$contrast &
        subset$time_month == key$time_month,
      ,
      drop = FALSE
    ]
    keep <- is.finite(data$estimate) & is.finite(data$variance) & data$variance >= 0
    q <- data$estimate[keep]
    u <- data$variance[keep]
    m <- length(q)
    signature_rows <- canonical[
      canonical$endpoint == key$endpoint & canonical$model_id == key$model_id &
        canonical$exposure_parameterization == key$exposure_form &
        canonical$contrast == key$contrast & canonical$time_month == key$time_month,
      , drop = FALSE
    ]
    signature <- unique(as.character(signature_rows$model_signature_sha256))
    if (length(signature) != 1L || !grepl("^[0-9a-f]{64}$", signature)) {
      stop("A13_MODEL_SIGNATURE_SOURCE_CARDINALITY_INVALID", call. = FALSE)
    }
    pooled <- if (m == 20L) tryCatch(pool_scalar_rubin(q, u), error = function(error) NULL) else NULL
    riv <- if (is.null(pooled)) NA_real_ else ((1 + 1 / m) * pooled$between_variance[[1L]]) / pooled$within_variance[[1L]]
    lambda <- if (is.null(pooled)) NA_real_ else ((1 + 1 / m) * pooled$between_variance[[1L]]) / pooled$total_variance[[1L]]
    fmi <- if (is.null(pooled)) NA_real_ else lambda + (1 - lambda) * 2 / (pooled$df[[1L]] + 3)
    relative_efficiency <- if (is.null(pooled)) NA_real_ else 1 / (1 + fmi / m)
    mc_error <- if (is.null(pooled)) NA_real_ else sqrt(pooled$between_variance[[1L]] / m)
    data.frame(
      sensitivity_id = "A13", analysis_variant = "RUBIN_INFORMATION_METRICS",
      endpoint = key$endpoint, model_id = key$model_id, exposure_form = key$exposure_form,
      model_signature_sha256 = signature,
      contrast = key$contrast, time_month = key$time_month,
      beta = if (is.null(pooled)) NA_real_ else pooled$pooled_estimate[[1L]],
      se = if (is.null(pooled)) NA_real_ else pooled$se[[1L]],
      hr = if (is.null(pooled)) NA_real_ else exp(pooled$pooled_estimate[[1L]]),
      lower_95_ci = if (is.null(pooled)) NA_real_ else exp(pooled$lower[[1L]]),
      upper_95_ci = if (is.null(pooled)) NA_real_ else exp(pooled$upper[[1L]]),
      p_value = if (is.null(pooled)) NA_real_ else pooled$p_value[[1L]],
      valid_imputation_n = m, fmi = fmi, riv = riv,
      relative_efficiency = relative_efficiency, mc_error = mc_error,
      mc_error_to_pooled_se = ifelse(is.null(pooled) || pooled$se[[1L]] == 0, NA_real_, mc_error / pooled$se[[1L]]),
      analysis_status = ifelse(is.null(pooled), "NOT_ESTIMABLE", "ESTIMABLE"),
      reason_code = ifelse(is.null(pooled), "NE_MI_INFORMATION_REQUIRES_20", ""),
      stringsAsFactors = FALSE
    )
  })
  decorate_sensitivity_results(do.call(rbind, rows))
}

map_secondary_estimands <- function(fixed, tve, endpoint_row, exposure_scale, root = ".") {
  registry <- utils::read.csv(file.path(root, "config", "estimand_registry.csv"), stringsAsFactors = FALSE, check.names = FALSE)
  expected <- registry[registry$endpoint == endpoint_row$event_variable[[1L]] & registry$endpoint_role == "supplementary", , drop = FALSE]
  rows <- lapply(seq_len(nrow(expected)), function(index) {
    target <- expected[index, , drop = FALSE]
    source <- if (target$estimand_type[[1L]] == "FIXED_HR") fixed else tve
    source_form <- if (target$exposure_parameterization[[1L]] == "LOG2_AST_ALT") "log2_AST_ALT" else "AST_ALT_Tertile"
    source_contrast <- switch(
      target$contrast[[1L]],
      PER_DOUBLING = "per_doubling",
      PER_1_SD = "per_doubling",
      PER_IQR = "per_doubling",
      T2_vs_T1 = "T2_vs_T1",
      T3_vs_T1 = "T3_vs_T1",
      target$contrast[[1L]]
    )
    matched <- source[
      source$model_id == target$model_id[[1L]] &
        source$exposure_parameterization == source_form &
        source$contrast == source_contrast,
      ,
      drop = FALSE
    ]
    if (target$estimand_type[[1L]] == "TIME_SPECIFIC_HR") {
      matched <- matched[matched$time_month == target$time_month[[1L]], , drop = FALSE]
    }
    if (nrow(matched) == 1L && target$contrast[[1L]] %in% c("PER_1_SD", "PER_IQR")) {
      multiplier <- if (target$contrast[[1L]] == "PER_1_SD") exposure_scale$log2_sd[[1L]] else exposure_scale$log2_iqr[[1L]]
      matched <- rescale_canonical_row(matched, multiplier, target$contrast[[1L]])
    }
    if (nrow(matched) != 1L) {
      return(data.frame(
        estimand_id = target$estimand_id[[1L]], endpoint = target$endpoint[[1L]],
        model_id = target$model_id[[1L]], exposure_parameterization = target$exposure_parameterization[[1L]],
        contrast = target$contrast[[1L]], time_month = target$time_month[[1L]],
        beta = NA_real_, se = NA_real_, hr = NA_real_, lower_95_ci = NA_real_, upper_95_ci = NA_real_,
        p_value = NA_real_, valid_imputation_n = 0L, estimate_status = "NOT_ESTIMABLE",
        not_estimable_reason_code = "NE_REGISTERED_ESTIMAND_SOURCE_MISSING", stringsAsFactors = FALSE
      ))
    }
    matched$estimand_id <- target$estimand_id[[1L]]
    matched$exposure_parameterization <- target$exposure_parameterization[[1L]]
    matched$contrast <- target$contrast[[1L]]
    matched
  })
  output <- bind_rows_fill(rows)
  output$sensitivity_id <- "B04"
  output$analysis_variant <- "EXACT_REGISTERED_SECONDARY_ESTIMAND"
  output$analysis_status <- output$estimate_status
  output$reason_code <- output$not_estimable_reason_code
  decorate_sensitivity_results(output)
}

run_secondary_endpoint_sensitivity <- function(completed, imp0, endpoint_registry, exposure_scale, root = ".") {
  endpoints <- endpoint_registry[endpoint_registry$endpoint_role == "supplementary", , drop = FALSE]
  rows <- lapply(seq_len(nrow(endpoints)), function(index) {
    endpoint <- endpoints[index, , drop = FALSE]
    if (!all(c(endpoint$event_variable[[1L]], endpoint$time_variable[[1L]]) %in% names(completed[[1L]]))) {
      return(data.frame())
    }
    fixed <- run_fixed_cox_stage(completed, endpoint, root)$canonical
    tve <- run_tve_stage(
      completed, endpoint, exposure_scale, local_riskset(imp0, endpoint), root,
      scientific_config_revision = "r04"
    )$canonical
    map_secondary_estimands(fixed, tve, endpoint, exposure_scale, root)
  })
  decorate_sensitivity_results(bind_rows_fill(rows))
}

run_landmark_sensitivity <- function(completed, endpoint_row, exposure_scale, root = ".") {
  landmarks <- sensitivity_parameter(read_sensitivity_parameters(root), "B01", "landmark_months", "numeric_vector")
  rows <- lapply(landmarks, function(landmark) {
    prepared <- lapply(completed, function(data) {
      keep <- data[[endpoint_row$time_variable[[1L]]]] > landmark
      data <- data[keep, , drop = FALSE]
      data[[endpoint_row$time_variable[[1L]]]] <- data[[endpoint_row$time_variable[[1L]]]] - landmark
      data
    })
    output <- run_primary_model_variant(
      prepared, endpoint_row, exposure_scale, "B01",
      paste0("LANDMARK_", landmark, "_MONTH"), include_tve = FALSE, root = root
    )
    output$landmark_month <- landmark
    output
  })
  decorate_sensitivity_results(bind_rows_fill(rows))
}

.sensitivity_canonicalize <- function(value) {
  if (is.data.frame(value)) {
    return(lapply(seq_len(nrow(value)), function(index) {
      .sensitivity_canonicalize(as.list(value[index, , drop = FALSE]))
    }))
  }
  if (is.list(value)) {
    if (!is.null(names(value))) value <- value[order(names(value))]
    return(lapply(value, .sensitivity_canonicalize))
  }
  if (!is.null(names(value))) {
    return(lapply(as.list(value[order(names(value))]), .sensitivity_canonicalize))
  }
  value
}

.sensitivity_canonical_json <- function(value) {
  # 加载 JSON 包并生成分支信封的规范序列化。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  as.character(jsonlite::toJSON(
    .sensitivity_canonicalize(value), auto_unbox = TRUE, null = "null",
    na = "null", digits = 17L, pretty = FALSE
  ))
}

.sensitivity_sha256_text <- function(value) {
  # 加载摘要包并计算分支内容身份。
  if (!requireNamespace("digest", quietly = TRUE)) stop("digest is required", call. = FALSE)
  digest::digest(
    enc2utf8(paste(value, collapse = "\n")),
    algo = "sha256", serialize = FALSE
  )
}

.sensitivity_no_retry_identity <- function(sensitivity_id) {
  .sensitivity_sha256_text(c("A06_NO_RETRY", sensitivity_id))
}

read_sensitivity_retry_identity <- function(run_root, sensitivity_id) {
  directory <- file.path(run_root, "control", "a06_retry_requests", sensitivity_id)
  files <- if (dir.exists(directory)) {
    list.files(directory, pattern = "^[0-9a-f]{64}[.]json$", full.names = TRUE)
  } else character()
  if (!length(files)) return(.sensitivity_no_retry_identity(sensitivity_id))
  if (length(files) != 1L) stop("A06_RETRY_REQUEST_CARDINALITY_INVALID: ", sensitivity_id, call. = FALSE)
  observed <- .sensitivity_sha256_text(paste(readLines(files[[1L]], warn = FALSE), collapse = "\n"))
  if (!identical(basename(files[[1L]]), paste0(observed, ".json"))) {
    stop("A06_RETRY_REQUEST_IDENTITY_MISMATCH: ", sensitivity_id, call. = FALSE)
  }
  request <- jsonlite::read_json(files[[1L]], simplifyVector = TRUE)
  required <- c(
    "schema_version", "sensitivity_id", "previous_failure_signature_sha256",
    "repair_revision_sha256", "approved_action"
  )
  if (!is.list(request) || !identical(sort(names(request)), sort(required)) ||
      !identical(request$schema_version, "1.0.0") ||
      !identical(request$sensitivity_id, sensitivity_id) ||
      !identical(request$approved_action, "RETRY_SAME_SEMANTICS") ||
      any(!grepl("^[0-9a-f]{64}$", c(
        request$previous_failure_signature_sha256, request$repair_revision_sha256
      )))) {
    stop("A06_RETRY_REQUEST_SCHEMA_INVALID: ", sensitivity_id, call. = FALSE)
  }
  observed
}

write_sensitivity_retry_request <- function(
    run_root, sensitivity_id, previous_failure_signature_sha256,
    repair_revision_sha256) {
  registry_ids <- read_sensitivity_registry(Sys.getenv("AST_ALT_PROJECT_ROOT", unset = "."))$sensitivity_id
  if (!sensitivity_id %in% registry_ids ||
      any(!grepl("^[0-9a-f]{64}$", c(
        previous_failure_signature_sha256, repair_revision_sha256
      )))) stop("A06_RETRY_REQUEST_INPUT_INVALID", call. = FALSE)
  object <- list(
    schema_version = "1.0.0",
    sensitivity_id = sensitivity_id,
    previous_failure_signature_sha256 = previous_failure_signature_sha256,
    repair_revision_sha256 = repair_revision_sha256,
    approved_action = "RETRY_SAME_SEMANTICS"
  )
  text <- .sensitivity_canonical_json(object)
  sha <- .sensitivity_sha256_text(text)
  directory <- file.path(run_root, "control", "a06_retry_requests", sensitivity_id)
  existing <- if (dir.exists(directory)) list.files(directory, full.names = TRUE) else character()
  if (length(existing)) stop("A06_RETRY_REQUEST_ALREADY_EXISTS: ", sensitivity_id, call. = FALSE)
  if (!exists(".control_write_atomic", mode = "function")) {
    source(file.path(Sys.getenv("AST_ALT_PROJECT_ROOT", unset = "."), "R", "control_kernel.R"))
  }
  path <- file.path(directory, paste0(sha, ".json"))
  .control_write_atomic(path, text, mode = "0600")
  list(path = path, sha256 = sha)
}

make_sensitivity_branch_specs <- function(root = ".", run_root = "") {
  registry <- read_sensitivity_registry(root)
  lapply(seq_len(nrow(registry)), function(index) {
    spec <- registry[index, , drop = FALSE]
    spec$retry_identity_sha256 <- if (nzchar(run_root)) {
      read_sensitivity_retry_identity(run_root, spec$sensitivity_id[[1L]])
    } else {
      .sensitivity_no_retry_identity(spec$sensitivity_id[[1L]])
    }
    spec
  })
}

sensitivity_branch_envelope <- function(
    sensitivity_id, standard = data.frame(), loio = data.frame(), loco = data.frame(),
    secondary = data.frame(), rcs = data.frame(), diagnostics = data.frame(),
    rcs_cutoff = data.frame(), schoenfeld_trend = data.frame(), schoenfeld_status = data.frame(),
    retry_identity_sha256 = .sensitivity_no_retry_identity(sensitivity_id),
    branch_status = NULL, branch_error = data.frame()) {
  result_frames <- list(standard, loio, loco, secondary, rcs)
  result_rows <- bind_rows_fill(result_frames)
  analysis_status <- if (nrow(result_rows) && any(result_rows$analysis_status == "ESTIMABLE", na.rm = TRUE)) "ESTIMABLE" else "NOT_ESTIMABLE"
  if (is.null(branch_status)) branch_status <- if (identical(analysis_status, "ESTIMABLE")) "PASS" else "NOT_ESTIMABLE"
  envelope <- list(
    envelope_schema_version = "A06_SENSITIVITY_BRANCH_ENVELOPE_V43_V1",
    sensitivity_id = sensitivity_id,
    branch_status = branch_status,
    retry_identity_sha256 = retry_identity_sha256,
    standard = standard,
    loio = loio,
    loco = loco,
    secondary = secondary,
    rcs = rcs,
    rcs_cutoff = rcs_cutoff,
    schoenfeld_trend = schoenfeld_trend,
    schoenfeld_status = schoenfeld_status,
    diagnostics = diagnostics,
    branch_error = branch_error,
    coverage = data.frame(
      sensitivity_id = sensitivity_id,
      branch_status = branch_status,
      analysis_status = if (identical(branch_status, "FAILED_TYPED")) "FAILED_TYPED" else analysis_status,
      retry_identity_sha256 = retry_identity_sha256,
      stringsAsFactors = FALSE
    )
  )
  envelope$result_identity_sha256 <- .sensitivity_sha256_text(.sensitivity_canonical_json(envelope))
  envelope
}

.sensitivity_branch_failure_envelope <- function(
    sensitivity_id, condition, retry_identity_sha256) {
  message <- conditionMessage(condition)
  if (exists("canonicalize_failure_message", mode = "function")) {
    message <- canonicalize_failure_message(message)
  } else {
    message <- gsub("(/[A-Za-z0-9._-]+)+", "<PATH>", message, perl = TRUE)
  }
  signature <- .sensitivity_sha256_text(c(
    sensitivity_id, class(condition)[[1L]], message, retry_identity_sha256
  ))
  error <- data.frame(
    sensitivity_id = sensitivity_id,
    error_class = class(condition)[[1L]],
    reason_code = "SENSITIVITY_BRANCH_EXECUTION_FAILED",
    failure_signature_sha256 = signature,
    canonical_message = message,
    retry_identity_sha256 = retry_identity_sha256,
    stringsAsFactors = FALSE
  )
  sensitivity_branch_envelope(
    sensitivity_id = sensitivity_id,
    retry_identity_sha256 = retry_identity_sha256,
    branch_status = "FAILED_TYPED",
    branch_error = error
  )
}

validate_sensitivity_branch_envelope <- function(envelope) {
  required <- c(
    "envelope_schema_version", "sensitivity_id", "branch_status",
    "retry_identity_sha256", "standard", "loio", "loco", "secondary",
    "rcs", "rcs_cutoff", "schoenfeld_trend", "schoenfeld_status",
    "diagnostics", "branch_error", "coverage", "result_identity_sha256"
  )
  if (!is.list(envelope) || !identical(sort(names(envelope)), sort(required)) ||
      !identical(envelope$envelope_schema_version, "A06_SENSITIVITY_BRANCH_ENVELOPE_V43_V1") ||
      !envelope$branch_status %in% c("PASS", "NOT_ESTIMABLE", "FAILED_TYPED") ||
      any(!grepl("^[0-9a-f]{64}$", c(
        envelope$retry_identity_sha256, envelope$result_identity_sha256
      ))) || !is.data.frame(envelope$coverage) || nrow(envelope$coverage) != 1L ||
      !identical(envelope$coverage$sensitivity_id[[1L]], envelope$sensitivity_id) ||
      !identical(envelope$coverage$branch_status[[1L]], envelope$branch_status)) {
    stop("A06_BRANCH_ENVELOPE_SCHEMA_INVALID", call. = FALSE)
  }
  payload <- envelope
  supplied <- payload$result_identity_sha256
  payload$result_identity_sha256 <- NULL
  observed <- .sensitivity_sha256_text(.sensitivity_canonical_json(payload))
  if (!identical(supplied, observed)) stop("A06_BRANCH_ENVELOPE_IDENTITY_MISMATCH", call. = FALSE)
  if (identical(envelope$branch_status, "FAILED_TYPED") != (nrow(envelope$branch_error) == 1L)) {
    stop("A06_BRANCH_ERROR_CARDINALITY_INVALID", call. = FALSE)
  }
  invisible(TRUE)
}

.run_sensitivity_branch_impl <- function(spec, state, context = stage_context()) {
  id <- spec$sensitivity_id[[1L]]
  root <- context$project_root
  completed <- state$exposure$completed
  imp0 <- state$sources$imp0
  mask <- state$sources$missing_mask
  exposure_scale <- state$exposure$exposure_scale
  primary <- state$endpoint_registry[state$endpoint_registry$endpoint_id == "EP01", , drop = FALSE]
  m5 <- split_registry_terms(read_model_spec("M5", root)$covariates[[1L]])
  if (id == "A01") {
    reused <- bind_rows_fill(list(
      canonical_to_sensitivity(state$fixed_stage$canonical[state$fixed_stage$canonical$model_id == "M5", , drop = FALSE], "A01", "REUSED_FIXED_M5"),
      canonical_to_sensitivity(state$tve_stage$canonical[state$tve_stage$canonical$model_id == "M5", , drop = FALSE], "A01", "REUSED_G12_TVE_M5")
    ))
    return(sensitivity_branch_envelope(id, standard = decorate_sensitivity_results(reused)))
  }
  if (id == "A02") return(sensitivity_branch_envelope(id, standard = run_piecewise_sensitivity(completed, primary, root)))
  if (id == "A03") return(sensitivity_branch_envelope(id, standard = build_multiscale_reuse(state$fixed_stage$canonical, state$tve_stage$canonical, exposure_scale)))
  if (id %in% c("A04", "A05", "B02")) {
    patient_ids <- define_sensitivity_patient_ids(id, imp0, mask, primary, root)
    label <- switch(id, A04 = "COMPLETE_CASE_FROZEN_SET", A05 = "ORIGINALLY_OBSERVED_ALB_CREATININE_LYMPH", B02 = "ORIGINAL_AST_ALT_LE_40")
    rows <- run_primary_model_variant(
      subset_completed_by_ids(completed, patient_ids), primary, exposure_scale, id, label,
      population = label, root = root
    )
    return(sensitivity_branch_envelope(
      id, standard = rows,
      diagnostics = data.frame(sensitivity_id = id, metric = "frozen_patient_n", value = length(patient_ids), status = ifelse(length(patient_ids) > 0L, "PASS", "FAIL"), stringsAsFactors = FALSE)
    ))
  }
  if (id == "A06") {
    rows <- pool_loio_contrasts(state$tve_stage$per_imputation[state$tve_stage$per_imputation$model_id == "M5", , drop = FALSE], root)
    return(sensitivity_branch_envelope(id, loio = rows))
  }
  if (id == "A07") {
    required <- c("eGFR_calc", "HGB")
    if (!all(required %in% names(completed[[1L]]))) return(sensitivity_branch_envelope(id))
    covariates <- c(setdiff(m5, c("CKD_bin", "Anemia")), required)
    return(sensitivity_branch_envelope(id, standard = run_primary_model_variant(completed, primary, exposure_scale, id, "REPLACE_CKD_ANEMIA_WITH_EGFR_HGB", covariates = covariates, root = root)))
  }
  if (id == "A08") return(sensitivity_branch_envelope(id, loco = run_loco_sensitivity(completed, primary, exposure_scale, root)))
  if (id == "A09") {
    rcs <- run_rcs_shape_sensitivity(completed, imp0, mask, primary, exposure_scale, state$rcs_stage, root)
    return(sensitivity_branch_envelope(
      id, standard = rcs$standard, rcs = rcs$rcs,
      rcs_cutoff = rcs$rcs_cutoff, diagnostics = rcs$diagnostics
    ))
  }
  if (id == "A10") {
    covariates <- setdiff(m5, sensitivity_parameter(read_sensitivity_parameters(root), id, "removed_covariates", "string_vector"))
    return(sensitivity_branch_envelope(id, standard = run_primary_model_variant(completed, primary, exposure_scale, id, "OMIT_THREE_MEDICATIONS", covariates = covariates, root = root)))
  }
  if (id == "A11") {
    covariates <- setdiff(m5, sensitivity_parameter(read_sensitivity_parameters(root), id, "removed_covariates", "string_vector"))
    return(sensitivity_branch_envelope(id, standard = run_primary_model_variant(completed, primary, exposure_scale, id, "OMIT_SURGERY_TYPE_SAME_POPULATION", covariates = covariates, root = root)))
  }
  if (id == "A12") {
    model_id <- sensitivity_parameter(read_sensitivity_parameters(root), id, "minimal_model_id", "string")
    covariates <- split_registry_terms(read_model_spec(model_id, root)$covariates[[1L]])
    return(sensitivity_branch_envelope(id, standard = run_primary_model_variant(completed, primary, exposure_scale, id, "REGISTERED_M3", model_id = model_id, covariates = covariates, root = root)))
  }
  if (id == "A13") return(sensitivity_branch_envelope(
    id,
    standard = run_mi_information_sensitivity(
      state$tve_stage$per_imputation, state$tve_stage$canonical
    )
  ))
  if (id == "B01") return(sensitivity_branch_envelope(id, standard = run_landmark_sensitivity(completed, primary, exposure_scale, root)))
  if (id == "B03") {
    component <- run_component_sensitivity(completed, primary, root)
    layer1_path <- file.path(context$run_root, "stage_work", "A06", "schoenfeld_component_layer1.rds")
    dir.create(dirname(layer1_path), recursive = TRUE, showWarnings = FALSE)
    # 保存 AST/ALT 事件级残差与 cox.zph 对象到受限 Layer 1；公开分支只携带聚合趋势。
    saveRDS(list(
      event_level = component$schoenfeld$restricted_event_level,
      zph_objects = component$schoenfeld$restricted_zph_objects
    ), layer1_path, compress = "xz")
    return(sensitivity_branch_envelope(
      id, standard = component$standard,
      schoenfeld_trend = component$schoenfeld$public_trend,
      schoenfeld_status = component$schoenfeld$status,
      diagnostics = transform(component$fit_receipt, sensitivity_id = "B03", status = ifelse(value == expected, "PASS", "FAIL"))
    ))
  }
  if (id == "B04") return(sensitivity_branch_envelope(id, secondary = run_secondary_endpoint_sensitivity(completed, state$exposure$imp0_eligible, state$endpoint_registry, exposure_scale, root)))
  if (id == "B05") {
    descriptive <- state$fixed_stage$canonical[
      state$fixed_stage$canonical$model_id == "M5" &
        state$fixed_stage$canonical$exposure_parameterization == "AST_ALT_Tertile",
      ,
      drop = FALSE
    ]
    return(sensitivity_branch_envelope(id, standard = canonical_to_sensitivity(descriptive, id, "OPTIONAL_TERTILE_DESCRIPTION")))
  }
  stop("No implementation for sensitivity branch: ", id, call. = FALSE)
}

run_sensitivity_branch <- function(spec, state, context = stage_context()) {
  if (!is.data.frame(spec) || nrow(spec) != 1L ||
      !all(c("sensitivity_id", "retry_identity_sha256") %in% names(spec))) {
    stop("A06_BRANCH_SPEC_INVALID", call. = FALSE)
  }
  id <- spec$sensitivity_id[[1L]]
  retry_identity <- spec$retry_identity_sha256[[1L]]
  envelope <- tryCatch(
    .run_sensitivity_branch_impl(spec, state, context),
    error = function(condition) {
      .sensitivity_branch_failure_envelope(id, condition, retry_identity)
    }
  )
  envelope$retry_identity_sha256 <- retry_identity
  envelope$coverage$retry_identity_sha256 <- retry_identity
  envelope$result_identity_sha256 <- NULL
  envelope$result_identity_sha256 <- .sensitivity_sha256_text(.sensitivity_canonical_json(envelope))
  validate_sensitivity_branch_envelope(envelope)
  envelope
}

combine_sensitivity_branches <- function(branches, root = ".") {
  branches <- unlist(lapply(branches, function(branch) {
    if (is.list(branch) && !is.null(branch$sensitivity_id)) list(branch) else branch
  }), recursive = FALSE)
  if (!length(branches)) stop("No sensitivity branches were produced", call. = FALSE)
  invisible(lapply(branches, validate_sensitivity_branch_envelope))
  registry_ids <- read_sensitivity_registry(root)$sensitivity_id
  observed_ids <- unname(vapply(branches, `[[`, character(1), "sensitivity_id"))
  if (anyDuplicated(observed_ids) ||
      !identical(sort(observed_ids, method = "radix"), sort(registry_ids, method = "radix"))) {
    stop("A06_BRANCH_REGISTRY_CLOSURE_FAILED", call. = FALSE)
  }
  branches <- branches[match(registry_ids, observed_ids)]
  output <- list(
    standard = decorate_sensitivity_results(bind_rows_fill(lapply(branches, `[[`, "standard"))),
    loio = decorate_sensitivity_results(bind_rows_fill(lapply(branches, `[[`, "loio"))),
    loco = decorate_sensitivity_results(bind_rows_fill(lapply(branches, `[[`, "loco"))),
    secondary = decorate_sensitivity_results(bind_rows_fill(lapply(branches, `[[`, "secondary"))),
    rcs = decorate_sensitivity_results(bind_rows_fill(lapply(branches, `[[`, "rcs"))),
    rcs_cutoff = bind_rows_fill(lapply(branches, `[[`, "rcs_cutoff")),
    schoenfeld_trend = bind_rows_fill(lapply(branches, `[[`, "schoenfeld_trend")),
    schoenfeld_status = bind_rows_fill(lapply(branches, `[[`, "schoenfeld_status")),
    diagnostics = bind_rows_fill(lapply(branches, `[[`, "diagnostics")),
    branch_errors = bind_rows_fill(lapply(branches, `[[`, "branch_error")),
    branch_coverage = bind_rows_fill(lapply(branches, `[[`, "coverage"))
  )
  if (!ncol(output$branch_errors)) {
    output$branch_errors <- data.frame(
      sensitivity_id = character(), error_class = character(),
      reason_code = character(), failure_signature_sha256 = character(),
      canonical_message = character(), retry_identity_sha256 = character(),
      stringsAsFactors = FALSE
    )
  }
  output$coverage <- validate_sensitivity_coverage(output$branch_coverage, root)
  output
}

record_sensitivity_branch_progress <- function(branch, context) {
  validate_sensitivity_branch_envelope(branch)
  write_stage_branch_progress_receipt(
    run_id = context$run_id,
    stage = "A06",
    target = "A06_sensitivity_branch",
    branch_type = "sensitivity_id",
    branch_id = branch$sensitivity_id,
    stage_request_sha256 = context$stage_request_semantic_sha256,
    result_sha256 = branch$result_identity_sha256,
    root = context$run_root
  )$path
}

run_a06_ipcw_timepoint <- function(state, time_month, context = stage_context()) {
  data <- state$exposure$imp0_eligible
  endpoint <- state$endpoint_registry[state$endpoint_registry$endpoint_id == "EP01", , drop = FALSE]
  required <- c("AST_ALT", endpoint$time_variable[[1L]], endpoint$event_variable[[1L]])
  if (!is.data.frame(data) || nrow(endpoint) != 1L || any(!required %in% names(data))) {
    stop("A06_IPCW_FROZEN_COHORT_INVALID", call. = FALSE)
  }
  registered_times <- c(6, 12, 24, 36)
  if (!time_month %in% registered_times) stop("A06_IPCW_TIMEPOINT_UNREGISTERED", call. = FALSE)
  streams <- make_ipcw_rng_streams(registered_times, seed = 42103L)
  time <- data[[endpoint$time_variable[[1L]]]]
  event <- data[[endpoint$event_variable[[1L]]]]
  marker <- data$AST_ALT
  estimate <- tryCatch(
    run_ipcw_timepoint(
      time, event, marker, time_month,
      bootstrap_n = 1000L, rng_stream = streams[[as.character(time_month)]]
    ),
    error = function(condition) list(error = conditionMessage(condition))
  )
  if (!is.null(estimate$error)) {
    return(list(
      time_month = time_month,
      summary = data.frame(
        time_month = time_month, auc = NA_real_, cutoff = NA_real_, sensitivity = NA_real_,
        specificity = NA_real_, youden_j = NA_real_, case_n = sum(event == 1L & time <= time_month),
        control_n = sum(time > time_month), g_time = NA_real_, maximum_weight = NA_real_,
        frozen_marker_median = if (all(is.finite(marker))) stats::median(marker) else NA_real_,
        auc_lower_95_ci = NA_real_, auc_upper_95_ci = NA_real_,
        cutoff_bootstrap_median = NA_real_, cutoff_bootstrap_iqr = NA_real_,
        cutoff_bootstrap_lower_95_ci = NA_real_, cutoff_bootstrap_upper_95_ci = NA_real_,
        valid_bootstrap_n = 0L, bootstrap_n = 1000L,
        status = "NOT_ESTIMABLE", reason_code = estimate$error, stringsAsFactors = FALSE
      ),
      public_roc = data.frame(
        time_month = time_month, fpr = seq(0, 1, length.out = 101L), tpr = NA_real_,
        status = "NOT_ESTIMABLE", reason_code = estimate$error, stringsAsFactors = FALSE
      ),
      gate = data.frame(
        time_month = time_month, check_id = "point_estimate", passed = FALSE,
        warning_class = "FAIL", status = "NOT_ESTIMABLE", reason_code = estimate$error,
        stringsAsFactors = FALSE
      ),
      restricted = list(thresholds = data.frame(), bootstrap = data.frame())
    ))
  }
  time_registry <- utils::read.csv(
    file.path(context$project_root, "config", "timepoint_registry.csv"),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  rule <- time_registry[time_registry$time_month == time_month, , drop = FALSE]
  if (nrow(rule) != 1L) stop("A06_IPCW_TIMEPOINT_RULE_INVALID", call. = FALSE)
  gate <- ipcw_validity_gate(
    estimate$summary, time, event, marker,
    minimum_at_risk_n = rule$minimum_at_risk_n[[1L]],
    minimum_at_risk_fraction = rule$minimum_at_risk_fraction[[1L]],
    minimum_cumulative_events = rule$minimum_cumulative_events[[1L]],
    minimum_valid_bootstrap_n = 950L
  )
  valid <- all(gate$passed) && all(gate$status == "VALID_YOUDEN_CUTOFF")
  failure_reason <- if (any(gate$warning_class == "BLOCKING_WARNING")) {
    "CENSOR_SURVIVAL_BELOW_0_10"
  } else {
    paste(gate$check_id[!gate$passed], collapse = "|")
  }
  estimate$summary$status <- ifelse(valid, "VALID_YOUDEN_CUTOFF", "NOT_ESTIMABLE")
  estimate$summary$reason_code <- ifelse(valid, "", failure_reason)
  estimate$public_roc$status <- estimate$summary$status[[1L]]
  estimate$public_roc$reason_code <- estimate$summary$reason_code[[1L]]
  list(
    time_month = time_month,
    summary = estimate$summary,
    public_roc = estimate$public_roc,
    gate = gate,
    restricted = list(
      thresholds = estimate$restricted_thresholds,
      bootstrap = estimate$restricted_bootstrap
    )
  )
}

.is_a06_ipcw_branch <- function(value) {
  is.list(value) && all(c("time_month", "summary", "public_roc", "gate", "restricted") %in% names(value))
}

.flatten_a06_ipcw_branches <- function(value) {
  if (.is_a06_ipcw_branch(value)) return(list(value))
  if (!is.list(value)) return(list())
  unlist(lapply(value, .flatten_a06_ipcw_branches), recursive = FALSE)
}

combine_a06_ipcw_timepoints <- function(branches) {
  branches <- .flatten_a06_ipcw_branches(branches)
  observed <- sort(vapply(branches, `[[`, numeric(1), "time_month"), method = "radix")
  if (!identical(observed, c(6, 12, 24, 36))) stop("A06_IPCW_TIMEPOINT_CLOSURE_INVALID", call. = FALSE)
  branches <- branches[match(c(6, 12, 24, 36), vapply(branches, `[[`, numeric(1), "time_month"))]
  list(
    summary = bind_rows_fill(lapply(branches, `[[`, "summary")),
    public_roc = bind_rows_fill(lapply(branches, `[[`, "public_roc")),
    gate = bind_rows_fill(lapply(branches, `[[`, "gate")),
    restricted = lapply(branches, `[[`, "restricted")
  )
}

finalize_a06_diagnostic_extensions <- function(state, analysis, ipcw, context = stage_context()) {
  variant_candidates <- analysis$rcs_cutoff
  rcs_stability <- validate_rcs_variant_stability(
    state$rcs_stage$cutoff$candidate,
    variant_candidates,
    maximum_difference_fraction = 0.10
  )
  data <- state$exposure$imp0_eligible
  endpoint <- state$endpoint_registry[state$endpoint_registry$endpoint_id == "EP01", , drop = FALSE]
  time <- data[[endpoint$time_variable[[1L]]]]
  event <- data[[endpoint$event_variable[[1L]]]]
  marker <- data$AST_ALT
  if (!is.list(state$schoenfeld_stage_a03) ||
      !is.data.frame(state$schoenfeld_stage_a03$status)) {
    stop("A06_APPROVED_A03_SCHOENFELD_STATE_MISSING", call. = FALSE)
  }
  a03_schoenfeld_status <- state$schoenfeld_stage_a03$status
  a03_schoenfeld_status$producer_stage <- "A03"
  a06_schoenfeld_status <- analysis$schoenfeld_status
  a06_schoenfeld_status$producer_stage <- "A06"
  analysis$schoenfeld_status_all <- bind_rows_fill(list(
    a03_schoenfeld_status, a06_schoenfeld_status
  ))
  roc_metadata_columns <- setdiff(
    names(ipcw$summary), c("status", "reason_code", "fpr", "tpr")
  )
  ipcw$public_roc <- merge(
    ipcw$public_roc,
    ipcw$summary[roc_metadata_columns],
    by = "time_month", all.x = TRUE, sort = FALSE
  )
  ipcw$public_roc <- ipcw$public_roc[
    order(ipcw$public_roc$time_month, ipcw$public_roc$fpr, method = "radix"),
    , drop = FALSE
  ]
  cutoff_specs <- data.frame(
    cutoff_source = c("RCS_STABLE", paste0("IPCW_M", sprintf("%02d", c(6, 12, 24, 36)))),
    cutoff = c(
      if (rcs_stability$status[[1L]] == "STABLE_RCS_CUTOFF") rcs_stability$cutoff_ast_alt[[1L]] else NA_real_,
      vapply(c(6, 12, 24, 36), function(value) {
        row <- ipcw$summary[ipcw$summary$time_month == value, , drop = FALSE]
        if (nrow(row) == 1L && row$status[[1L]] == "VALID_YOUDEN_CUTOFF") row$cutoff[[1L]] else NA_real_
      }, numeric(1))
    ),
    stringsAsFactors = FALSE
  )
  km <- lapply(seq_len(nrow(cutoff_specs)), function(index) {
    run_cutoff_km(
      time, event, marker, cutoff_specs$cutoff[[index]],
      cutoff_specs$cutoff_source[[index]], risk_times = c(0, 6, 12, 24, 36)
    )
  })
  km_status <- bind_rows_fill(lapply(km, `[[`, "status"))
  km_statistics <- bind_rows_fill(lapply(km, `[[`, "statistics"))
  km_curve <- bind_rows_fill(lapply(seq_along(km), function(index) {
    curve <- km[[index]]$curve
    status <- km[[index]]$status
    statistics <- km[[index]]$statistics
    curve$cutoff_status <- status$status[[1L]]
    curve$cutoff_reason_code <- status$reason_code[[1L]]
    for (column in c(
      "low_n", "high_n", "low_events", "high_events", "p_value",
      "annotation_p", "annotation_p_type", "significance_symbol"
    )) {
      curve[[column]] <- rep(statistics[[column]][[1L]], nrow(curve))
    }
    curve
  }))
  km_risk_table <- bind_rows_fill(lapply(km, `[[`, "risk_table"))
  status_publication <- transform(km_status, row_type = "STATUS", group = "", time_month = NA_real_, n_risk = NA_integer_)
  statistics_publication <- transform(km_statistics, row_type = "STATISTICS", group = "", time_month = NA_real_, n_risk = NA_integer_)
  risk_publication <- transform(km_risk_table, row_type = "RISKSET")
  analysis$rcs_cutoff_stability <- rcs_stability
  analysis$ipcw <- ipcw
  analysis$cutoff_km <- list(
    status = km_status,
    curve = km_curve,
    risk_table = km_risk_table,
    statistics = km_statistics,
    publication = bind_rows_fill(list(
      status_publication, statistics_publication, risk_publication
    ))
  )
  analysis
}

run_sensitivity_stage <- function(state, context = stage_context()) {
  specs <- make_sensitivity_branch_specs(context$project_root, context$run_root)
  branches <- lapply(specs, run_sensitivity_branch, state = state, context = context)
  combine_sensitivity_branches(branches, context$project_root)
}
