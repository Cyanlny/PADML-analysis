# TVE 时间函数：输入固定为月并以12个月中心化。
g12 <- function(time_months) {
  if (any(!is.finite(time_months)) || any(time_months < 0)) stop("Invalid follow-up time", call. = FALSE)
  log1p(time_months) - log(13)
}

# 计算单套插补的时间特异性线性对比及完整方差。
derive_tve_contrast <- function(beta, covariance, beta_term, gamma_term, time_month, multiplier = 1) {
  if (!all(c(beta_term, gamma_term) %in% names(beta))) stop("TVE coefficient missing", call. = FALSE)
  idx <- match(c(beta_term, gamma_term), names(beta))
  cvec <- multiplier * c(1, g12(time_month))
  estimate <- sum(cvec * beta[idx])
  variance <- as.numeric(t(cvec) %*% covariance[idx, idx, drop = FALSE] %*% cvec)
  list(estimate = estimate, variance = variance)
}

read_rutherford_tve_projection <- function(root = ".") {
  root <- normalizePath(root, mustWork = TRUE)
  path <- file.path(
    root, "protocol", "decisions", "approved",
    "RUTHERFORD_TVE_ESTIMAND_V43_001_SELECTION.json"
  )
  if (!file.exists(path)) stop("RUTHERFORD_TVE_SELECTION_RECEIPT_MISSING", call. = FALSE)
  # 加载 JSON 与摘要包并验证用户选择回执及 DecisionPackage 身份。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  if (!requireNamespace("digest", quietly = TRUE)) stop("digest is required", call. = FALSE)
  selection <- jsonlite::read_json(path, simplifyVector = TRUE)
  mapping <- unlist(
    selection$selected_rule$source_collection_to_parameterization,
    use.names = TRUE
  )
  contrasts <- unlist(selection$selected_rule$contrasts, use.names = TRUE)
  time_months <- as.integer(selection$selected_rule$time_months)
  package_path <- file.path(root, selection$decision_package_relative_path)
  valid <- identical(selection$decision_id, "RUTHERFORD_TVE_ESTIMAND_V43_001") &&
    identical(selection$selected_option_id, "RUTH_TVE_1C") &&
    identical(selection$status, "HUMAN_APPROVED") &&
    identical(selection$authority_class, "USER_SELECTION") &&
    identical(
      digest::digest(selection$selected_option_id, algo = "sha256", serialize = FALSE),
      selection$selection_sha256
    ) && file.exists(package_path) &&
    identical(digest::digest(file = package_path, algo = "sha256"), selection$decision_package_sha256) &&
    identical(
      mapping,
      c(
        M5__AST_ALT_Tertile = "Rutherford_TVE_ADJUSTED_AST_ALT_TERTILE",
        M5__log2_AST_ALT = "Rutherford_TVE_ADJUSTED_LOG2_AST_ALT"
      )
    ) && identical(
      contrasts,
      c(
        Rutherford_G34 = "Rutherford_Grade_3_4",
        Rutherford_G56 = "Rutherford_Grade_5_6"
      )
    ) && identical(time_months, c(6L, 12L, 24L, 36L)) &&
    identical(as.integer(selection$selected_rule$expected_row_n_per_primary_endpoint), 16L) &&
    identical(selection$selected_rule$a03_refit_required, FALSE) &&
    identical(selection$selected_rule$a06_sensitivity_definition_change, FALSE)
  if (!isTRUE(valid)) stop("RUTHERFORD_TVE_SELECTION_RECEIPT_INVALID", call. = FALSE)
  list(
    source_collection_to_parameterization = mapping,
    contrasts = contrasts,
    reference_category = selection$selected_rule$reference_category,
    time_months = time_months,
    expected_row_n = 16L,
    selection_sha256 = selection$selection_sha256
  )
}

# 校验同一连续模型派生尺度的代数恒等式。
validate_scale_identity <- function(log_hr_doubling, log_hr_sd, log_hr_iqr, frozen_sd, frozen_iqr, tolerance = 1e-10) {
  checks <- c(
    sd = abs(log_hr_sd - frozen_sd * log_hr_doubling),
    iqr = abs(log_hr_iqr - frozen_iqr * log_hr_doubling)
  )
  data.frame(check = names(checks), absolute_difference = as.numeric(checks), tolerance = tolerance, status = ifelse(checks <= tolerance, "PASS", "FAIL"))
}

prepare_tve_analysis_data <- function(data) {
  data <- normalize_cox_factor_levels(data)
  data$AST_ALT_T2 <- as.integer(data$AST_ALT_Tertile == "T2")
  data$AST_ALT_T3 <- as.integer(data$AST_ALT_Tertile == "T3")
  if ("Rutherford_cat" %in% names(data)) {
    data$Rutherford_G34 <- as.integer(as.character(data$Rutherford_cat) == "Grade 3-4")
    data$Rutherford_G56 <- as.integer(as.character(data$Rutherford_cat) == "Grade 5-6")
  }
  data
}

build_nuisance_tve_specs <- function(data, nuisance_terms = character()) {
  nuisance_terms <- setdiff(unique(nuisance_terms), c("log2_AST_ALT", "AST_ALT_Tertile", "Rutherford_cat"))
  if (!length(nuisance_terms)) return(list())
  lapply(nuisance_terms, function(term) {
    if (!term %in% names(data)) stop("Approved nuisance TVE variable is missing: ", term, call. = FALSE)
    value <- data[[term]]
    if (is.factor(value)) {
      levels <- levels(value)
      if (length(levels) < 2L) stop("Approved nuisance factor has fewer than two locked levels: ", term, call. = FALSE)
      safe_term <- gsub("[^A-Za-z0-9_]", "_", term)
      columns <- paste0("NUIS_TVE_", safe_term, "_L", seq_along(levels[-1L]) + 1L)
      list(parent_term = term, term_type = "multilevel", levels = levels, columns = columns)
    } else if (is.numeric(value) || is.integer(value) || is.logical(value)) {
      list(parent_term = term, term_type = "scalar", levels = character(), columns = term)
    } else {
      stop("Approved nuisance TVE variable lacks a locked numeric/factor type: ", term, call. = FALSE)
    }
  })
}

apply_nuisance_tve_specs <- function(data, specs) {
  for (spec in specs) {
    if (identical(spec$term_type, "multilevel")) {
      observed <- as.character(data[[spec$parent_term]])
      if (any(!is.na(observed) & !observed %in% spec$levels)) stop("Nuisance factor contains an unlocked level", call. = FALSE)
      for (j in seq_along(spec$columns)) data[[spec$columns[[j]]]] <- as.integer(observed == spec$levels[[j + 1L]])
    }
  }
  data
}

build_tve_formula_text <- function(model_id, endpoint_row, exposure_form, root = ".", covariates_override = NULL, include_rutherford_tve = TRUE, nuisance_specs = list()) {
  model <- read_model_spec(model_id, root)
  covariates <- if (is.null(covariates_override)) split_registry_terms(model$covariates[[1L]]) else covariates_override
  exposure_terms <- if (exposure_form == "log2_AST_ALT") "log2_AST_ALT" else c("AST_ALT_T2", "AST_ALT_T3")
  fixed_terms <- exposure_terms
  time_terms <- paste0("tt(", exposure_terms, ")")
  if (include_rutherford_tve && "Rutherford_cat" %in% covariates) {
    covariates <- setdiff(covariates, "Rutherford_cat")
    fixed_terms <- c(fixed_terms, "Rutherford_G34", "Rutherford_G56")
    time_terms <- c(time_terms, "tt(Rutherford_G34)", "tt(Rutherford_G56)")
  }
  for (spec in nuisance_specs) {
    if (!spec$parent_term %in% covariates) stop("Approved nuisance TVE term is not in the model covariate set: ", spec$parent_term, call. = FALSE)
    if (identical(spec$term_type, "multilevel")) {
      covariates <- setdiff(covariates, spec$parent_term)
      fixed_terms <- c(fixed_terms, spec$columns)
      time_terms <- c(time_terms, paste0("tt(", spec$columns, ")"))
    } else {
      time_terms <- c(time_terms, paste0("tt(", spec$parent_term, ")"))
    }
  }
  rhs <- c(fixed_terms, covariates, time_terms)
  sprintf(
    "survival::Surv(%s, %s) ~ %s",
    endpoint_row$time_variable[[1L]], endpoint_row$event_variable[[1L]], paste(rhs, collapse = " + ")
  )
}

make_tve_collection_spec <- function(
    completed, model_id, endpoint_row, exposure_form, root = ".",
    covariates_override = NULL, include_rutherford_tve = TRUE,
    nuisance_terms = character(), scientific_config_revision = "r02") {
  if (!is.list(completed) || length(completed) != 20L ||
      !model_id %in% paste0("M", 1:5) ||
      !exposure_form %in% c("AST_ALT_Tertile", "log2_AST_ALT")) {
    stop("A04_TVE_BRANCH_CONTRACT_INVALID", call. = FALSE)
  }
  reference_data <- prepare_tve_analysis_data(completed[[1L]])
  nuisance_specs <- build_nuisance_tve_specs(reference_data, nuisance_terms)
  formula_text <- build_tve_formula_text(model_id, endpoint_row, exposure_form, root, covariates_override, include_rutherford_tve, nuisance_specs)
  list(
    collection_key = paste(model_id, exposure_form, sep = "__"),
    formula_text = formula_text, model_id = model_id,
    exposure_form = exposure_form, endpoint_row = endpoint_row,
    nuisance_terms = nuisance_terms, nuisance_specs = nuisance_specs,
    scientific_config_revision = scientific_config_revision,
    time_function_id = "g12_log1p_centered_12m"
  )
}

make_tve_branch_specs <- function(
    completed, endpoint_row, root = ".", nuisance_terms = character(),
    scientific_config_revision = "r02") {
  specs <- list()
  index <- 1L
  for (model_id in paste0("M", 1:5)) {
    for (exposure_form in c("AST_ALT_Tertile", "log2_AST_ALT")) {
      collection <- make_tve_collection_spec(
        completed, model_id, endpoint_row, exposure_form, root,
        include_rutherford_tve = identical(model_id, "M5"),
        nuisance_terms = if (identical(model_id, "M5")) nuisance_terms else character(),
        scientific_config_revision = scientific_config_revision
      )
      for (imputation_id in seq_along(completed)) {
        specs[[index]] <- c(collection, list(imputation_id = as.integer(imputation_id)))
        index <- index + 1L
      }
    }
  }
  keys <- vapply(specs, function(spec) {
    paste(spec$collection_key, spec$imputation_id, sep = "__")
  }, character(1))
  if (length(specs) != 200L || anyDuplicated(keys)) {
    stop("A04_TVE_BRANCH_CONTRACT_INVALID", call. = FALSE)
  }
  specs
}

fit_tve_branch <- function(completed, branch_spec) {
  required <- c(
    "collection_key", "formula_text", "model_id", "exposure_form", "endpoint_row",
    "nuisance_terms", "nuisance_specs", "scientific_config_revision",
    "time_function_id", "imputation_id"
  )
  if (!is.list(branch_spec) || !identical(names(branch_spec), required) ||
      length(completed) != 20L || !branch_spec$imputation_id %in% seq_along(completed) ||
      !identical(branch_spec$time_function_id, "g12_log1p_centered_12m")) {
    stop("A04_TVE_BRANCH_CONTRACT_INVALID", call. = FALSE)
  }
  data <- apply_nuisance_tve_specs(
    prepare_tve_analysis_data(completed[[branch_spec$imputation_id]]),
    branch_spec$nuisance_specs
  )
  formula <- stats::as.formula(branch_spec$formula_text)
  tt_function <- function(x, t, ...) x * g12(t)
  failure <- ""
  fit <- tryCatch({
    if (!requireNamespace("survival", quietly = TRUE)) stop("survival is required")
    survival::coxph(
      formula, data = data, ties = "efron", na.action = stats::na.fail,
      tt = tt_function, x = FALSE, y = FALSE, model = FALSE
    )
  }, error = function(error) {
    failure <<- conditionMessage(error)
    NULL
  })
  list(spec = branch_spec, fit = fit, failure = failure)
}

assemble_tve_branch_collections <- function(branches) {
  if (!is.list(branches) || length(branches) != 200L) {
    stop("A04_TVE_BRANCH_CARDINALITY_INVALID", call. = FALSE)
  }
  keys <- vapply(branches, function(branch) {
    if (!is.list(branch) || !all(c("spec", "fit", "failure") %in% names(branch))) {
      stop("A04_TVE_BRANCH_CONTRACT_INVALID", call. = FALSE)
    }
    paste(branch$spec$collection_key, branch$spec$imputation_id, sep = "__")
  }, character(1))
  if (anyDuplicated(keys)) stop("A04_TVE_BRANCH_DUPLICATED", call. = FALSE)
  expected <- as.vector(outer(
    as.vector(outer(paste0("M", 1:5), c("AST_ALT_Tertile", "log2_AST_ALT"), paste, sep = "__")),
    seq_len(20L), paste, sep = "__"
  ))
  if (!identical(sort(keys), sort(expected))) stop("A04_TVE_BRANCH_SET_INVALID", call. = FALSE)
  groups <- split(branches, vapply(branches, function(branch) branch$spec$collection_key, character(1)))
  lapply(groups, function(group) {
    group <- group[order(vapply(group, function(branch) branch$spec$imputation_id, integer(1)))]
    spec <- group[[1L]]$spec
    stable_fields <- setdiff(names(spec), "imputation_id")
    if (!identical(
        vapply(group, function(branch) branch$spec$imputation_id, integer(1)),
        seq_len(20L)
      ) || !all(vapply(group, function(branch) {
        identical(branch$spec[stable_fields], spec[stable_fields])
      }, logical(1)))) {
      stop("A04_TVE_BRANCH_SCIENTIFIC_IDENTITY_MISMATCH", call. = FALSE)
    }
    list(
      fits = lapply(group, `[[`, "fit"),
      failures = lapply(group, function(branch) if (nzchar(branch$failure)) branch$failure else NULL),
      formula_text = spec$formula_text, model_id = spec$model_id,
      exposure_form = spec$exposure_form, endpoint_row = spec$endpoint_row,
      nuisance_terms = spec$nuisance_terms, nuisance_specs = spec$nuisance_specs,
      scientific_config_revision = spec$scientific_config_revision,
      time_function_id = spec$time_function_id
    )
  })
}

fit_tve_collection <- function(completed, model_id, endpoint_row, exposure_form, root = ".", covariates_override = NULL, include_rutherford_tve = TRUE, nuisance_terms = character(), time_function = g12, scientific_config_revision = "r02") {
  if (!identical(time_function, g12)) stop("A04_TVE_TIME_FUNCTION_INVALID", call. = FALSE)
  collection <- make_tve_collection_spec(
    completed, model_id, endpoint_row, exposure_form, root, covariates_override,
    include_rutherford_tve, nuisance_terms, scientific_config_revision
  )
  branches <- lapply(seq_along(completed), function(imputation_id) {
    fit_tve_branch(completed, c(collection, list(imputation_id = as.integer(imputation_id))))
  })
  list(
    fits = lapply(branches, `[[`, "fit"),
    failures = lapply(branches, function(branch) if (nzchar(branch$failure)) branch$failure else NULL),
    formula_text = collection$formula_text, model_id = collection$model_id,
    exposure_form = collection$exposure_form, endpoint_row = collection$endpoint_row,
    nuisance_terms = collection$nuisance_terms, nuisance_specs = collection$nuisance_specs,
    scientific_config_revision = collection$scientific_config_revision,
    time_function_id = collection$time_function_id
  )
}

pool_tve_collection <- function(collection, exposure_scale, riskset, root = ".") {
  source(file.path(root, "R", "pooling_engine.R"))
  source(file.path(root, "R", "canonical_results.R"))
  source(file.path(root, "R", "model_signature.R"))
  valid_index <- which(!vapply(collection$fits, is.null, logical(1)))
  if (!length(valid_index)) return(list(canonical = data.frame(), per_imputation = data.frame()))
  first <- collection$fits[[valid_index[[1L]]]]
  endpoint <- collection$endpoint_row$event_variable[[1L]]
  exposure_terms <- if (collection$exposure_form == "log2_AST_ALT") "log2_AST_ALT" else c("AST_ALT_T2", "AST_ALT_T3")
  scales <- if (collection$exposure_form == "log2_AST_ALT") {
    c(per_doubling = 1, per_1_SD = exposure_scale$log2_sd[[1L]], per_IQR = exposure_scale$log2_iqr[[1L]])
  } else c(T2_vs_T1 = 1, T3_vs_T1 = 1)
  rows <- list()
  per_imp_rows <- list()
  index <- 1L
  imp_index <- 1L
  for (term_i in seq_along(exposure_terms)) {
    beta_term <- exposure_terms[[term_i]]
    gamma_term <- paste0("tt(", beta_term, ")")
    scale_names <- if (collection$exposure_form == "log2_AST_ALT") names(scales) else names(scales)[[term_i]]
    for (scale_name in scale_names) {
      multiplier <- if (collection$exposure_form == "log2_AST_ALT") scales[[scale_name]] else 1
      for (time_month in c(6, 12, 24, 36)) {
        estimates <- variances <- rep(NA_real_, length(collection$fits))
        for (i in seq_along(collection$fits)) {
          fit <- collection$fits[[i]]
          if (is.null(fit)) next
          value <- tryCatch(derive_tve_contrast(stats::coef(fit), stats::vcov(fit), beta_term, gamma_term, time_month, multiplier), error = function(e) NULL)
          if (!is.null(value)) {
            estimates[[i]] <- value$estimate
            variances[[i]] <- value$variance
            per_imp_rows[[imp_index]] <- data.frame(
              imputation = i, endpoint = endpoint, model_id = collection$model_id, exposure_form = collection$exposure_form,
              contrast = scale_name, time_month = time_month, estimate = value$estimate, variance = value$variance,
              stringsAsFactors = FALSE
            )
            imp_index <- imp_index + 1L
          }
        }
        pooled <- tryCatch(pool_scalar_rubin(estimates, variances), error = function(e) NULL)
        at_risk <- riskset$at_risk_n[riskset$endpoint == endpoint & riskset$time_month == time_month]
        if (!length(at_risk)) at_risk <- NA_integer_
        signature <- model_signature_sha256(
          endpoint, "MAIN_EXPOSURE_ELIGIBLE", "AST_ALT", collection$exposure_form,
          collection$formula_text, c("AST_ALT_Tertile=T1"), "efron", "baseline",
          collection$time_function_id, c(beta_term, gamma_term), scale_name,
          "Rubin_linear_contrast", 0.95, collection$scientific_config_revision
        )
        rows[[index]] <- new_canonical_result_row(
          estimand_id = paste(endpoint, collection$model_id, collection$exposure_form, scale_name, paste0("M", time_month), sep = "__"),
          endpoint = endpoint, model_id = collection$model_id, model_signature_sha256 = signature,
          exposure_parameterization = collection$exposure_form, contrast = scale_name,
          n = first$n, events = first$nevent, pooled = pooled, time_month = time_month, at_risk_n = at_risk[[1L]],
          stability_flag = ifelse(sum(is.finite(estimates)) == length(collection$fits), "STABLE", "INCOMPLETE_IMPUTATIONS"),
          notes = "Time-specific effect from beta-gamma covariance"
        )
        index <- index + 1L
      }
    }
  }
  list(
    canonical = do.call(rbind, rows),
    per_imputation = if (length(per_imp_rows)) do.call(rbind, per_imp_rows) else data.frame()
  )
}

pool_rutherford_tve_collection <- function(collection, riskset, projection, root = ".") {
  # 中文备注：加载统一 pooling、canonical 与模型签名实现，避免建立第二条统计路径。
  source(file.path(root, "R", "pooling_engine.R"))
  source(file.path(root, "R", "canonical_results.R"))
  source(file.path(root, "R", "model_signature.R"))
  collection_key <- paste(collection$model_id, collection$exposure_form, sep = "__")
  mapping <- projection$source_collection_to_parameterization
  if (!collection_key %in% names(mapping)) {
    stop("RUTHERFORD_TVE_SOURCE_COLLECTION_NOT_SELECTED", call. = FALSE)
  }
  valid_index <- which(!vapply(collection$fits, is.null, logical(1)))
  if (!length(valid_index)) return(list(canonical = data.frame(), per_imputation = data.frame()))
  first <- collection$fits[[valid_index[[1L]]]]
  endpoint <- collection$endpoint_row$event_variable[[1L]]
  parameterization <- unname(mapping[[collection_key]])
  rows <- list()
  per_imp_rows <- list()
  index <- 1L
  imp_index <- 1L
  for (beta_term in names(projection$contrasts)) {
    gamma_term <- paste0("tt(", beta_term, ")")
    contrast_name <- unname(projection$contrasts[[beta_term]])
    for (time_month in projection$time_months) {
      estimates <- variances <- rep(NA_real_, length(collection$fits))
      for (i in seq_along(collection$fits)) {
        fit <- collection$fits[[i]]
        if (is.null(fit)) next
        coefficients <- if (is.list(fit) &&
            all(c("coefficients", "covariance") %in% names(fit))) {
          fit$coefficients
        } else {
          stats::coef(fit)
        }
        covariance <- if (is.list(fit) &&
            all(c("coefficients", "covariance") %in% names(fit))) {
          fit$covariance
        } else {
          stats::vcov(fit)
        }
        value <- tryCatch(
          derive_tve_contrast(
            coefficients, covariance, beta_term, gamma_term,
            time_month, multiplier = 1
          ),
          error = function(condition) NULL
        )
        if (!is.null(value)) {
          estimates[[i]] <- value$estimate
          variances[[i]] <- value$variance
          per_imp_rows[[imp_index]] <- data.frame(
            imputation = i,
            endpoint = endpoint,
            model_id = collection$model_id,
            exposure_form = parameterization,
            contrast = contrast_name,
            time_month = time_month,
            estimate = value$estimate,
            variance = value$variance,
            stringsAsFactors = FALSE
          )
          imp_index <- imp_index + 1L
        }
      }
      # 中文备注：每套插补先使用 beta-gamma 完整协方差，再执行 Rubin 标量合并。
      pooled <- tryCatch(
        pool_scalar_rubin(estimates, variances),
        error = function(condition) NULL
      )
      at_risk <- riskset$at_risk_n[
        riskset$endpoint == endpoint & riskset$time_month == time_month
      ]
      if (!length(at_risk)) at_risk <- NA_integer_
      references <- c(paste0("Rutherford_cat=", projection$reference_category))
      if (identical(collection$exposure_form, "AST_ALT_Tertile")) {
        references <- c(references, "AST_ALT_Tertile=T1")
      }
      signature <- model_signature_sha256(
        endpoint, "MAIN_EXPOSURE_ELIGIBLE", "Rutherford_cat", parameterization,
        collection$formula_text, references, "efron", "baseline",
        collection$time_function_id, c(beta_term, gamma_term), contrast_name,
        "Rubin_linear_contrast", 0.95, collection$scientific_config_revision
      )
      rows[[index]] <- new_canonical_result_row(
        estimand_id = paste(
          endpoint, parameterization, collection$model_id, contrast_name,
          paste0("M", time_month), sep = "__"
        ),
        endpoint = endpoint,
        model_id = collection$model_id,
        model_signature_sha256 = signature,
        exposure_parameterization = parameterization,
        contrast = contrast_name,
        n = first$n,
        events = first$nevent,
        pooled = pooled,
        time_month = time_month,
        at_risk_n = at_risk[[1L]],
        stability_flag = ifelse(
          sum(is.finite(estimates)) == length(collection$fits),
          "STABLE", "INCOMPLETE_IMPUTATIONS"
        ),
        notes = paste0(
          "Rutherford nuisance TVE; adjusted_by=", collection$exposure_form,
          "; selection=RUTH_TVE_1C; beta-gamma covariance before Rubin pooling"
        )
      )
      index <- index + 1L
    }
  }
  list(
    canonical = do.call(rbind, rows),
    per_imputation = if (length(per_imp_rows)) do.call(rbind, per_imp_rows) else data.frame()
  )
}

combine_tve_branches <- function(
    branches, exposure_scale, riskset, root = ".") {
  projection <- read_rutherford_tve_projection(root)
  raw_collections <- assemble_tve_branch_collections(branches)
  collections <- list()
  canonical <- list()
  per_imp <- list()
  rutherford_per_imp <- list()
  diagnostics <- list()
  index <- 1L
  rutherford_index <- 1L
  for (model_id in paste0("M", 1:5)) {
    for (form in c("AST_ALT_Tertile", "log2_AST_ALT")) {
      key <- paste(model_id, form, sep = "__")
      collection <- raw_collections[[key]]
      if (is.null(collection)) stop("A04_TVE_BRANCH_SET_INVALID", call. = FALSE)
      active_nuisance_terms <- collection$nuisance_terms
      pooled <- pool_tve_collection(collection, exposure_scale, riskset, root)
      if (key %in% names(projection$source_collection_to_parameterization)) {
        rutherford <- pool_rutherford_tve_collection(
          collection, riskset, projection, root
        )
        pooled$canonical <- rbind(pooled$canonical, rutherford$canonical)
        rutherford_per_imp[[rutherford_index]] <- rutherford$per_imputation
        rutherford_index <- rutherford_index + 1L
      }
      # 中文备注：pooling 完成后仅保留系数、协方差和诊断，避免缓存完整设计矩阵。
      collections[[key]] <- compact_cox_collection(collection)
      canonical[[index]] <- pooled$canonical
      per_imp[[index]] <- pooled$per_imputation
      diagnostics[[index]] <- data.frame(
        model_id = model_id, exposure_form = form,
        valid_imputation_n = sum(!vapply(collection$fits, is.null, logical(1))),
        total_imputation_n = length(collection$fits),
        nuisance_tve_terms = paste(active_nuisance_terms, collapse = "|"),
        status = ifelse(all(!vapply(collection$fits, is.null, logical(1))), "PASS", "FAIL"),
        stringsAsFactors = FALSE
      )
      index <- index + 1L
    }
  }
  list(
    collections = collections,
    canonical = do.call(rbind, canonical),
    per_imputation = do.call(rbind, per_imp),
    rutherford_per_imputation = if (length(rutherford_per_imp)) {
      do.call(rbind, rutherford_per_imp)
    } else {
      data.frame()
    },
    diagnostics = do.call(rbind, diagnostics)
  )
}

run_tve_stage <- function(completed, endpoint_row, exposure_scale, riskset, root = ".", nuisance_terms = character(), scientific_config_revision = "r02") {
  specs <- make_tve_branch_specs(
    completed, endpoint_row, root, nuisance_terms, scientific_config_revision
  )
  branches <- lapply(specs, function(spec) fit_tve_branch(completed, spec))
  combine_tve_branches(branches, exposure_scale, riskset, root)
}
