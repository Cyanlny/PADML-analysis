# Canonical result 格式化模块：保留数值列并单独生成显示文本。
format_p_display <- function(p) {
  ifelse(is.na(p), "", ifelse(p < 0.001, "<0.001", sprintf("%.3f", p)))
}

format_significance_symbol <- function(p) {
  ifelse(is.na(p), "", ifelse(p < 0.001, "***", ifelse(p < 0.01, "**", ifelse(p < 0.05, "*", ""))))
}

.rubin_df_canonicalize_v43 <- function(value) {
  if (is.data.frame(value)) {
    return(lapply(seq_len(nrow(value)), function(index) {
      .rubin_df_canonicalize_v43(as.list(value[index, , drop = FALSE]))
    }))
  }
  if (is.list(value)) {
    if (!is.null(names(value))) value <- value[order(names(value))]
    return(lapply(value, .rubin_df_canonicalize_v43))
  }
  if (!is.null(names(value))) {
    return(lapply(as.list(value[order(names(value))]), .rubin_df_canonicalize_v43))
  }
  value
}

.rubin_df_canonical_json_v43 <- function(value) {
  # 加载 JSON 包以生成 Rubin df 决策与 QC 回执的规范序列化。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  as.character(jsonlite::toJSON(
    .rubin_df_canonicalize_v43(value), auto_unbox = TRUE, null = "null",
    na = "null", digits = 17, pretty = FALSE
  ))
}

.rubin_df_sha256_text_v43 <- function(text) {
  # 加载摘要包以计算 Rubin df 合同身份。
  if (!requireNamespace("digest", quietly = TRUE)) stop("digest is required", call. = FALSE)
  digest::digest(enc2utf8(paste(text, collapse = "\n")), algo = "sha256", serialize = FALSE)
}

.rubin_df_sha256_file_v43 <- function(path) {
  # 加载摘要包以计算 Rubin df owner 与 source 文件身份。
  if (!requireNamespace("digest", quietly = TRUE)) stop("digest is required", call. = FALSE)
  digest::digest(file = path, algo = "sha256", serialize = FALSE)
}

read_rubin_df_selection_v43 <- function(project_root = ".") {
  project_root <- normalizePath(project_root, mustWork = TRUE)
  selection_path <- file.path(
    project_root, "protocol", "decisions", "approved",
    "RUBIN_DF_ZERO_INFORMATION_V43_001_SELECTION.json"
  )
  if (!file.exists(selection_path)) stop("RUBIN_DF_SELECTION_RECEIPT_MISSING", call. = FALSE)
  # 加载用户选择回执并验证 DecisionPackage、规则与内容地址闭包。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  selection <- jsonlite::read_json(selection_path, simplifyVector = TRUE)
  expected_selection_names <- c(
    "schema_version", "decision_id", "conflict_id", "decision_package_relative_path",
    "decision_package_sha256", "selected_option_id", "selection_sha256", "status",
    "authority_class", "approved_at", "activation_owner_relative_path",
    "activation_owner_pointer", "selected_rule", "invalidation_frontier",
    "production_authorized"
  )
  expected_rule_names <- c(
    "policy", "between_variance_comparison", "allowed_nonfinite_field",
    "allowed_nonfinite_value", "required_finite_fields", "optional_inferential_fields",
    "minimum_valid_imputation_n", "finite_rubin_df_rule", "typed_not_estimable_rule",
    "all_other_nonfinite_cases", "numeric_tolerance", "changes_estimates_or_inference"
  )
  relative_package <- selection$decision_package_relative_path
  safe_package_path <- is.character(relative_package) && length(relative_package) == 1L &&
    !is.na(relative_package) && nzchar(relative_package) &&
    !grepl("^/|^[A-Za-z]:[/\\\\]|(^|/)\\.\\.(/|$)", relative_package, perl = TRUE)
  if (!isTRUE(safe_package_path)) stop("RUBIN_DF_SELECTION_RECEIPT_INVALID", call. = FALSE)
  package_path <- file.path(project_root, relative_package)
  required_finite <- c(
    "beta", "se", "hr", "lower_95_ci", "upper_95_ci", "p_value",
    "within_variance", "between_variance", "total_variance"
  )
  optional_inferential <- c("joint_p", "annotation_p")
  package_valid <- FALSE
  if (file.exists(package_path) && !file.info(package_path)$isdir) {
    package <- tryCatch(
      jsonlite::read_json(package_path, simplifyVector = FALSE),
      error = function(error) NULL
    )
    if (!is.null(package) && is.list(package$options)) {
      option_ids <- vapply(package$options, function(option) option$option_id, character(1))
      package_valid <- identical(package$decision_id, selection$decision_id) &&
        identical(package$conflict_id, selection$conflict_id) &&
        selection$selected_option_id %in% option_ids
    }
  }
  rule <- selection$selected_rule
  valid <- identical(sort(names(selection)), sort(expected_selection_names)) &&
    is.list(rule) && identical(sort(names(rule)), sort(expected_rule_names)) &&
    identical(selection$schema_version, "1.0.0") &&
    identical(selection$decision_id, "RUBIN_DF_ZERO_INFORMATION_V43_001") &&
    identical(selection$conflict_id, "d1458b1e3f4f977514e867245a92cd44cee0984efa312fe0386df3fd5c7734e0") &&
    identical(selection$selected_option_id, "RUBIN_DF_1A") &&
    identical(selection$status, "HUMAN_APPROVED") &&
    identical(selection$authority_class, "USER_SELECTION") &&
    identical(selection$activation_owner_relative_path,
      "protocol/decisions/approved/RUBIN_DF_ZERO_INFORMATION_V43_001_SELECTION.json") &&
    identical(selection$activation_owner_pointer, "/selected_rule") &&
    identical(selection$production_authorized, FALSE) &&
    identical(
      .rubin_df_sha256_text_v43(selection$selected_option_id),
      selection$selection_sha256
    ) && file.exists(package_path) &&
    identical(.rubin_df_sha256_file_v43(package_path), selection$decision_package_sha256) &&
    isTRUE(package_valid) &&
    identical(rule$policy, "ALLOW_POSITIVE_INFINITY_ONLY_AT_EXACT_ZERO_BETWEEN_VARIANCE") &&
    identical(rule$between_variance_comparison, "EXACT_NUMERIC_ZERO") &&
    identical(rule$allowed_nonfinite_field, "rubin_df") &&
    identical(rule$allowed_nonfinite_value, "POSITIVE_INFINITY") &&
    identical(as.character(rule$required_finite_fields), required_finite) &&
    identical(as.character(rule$optional_inferential_fields), optional_inferential) &&
    identical(as.integer(rule$minimum_valid_imputation_n), 2L) &&
    identical(rule$finite_rubin_df_rule, "STRICTLY_POSITIVE") &&
    identical(
      rule$typed_not_estimable_rule,
      "RUBIN_DF_MUST_BE_MISSING_AND_REGISTERED_REASON_MUST_BE_PRESENT"
    ) &&
    identical(rule$all_other_nonfinite_cases, "FAIL") &&
    identical(as.numeric(rule$numeric_tolerance), 0) &&
    identical(rule$changes_estimates_or_inference, FALSE)
  if (!isTRUE(valid)) stop("RUBIN_DF_SELECTION_RECEIPT_INVALID", call. = FALSE)
  selection$selection_receipt_file_sha256 <- .rubin_df_sha256_file_v43(selection_path)
  selection
}

evaluate_rubin_df_contract_v43 <- function(data, project_root = ".", source_id = "") {
  if (!is.data.frame(data)) stop("RUBIN_DF_SOURCE_NOT_DATA_FRAME", call. = FALSE)
  selection <- read_rubin_df_selection_v43(project_root)
  required_finite <- as.character(selection$selected_rule$required_finite_fields)
  required <- unique(c(
    required_finite, "rubin_df", "valid_imputation_n", "estimate_status",
    "not_estimable_reason_code"
  ))
  missing <- setdiff(required, names(data))
  if (length(missing)) {
    stop("RUBIN_DF_SOURCE_COLUMNS_MISSING: ", paste(missing, collapse = "|"), call. = FALSE)
  }
  optional_inferential <- intersect(
    as.character(selection$selected_rule$optional_inferential_fields), names(data)
  )
  numeric_fields <- unique(c(required_finite, "rubin_df", "valid_imputation_n", optional_inferential))
  nonnumeric <- numeric_fields[!vapply(data[numeric_fields], is.numeric, logical(1))]
  if (length(nonnumeric)) {
    stop("RUBIN_DF_SOURCE_TYPE_INVALID: ", paste(nonnumeric, collapse = "|"), call. = FALSE)
  }
  row_n <- nrow(data)
  status_value <- as.character(data$estimate_status)
  estimable <- !is.na(status_value) & status_value == "ESTIMABLE"
  not_estimable <- !is.na(status_value) & status_value == "NOT_ESTIMABLE"
  reason_registry_path <- file.path(project_root, "config", "not_estimable_reason_registry.csv")
  if (!file.exists(reason_registry_path)) stop("RUBIN_DF_REASON_REGISTRY_MISSING", call. = FALSE)
  reason_registry <- utils::read.csv(
    reason_registry_path, stringsAsFactors = FALSE, check.names = FALSE,
    na.strings = character()
  )
  if (!identical(names(reason_registry), c("reason_code", "description", "default_severity")) ||
      !nrow(reason_registry) || anyDuplicated(reason_registry$reason_code) ||
      any(!nzchar(reason_registry$reason_code))) {
    stop("RUBIN_DF_REASON_REGISTRY_INVALID", call. = FALSE)
  }
  finite_required <- rep(TRUE, row_n)
  for (column in required_finite) {
    finite_required <- finite_required & !is.na(data[[column]]) & is.finite(data[[column]])
  }
  optional_valid <- rep(TRUE, row_n)
  for (column in optional_inferential) {
    value <- data[[column]]
    optional_valid <- optional_valid & ((is.na(value) & !is.nan(value)) | is.finite(value))
  }
  valid_imputation <- is.finite(data$valid_imputation_n) &
    data$valid_imputation_n == floor(data$valid_imputation_n) &
    data$valid_imputation_n >= as.integer(selection$selected_rule$minimum_valid_imputation_n)
  variance_domain <- data$within_variance >= 0 & data$between_variance >= 0 &
    data$total_variance >= 0 & data$se >= 0
  finite_df <- is.finite(data$rubin_df) & data$rubin_df > 0
  positive_infinite_df <- is.infinite(data$rubin_df) & data$rubin_df > 0
  reason <- as.character(data$not_estimable_reason_code)
  estimable_reason_valid <- is.na(reason) | !nzchar(trimws(reason))
  common_estimable <- estimable & finite_required & optional_valid & valid_imputation &
    variance_domain & estimable_reason_valid
  finite_valid <- common_estimable & finite_df
  zero_limit_valid <- common_estimable & positive_infinite_df & data$between_variance == 0
  proper_missing_df <- is.na(data$rubin_df) & !is.nan(data$rubin_df)
  not_estimable_numeric_valid <- rep(TRUE, row_n)
  for (column in numeric_fields) {
    value <- data[[column]]
    not_estimable_numeric_valid <- not_estimable_numeric_valid &
      ((is.na(value) & !is.nan(value)) | is.finite(value))
  }
  typed_not_estimable <- not_estimable & proper_missing_df &
    !is.na(reason) & nzchar(trimws(reason)) & reason %in% reason_registry$reason_code &
    not_estimable_numeric_valid
  valid <- finite_valid | zero_limit_valid | typed_not_estimable
  valid[is.na(valid)] <- FALSE
  finite_valid[is.na(finite_valid)] <- FALSE
  zero_limit_valid[is.na(zero_limit_valid)] <- FALSE
  typed_not_estimable[is.na(typed_not_estimable)] <- FALSE
  classification <- rep("INVALID", row_n)
  classification[finite_valid] <- "FINITE_POSITIVE_RUBIN_DF"
  classification[zero_limit_valid] <- "POSITIVE_INFINITY_EXACT_ZERO_BETWEEN_VARIANCE_LIMIT"
  classification[typed_not_estimable] <- "TYPED_NOT_ESTIMABLE_RUBIN_DF_NOT_APPLICABLE"
  invalid_index <- which(!valid)
  list(
    schema_version = "1.0.0",
    decision_id = selection$decision_id,
    selected_option_id = selection$selected_option_id,
    decision_package_sha256 = selection$decision_package_sha256,
    selection_sha256 = selection$selection_sha256,
    selection_receipt_file_sha256 = selection$selection_receipt_file_sha256,
    qc_gate_id = "QC029",
    source_id = as.character(source_id),
    source_row_n = as.integer(row_n),
    estimable_row_n = as.integer(sum(estimable)),
    finite_rubin_df_row_n = as.integer(sum(finite_valid)),
    zero_between_positive_infinite_rubin_df_row_n = as.integer(sum(zero_limit_valid)),
    typed_not_estimable_row_n = as.integer(sum(typed_not_estimable)),
    invalid_row_n = as.integer(length(invalid_index)),
    invalid_row_index = as.integer(invalid_index),
    row_classification = classification,
    allowed_positive_infinite_rubin_df = zero_limit_valid,
    status = if (length(invalid_index)) "FAIL" else "PASS"
  )
}

assert_rubin_df_contract_v43 <- function(data, project_root = ".", source_id = "") {
  audit <- evaluate_rubin_df_contract_v43(data, project_root, source_id)
  if (!identical(audit$status, "PASS")) {
    stop(
      "RUBIN_DF_CONTRACT_INVALID: ", source_id,
      "; invalid_rows=", paste(audit$invalid_row_index, collapse = "|"),
      call. = FALSE
    )
  }
  audit
}

finalize_rubin_df_qc_receipt_v43 <- function(audit, source_path, project_root = ".") {
  if (!is.list(audit) || !identical(audit$status, "PASS") || audit$invalid_row_n != 0L ||
      !file.exists(source_path) || file.info(source_path)$isdir) {
    stop("RUBIN_DF_QC_RECEIPT_INPUT_INVALID", call. = FALSE)
  }
  selection <- read_rubin_df_selection_v43(project_root)
  if (!identical(audit$selection_receipt_file_sha256, selection$selection_receipt_file_sha256)) {
    stop("RUBIN_DF_QC_RECEIPT_SELECTION_MISMATCH", call. = FALSE)
  }
  receipt <- list(
    schema_version = "1.0.0",
    decision_id = audit$decision_id,
    selected_option_id = audit$selected_option_id,
    decision_package_sha256 = audit$decision_package_sha256,
    selection_sha256 = audit$selection_sha256,
    selection_receipt_file_sha256 = audit$selection_receipt_file_sha256,
    qc_gate_id = "QC029",
    source_file = basename(source_path),
    source_file_sha256 = .rubin_df_sha256_file_v43(source_path),
    source_row_n = as.integer(audit$source_row_n),
    estimable_row_n = as.integer(audit$estimable_row_n),
    finite_rubin_df_row_n = as.integer(audit$finite_rubin_df_row_n),
    zero_between_positive_infinite_rubin_df_row_n = as.integer(
      audit$zero_between_positive_infinite_rubin_df_row_n
    ),
    typed_not_estimable_row_n = as.integer(audit$typed_not_estimable_row_n),
    invalid_row_n = 0L,
    status = "PASS"
  )
  receipt$receipt_sha256 <- .rubin_df_sha256_text_v43(
    .rubin_df_canonical_json_v43(receipt)
  )
  if (!validate_rubin_df_qc_receipt_v43(receipt, source_path, project_root)) {
    stop("RUBIN_DF_QC_RECEIPT_FINALIZATION_FAILED", call. = FALSE)
  }
  receipt
}

.read_rubin_df_source_v43 <- function(source_path, selection) {
  header <- names(utils::read.csv(
    source_path, stringsAsFactors = FALSE, check.names = FALSE, nrows = 0L
  ))
  numeric_contract <- unique(c(
    as.character(selection$selected_rule$required_finite_fields),
    as.character(selection$selected_rule$optional_inferential_fields),
    "rubin_df", "valid_imputation_n"
  ))
  classes <- rep(NA_character_, length(header))
  classes[header %in% numeric_contract] <- "numeric"
  classes[header %in% c(
    "estimand_id", "estimate_status", "not_estimable_reason_code"
  )] <- "character"
  utils::read.csv(
    source_path, stringsAsFactors = FALSE, check.names = FALSE,
    colClasses = classes, na.strings = c("", "NA")
  )
}

validate_rubin_df_qc_receipt_v43 <- function(receipt, source_path, project_root = ".") {
  expected_names <- c(
    "schema_version", "decision_id", "selected_option_id", "decision_package_sha256",
    "selection_sha256", "selection_receipt_file_sha256", "qc_gate_id", "source_file",
    "source_file_sha256", "source_row_n", "estimable_row_n", "finite_rubin_df_row_n",
    "zero_between_positive_infinite_rubin_df_row_n", "typed_not_estimable_row_n",
    "invalid_row_n", "status", "receipt_sha256"
  )
  if (!is.list(receipt) || !identical(names(receipt), expected_names)) return(FALSE)
  selection <- tryCatch(read_rubin_df_selection_v43(project_root), error = function(error) NULL)
  if (is.null(selection) || !is.character(source_path) || length(source_path) != 1L ||
      is.na(source_path) || !file.exists(source_path) || file.info(source_path)$isdir) return(FALSE)
  unsigned <- receipt[setdiff(names(receipt), "receipt_sha256")]
  count_fields <- c(
    "source_row_n", "estimable_row_n", "finite_rubin_df_row_n",
    "zero_between_positive_infinite_rubin_df_row_n", "typed_not_estimable_row_n",
    "invalid_row_n"
  )
  counts <- suppressWarnings(as.integer(unlist(receipt[count_fields], use.names = FALSE)))
  static_valid <- isTRUE(
    identical(receipt$schema_version, "1.0.0") &&
      identical(receipt$decision_id, selection$decision_id) &&
      identical(receipt$selected_option_id, "RUBIN_DF_1A") &&
      identical(receipt$decision_package_sha256, selection$decision_package_sha256) &&
      identical(receipt$selection_sha256, selection$selection_sha256) &&
      identical(receipt$selection_receipt_file_sha256, selection$selection_receipt_file_sha256) &&
      identical(receipt$qc_gate_id, "QC029") &&
      is.character(receipt$source_file) && length(receipt$source_file) == 1L &&
      nzchar(receipt$source_file) && identical(basename(receipt$source_file), receipt$source_file) &&
      grepl("^[0-9a-f]{64}$", receipt$source_file_sha256) &&
      identical(basename(source_path), receipt$source_file) &&
      identical(.rubin_df_sha256_file_v43(source_path), receipt$source_file_sha256) &&
      length(counts) == length(count_fields) && all(!is.na(counts) & counts >= 0L) &&
      counts[[1L]] == counts[[2L]] + counts[[5L]] &&
      counts[[2L]] == counts[[3L]] + counts[[4L]] &&
      counts[[6L]] == 0L && identical(receipt$status, "PASS") &&
      identical(
        receipt$receipt_sha256,
        .rubin_df_sha256_text_v43(.rubin_df_canonical_json_v43(unsigned))
      )
  )
  if (!static_valid) return(FALSE)
  source_data <- tryCatch(
    .read_rubin_df_source_v43(source_path, selection),
    error = function(error) NULL
  )
  if (is.null(source_data)) return(FALSE)
  audit <- tryCatch(
    assert_rubin_df_contract_v43(source_data, project_root, receipt$source_file),
    error = function(error) NULL
  )
  if (is.null(audit)) return(FALSE)
  identical(as.integer(receipt$source_row_n), audit$source_row_n) &&
    identical(as.integer(receipt$estimable_row_n), audit$estimable_row_n) &&
    identical(as.integer(receipt$finite_rubin_df_row_n), audit$finite_rubin_df_row_n) &&
    identical(
      as.integer(receipt$zero_between_positive_infinite_rubin_df_row_n),
      audit$zero_between_positive_infinite_rubin_df_row_n
    ) &&
    identical(
      as.integer(receipt$typed_not_estimable_row_n), audit$typed_not_estimable_row_n
    ) && identical(as.integer(receipt$invalid_row_n), audit$invalid_row_n)
}

validate_canonical_numeric_integrity <- function(data) {
  checks <- list(
    p_range = all(is.na(data$p_value) | (data$p_value >= 0 & data$p_value <= 1)),
    ci_order = all(is.na(data$hr) | (data$lower_95_ci <= data$hr & data$hr <= data$upper_95_ci)),
    finite_estimates = all(is.na(data$hr) | is.finite(data$hr)),
    valid_status = all(data$estimate_status %in% c("ESTIMABLE", "NOT_ESTIMABLE"))
  )
  data.frame(qc_item = names(checks), status = ifelse(unlist(checks), "PASS", "FAIL"), stringsAsFactors = FALSE)
}

new_not_estimable_row <- function(template, reason_code, detail) {
  template$estimate_status <- "NOT_ESTIMABLE"
  template$not_estimable_reason_code <- reason_code
  template$not_estimable_reason_detail <- detail
  for (name in c("beta", "se", "hr", "lower_95_ci", "upper_95_ci", "p_value", "joint_p")) template[[name]] <- NA_real_
  template
}

new_canonical_result_row <- function(
    estimand_id, endpoint, model_id, model_signature_sha256,
    exposure_parameterization, contrast, n, events,
    pooled = NULL, time_month = NA_real_, at_risk_n = NA_integer_,
    joint_p = NA_real_, stability_flag = "STABLE", notes = "") {
  estimable <- !is.null(pooled)
  p <- if (estimable) pooled$p_value[[1L]] else NA_real_
  data.frame(
    estimand_id = estimand_id,
    endpoint = endpoint,
    analysis_population = "MAIN_EXPOSURE_ELIGIBLE",
    model_id = model_id,
    model_signature_sha256 = model_signature_sha256,
    exposure_parameterization = exposure_parameterization,
    contrast = contrast,
    time_month = time_month,
    n = as.integer(n),
    events = as.integer(events),
    at_risk_n = as.integer(at_risk_n),
    beta = if (estimable) pooled$pooled_estimate[[1L]] else NA_real_,
    se = if (estimable) pooled$se[[1L]] else NA_real_,
    hr = if (estimable) exp(pooled$pooled_estimate[[1L]]) else NA_real_,
    lower_95_ci = if (estimable) exp(pooled$lower[[1L]]) else NA_real_,
    upper_95_ci = if (estimable) exp(pooled$upper[[1L]]) else NA_real_,
    p_value = p,
    p_display = format_p_display(p),
    joint_p = joint_p,
    joint_p_display = format_p_display(joint_p),
    within_variance = if (estimable) pooled$within_variance[[1L]] else NA_real_,
    between_variance = if (estimable) pooled$between_variance[[1L]] else NA_real_,
    total_variance = if (estimable) pooled$total_variance[[1L]] else NA_real_,
    rubin_df = if (estimable) pooled$df[[1L]] else NA_real_,
    valid_imputation_n = if (estimable) as.integer(pooled$valid_imputation_n[[1L]]) else 0L,
    estimate_status = if (estimable) "ESTIMABLE" else "NOT_ESTIMABLE",
    not_estimable_reason_code = if (estimable) "" else "NE_MODEL_NONCONVERGENCE",
    not_estimable_reason_detail = if (estimable) "" else "No pooled estimate was available",
    stability_flag = stability_flag,
    annotation_p = p,
    annotation_p_display = format_p_display(p),
    annotation_p_type = "contrast_specific_pooled_wald",
    significance_symbol = format_significance_symbol(p),
    notes = notes,
    stringsAsFactors = FALSE
  )
}
