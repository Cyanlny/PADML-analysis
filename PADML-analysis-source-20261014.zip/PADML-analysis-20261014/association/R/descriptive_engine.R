# 描述性分析引擎：Table 1、风险集和 KM 均固定使用 .imp=0 暴露合格队列。

safe_numeric <- function(x) suppressWarnings(as.numeric(as.character(x)))

generalized_smd_continuous <- function(x, group) {
  levels <- levels(group)
  pairs <- utils::combn(levels, 2, simplify = FALSE)
  values <- vapply(pairs, function(pair) {
    a <- x[group == pair[[1L]]]
    b <- x[group == pair[[2L]]]
    pooled <- sqrt((stats::var(a, na.rm = TRUE) + stats::var(b, na.rm = TRUE)) / 2)
    if (!is.finite(pooled) || pooled == 0) return(NA_real_)
    abs(mean(a, na.rm = TRUE) - mean(b, na.rm = TRUE)) / pooled
  }, numeric(1))
  if (all(is.na(values))) NA_real_ else max(values, na.rm = TRUE)
}

summarize_table1 <- function(data, method_registry) {
  if (!"AST_ALT_Tertile" %in% names(data)) stop("Frozen tertile is missing", call. = FALSE)
  group <- factor(data$AST_ALT_Tertile, levels = c("T1", "T2", "T3"), ordered = TRUE)
  rows <- lapply(seq_len(nrow(method_registry)), function(i) {
    rule <- method_registry[i, , drop = FALSE]
    variable <- rule$variable
    if (!variable %in% names(data)) {
      return(data.frame(
        variable = variable, overall = "", T1 = "", T2 = "", T3 = "", missing_n = NA_integer_, missing_rate = NA_real_,
        p_value = NA_real_, p_display = "", smd_generalized = NA_real_, smd_T2_T1 = NA_real_, smd_T3_T1 = NA_real_,
        method = rule$primary_test, estimate_status = "NOT_ESTIMABLE", notes = "Variable absent from source contract", stringsAsFactors = FALSE
      ))
    }
    x <- data[[variable]]
    missing_n <- sum(is.na(x))
    missing_rate <- mean(is.na(x))
    if (rule$variable_type == "continuous") {
      y <- safe_numeric(x)
      format_one <- function(z) {
        if (rule$display_method == "mean_sd") sprintf("%.2f (%.2f)", mean(z, na.rm = TRUE), stats::sd(z, na.rm = TRUE))
        else sprintf("%.2f [%.2f, %.2f]", stats::median(z, na.rm = TRUE), stats::quantile(z, 0.25, na.rm = TRUE, type = 7), stats::quantile(z, 0.75, na.rm = TRUE, type = 7))
      }
      p <- tryCatch({
        if (rule$primary_test == "ANOVA") stats::anova(stats::lm(y ~ group))[["Pr(>F)"]][[1L]]
        else stats::kruskal.test(y ~ group)$p.value
      }, error = function(e) NA_real_)
      smd <- generalized_smd_continuous(y, group)
      pooled_sd_21 <- sqrt((stats::var(y[group == "T2"], na.rm = TRUE) + stats::var(y[group == "T1"], na.rm = TRUE)) / 2)
      pooled_sd_31 <- sqrt((stats::var(y[group == "T3"], na.rm = TRUE) + stats::var(y[group == "T1"], na.rm = TRUE)) / 2)
      smd21 <- if (is.finite(pooled_sd_21) && pooled_sd_21 > 0) abs(mean(y[group == "T2"], na.rm = TRUE) - mean(y[group == "T1"], na.rm = TRUE)) / pooled_sd_21 else NA_real_
      smd31 <- if (is.finite(pooled_sd_31) && pooled_sd_31 > 0) abs(mean(y[group == "T3"], na.rm = TRUE) - mean(y[group == "T1"], na.rm = TRUE)) / pooled_sd_31 else NA_real_
      return(data.frame(
        variable = variable, overall = format_one(y), T1 = format_one(y[group == "T1"]), T2 = format_one(y[group == "T2"]), T3 = format_one(y[group == "T3"]),
        missing_n = missing_n, missing_rate = missing_rate, p_value = p, p_display = format_p_display(p), smd_generalized = smd,
        smd_T2_T1 = smd21, smd_T3_T1 = smd31, method = rule$primary_test, estimate_status = "ESTIMABLE", notes = "Observed .imp=0 values", stringsAsFactors = FALSE
      ))
    }
    factor_x <- factor(x)
    table_data <- table(factor_x, group, useNA = "no")
    p <- tryCatch({
      expected <- suppressWarnings(stats::chisq.test(table_data)$expected)
      if (any(expected < 5)) {
        set.seed(as.integer(rule$monte_carlo_seed))
        stats::fisher.test(table_data, simulate.p.value = TRUE, B = 10000)$p.value
      } else stats::chisq.test(table_data, correct = FALSE)$p.value
    }, error = function(e) NA_real_)
    format_cat <- function(index) {
      tab <- table(factor_x[index], useNA = "no")
      paste(sprintf("%s: %d (%.1f%%)", names(tab), as.integer(tab), 100 * as.integer(tab) / sum(tab)), collapse = "; ")
    }
    data.frame(
      variable = variable, overall = format_cat(rep(TRUE, length(factor_x))), T1 = format_cat(group == "T1"), T2 = format_cat(group == "T2"), T3 = format_cat(group == "T3"),
      missing_n = missing_n, missing_rate = missing_rate, p_value = p, p_display = format_p_display(p), smd_generalized = NA_real_,
      smd_T2_T1 = NA_real_, smd_T3_T1 = NA_real_, method = ifelse(any(suppressWarnings(stats::chisq.test(table_data)$expected) < 5), "Monte_Carlo_Fisher", "Pearson_chisq"),
      estimate_status = "ESTIMABLE", notes = "Observed .imp=0 values", stringsAsFactors = FALSE
    )
  })
  do.call(rbind, rows)
}

compute_riskset_results <- function(data, endpoint_registry, times = c(6, 12, 24, 36)) {
  rows <- list()
  index <- 1L
  for (i in seq_len(nrow(endpoint_registry))) {
    event_name <- endpoint_registry$event_variable[[i]]
    time_name <- endpoint_registry$time_variable[[i]]
    if (!all(c(event_name, time_name) %in% names(data))) next
    event <- .assert_analysis_binary_event_integer(data[[event_name]], event_name)
    followup <- safe_numeric(data[[time_name]])
    if (anyNA(event) || anyNA(followup) || any(followup <= 0)) stop("Invalid endpoint contract in risk-set calculation", call. = FALSE)
    interval_left <- c(0, head(times, -1L))
    for (j in seq_along(times)) {
      t <- times[[j]]
      rows[[index]] <- data.frame(
        endpoint = event_name, time_month = t, baseline_n = nrow(data), at_risk_n = sum(followup >= t),
        at_risk_fraction = mean(followup >= t), cumulative_events_by_time = sum(event == 1L & followup <= t),
        events_in_previous_interval = sum(event == 1L & followup > interval_left[[j]] & followup <= t),
        riskset_source = "frozen_imp0_exposure_eligible", stringsAsFactors = FALSE
      )
      index <- index + 1L
    }
  }
  do.call(rbind, rows)
}

compute_km_canonical <- function(data, time_variable = "Death_Followup_months", event_variable = "All_Cause_Death") {
  # 加载 survival 包以计算不依赖插补集的 KM 曲线。
  if (!requireNamespace("survival", quietly = TRUE)) stop("survival is required", call. = FALSE)
  analysis_data <- data
  analysis_data[[event_variable]] <- .assert_analysis_binary_event_integer(
    data[[event_variable]], event_variable
  )
  formula <- stats::as.formula(sprintf("survival::Surv(%s, %s) ~ AST_ALT_Tertile", time_variable, event_variable))
  fit <- survival::survfit(formula, data = analysis_data, conf.type = "log")
  summary <- summary(fit)
  strata <- if (is.null(summary$strata)) "Overall" else sub("AST_ALT_Tertile=", "", as.character(summary$strata), fixed = TRUE)
  curve <- data.frame(
    stratum = strata, time_month = summary$time, n_risk = summary$n.risk, n_event = summary$n.event,
    survival = summary$surv, lower_95_ci = summary$lower, upper_95_ci = summary$upper,
    stringsAsFactors = FALSE
  )
  logrank <- survival::survdiff(formula, data = analysis_data)
  p <- stats::pchisq(logrank$chisq, df = length(logrank$n) - 1L, lower.tail = FALSE)
  list(curve = curve, logrank = data.frame(chisq = logrank$chisq, df = length(logrank$n) - 1L, p_value = p, p_display = format_p_display(p)))
}
