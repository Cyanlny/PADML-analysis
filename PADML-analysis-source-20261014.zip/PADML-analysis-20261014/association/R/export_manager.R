# CSV导出模块：正式表格只写UTF-8 CSV。
export_canonical_csv <- function(data, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  # 写出正式CSV，并保留数值Schema。
  utils::write.csv(data, path, row.names = FALSE, na = "")
  invisible(path)
}

# SVG导出模块：正式图形只由R生成、白底且无网格。
export_smoke_svg <- function(data, path, title_cn = "合成数据构建验证") {
  # 加载绘图包以生成R原生SVG。
  if (!requireNamespace("ggplot2", quietly = TRUE)) stop("ggplot2 is required", call. = FALSE)
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  plot <- ggplot2::ggplot(data, ggplot2::aes(x = x, y = y)) +
    ggplot2::geom_line(linewidth = 0.7, colour = "#0072B2") +
    ggplot2::labs(title = title_cn, x = "时间（月）", y = "合成指标") +
    ggplot2::theme_classic(base_size = 10) +
    ggplot2::theme(panel.grid = ggplot2::element_blank(), plot.background = ggplot2::element_rect(fill = "white", colour = NA))
  # 输出SVG结果，并禁止生成PDF或PNG正式副本。
  ggplot2::ggsave(path, plot = plot, device = "svg", width = 6, height = 4, bg = "white")
  invisible(path)
}

