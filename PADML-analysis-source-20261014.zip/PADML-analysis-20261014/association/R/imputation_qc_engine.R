# 插补质控引擎：A02 只消费 v4.3 唯一 MI-QC owner，不复制阈值或诊断算法。

read_a02_mi_qc_owner <- function(root = ".") {
  if (!exists("read_mi_contract_v43", mode = "function") ||
      !exists("validate_mi_contract_v43", mode = "function")) {
    source(file.path(root, "R", "mi_recipe_engine.R"))
  }
  owner <- read_mi_contract_v43(root)
  validate_mi_contract_v43(owner)
  owner
}

a02_imputed_target_names <- function(mids_object) {
  if (!inherits(mids_object, "mids") || is.null(mids_object$method)) {
    stop("A02_MIDS_OBJECT_INVALID", call. = FALSE)
  }
  methods <- as.character(mids_object$method)
  target_names <- names(mids_object$method)[nzchar(methods)]
  if (!length(target_names) || anyDuplicated(target_names) ||
      length(setdiff(target_names, names(mids_object$data)))) {
    stop("A02_MIDS_TARGET_SET_INVALID", call. = FALSE)
  }
  target_names
}

compute_mids_chain_diagnostics <- function(mids_object, root = ".") {
  if (!exists("compute_mice_convergence_diagnostics_v43", mode = "function")) {
    source(file.path(root, "R", "mi_qc_engine_v43.R"))
  }
  owner <- read_a02_mi_qc_owner(root)
  compute_mice_convergence_diagnostics_v43(
    mids_object = mids_object,
    target_names = a02_imputed_target_names(mids_object),
    owner = owner,
    project_root = root
  )
}

approx_wasserstein <- function(a, b, probs = seq(0.01, 0.99, length.out = 99)) {
  a <- a[is.finite(a)]
  b <- b[is.finite(b)]
  if (!length(a) || !length(b)) return(NA_real_)
  mean(abs(stats::quantile(a, probs, type = 7) - stats::quantile(b, probs, type = 7)))
}

run_imputation_distribution_qc <- function(sources, frozen_completed, target_names, owner) {
  imp0 <- sources$imp0
  mask <- sources$missing_mask
  validate_mi_contract_v43(owner)
  shift_threshold <- as.numeric(owner$qc$standardized_mean_shift_review_abs_threshold)
  common <- Reduce(intersect, lapply(c(list(imp0), frozen_completed), names))
  variables <- intersect(as.character(target_names), common)
  if (!identical(variables, as.character(target_names))) {
    stop("A02_DISTRIBUTION_TARGET_SET_INVALID", call. = FALSE)
  }
  rows <- lapply(variables, function(variable) {
    original <- imp0[[variable]]
    missing_index <- if (!is.null(mask) && variable %in% colnames(mask)) as.logical(mask[, variable]) else is.na(original)
    observed_index <- !missing_index & !is.na(original)
    completed_values <- unlist(lapply(frozen_completed, function(data) data[[variable]][missing_index]), use.names = FALSE)
    if (is.numeric(original) || is.integer(original)) {
      observed <- as.numeric(original[observed_index])
      completed_numeric <- suppressWarnings(as.numeric(completed_values))
      data.frame(
        variable = variable, variable_type = "continuous", observed_n = length(observed), imputed_n_total = length(completed_numeric),
        observed_mean = mean(observed, na.rm = TRUE), imputed_mean = mean(completed_numeric, na.rm = TRUE),
        observed_sd = stats::sd(observed, na.rm = TRUE), imputed_sd = stats::sd(completed_numeric, na.rm = TRUE),
        standardized_mean_shift = ifelse(stats::sd(observed, na.rm = TRUE) > 0, (mean(completed_numeric, na.rm = TRUE) - mean(observed, na.rm = TRUE)) / stats::sd(observed, na.rm = TRUE), NA_real_),
        wasserstein_approx = approx_wasserstein(observed, completed_numeric), illegal_level_n = NA_integer_, remaining_missing_n = sum(vapply(frozen_completed, function(data) sum(is.na(data[[variable]])), integer(1))),
        nonfinite_n = sum(!is.finite(completed_numeric), na.rm = TRUE),
        review_flag = ifelse(
          abs((mean(completed_numeric, na.rm = TRUE) - mean(observed, na.rm = TRUE)) / stats::sd(observed, na.rm = TRUE)) > shift_threshold,
          "MANUAL_REVIEW", "PASS"
        ),
        stringsAsFactors = FALSE
      )
    } else {
      allowed <- unique(as.character(original[observed_index]))
      imputed <- as.character(completed_values)
      data.frame(
        variable = variable, variable_type = "categorical", observed_n = sum(observed_index), imputed_n_total = length(imputed),
        observed_mean = NA_real_, imputed_mean = NA_real_, observed_sd = NA_real_, imputed_sd = NA_real_, standardized_mean_shift = NA_real_, wasserstein_approx = NA_real_,
        illegal_level_n = sum(!is.na(imputed) & !imputed %in% allowed), remaining_missing_n = sum(vapply(frozen_completed, function(data) sum(is.na(data[[variable]])), integer(1))),
        nonfinite_n = NA_integer_, review_flag = ifelse(sum(!is.na(imputed) & !imputed %in% allowed) > 0L, "FAIL", "PASS"), stringsAsFactors = FALSE
      )
    }
  })
  do.call(rbind, rows)
}

summarize_logged_events <- function(logged_events) {
  if (is.null(logged_events) || !nrow(logged_events)) {
    return(data.frame(event_id = character(), iteration = integer(), imputation = integer(), variable = character(), message = character(), review_status = character(), stringsAsFactors = FALSE))
  }
  output <- as.data.frame(logged_events, stringsAsFactors = FALSE)
  names(output) <- make.names(names(output), unique = TRUE)
  output$event_id <- sprintf("LE%04d", seq_len(nrow(output)))
  output$review_status <- "MANUAL_REVIEW_REQUIRED"
  output
}

run_imputation_structure_qc <- function(frozen_completed, expected_m = 20L) {
  if (!is.list(frozen_completed) || length(frozen_completed) != as.integer(expected_m) ||
      !length(frozen_completed) || any(!vapply(frozen_completed, is.data.frame, logical(1)))) {
    stop("A02_COMPLETED_DATASET_COUNT_INVALID", call. = FALSE)
  }
  reference_ids <- as.character(frozen_completed[[1L]]$Patient_ID)
  reference_names <- names(frozen_completed[[1L]])
  rows <- lapply(seq_along(frozen_completed), function(i) {
    data <- frozen_completed[[i]]
    numeric_columns <- vapply(data, is.numeric, logical(1))
    data.frame(
      imputation = i, row_n = nrow(data), column_n = ncol(data),
      same_patient_set = setequal(as.character(data$Patient_ID), reference_ids),
      same_patient_order = identical(as.character(data$Patient_ID), reference_ids),
      same_column_order = identical(names(data), reference_names),
      remaining_missing_n = sum(is.na(data)),
      nonfinite_numeric_n = sum(vapply(data[numeric_columns], function(x) sum(!is.finite(x)), integer(1))),
      stringsAsFactors = FALSE
    )
  })
  output <- do.call(rbind, rows)
  output$status <- ifelse(
    output$same_patient_set & output$same_patient_order & output$same_column_order & output$remaining_missing_n == 0L & output$nonfinite_numeric_n == 0L,
    "PASS", "FAIL"
  )
  output
}
