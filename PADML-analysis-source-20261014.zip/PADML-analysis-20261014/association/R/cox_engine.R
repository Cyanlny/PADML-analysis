# 固定 Cox 生产引擎：按 registry 构建 M1-M5 并在每套插补中独立拟合。

normalize_cox_factor_levels <- function(data) {
  if ("AST_ALT_Tertile" %in% names(data)) data$AST_ALT_Tertile <- factor(as.character(data$AST_ALT_Tertile), levels = c("T1", "T2", "T3"))
  factor_levels <- list(
    Sex = c("0", "1"), Rutherford_cat = c("Grade 0-2", "Grade 3-4", "Grade 5-6"),
    Prior_LE_Surgery_cat = c("None", "Procedure", "Amputation", "Other"),
    Surgery_Type_cat = c("None", "Procedure", "Amputation", "Other"),
    HF_NYHA_bin = c("No", "Yes")
  )
  for (variable in intersect(names(factor_levels), names(data))) {
    observed <- as.character(data[[variable]])
    requested <- factor_levels[[variable]]
    if (all(observed[!is.na(observed)] %in% requested)) data[[variable]] <- factor(observed, levels = requested)
  }
  data
}

required_exposure_coefficients <- function(exposure_form) {
  if (exposure_form == "log2_AST_ALT") "log2_AST_ALT" else c("AST_ALT_TertileT2", "AST_ALT_TertileT3")
}

# 将 Cox 对象压缩为后续审计真正需要的数值层，避免公式环境捕获整套患者数据。
compact_cox_fit <- function(fit) {
  if (is.null(fit)) return(NULL)
  list(
    coefficients = stats::coef(fit),
    covariance = stats::vcov(fit),
    n = fit$n,
    nevent = fit$nevent,
    loglik = fit$loglik,
    concordance = fit$concordance,
    failure = if (is.null(fit$fail)) "" else as.character(fit$fail)
  )
}

# 压缩一个插补模型集合，并移除可捕获完整数据的公式环境与设计矩阵。
compact_cox_collection <- function(collection) {
  collection$fits <- lapply(collection$fits, compact_cox_fit)
  collection
}

fit_cox_collection <- function(completed, model_id, endpoint_row, exposure_form, root = ".", covariates_override = NULL) {
  source(file.path(root, "R", "model_term_map.R"))
  formula_text <- build_cox_formula_text(model_id, endpoint_row, exposure_form, root, covariates_override)
  formula <- stats::as.formula(formula_text)
  fits <- vector("list", length(completed))
  failures <- vector("list", length(completed))
  for (i in seq_along(completed)) {
    data <- normalize_cox_factor_levels(completed[[i]])
    missing_terms <- setdiff(all.vars(formula), names(data))
    if (length(missing_terms)) {
      failures[[i]] <- paste("missing variables", paste(missing_terms, collapse = "|"))
      next
    }
    fits[[i]] <- tryCatch({
      # 加载 survival 包并拟合当前插补集的预注册 Cox 模型。
      if (!requireNamespace("survival", quietly = TRUE)) stop("survival is required")
      survival::coxph(formula, data = data, ties = "efron", na.action = stats::na.fail, x = TRUE, y = TRUE, model = TRUE)
    }, error = function(e) {
      failures[[i]] <<- conditionMessage(e)
      NULL
    })
  }
  list(fits = fits, failures = failures, formula_text = formula_text, model_id = model_id, exposure_form = exposure_form, endpoint_row = endpoint_row)
}

extract_fit_diagnostics <- function(collection) {
  rows <- lapply(seq_along(collection$fits), function(i) {
    fit <- collection$fits[[i]]
    if (is.null(fit)) {
      return(data.frame(
        imputation = i, model_id = collection$model_id, exposure_form = collection$exposure_form,
        converged = FALSE, coefficient_n = NA_integer_, loglik = NA_real_, failure_reason = collection$failures[[i]], stringsAsFactors = FALSE
      ))
    }
    converged <- all(is.finite(stats::coef(fit))) && all(is.finite(stats::vcov(fit))) && is.null(fit$fail)
    data.frame(
      imputation = i, model_id = collection$model_id, exposure_form = collection$exposure_form,
      converged = converged, coefficient_n = length(stats::coef(fit)), loglik = tail(fit$loglik, 1L), failure_reason = "", stringsAsFactors = FALSE
    )
  })
  do.call(rbind, rows)
}

fixed_collection_model_signature <- function(collection, root = ".") {
  source(file.path(root, "R", "model_signature.R"))
  endpoint <- collection$endpoint_row$event_variable[[1L]]
  exposure_terms <- required_exposure_coefficients(collection$exposure_form)
  model_signature_sha256(
    endpoint = endpoint, population = "MAIN_EXPOSURE_ELIGIBLE", exposure = "AST_ALT",
    exposure_scale = collection$exposure_form, formula_text = collection$formula_text,
    factor_references = c("AST_ALT_Tertile=T1"), ties_method = "efron", time_origin = "baseline",
    time_function = "fixed", tve_terms = character(), contrast = paste(exposure_terms, collapse = "|"),
    pooling_method = "Rubin_scalar", confidence_level = 0.95, scientific_config_revision = "r02"
  )
}

pool_fixed_cox_collection <- function(collection, root = ".") {
  source(file.path(root, "R", "pooling_engine.R"))
  source(file.path(root, "R", "canonical_results.R"))
  source(file.path(root, "R", "model_signature.R"))
  valid <- Filter(Negate(is.null), collection$fits)
  if (!length(valid)) return(data.frame())
  exposure_terms <- if (collection$exposure_form == "log2_AST_ALT") "log2_AST_ALT" else c("AST_ALT_TertileT2", "AST_ALT_TertileT3")
  endpoint <- collection$endpoint_row$event_variable[[1L]]
  n <- collection$fits[[which(!vapply(collection$fits, is.null, logical(1)))[[1L]]]]$n
  events <- collection$fits[[which(!vapply(collection$fits, is.null, logical(1)))[[1L]]]]$nevent
  signature <- fixed_collection_model_signature(collection, root)
  rows <- lapply(exposure_terms, function(term) {
    estimates <- vapply(collection$fits, function(fit) if (is.null(fit) || !term %in% names(stats::coef(fit))) NA_real_ else stats::coef(fit)[[term]], numeric(1))
    variances <- vapply(collection$fits, function(fit) if (is.null(fit) || !term %in% names(stats::coef(fit))) NA_real_ else stats::vcov(fit)[term, term], numeric(1))
    pooled <- tryCatch(pool_scalar_rubin(estimates, variances), error = function(e) NULL)
    contrast <- sub("AST_ALT_Tertile", "", term, fixed = TRUE)
    if (contrast == "log2_AST_ALT") contrast <- "per_doubling"
    if (contrast %in% c("T2", "T3")) contrast <- paste0(contrast, "_vs_T1")
    new_canonical_result_row(
      estimand_id = paste(endpoint, collection$model_id, collection$exposure_form, contrast, "FIXED", sep = "__"),
      endpoint = endpoint, model_id = collection$model_id, model_signature_sha256 = signature,
      exposure_parameterization = collection$exposure_form, contrast = contrast,
      n = n, events = events, pooled = pooled,
      stability_flag = ifelse(sum(is.finite(estimates)) == length(collection$fits), "STABLE", "INCOMPLETE_IMPUTATIONS"),
      notes = "Fixed Cox average association"
    )
  })
  do.call(rbind, rows)
}

run_fixed_cox_stage <- function(completed, endpoint_row, root = ".") {
  models <- paste0("M", 1:5)
  forms <- c("AST_ALT_Tertile", "log2_AST_ALT")
  collections <- list()
  canonical <- list()
  diagnostics <- list()
  index <- 1L
  for (model_id in models) {
    for (form in forms) {
      collection <- fit_cox_collection(completed, model_id, endpoint_row, form, root)
      key <- paste(model_id, form, sep = "__")
      collections[[key]] <- collection
      diagnostics[[index]] <- extract_fit_diagnostics(collection)
      canonical[[index]] <- pool_fixed_cox_collection(collection, root)
      index <- index + 1L
    }
  }
  list(collections = collections, canonical = do.call(rbind, canonical), diagnostics = do.call(rbind, diagnostics))
}

# 生成20套插补乘两种暴露形式的40个A03拟合分支；分支本身不复制患者数据。
make_a03_branch_specs <- function(completed) {
  specifications <- expand.grid(
    imputation = seq_along(completed),
    exposure_form = c("AST_ALT_Tertile", "log2_AST_ALT"),
    stringsAsFactors = FALSE
  )
  lapply(seq_len(nrow(specifications)), function(index) specifications[index, , drop = FALSE])
}

# 在一个插补乘暴露形式分支内依次首次拟合M1-M5，共享类型规范和数据加载。
fit_fixed_cox_branch <- function(completed, branch_spec, endpoint_row, root = ".") {
  source(file.path(root, "R", "model_term_map.R"))
  imputation <- as.integer(branch_spec$imputation[[1L]])
  exposure_form <- branch_spec$exposure_form[[1L]]
  data <- normalize_cox_factor_levels(completed[[imputation]])
  models <- paste0("M", 1:5)
  fits <- setNames(vector("list", length(models)), models)
  failures <- setNames(vector("list", length(models)), models)
  warnings <- setNames(vector("list", length(models)), models)
  formula_texts <- setNames(character(length(models)), models)
  for (model_id in models) {
    formula_text <- build_cox_formula_text(model_id, endpoint_row, exposure_form, root)
    formula_texts[[model_id]] <- formula_text
    formula <- stats::as.formula(formula_text)
    missing_terms <- setdiff(all.vars(formula), names(data))
    if (length(missing_terms)) {
      failures[[model_id]] <- paste("missing variables", paste(missing_terms, collapse = "|"))
      next
    }
    captured_warnings <- character()
    fits[[model_id]] <- tryCatch(
      withCallingHandlers({
        # 加载 survival 包并执行当前分支的预注册 fixed Cox 首次拟合。
        if (!requireNamespace("survival", quietly = TRUE)) stop("survival is required")
        survival::coxph(
          formula, data = data, ties = "efron", na.action = stats::na.fail,
          x = TRUE, y = TRUE, model = TRUE
        )
      }, warning = function(warning) {
        captured_warnings <<- c(captured_warnings, conditionMessage(warning))
        invokeRestart("muffleWarning")
      }),
      error = function(error) {
        failures[[model_id]] <<- conditionMessage(error)
        NULL
      }
    )
    warnings[[model_id]] <- paste(unique(captured_warnings), collapse = " | ")
  }
  list(
    endpoint = endpoint_row$event_variable[[1L]],
    endpoint_row = endpoint_row,
    imputation = imputation,
    exposure_form = exposure_form,
    fits = fits,
    failures = failures,
    warnings = warnings,
    formula_texts = formula_texts,
    project_root = root,
    planned_fit_count = length(models),
    observed_fit_attempt_count = length(models)
  )
}

is_a03_fit_bundle <- function(value) {
  is.list(value) && all(c("endpoint", "imputation", "exposure_form", "fits", "formula_texts") %in% names(value))
}

# 兼容targets动态分支聚合形态，仅保留真正的A03拟合bundle。
flatten_a03_fit_bundles <- function(value) {
  if (is_a03_fit_bundle(value)) return(list(value))
  if (!is.list(value)) return(list())
  unlist(lapply(value, flatten_a03_fit_bundles), recursive = FALSE)
}

fit_bundle_status <- function(bundle) {
  do.call(rbind, lapply(names(bundle$fits), function(model_id) {
    fit <- bundle$fits[[model_id]]
    coefficient <- if (is.null(fit)) numeric() else stats::coef(fit)
    covariance <- if (is.null(fit)) matrix(numeric(), 0, 0) else stats::vcov(fit)
    required <- required_exposure_coefficients(bundle$exposure_form)
    required_available <- !is.null(fit) && all(required %in% names(coefficient)) && all(is.finite(coefficient[required]))
    required_covariance_valid <- required_available && all(is.finite(covariance[required, required, drop = FALSE]))
    collection_stub <- list(
      endpoint_row = bundle$endpoint_row, exposure_form = bundle$exposure_form,
      formula_text = bundle$formula_texts[[model_id]]
    )
    data.frame(
      fit_id = paste(bundle$endpoint, bundle$imputation, bundle$exposure_form, model_id, sep = "__"),
      endpoint = bundle$endpoint,
      imputation = bundle$imputation,
      model_id = model_id,
      exposure_form = bundle$exposure_form,
      model_signature_sha256 = fixed_collection_model_signature(collection_stub, bundle$project_root),
      fit_attempted = TRUE,
      fit_available = !is.null(fit),
      converged = !is.null(fit) && required_available && required_covariance_valid && is.null(fit$fail),
      all_coefficient_finite = !is.null(fit) && all(is.finite(coefficient)),
      coefficient_n = if (is.null(fit)) NA_integer_ else length(coefficient),
      coefficient_finite_n = sum(is.finite(coefficient)),
      covariance_valid = required_covariance_valid,
      full_covariance_valid = !is.null(fit) && length(covariance) && all(is.finite(covariance)),
      warning = if (is.null(bundle$warnings[[model_id]])) "" else bundle$warnings[[model_id]],
      failure_reason = if (is.null(bundle$failures[[model_id]])) "" else bundle$failures[[model_id]],
      stringsAsFactors = FALSE
    )
  }))
}

# 将40个分支还原为既有的模型乘暴露collection，供pooling和PH共同读取，不重新拟合。
combine_a03_fit_bundles <- function(fit_bundles, root = ".") {
  fit_bundles <- flatten_a03_fit_bundles(fit_bundles)
  if (length(fit_bundles) != 40L) stop("A03 requires exactly 40 fit branches", call. = FALSE)
  models <- paste0("M", 1:5)
  forms <- c("AST_ALT_Tertile", "log2_AST_ALT")
  endpoint_row <- fit_bundles[[1L]]$endpoint_row
  collections <- list()
  for (model_id in models) {
    for (form in forms) {
      selected <- fit_bundles[vapply(fit_bundles, function(bundle) identical(bundle$exposure_form, form), logical(1))]
      selected <- selected[order(vapply(selected, function(bundle) bundle$imputation, integer(1)))]
      key <- paste(model_id, form, sep = "__")
      collections[[key]] <- list(
        fits = lapply(selected, function(bundle) bundle$fits[[model_id]]),
        failures = lapply(selected, function(bundle) bundle$failures[[model_id]]),
        formula_text = selected[[1L]]$formula_texts[[model_id]],
        model_id = model_id,
        exposure_form = form,
        endpoint_row = endpoint_row
      )
    }
  }
  diagnostics <- do.call(rbind, lapply(fit_bundles, fit_bundle_status))
  canonical <- do.call(rbind, lapply(collections, pool_fixed_cox_collection, root = root))
  list(
    collections = collections,
    canonical = canonical,
    diagnostics = diagnostics,
    fit_bundles = fit_bundles,
    observed_fixed_cox_fit_count = sum(vapply(fit_bundles, function(bundle) bundle$observed_fit_attempt_count, integer(1))),
    expected_fixed_cox_fit_count = 200L
  )
}
