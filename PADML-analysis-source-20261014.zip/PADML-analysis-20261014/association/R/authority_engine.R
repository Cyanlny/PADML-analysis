# v4.3 权威与裁决引擎：一个 semantic_key 仅允许一个 ACTIVE owner。

.authority_stop <- function(code, detail = "") {
  message <- if (nzchar(detail)) paste(code, detail, sep = ": ") else code
  stop(message, call. = FALSE)
}

.authority_canonicalize <- function(value) {
  if (is.data.frame(value)) return(lapply(seq_len(nrow(value)), function(index) .authority_canonicalize(as.list(value[index, , drop = FALSE]))))
  if (is.list(value)) {
    if (!is.null(names(value))) value <- value[order(names(value))]
    return(lapply(value, .authority_canonicalize))
  }
  if (!is.null(names(value))) return(lapply(as.list(value[order(names(value))]), .authority_canonicalize))
  value
}

if (!exists("canonical_json", mode = "function")) {
  canonical_json <- function(value) {
    # 加载 JSON 包并生成权威记录的规范序列化。
    if (!requireNamespace("jsonlite", quietly = TRUE)) .authority_stop("AUTHORITY_DEPENDENCY_MISSING", "jsonlite")
    as.character(jsonlite::toJSON(.authority_canonicalize(value), auto_unbox = TRUE, null = "null", na = "null", digits = 17, pretty = FALSE))
  }
}

.authority_sha256_text <- function(text) {
  # 加载摘要包并计算权威身份 SHA-256。
  if (!requireNamespace("digest", quietly = TRUE)) .authority_stop("AUTHORITY_DEPENDENCY_MISSING", "digest")
  digest::digest(enc2utf8(paste(text, collapse = "\n")), algo = "sha256", serialize = FALSE)
}

.authority_file_sha256 <- function(path) {
  # 加载摘要包并计算 owner 文件 SHA-256。
  if (!requireNamespace("digest", quietly = TRUE)) .authority_stop("AUTHORITY_DEPENDENCY_MISSING", "digest")
  digest::digest(file = path, algo = "sha256", serialize = FALSE)
}

.split_consumers <- function(value) {
  if (length(value) != 1L || is.na(value) || !nzchar(value)) return(character())
  strsplit(value, "|", fixed = TRUE)[[1L]]
}

read_contract_index <- function(project_root = ".") {
  path <- file.path(project_root, "config", "contract_index.csv")
  if (!file.exists(path)) .authority_stop("CONTRACT_INDEX_MISSING")
  utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE, na.strings = character())
}

.supersession_is_acyclic <- function(index) {
  parent <- setNames(index$supersedes_contract_id, index$contract_id)
  for (start in names(parent)) {
    seen <- character()
    node <- start
    while (nzchar(parent[[node]])) {
      node <- parent[[node]]
      if (node %in% seen || identical(node, start)) return(FALSE)
      seen <- c(seen, node)
    }
  }
  TRUE
}

.supersession_ancestors <- function(index, contract_id) {
  parent <- setNames(index$supersedes_contract_id, index$contract_id)
  ancestors <- character()
  node <- contract_id
  while (nzchar(parent[[node]])) {
    node <- parent[[node]]
    ancestors <- c(ancestors, node)
  }
  ancestors
}

.validate_amendment_decision_receipts <- function(amendment, project_root) {
  receipts <- amendment$decision_receipts
  required <- c(
    "decision_id", "conflict_id", "selected_option_id", "selection_sha256",
    "decision_package_sha256", "selection_receipt_relative_path", "approved_at"
  )
  if (!is.data.frame(receipts) || !nrow(receipts) || !identical(names(receipts), required) ||
      anyDuplicated(receipts$decision_id)) {
    .authority_stop("AMENDMENT_DECISION_RECEIPT_INVALID")
  }
  for (index in seq_len(nrow(receipts))) {
    row <- receipts[index, , drop = FALSE]
    if (!grepl("^[0-9a-f]{64}$", row$conflict_id[[1L]]) ||
        !grepl("^[0-9a-f]{64}$", row$selection_sha256[[1L]]) ||
        !grepl("^[0-9a-f]{64}$", row$decision_package_sha256[[1L]]) ||
        !identical(.authority_sha256_text(row$selected_option_id[[1L]]), row$selection_sha256[[1L]]) ||
        grepl("^/|^[A-Za-z]:[/\\\\]|(^|/)\\.\\.(/|$)", row$selection_receipt_relative_path[[1L]], perl = TRUE)) {
      .authority_stop("AMENDMENT_DECISION_RECEIPT_INVALID", row$decision_id[[1L]])
    }
    selection_path <- file.path(project_root, row$selection_receipt_relative_path[[1L]])
    if (!file.exists(selection_path) || file.info(selection_path)$isdir) {
      .authority_stop("AMENDMENT_SELECTION_RECEIPT_MISSING", row$decision_id[[1L]])
    }
    # 加载 JSON 包并验证用户选择收据与原 DecisionPackage 的闭包。
    if (!requireNamespace("jsonlite", quietly = TRUE)) .authority_stop("AUTHORITY_DEPENDENCY_MISSING", "jsonlite")
    selection <- jsonlite::read_json(selection_path, simplifyVector = TRUE)
    selection_required <- c(
      "schema_version", "decision_id", "conflict_id", "decision_package_relative_path",
      "decision_package_sha256", "selected_option_id", "selection_sha256", "status",
      "authority_class", "approved_at", "activation_owner_relative_path",
      "activation_owner_pointer", "invalidation_frontier"
    )
    if (!identical(names(selection), selection_required) ||
        !identical(selection$decision_id, row$decision_id[[1L]]) ||
        !identical(selection$conflict_id, row$conflict_id[[1L]]) ||
        !identical(selection$selected_option_id, row$selected_option_id[[1L]]) ||
        !identical(selection$selection_sha256, row$selection_sha256[[1L]]) ||
        !identical(selection$decision_package_sha256, row$decision_package_sha256[[1L]]) ||
        !identical(selection$status, "HUMAN_APPROVED") ||
        !identical(selection$authority_class, "USER_SELECTION") ||
        !identical(selection$activation_owner_relative_path,
          "protocol/amendments/MAIN_V43_R00_CONFLICT_SAFE_DRIFT_SAFE_EXACT_CLOSURE_FINAL.json") ||
        !identical(selection$activation_owner_pointer, "/scientific_contract/mi_predictor_rule")) {
      .authority_stop("AMENDMENT_SELECTION_RECEIPT_MISMATCH", row$decision_id[[1L]])
    }
    package_path <- file.path(project_root, selection$decision_package_relative_path)
    if (!file.exists(package_path) ||
        !identical(.authority_file_sha256(package_path), row$decision_package_sha256[[1L]])) {
      .authority_stop("AMENDMENT_DECISION_PACKAGE_IDENTITY_MISMATCH", row$decision_id[[1L]])
    }
    package <- jsonlite::read_json(package_path, simplifyVector = FALSE)
    option_ids <- vapply(package$options, `[[`, character(1), "option_id")
    if (!identical(package$decision_id, row$decision_id[[1L]]) ||
        !identical(package$conflict_id, row$conflict_id[[1L]]) ||
        !row$selected_option_id[[1L]] %in% option_ids) {
      .authority_stop("AMENDMENT_DECISION_OPTION_INVALID", row$decision_id[[1L]])
    }
  }
  TRUE
}

.validate_active_amendments <- function(index, project_root) {
  amendments <- unique(index$owner_relative_path[index$status == "ACTIVE" & index$authority_class == "AMENDMENT"])
  for (relative_path in amendments) {
    # 加载 JSON 包并验证 active amendment 的 decision/hash/activation receipt。
    if (!requireNamespace("jsonlite", quietly = TRUE)) .authority_stop("AUTHORITY_DEPENDENCY_MISSING", "jsonlite")
    amendment <- tryCatch(
      jsonlite::read_json(file.path(project_root, relative_path), simplifyVector = TRUE),
      error = function(error) .authority_stop("AMENDMENT_JSON_INVALID", relative_path)
    )
    required <- c(
      "amendment_id", "decision_id", "directive_sha256", "status",
      "supersedes_contract_ids", "decision_receipts"
    )
    if (length(setdiff(required, names(amendment))) ||
        !is.character(amendment$decision_id) || length(amendment$decision_id) != 1L || !nzchar(amendment$decision_id) ||
        !is.character(amendment$directive_sha256) || length(amendment$directive_sha256) != 1L || !grepl("^[0-9a-f]{64}$", amendment$directive_sha256) ||
        !identical(amendment$status, "ACTIVE")) {
      .authority_stop("AMENDMENT_ACTIVATION_RECEIPT_INVALID", relative_path)
    }
    .validate_amendment_decision_receipts(amendment, project_root)
    indexed_superseded <- sort(unique(index$supersedes_contract_id[
      index$status == "ACTIVE" & index$authority_class == "AMENDMENT" &
        index$owner_relative_path == relative_path & nzchar(index$supersedes_contract_id)
    ]))
    declared_superseded <- sort(unique(as.character(amendment$supersedes_contract_ids)))
    if (length(setdiff(indexed_superseded, declared_superseded))) {
      .authority_stop("AMENDMENT_SUPERSESSION_RECEIPT_MISMATCH", relative_path)
    }
  }
  TRUE
}

validate_contract_index <- function(index, project_root = ".") {
  required <- c(
    "contract_id", "semantic_key", "owner_relative_path", "owner_pointer",
    "authority_class", "status", "supersedes_contract_id", "producer_stage",
    "consumer_stages", "schema_id", "semantic_domain", "data_classification"
  )
  if (!is.data.frame(index) || !identical(names(index), required)) .authority_stop("CONTRACT_INDEX_SCHEMA_INVALID")
  if (!nrow(index) || anyDuplicated(index$contract_id) || any(!grepl("^[A-Z][A-Z0-9_]*$", index$contract_id))) {
    .authority_stop("CONTRACT_ID_INVALID")
  }
  if (any(!nzchar(index$semantic_key)) || any(!nzchar(index$owner_pointer))) .authority_stop("CONTRACT_POINTER_INVALID")
  if (any(grepl("^/|^[A-Za-z]:[/\\\\]|(^|/)\\.\\.(/|$)", index$owner_relative_path, perl = TRUE))) {
    .authority_stop("CONTRACT_OWNER_PATH_NOT_RELATIVE")
  }
  allowed_authority <- c("AMENDMENT", "PROTOCOL", "REGISTRY", "REFERENCE_APPROVAL", "COMPILED_PROJECTION")
  allowed_status <- c("ACTIVE", "RETIRED", "HISTORICAL")
  allowed_domain <- c("SOURCE_IDENTITY", "SOURCE_PREPROCESSING", "MI_RECIPE", "SCIENTIFIC_MODEL", "SENSITIVITY", "PUBLICATION", "CONTROL_PLANE", "REMOTE_RUNTIME", "DOCUMENTATION_ONLY")
  allowed_classification <- c("PUBLIC_AGGREGATE", "RESTRICTED_AGGREGATE", "PATIENT_LEVEL_RESTRICTED")
  if (any(!index$authority_class %in% allowed_authority)) .authority_stop("AUTHORITY_CLASS_INVALID")
  if (any(!index$status %in% allowed_status)) .authority_stop("CONTRACT_STATUS_INVALID")
  if (any(!index$semantic_domain %in% allowed_domain)) .authority_stop("SEMANTIC_DOMAIN_INVALID")
  if (any(!index$data_classification %in% allowed_classification)) .authority_stop("DATA_CLASSIFICATION_INVALID")

  active <- index[index$status == "ACTIVE", , drop = FALSE]
  owner_count <- table(active$semantic_key)
  duplicate_active_owner_n <- sum(owner_count > 1L)
  if (duplicate_active_owner_n) .authority_stop("DUPLICATE_ACTIVE_OWNER")
  owner_paths <- file.path(project_root, index$owner_relative_path)
  missing_owner_n <- sum(!file.exists(owner_paths) | file.info(owner_paths)$isdir %in% TRUE)
  if (missing_owner_n) .authority_stop("CONTRACT_OWNER_MISSING")

  superseded <- index$supersedes_contract_id[nzchar(index$supersedes_contract_id)]
  if (length(setdiff(superseded, index$contract_id))) .authority_stop("SUPERSESSION_TARGET_MISSING")
  supersession_acyclic <- .supersession_is_acyclic(index)
  if (!supersession_acyclic) .authority_stop("SUPERSESSION_CYCLE")
  active_supersedes_active <- vapply(seq_len(nrow(active)), function(position) {
    predecessor <- active$supersedes_contract_id[[position]]
    nzchar(predecessor) && index$status[match(predecessor, index$contract_id)] == "ACTIVE"
  }, logical(1))
  if (any(active_supersedes_active)) .authority_stop("ACTIVE_SUPERSEDES_ACTIVE")
  .validate_active_amendments(index, project_root)

  repeated_keys <- names(table(index$semantic_key))[table(index$semantic_key) > 1L]
  unresolved_alias_n <- sum(vapply(repeated_keys, function(key) {
    rows <- index[index$semantic_key == key, , drop = FALSE]
    active_id <- rows$contract_id[rows$status == "ACTIVE"]
    if (length(active_id) != 1L) return(TRUE)
    inactive_ids <- rows$contract_id[rows$status != "ACTIVE"]
    !all(inactive_ids %in% .supersession_ancestors(index, active_id[[1L]]))
  }, logical(1)))
  if (unresolved_alias_n) .authority_stop("UNRESOLVED_CONTRACT_ALIAS")

  scientific_domains <- c("SOURCE_IDENTITY", "SOURCE_PREPROCESSING", "MI_RECIPE", "SCIENTIFIC_MODEL", "SENSITIVITY", "PUBLICATION")
  runtime_writable <- active$semantic_domain %in% scientific_domains &
    (grepl("^(runs|runtime|cache|approved_cache|candidate_cache)/", active$owner_relative_path) |
       active$authority_class == "COMPILED_PROJECTION")
  runtime_writable_scientific_field_n <- sum(runtime_writable)
  if (runtime_writable_scientific_field_n) .authority_stop("RUNTIME_WRITABLE_SCIENTIFIC_OWNER")

  list(
    contract_n = nrow(index),
    active_contract_n = nrow(active),
    duplicate_active_owner_n = as.integer(duplicate_active_owner_n),
    missing_owner_n = as.integer(missing_owner_n),
    unresolved_alias_n = as.integer(unresolved_alias_n),
    runtime_writable_scientific_field_n = as.integer(runtime_writable_scientific_field_n),
    supersession_acyclic = supersession_acyclic
  )
}

resolve_authority <- function(index, semantic_key) {
  rows <- index[index$semantic_key == semantic_key & index$status == "ACTIVE", , drop = FALSE]
  if (nrow(rows) == 0L) .authority_stop("ACTIVE_OWNER_MISSING", semantic_key)
  if (nrow(rows) != 1L) .authority_stop("DUPLICATE_ACTIVE_OWNER", semantic_key)
  rows
}

.authority_pointer_tokens <- function(pointer) {
  if (!is.character(pointer) || length(pointer) != 1L || is.na(pointer) || !nzchar(pointer)) {
    .authority_stop("OWNER_POINTER_INVALID")
  }
  if (identical(pointer, "/")) return(character())
  if (!startsWith(pointer, "/")) .authority_stop("OWNER_POINTER_INVALID", pointer)
  tokens <- strsplit(substring(pointer, 2L), "/", fixed = TRUE)[[1L]]
  gsub("~1", "/", gsub("~0", "~", tokens, fixed = TRUE), fixed = TRUE)
}

.authority_json_pointer_value <- function(object, tokens, pointer) {
  value <- object
  for (token in tokens) {
    if (is.list(value) && !is.null(names(value)) && token %in% names(value)) {
      value <- value[[token]]
    } else if (is.list(value) && is.null(names(value)) && grepl("^(0|[1-9][0-9]*)$", token)) {
      index <- as.integer(token) + 1L
      if (index > length(value)) .authority_stop("OWNER_POINTER_NOT_FOUND", pointer)
      value <- value[[index]]
    } else {
      .authority_stop("OWNER_POINTER_NOT_FOUND", pointer)
    }
  }
  value
}

.authority_owner_value_sha256 <- function(path, pointer) {
  tokens <- .authority_pointer_tokens(pointer)
  if (!length(tokens)) return(.authority_file_sha256(path))
  extension <- tolower(tools::file_ext(path))
  value <- if (identical(extension, "json")) {
    # 加载 JSON 包并只投影 owner_pointer 指定的语义值，避免同文件跨 epoch 串扰。
    if (!requireNamespace("jsonlite", quietly = TRUE)) {
      .authority_stop("AUTHORITY_DEPENDENCY_MISSING", "jsonlite")
    }
    object <- jsonlite::read_json(path, simplifyVector = FALSE)
    .authority_json_pointer_value(object, tokens, pointer)
  } else if (identical(extension, "csv") && identical(tokens[[1L]], "rows")) {
    data <- utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE, na.strings = character())
    if (length(tokens) == 1L) {
      data
    } else if (length(tokens) == 2L && ncol(data) >= 1L) {
      rows <- data[as.character(data[[1L]]) == tokens[[2L]], , drop = FALSE]
      if (nrow(rows) != 1L) .authority_stop("OWNER_POINTER_ROW_CARDINALITY", pointer)
      rows
    } else {
      .authority_stop("OWNER_POINTER_UNSUPPORTED", pointer)
    }
  } else {
    .authority_stop("OWNER_POINTER_UNSUPPORTED", pointer)
  }
  .authority_sha256_text(canonical_json(value))
}

.authority_projection <- function(rows, project_root) {
  rows <- rows[order(rows$semantic_key, rows$contract_id), , drop = FALSE]
  owner_sha <- vapply(seq_len(nrow(rows)), function(index) {
    .authority_owner_value_sha256(
      file.path(project_root, rows$owner_relative_path[[index]]),
      rows$owner_pointer[[index]]
    )
  }, character(1))
  paste(
    rows$contract_id, rows$semantic_key, rows$owner_relative_path, rows$owner_pointer,
    rows$authority_class, rows$status, rows$supersedes_contract_id,
    rows$producer_stage, rows$consumer_stages, rows$schema_id,
    rows$semantic_domain, rows$data_classification, owner_sha,
    sep = "\t", collapse = "\n"
  )
}

authority_digests <- function(index, project_root = ".", stage = NULL) {
  validate_contract_index(index, project_root)
  active <- index[index$status == "ACTIVE", , drop = FALSE]
  reachable <- active
  if (!is.null(stage)) {
    keep <- vapply(active$consumer_stages, function(value) stage %in% .split_consumers(value), logical(1))
    reachable <- active[keep, , drop = FALSE]
  }
  source_domains <- c("SOURCE_IDENTITY", "SOURCE_PREPROCESSING")
  scientific_domains <- c("MI_RECIPE", "SCIENTIFIC_MODEL", "SENSITIVITY")
  consumer_digest <- function(domains) {
    subset <- reachable[reachable$semantic_domain %in% domains, , drop = FALSE]
    .authority_sha256_text(paste(
      sort(paste(subset$semantic_key, subset$consumer_stages, sep = "\t")),
      collapse = "\n"
    ))
  }
  list(
    authority_catalog_digest = .authority_sha256_text(.authority_projection(index, project_root)),
    authority_resolution_digest = .authority_sha256_text(.authority_projection(active, project_root)),
    source_value_digest = .authority_sha256_text(.authority_projection(reachable[reachable$semantic_domain %in% source_domains, , drop = FALSE], project_root)),
    scientific_value_digest = .authority_sha256_text(.authority_projection(reachable[reachable$semantic_domain %in% scientific_domains, , drop = FALSE], project_root)),
    execution_plan_digest = .authority_sha256_text(.authority_projection(reachable[reachable$semantic_domain == "CONTROL_PLANE", , drop = FALSE], project_root)),
    runtime_plan_digest = .authority_sha256_text(.authority_projection(reachable[reachable$semantic_domain == "REMOTE_RUNTIME", , drop = FALSE], project_root)),
    deliverable_registry_digest = .authority_sha256_text(.authority_projection(reachable[reachable$semantic_domain == "PUBLICATION", , drop = FALSE], project_root)),
    source_consumer_set_digest = consumer_digest(source_domains),
    science_consumer_set_digest = consumer_digest(scientific_domains),
    execution_consumer_set_digest = consumer_digest("CONTROL_PLANE"),
    runtime_consumer_set_digest = consumer_digest("REMOTE_RUNTIME"),
    publication_consumer_set_digest = consumer_digest("PUBLICATION"),
    exact_consumer_set_digest = .authority_sha256_text(paste(sort(paste(reachable$semantic_key, reachable$consumer_stages, sep = "\t")), collapse = "\n")),
    reachable_authority_slice_digest = .authority_sha256_text(.authority_projection(reachable, project_root))
  )
}

compute_conflict_id <- function(conflict_class, semantic_key, participant_identities, epochs) {
  if (!length(participant_identities) || any(!nzchar(participant_identities))) .authority_stop("CONFLICT_PARTICIPANTS_INVALID")
  epoch_text <- paste(names(epochs)[order(names(epochs))], epochs[order(names(epochs))], sep = "=", collapse = "|")
  .authority_sha256_text(paste(conflict_class, semantic_key, paste(sort(participant_identities), collapse = "|"), epoch_text, sep = "\n"))
}

arbitrate_conflict <- function(
    conflict_class, semantic_key, participant_identities, epochs,
    semantic_equal = FALSE, unique_active_owner = FALSE,
    supersession_verified = FALSE, output_impact = "UNKNOWN") {
  conflict_id <- compute_conflict_id(conflict_class, semantic_key, participant_identities, epochs)
  decision <- switch(
    conflict_class,
    EXACT_DUPLICATE = if (isTRUE(semantic_equal) && isTRUE(unique_active_owner)) c("AUTO_RESOLVED", "EXACT_DUPLICATE_CANONICALIZED") else c("HUMAN_DECISION_REQUIRED", "DUPLICATE_IDENTITY_UNPROVEN"),
    OWNER_IMPLEMENTATION = if (isTRUE(unique_active_owner)) c("AUTO_RESOLVED", "OWNER_CONFORMANCE_FIX") else c("HUMAN_DECISION_REQUIRED", "OWNER_NOT_UNIQUE"),
    ACTIVE_RETIRED_SUPERSESSION = if (isTRUE(unique_active_owner) && isTRUE(supersession_verified)) c("AUTO_RESOLVED", "VERIFIED_SUPERSESSION_APPLIED") else c("HUMAN_DECISION_REQUIRED", "SUPERSESSION_UNVERIFIED"),
    ENGINEERING_REPRESENTATION = if (isTRUE(semantic_equal)) c("AUTO_RESOLVED", "OUTPUT_PRESERVING_ENGINEERING_FIX") else c("HUMAN_DECISION_REQUIRED", "SEMANTIC_EQUIVALENCE_UNPROVEN"),
    PUBLICATION_LAYER2 = if (isTRUE(unique_active_owner)) c("AUTO_RESOLVED", "REGENERATE_FROM_LAYER2_OWNER") else c("HUMAN_DECISION_REQUIRED", "LAYER2_OWNER_CONFLICT"),
    EXTERNAL_INPUT = c("EXTERNAL_INPUT_BLOCKED", "EXTERNAL_INPUT_REQUIRED"),
    INTEGRITY = c("FAILED_INTEGRITY", "IDENTITY_INTEGRITY_FAILURE"),
    c("HUMAN_DECISION_REQUIRED", "SCIENTIFIC_OR_AUTHORITY_CONFLICT")
  )
  list(
    schema_version = "1.0.0",
    conflict_id = conflict_id,
    conflict_class = conflict_class,
    semantic_key = semantic_key,
    participant_identities = sort(participant_identities),
    epoch_identity_sha256 = .authority_sha256_text(canonical_json(epochs)),
    status = unname(decision[[1L]]),
    reason_code = unname(decision[[2L]]),
    output_impact = output_impact
  )
}

write_arbitration_record <- function(run_root, record) {
  if (!is.list(record) || !grepl("^[0-9a-f]{64}$", record$conflict_id)) .authority_stop("ARBITRATION_RECORD_INVALID")
  directory <- file.path(run_root, "control", "arbitrations")
  dir.create(directory, recursive = TRUE, showWarnings = FALSE, mode = "0700")
  path <- file.path(directory, paste0(record$conflict_id, ".json"))
  text <- canonical_json(record)
  if (file.exists(path)) {
    observed <- paste(readLines(path, warn = FALSE), collapse = "\n")
    if (!identical(observed, text)) .authority_stop("ARBITRATION_RESULT_CONFLICT")
  } else {
    temporary <- tempfile(pattern = ".arbitration.", tmpdir = directory)
    on.exit(if (file.exists(temporary)) unlink(temporary), add = TRUE)
    # 写入唯一冲突的不可变 ArbitrationRecord。
    writeLines(text, temporary, useBytes = TRUE)
    invisible(Sys.chmod(temporary, mode = "0600", use_umask = FALSE))
    if (!file.rename(temporary, path)) .authority_stop("ARBITRATION_ATOMIC_RENAME_FAILED")
  }
  list(relative_path = file.path("control", "arbitrations", basename(path)), sha256 = .authority_file_sha256(path))
}
