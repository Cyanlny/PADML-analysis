# Schoenfeld 探索性诊断：仅复用既有 Cox fit，公开层不保存事件级残差。

.schoenfeld_stop <- function(code) stop(code, call. = FALSE)

validate_schoenfeld_series_registry <- function(series) {
  required <- c("diagnostic_id", "series_id", "mode", "term_pattern", "legend_label")
  if (!is.data.frame(series) || !nrow(series) || !identical(names(series), required) ||
      any(!series$mode %in% c("coefficient", "parent")) ||
      any(!nzchar(series$diagnostic_id)) || any(!nzchar(series$series_id)) ||
      anyDuplicated(series[c("diagnostic_id", "series_id")])) {
    .schoenfeld_stop("SCHOENFELD_SERIES_REGISTRY_INVALID")
  }
  invisible(TRUE)
}

.schoenfeld_one_mode <- function(fit, mode) {
  # 加载 survival 包并从既有 fit 提取 km 变换 Schoenfeld 诊断；禁止重新拟合 Cox。
  if (!requireNamespace("survival", quietly = TRUE)) .schoenfeld_stop("SCHOENFELD_SURVIVAL_MISSING")
  tryCatch(
    survival::cox.zph(
      fit, transform = "km", terms = identical(mode, "parent"),
      singledf = FALSE
    ),
    error = function(condition) structure(list(message = conditionMessage(condition)), class = "schoenfeld_failure")
  )
}

.schoenfeld_selected_columns <- function(zph, pattern) {
  if (inherits(zph, "schoenfeld_failure") || is.null(zph$y) || is.null(colnames(zph$y))) return(character())
  grep(pattern, colnames(zph$y), value = TRUE, perl = TRUE)
}

.schoenfeld_p_value <- function(zph, term) {
  if (inherits(zph, "schoenfeld_failure") || is.null(zph$table)) return(NA_real_)
  table <- as.matrix(zph$table)
  p_column <- grep("^p$", colnames(table), ignore.case = TRUE, value = TRUE)
  if (!length(p_column) || !term %in% rownames(table)) return(NA_real_)
  as.numeric(table[term, p_column[[1L]]])
}

.schoenfeld_smooth <- function(x, y, grid, spline_df) {
  keep <- is.finite(x) & is.finite(y)
  x <- as.numeric(x[keep])
  y <- as.numeric(y[keep])
  if (length(x) < spline_df + 2L || length(unique(x)) < spline_df + 2L) return(rep(NA_real_, length(grid)))
  frame <- data.frame(x = x, y = y)
  # 使用固定 df=4 的自然样条拟合描述性趋势，不产生新的生存模型或推断性 pooling。
  model <- tryCatch(stats::lm(y ~ splines::ns(x, df = spline_df), data = frame), error = function(condition) NULL)
  if (is.null(model)) return(rep(NA_real_, length(grid)))
  as.numeric(tryCatch(
    stats::predict(model, newdata = data.frame(x = grid)),
    error = function(condition) rep(NA_real_, length(grid))
  ))
}

run_schoenfeld_diagnostic <- function(
    fits, series, spline_df = 4L, grid_n = 120L,
    minimum_valid_imputations = 16L, ph_alpha = 0.05) {
  validate_schoenfeld_series_registry(series)
  if (!is.list(fits) || !length(fits) || spline_df != 4L || grid_n != 120L) {
    .schoenfeld_stop("SCHOENFELD_EXECUTION_CONTRACT_INVALID")
  }
  modes <- sort(unique(series$mode), method = "radix")
  fit_n <- vapply(fits, function(fit) if (is.null(fit)) NA_integer_ else as.integer(fit$n), integer(1))
  fit_events <- vapply(fits, function(fit) if (is.null(fit)) NA_integer_ else as.integer(fit$nevent), integer(1))
  unique_n <- unique(fit_n[is.finite(fit_n)])
  unique_events <- unique(fit_events[is.finite(fit_events)])
  if (length(unique_n) > 1L || length(unique_events) > 1L) {
    .schoenfeld_stop("SCHOENFELD_SOURCE_SAMPLE_EVENT_IDENTITY_MISMATCH")
  }
  analysis_n <- if (length(unique_n) == 1L) unique_n[[1L]] else NA_integer_
  event_n <- if (length(unique_events) == 1L) unique_events[[1L]] else NA_integer_
  extracted <- lapply(seq_along(fits), function(imputation) {
    fit <- fits[[imputation]]
    if (is.null(fit)) return(setNames(vector("list", length(modes)), modes))
    setNames(lapply(modes, function(mode) .schoenfeld_one_mode(fit, mode)), modes)
  })

  raw <- list()
  raw_index <- 1L
  zph_layer1 <- list()
  for (imputation in seq_along(extracted)) {
    for (row_index in seq_len(nrow(series))) {
      specification <- series[row_index, , drop = FALSE]
      zph <- extracted[[imputation]][[specification$mode[[1L]]]]
      zph_layer1[[paste(imputation, specification$mode[[1L]], sep = "__")]] <- zph
      for (term in .schoenfeld_selected_columns(zph, specification$term_pattern[[1L]])) {
        residual <- as.numeric(zph$y[, term])
        raw[[raw_index]] <- data.frame(
          diagnostic_id = specification$diagnostic_id[[1L]],
          series_id = specification$series_id[[1L]],
          resolved_term = term,
          legend_label = specification$legend_label[[1L]],
          imputation = as.integer(imputation),
          event_index = seq_along(residual),
          transformed_time = as.numeric(zph$x),
          event_time = if (length(zph$time) == length(residual)) as.numeric(zph$time) else NA_real_,
          scaled_residual = residual,
          ph_p_value = .schoenfeld_p_value(zph, term),
          stringsAsFactors = FALSE
        )
        raw_index <- raw_index + 1L
      }
    }
  }
  event_level <- if (length(raw)) do.call(rbind, raw) else data.frame()
  if (!nrow(event_level)) {
    empty_trend <- data.frame(
      diagnostic_id = character(), series_id = character(), resolved_term = character(),
      legend_label = character(), time_grid_index = integer(), transformed_time = numeric(),
      trend_median = numeric(), trend_p10 = numeric(), trend_p90 = numeric(),
      valid_imputation_n = integer(), ph_trigger_n = integer(),
      ph_valid_imputation_n = integer(), analysis_n = integer(), event_n = integer(),
      diagnostic_interpretation = character(), data_classification = character(),
      stringsAsFactors = FALSE
    )
    return(list(
      public_trend = empty_trend, status = data.frame(
        diagnostic_id = series$diagnostic_id, series_id = series$series_id,
        resolved_term = "", valid_imputation_n = 0L, ph_valid_imputation_n = 0L,
        ph_trigger_n = 0L, ph_trigger_fraction = NA_real_,
        analysis_n = analysis_n, event_n = event_n, status = "NOT_ESTIMABLE",
        reason_code = "NO_VALID_SCHOENFELD_SERIES", selection_effect = "NONE",
        stringsAsFactors = FALSE
      ),
      restricted_event_level = event_level, restricted_zph_objects = zph_layer1,
      fit_count_added = 0L
    ))
  }

  groups <- split(
    event_level,
    interaction(event_level$diagnostic_id, event_level$series_id, event_level$resolved_term, drop = TRUE, lex.order = TRUE)
  )
  trend_rows <- list()
  status_rows <- list()
  group_index <- 1L
  for (group in groups) {
    by_imputation <- split(group, group$imputation)
    lower <- max(vapply(by_imputation, function(data) min(data$transformed_time, na.rm = TRUE), numeric(1)))
    upper <- min(vapply(by_imputation, function(data) max(data$transformed_time, na.rm = TRUE), numeric(1)))
    if (!is.finite(lower) || !is.finite(upper) || lower >= upper) next
    grid <- seq(lower, upper, length.out = grid_n)
    smooth_matrix <- vapply(by_imputation, function(data) {
      .schoenfeld_smooth(data$transformed_time, data$scaled_residual, grid, spline_df)
    }, numeric(grid_n))
    if (is.null(dim(smooth_matrix))) smooth_matrix <- matrix(smooth_matrix, ncol = 1L)
    valid_n <- rowSums(is.finite(smooth_matrix))
    quantile_row <- function(index, probability) {
      values <- smooth_matrix[index, is.finite(smooth_matrix[index, ])]
      if (length(values)) as.numeric(stats::quantile(values, probability, type = 7, names = FALSE)) else NA_real_
    }
    p_values <- vapply(by_imputation, function(data) unique(data$ph_p_value)[[1L]], numeric(1))
    trend_rows[[group_index]] <- data.frame(
      diagnostic_id = group$diagnostic_id[[1L]],
      series_id = group$series_id[[1L]],
      resolved_term = group$resolved_term[[1L]],
      legend_label = group$legend_label[[1L]],
      time_grid_index = seq_len(grid_n),
      transformed_time = grid,
      trend_median = apply(smooth_matrix, 1L, stats::median, na.rm = TRUE),
      trend_p10 = vapply(seq_len(grid_n), quantile_row, numeric(1), probability = 0.10),
      trend_p90 = vapply(seq_len(grid_n), quantile_row, numeric(1), probability = 0.90),
      valid_imputation_n = valid_n,
      ph_trigger_n = sum(is.finite(p_values) & p_values < ph_alpha),
      ph_valid_imputation_n = sum(is.finite(p_values)),
      analysis_n = analysis_n, event_n = event_n,
      diagnostic_interpretation = "MI descriptive trend; not Rubin-pooled residual test",
      data_classification = "PUBLIC_AGGREGATE",
      stringsAsFactors = FALSE
    )
    status_rows[[group_index]] <- data.frame(
      diagnostic_id = group$diagnostic_id[[1L]], series_id = group$series_id[[1L]],
      resolved_term = group$resolved_term[[1L]],
      valid_imputation_n = max(valid_n), ph_valid_imputation_n = sum(is.finite(p_values)),
      ph_trigger_n = sum(is.finite(p_values) & p_values < ph_alpha),
      ph_trigger_fraction = if (sum(is.finite(p_values))) mean(p_values[is.finite(p_values)] < ph_alpha) else NA_real_,
      analysis_n = analysis_n, event_n = event_n,
      status = ifelse(max(valid_n) >= minimum_valid_imputations, "ESTIMABLE", "NOT_ESTIMABLE"),
      reason_code = ifelse(max(valid_n) >= minimum_valid_imputations, "", "INSUFFICIENT_VALID_IMPUTATIONS"),
      selection_effect = "NONE", stringsAsFactors = FALSE
    )
    group_index <- group_index + 1L
  }
  # 汇总 20 套插补的中位数、P10、P90 和触发频数；该步骤不做 Rubin 残差检验。
  public_trend <- if (length(trend_rows)) do.call(rbind, trend_rows) else data.frame()
  status <- if (length(status_rows)) do.call(rbind, status_rows) else data.frame()
  observed_key <- if (nrow(status)) {
    paste(status$diagnostic_id, status$series_id, sep = "\r")
  } else character()
  expected_key <- paste(series$diagnostic_id, series$series_id, sep = "\r")
  missing_index <- which(!expected_key %in% observed_key)
  if (length(missing_index)) {
    missing_status <- data.frame(
      diagnostic_id = series$diagnostic_id[missing_index],
      series_id = series$series_id[missing_index], resolved_term = "",
      valid_imputation_n = 0L, ph_valid_imputation_n = 0L,
      ph_trigger_n = 0L, ph_trigger_fraction = NA_real_,
      analysis_n = analysis_n, event_n = event_n, status = "NOT_ESTIMABLE",
      reason_code = "REGISTERED_TERM_NOT_RESOLVED", selection_effect = "NONE",
      stringsAsFactors = FALSE
    )
    status <- if (nrow(status)) rbind(status, missing_status) else missing_status
  }
  status <- status[match(expected_key, paste(status$diagnostic_id, status$series_id, sep = "\r")), , drop = FALSE]
  rownames(public_trend) <- NULL
  rownames(status) <- NULL
  list(
    public_trend = public_trend,
    status = status,
    restricted_event_level = event_level,
    restricted_zph_objects = zph_layer1,
    fit_count_added = 0L
  )
}
