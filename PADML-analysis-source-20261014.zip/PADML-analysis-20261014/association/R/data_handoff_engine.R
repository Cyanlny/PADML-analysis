# 数据交接引擎：统一合成验证与正式只读 handoff 的输入接口。

.handoff_stop <- function(code, detail = "") {
  message <- if (nzchar(detail)) paste(code, detail, sep = ": ") else code
  stop(message, call. = FALSE)
}

.handoff_file_sha256 <- function(path) {
  # 加载摘要包，在读取 ZIP 目录或对象前验证正式 handoff 身份。
  if (!requireNamespace("digest", quietly = TRUE)) .handoff_stop("HANDOFF_DEPENDENCY_MISSING", "digest")
  digest::digest(file = path, algo = "sha256", serialize = FALSE)
}

.handoff_sha256_text <- function(text) {
  # 加载摘要包，计算不含路径和患者值的 handoff 身份摘要。
  if (!requireNamespace("digest", quietly = TRUE)) .handoff_stop("HANDOFF_DEPENDENCY_MISSING", "digest")
  digest::digest(enc2utf8(paste(text, collapse = "\n")), algo = "sha256", serialize = FALSE)
}

.handoff_protocol_is_v43 <- function(approval_row) {
  !is.null(approval_row) && nrow(approval_row) == 1L &&
    identical(as.character(approval_row$protocol_revision[[1L]]), "v4.3-r00")
}

required_handoff_members <- function(approval_row = NULL) {
  base <- c(
    "original_frozen_completed_analysis_list.rds",
    "original_frozen_mids.rds",
    "core_column_role_registry.csv",
    "factor_level_registry.csv",
    "DOWNSTREAM_READINESS_GATE.csv",
    "completed_data_semantic_identity_receipt.json",
    "serialization_identity_receipt.json",
    "PACKAGE_MANIFEST.csv"
  )
  if (!.handoff_protocol_is_v43(approval_row)) return(base)
  c(
    base,
    "source_candidate_receipt.json",
    "source_mi_recipe_receipt.json",
    "mi_qc_receipt.json",
    "FROZEN_HANDOFF_RECEIPT.json"
  )
}

find_handoff_member <- function(root, member) {
  hits <- list.files(root, pattern = paste0("^", member, "$"), recursive = TRUE, full.names = TRUE)
  if (length(hits) != 1L) {
    stop("Expected exactly one handoff member: ", member, call. = FALSE)
  }
  hits[[1L]]
}

assert_handoff_archive_matches_approval <- function(zip_path, approval_row) {
  if (!file.exists(zip_path) || isTRUE(file.info(zip_path)$isdir)) .handoff_stop("HANDOFF_FILE_NOT_FOUND")
  if (!is.data.frame(approval_row) || nrow(approval_row) != 1L ||
      !identical(as.character(approval_row$approval_status[[1L]]), "APPROVED")) {
    .handoff_stop("HANDOFF_APPROVAL_REQUIRED_BEFORE_READ")
  }
  expected <- as.character(approval_row$handoff_sha256[[1L]])
  if (!grepl("^[0-9a-f]{64}$", expected)) .handoff_stop("HANDOFF_APPROVAL_SHA256_INVALID")
  observed <- .handoff_file_sha256(zip_path)
  if (!identical(observed, expected)) .handoff_stop("HANDOFF_ARCHIVE_SHA256_MISMATCH")
  invisible(observed)
}

resolve_approved_handoff <- function(zip_path, project_root = ".") {
  if (!exists("read_approved_handoff_registry", mode = "function") ||
      !exists("match_approved_handoff", mode = "function") ||
      !exists("approved_handoff_identity", mode = "function")) {
    source(file.path(project_root, "R", "source_input_adapter.R"))
  }
  registry <- read_approved_handoff_registry(project_root)
  row <- match_approved_handoff(zip_path, registry)
  list(row = row, identity = handoff_identity_from_approval_row(row))
}

.handoff_unsafe_relative_path <- function(path) {
  if (!is.character(path) || length(path) != 1L || is.na(path) || !nzchar(path) ||
      grepl("[[:cntrl:]]", path) || grepl("\\\\", path) || grepl("^/", path) ||
      grepl("^[A-Za-z]:", path)) return(TRUE)
  parts <- strsplit(path, "/", fixed = TRUE)[[1L]]
  any(!nzchar(parts) | parts %in% c(".", ".."))
}

inspect_handoff_zip_structure <- function(zip_path, approval_row = NULL) {
  if (is.null(approval_row)) .handoff_stop("HANDOFF_APPROVAL_REQUIRED_BEFORE_ZIP_LIST")
  assert_handoff_archive_matches_approval(zip_path, approval_row)
  # 读取 ZIP 中央目录；此时归档的精确批准 SHA 已先通过。
  listing <- utils::unzip(zip_path, list = TRUE)
  if (!nrow(listing) || any(vapply(listing$Name, .handoff_unsafe_relative_path, logical(1)))) {
    .handoff_stop("HANDOFF_ZIP_PATH_UNSAFE")
  }
  file_names <- listing$Name[!endsWith(listing$Name, "/")]
  if (anyDuplicated(file_names)) .handoff_stop("HANDOFF_ZIP_MEMBER_DUPLICATE")
  required <- required_handoff_members(approval_row)
  observed <- basename(listing$Name)
  data.frame(
    member = required,
    present_n = vapply(required, function(x) sum(observed == x), integer(1)),
    status = ifelse(vapply(required, function(x) sum(observed == x), integer(1)) == 1L, "PASS", "FAIL"),
    stringsAsFactors = FALSE
  )
}

inspect_handoff_candidate_zip_structure <- function(zip_path) {
  if (!file.exists(zip_path) || isTRUE(file.info(zip_path)$isdir) || nzchar(Sys.readlink(zip_path))) {
    .handoff_stop("HANDOFF_CANDIDATE_ZIP_INVALID")
  }
  # 只读取候选 ZIP 中央目录，不反序列化任何 RDS 或患者级对象。
  listing <- tryCatch(utils::unzip(zip_path, list = TRUE), error = function(condition) NULL)
  if (is.null(listing) || !nrow(listing) || anyDuplicated(listing$Name) ||
      any(vapply(listing$Name, .handoff_unsafe_relative_path, logical(1))) ||
      any(endsWith(listing$Name, "/"))) {
    .handoff_stop("HANDOFF_CANDIDATE_ZIP_CENTRAL_DIRECTORY_INVALID")
  }
  if (sum(listing$Name == "PACKAGE_MANIFEST.csv") != 1L) {
    .handoff_stop("HANDOFF_CANDIDATE_MANIFEST_CARDINALITY_INVALID")
  }
  extraction <- tempfile("handoff-candidate-structural-")
  dir.create(extraction, recursive = TRUE, mode = "0700")
  on.exit(unlink(extraction, recursive = TRUE, force = TRUE), add = TRUE)
  extracted_result <- tryCatch(
    suppressWarnings(utils::unzip(zip_path, exdir = extraction, unzip = "internal")),
    error = function(condition) NULL
  )
  if (is.null(extracted_result) || length(extracted_result) != nrow(listing)) {
    .handoff_stop("HANDOFF_CANDIDATE_ZIP_EXTRACTION_FAILED")
  }
  extracted <- list.files(extraction, recursive = TRUE, full.names = TRUE, all.files = TRUE, no.. = TRUE)
  if (any(nzchar(Sys.readlink(extracted)))) .handoff_stop("HANDOFF_CANDIDATE_ZIP_LINK_FORBIDDEN")
  manifest_path <- file.path(extraction, "PACKAGE_MANIFEST.csv")
  manifest <- utils::read.csv(manifest_path, stringsAsFactors = FALSE, check.names = FALSE)
  required_fields <- c("relative_path", "sha256", "size_bytes")
  if (!identical(names(manifest), required_fields) || !nrow(manifest) ||
      anyDuplicated(manifest$relative_path) ||
      any(vapply(manifest$relative_path, .handoff_unsafe_relative_path, logical(1))) ||
      any(!grepl("^[0-9a-f]{64}$", manifest$sha256)) ||
      any(!is.finite(as.numeric(manifest$size_bytes)) | as.numeric(manifest$size_bytes) < 0)) {
    .handoff_stop("HANDOFF_CANDIDATE_MANIFEST_SCHEMA_INVALID")
  }
  observed <- sort(listing$Name, method = "radix")
  expected <- sort(c(manifest$relative_path, "PACKAGE_MANIFEST.csv"), method = "radix")
  if (!identical(observed, expected)) .handoff_stop("HANDOFF_CANDIDATE_EXACT_MEMBERSHIP_FAILED")
  required <- required_handoff_members(data.frame(protocol_revision = "v4.3-r00"))
  if (any(vapply(required, function(member) sum(basename(observed) == member), integer(1)) != 1L)) {
    .handoff_stop("HANDOFF_CANDIDATE_REQUIRED_MEMBER_CLOSURE_FAILED")
  }
  for (index in seq_len(nrow(manifest))) {
    path <- file.path(extraction, manifest$relative_path[[index]])
    if (!file.exists(path) || isTRUE(file.info(path)$isdir) ||
        !identical(.handoff_file_sha256(path), manifest$sha256[[index]]) ||
        !identical(as.character(file.info(path)$size), as.character(manifest$size_bytes[[index]]))) {
      .handoff_stop("HANDOFF_CANDIDATE_MEMBER_INTEGRITY_FAILED", manifest$relative_path[[index]])
    }
  }
  data.frame(
    check_id = c("CENTRAL_DIRECTORY", "EXACT_MEMBERSHIP", "MEMBER_SHA_SIZE"),
    status = "PASS", stringsAsFactors = FALSE
  )
}

.handoff_manifest_files <- function(staging, manifest_path, manifest) {
  required <- c("relative_path", "sha256", "size_bytes")
  if (!all(required %in% names(manifest)) || !nrow(manifest) || anyDuplicated(manifest$relative_path) ||
      any(vapply(manifest$relative_path, .handoff_unsafe_relative_path, logical(1))) ||
      any(!grepl("^[0-9a-f]{64}$", manifest$sha256)) ||
      any(!is.finite(as.numeric(manifest$size_bytes)) | as.numeric(manifest$size_bytes) < 0)) {
    .handoff_stop("HANDOFF_PACKAGE_MANIFEST_SCHEMA_INVALID")
  }
  roots <- unique(normalizePath(c(dirname(manifest_path), staging), mustWork = TRUE))
  candidates <- lapply(roots, function(root) file.path(root, manifest$relative_path))
  valid <- vapply(candidates, function(paths) all(file.exists(paths) & !file.info(paths)$isdir), logical(1))
  if (!any(valid)) .handoff_stop("HANDOFF_PACKAGE_MANIFEST_MISSING_FILES")
  selected <- which(valid)[[1L]]
  list(root = roots[[selected]], files = candidates[[selected]])
}

.handoff_approval_identity <- function(approval_row) {
  fields <- c(
    "handoff_id", "approval_id", "source_id", "source_epoch", "handoff_sha256",
    "expected_source_sha256", "expected_patient_order_sha256", "expected_mids_sha256",
    "expected_completed_sha256", "expected_factor_sha256", "expected_schema_sha256",
    "expected_core_column_n", "expected_semantic_status", "protocol_revision"
  )
  identity <- as.list(approval_row[1L, fields, drop = FALSE])
  identity$expected_core_column_n <- as.integer(identity$expected_core_column_n)
  identity$handoff_identity_sha256 <- .handoff_sha256_text(
    paste(fields, vapply(identity[fields], as.character, character(1)), sep = "=")
  )
  identity
}

extract_handoff_restricted <- function(zip_path, approval_row, root = ".") {
  structure_qc <- inspect_handoff_zip_structure(zip_path, approval_row)
  if (any(structure_qc$status != "PASS")) .handoff_stop("HANDOFF_STRUCTURE_VALIDATION_FAILED")
  zip_sha <- as.character(approval_row$handoff_sha256[[1L]])
  approval_identity <- .handoff_approval_identity(approval_row)
  parent <- file.path(root, "restricted_cache", "handoffs")
  destination <- file.path(parent, zip_sha, approval_identity$handoff_identity_sha256)
  sentinel <- file.path(destination, "HANDOFF_COMPLETE")
  zip_receipt <- file.path(destination, "HANDOFF_ZIP_SHA256")
  approval_receipt <- file.path(destination, "HANDOFF_APPROVAL_RECEIPT.json")
  if (dir.exists(destination)) {
    # 加载 JSON 包，验证内容寻址缓存同时绑定当前批准身份。
    if (!requireNamespace("jsonlite", quietly = TRUE)) .handoff_stop("HANDOFF_DEPENDENCY_MISSING", "jsonlite")
    cached_approval <- if (file.exists(approval_receipt)) {
      jsonlite::read_json(approval_receipt, simplifyVector = TRUE)
    } else list()
    complete <- file.exists(sentinel) && file.exists(zip_receipt) &&
      identical(trimws(readLines(zip_receipt, warn = FALSE)), zip_sha) &&
      identical(trimws(readLines(sentinel, warn = FALSE)), approval_identity$handoff_identity_sha256) &&
      identical(.handoff_receipt_value(cached_approval, "handoff_identity_sha256"), approval_identity$handoff_identity_sha256)
    if (complete) return(destination)
    .handoff_stop("HANDOFF_CONTENT_ADDRESS_COLLISION_OR_INCOMPLETE")
  }
  dir.create(dirname(destination), recursive = TRUE, showWarnings = FALSE, mode = "0700")
  staging <- tempfile(pattern = paste0(".", zip_sha, ".staging_"), tmpdir = parent)
  if (!dir.create(staging, mode = "0700")) .handoff_stop("HANDOFF_STAGING_CREATE_FAILED")
  on.exit(if (dir.exists(staging)) unlink(staging, recursive = TRUE), add = TRUE)
  # 解压正式 handoff 到受限缓存；该目录永久禁止进入审核包和 release。
  utils::unzip(zip_path, exdir = staging)
  invisible(Sys.chmod(staging, mode = "0700", use_umask = FALSE))
  extracted_members <- list.files(staging, recursive = TRUE, full.names = TRUE, all.files = TRUE, no.. = TRUE)
  if (any(nzchar(Sys.readlink(extracted_members)))) .handoff_stop("HANDOFF_SYMLINK_FORBIDDEN")
  staging_prefix <- paste0(normalizePath(staging, mustWork = TRUE), .Platform$file.sep)
  normalized_members <- normalizePath(extracted_members, mustWork = TRUE)
  if (any(!startsWith(normalized_members, staging_prefix))) .handoff_stop("HANDOFF_EXTRACTION_ESCAPE")
  manifest_path <- find_handoff_member(staging, "PACKAGE_MANIFEST.csv")
  manifest <- utils::read.csv(manifest_path, stringsAsFactors = FALSE, check.names = FALSE)
  manifest_resolution <- .handoff_manifest_files(staging, manifest_path, manifest)
  manifest_files <- manifest_resolution$files
  actual_package_files <- list.files(
    manifest_resolution$root, recursive = TRUE, full.names = FALSE,
    all.files = TRUE, no.. = TRUE
  )
  actual_package_files <- actual_package_files[
    !file.info(file.path(manifest_resolution$root, actual_package_files))$isdir
  ]
  manifest_relative <- gsub("^\\./", "", manifest$relative_path)
  manifest_self_relative <- substring(
    normalizePath(manifest_path, mustWork = TRUE),
    nchar(paste0(normalizePath(manifest_resolution$root, mustWork = TRUE), .Platform$file.sep)) + 1L
  )
  expected_covered_files <- setdiff(actual_package_files, manifest_self_relative)
  if (!setequal(manifest_relative, expected_covered_files)) {
    .handoff_stop("HANDOFF_PACKAGE_MANIFEST_COVERAGE_FAILED")
  }
  observed_sha <- vapply(manifest_files, .handoff_file_sha256, character(1))
  observed_size <- unname(as.numeric(file.info(manifest_files)$size))
  if (!identical(unname(observed_sha), as.character(manifest$sha256)) ||
      !identical(observed_size, as.numeric(manifest$size_bytes))) {
    .handoff_stop("HANDOFF_PACKAGE_MANIFEST_INTEGRITY_FAILED")
  }
  writeLines(zip_sha, file.path(staging, "HANDOFF_ZIP_SHA256"), useBytes = TRUE)
  # 加载 JSON 包，写入不含原始路径和患者值的批准身份收据。
  if (!requireNamespace("jsonlite", quietly = TRUE)) .handoff_stop("HANDOFF_DEPENDENCY_MISSING", "jsonlite")
  jsonlite::write_json(
    approval_identity, file.path(staging, "HANDOFF_APPROVAL_RECEIPT.json"),
    auto_unbox = TRUE, pretty = TRUE, na = "null"
  )
  writeLines(approval_identity$handoff_identity_sha256, file.path(staging, "HANDOFF_COMPLETE"), useBytes = TRUE)
  if (!file.rename(staging, destination)) .handoff_stop("HANDOFF_ATOMIC_PUBLISH_FAILED")
  destination
}

validate_completed_analysis_list <- function(completed, expected_m = 20L, expected_column_n = NULL, role_registry = NULL, factor_registry = NULL) {
  if (!is.list(completed) || length(completed) != expected_m) {
    stop("Frozen completed analysis list must contain exactly ", expected_m, " datasets", call. = FALSE)
  }
  if (!all(vapply(completed, is.data.frame, logical(1)))) stop("Every completed dataset must be a data.frame", call. = FALSE)
  reference_names <- names(completed[[1L]])
  reference_n <- nrow(completed[[1L]])
  required <- c("Patient_ID", "AST", "ALT", "All_Cause_Death", "Death_Followup_months", "MACE", "MACE_Followup_months", "CV_CBV_Death")
  if (!all(required %in% reference_names)) stop("Required production columns are missing", call. = FALSE)
  checks <- data.frame(
    imputation = seq_along(completed),
    row_n = vapply(completed, nrow, integer(1)),
    column_n = vapply(completed, ncol, integer(1)),
    same_column_order = vapply(completed, function(x) identical(names(x), reference_names), logical(1)),
    same_patient_order = vapply(completed, function(x) identical(as.character(x$Patient_ID), as.character(completed[[1L]]$Patient_ID)), logical(1)),
    missing_patient_id_n = vapply(completed, function(x) sum(is.na(x$Patient_ID) | !nzchar(as.character(x$Patient_ID))), integer(1)),
    duplicate_patient_id_n = vapply(completed, function(x) sum(duplicated(as.character(x$Patient_ID))), integer(1)),
    same_storage_types = vapply(completed, function(x) identical(vapply(x, function(column) paste(class(column), collapse = "|"), character(1)), vapply(completed[[1L]], function(column) paste(class(column), collapse = "|"), character(1))), logical(1)),
    outcome_followup_identical = vapply(completed, function(x) identical(x[c("All_Cause_Death", "Death_Followup_months", "MACE", "MACE_Followup_months", "CV_CBV_Death")], completed[[1L]][c("All_Cause_Death", "Death_Followup_months", "MACE", "MACE_Followup_months", "CV_CBV_Death")]), logical(1)),
    stringsAsFactors = FALSE
  )
  checks$status <- ifelse(
    checks$row_n == reference_n & checks$same_column_order & checks$same_patient_order &
      checks$missing_patient_id_n == 0L & checks$duplicate_patient_id_n == 0L & checks$same_storage_types & checks$outcome_followup_identical,
    "PASS", "FAIL"
  )
  if (!is.null(expected_column_n) && any(checks$column_n != expected_column_n)) checks$status[checks$column_n != expected_column_n] <- "FAIL"
  if (!is.null(role_registry)) {
    expected_names <- role_registry$variable[order(as.integer(role_registry$column_position))]
    if (!identical(reference_names, expected_names)) stop("Completed data columns do not match core role registry", call. = FALSE)
  }
  if (!is.null(factor_registry)) {
    for (variable in intersect(factor_registry$variable, reference_names)) {
      allowed <- strsplit(factor_registry$csv_value_domain[factor_registry$variable == variable][[1L]], "\\|", fixed = FALSE)[[1L]]
      valid <- vapply(completed, function(data) all(as.character(data[[variable]])[!is.na(data[[variable]])] %in% allowed), logical(1))
      if (!all(valid)) stop("Illegal factor level in completed data: ", variable, call. = FALSE)
    }
  }
  for (event in c("All_Cause_Death", "MACE", "CV_CBV_Death")) {
    values <- completed[[1L]][[event]]
    if (anyNA(values) || !all(as.character(values) %in% c("0", "1"))) stop("Invalid event coding: ", event, call. = FALSE)
  }
  for (time in c("Death_Followup_months", "MACE_Followup_months")) {
    values <- suppressWarnings(as.numeric(completed[[1L]][[time]]))
    if (any(!is.finite(values)) || any(values <= 0)) stop("Invalid follow-up time: ", time, call. = FALSE)
  }
  if (any(checks$status != "PASS")) stop("Completed analysis list identity validation failed", call. = FALSE)
  checks
}

.handoff_json_member <- function(extracted, member) {
  # 加载 JSON 包，读取已通过 ZIP 与 manifest 完整性校验的身份收据。
  if (!requireNamespace("jsonlite", quietly = TRUE)) .handoff_stop("HANDOFF_DEPENDENCY_MISSING", "jsonlite")
  jsonlite::read_json(find_handoff_member(extracted, member), simplifyVector = TRUE)
}

.handoff_qc <- function(qc_item, observed, expected, pass) {
  data.frame(
    qc_item = qc_item,
    observed = as.character(observed),
    expected = as.character(expected),
    status = ifelse(isTRUE(pass), "PASS", "FAIL"),
    stringsAsFactors = FALSE
  )
}

.handoff_receipt_value <- function(receipt, field) {
  value <- receipt[[field]]
  if (is.null(value) || length(value) != 1L || is.na(value)) "" else as.character(value)
}

.handoff_is_sha256 <- function(value) {
  is.character(value) && length(value) == 1L && !is.na(value) &&
    grepl("^[0-9a-f]{64}$", value)
}

.handoff_receipt_fields_exact <- function(receipt, fields, code) {
  if (!is.list(receipt) || !setequal(names(receipt), fields)) .handoff_stop(code)
  receipt[fields]
}

.handoff_hash_object <- function(object) {
  # 加载摘要包，仅比较患者级对象的不可逆内容身份。
  if (!requireNamespace("digest", quietly = TRUE)) .handoff_stop("HANDOFF_DEPENDENCY_MISSING", "digest")
  digest::digest(object, algo = "sha256", serialize = TRUE)
}

.handoff_execution_identity <- function(project_root, relative_paths) {
  relative_paths <- sort(unique(relative_paths))
  paths <- file.path(project_root, relative_paths)
  if (any(!file.exists(paths)) || any(file.info(paths)$isdir %in% TRUE)) {
    .handoff_stop("HANDOFF_EXECUTION_IDENTITY_FILE_MISSING")
  }
  hashes <- vapply(paths, .handoff_file_sha256, character(1))
  .handoff_sha256_text(paste(relative_paths, hashes, sep = "\t"))
}

.handoff_u05_execution_identity <- function(project_root) {
  .handoff_execution_identity(project_root, c(
    "R/source_handoff_builder.R", "R/data_handoff_engine.R",
    "schemas/source_candidate_receipt_schema.json",
    "schemas/mi_qc_receipt_schema_v43.json",
    "schemas/source_mi_recipe_receipt_schema_v43.json",
    "schemas/completed_data_semantic_identity_receipt_schema_v43.json",
    "schemas/serialization_identity_receipt_schema_v43.json",
    "schemas/frozen_handoff_receipt_schema_v43.json"
  ))
}

validate_v43_handoff_receipt_closure <- function(
    source_receipt, recipe_receipt, mi_qc_receipt, frozen_receipt,
    semantic, serialization, completed, mids_object, approval_row,
    actual_mids_sha, actual_completed_sha, actual_factor_sha,
    actual_patient_order, actual_schema_sha, project_root = ".") {
  if (!exists(".mi_named_matrix_identity_v43", mode = "function")) {
    # 中文备注：加载唯一 MI recipe owner 以重建并核验 handoff predictor matrix。
    source(file.path(project_root, "R", "mi_recipe_engine.R"))
  }
  if (!exists("read_source_column_mapping_registry", mode = "function")) {
    # 中文备注：加载 source adapter 以读取既有列映射，不建立第二输入适配器。
    source(file.path(project_root, "R", "source_input_adapter.R"))
  }
  owner <- read_mi_contract_v43(project_root)
  mapping <- read_source_column_mapping_registry(project_root)
  projection <- compile_mi_projection_v43(project_root, owner, mapping)
  if (!exists(".formal_mi_validate_chain_state_v43", mode = "function") ||
      !exists("validate_formal_working_mids_v43", mode = "function")) {
    source(file.path(project_root, "R", "formal_mice_engine.R"))
  }
  if (!exists("complete_and_recalculate_mids_v43", mode = "function") ||
      !exists("validate_mi_qc_receipt_v43", mode = "function")) {
    source(file.path(project_root, "R", "mi_qc_engine_v43.R"))
  }
  if (!exists(".source_candidate_receipt_fields", mode = "function") ||
      !exists("validate_source_candidate_receipt", mode = "function") ||
      !exists("validate_source_candidate_receipt_current_owner_v43", mode = "function")) {
    source(file.path(project_root, "R", "source_input_adapter.R"))
  }
  source_receipt <- .handoff_receipt_fields_exact(
    source_receipt, .source_candidate_receipt_fields(), "HANDOFF_SOURCE_RECEIPT_SCHEMA_INVALID"
  )
  validate_source_candidate_receipt_current_owner_v43(source_receipt, project_root)

  recipe_fields <- c(
    "schema_version", "status", "source_id", "source_epoch", "request_sha256",
    "recipe_id", "recipe_epoch", "recipe_projection_sha256", "runtime_epoch",
    "predictor_policy_sha256", "candidate_projection_sha256", "candidate_edge_n",
    "predictor_matrix_sha256", "predictor_edge_n",
    "runtime_identity_sha256", "selected_option_id", "m", "seed", "maxit_initial",
    "continuation_maxit", "scientific_generation_id", "rng_kind", "chain_count",
    "worker_pool_capacity", "chain_stream_policy", "chain_merge_order",
    "final_iteration", "continuation_count", "target_n",
    "core_completed_column_n", "working_mids_column_n",
    "contains_patient_values"
  )
  recipe_receipt <- .handoff_receipt_fields_exact(
    recipe_receipt, recipe_fields, "HANDOFF_MI_RECIPE_RECEIPT_SCHEMA_INVALID"
  )
  semantic_fields <- c(
    "schema_version", "status", "source_id", "source_epoch", "request_sha256",
    "final_checkpoint_sha256", "source_mids_sha", "completed_list_sha256",
    "factor_level_sha", "passive_formula_registry_sha256", "patient_order_sha256",
    "canonical_schema_sha256", "canonical_column_order_sha256",
    "completed_dataset_sha256", "m", "core_completed_column_n",
    "working_mids_column_n", "contains_patient_values"
  )
  semantic <- .handoff_receipt_fields_exact(
    semantic, semantic_fields, "HANDOFF_SEMANTIC_RECEIPT_SCHEMA_INVALID"
  )
  serialization_fields <- c(
    "schema_version", "status", "source_mids_sha256", "completed_list_sha256",
    "m", "final_iteration", "continuation_count", "core_completed_column_n",
    "working_mids_column_n", "imp0_origin", "completed_origin",
    "imp0_matches_canonical_pre_mi", "long_imp1_20_match_completed_list",
    "factor_identity_verified", "patient_order_verified",
    "passive_recalculation_verified", "contains_patient_values"
  )
  serialization <- .handoff_receipt_fields_exact(
    serialization, serialization_fields, "HANDOFF_SERIALIZATION_RECEIPT_SCHEMA_INVALID"
  )
  frozen_fields <- c(
    "schema_version", "status", "seal_scope", "registry_approval_status",
    "approval_id", "approval_basis", "source_id", "source_epoch", "request_sha256",
    "final_checkpoint_sha256", "mi_qc_receipt_sha256", "mids_sha256",
    "completed_list_sha256", "factor_level_sha256", "canonical_schema_sha256",
    "u05_execution_identity_sha256", "created_at", "contains_patient_values"
  )
  frozen_receipt <- .handoff_receipt_fields_exact(
    frozen_receipt, frozen_fields, "HANDOFF_FROZEN_RECEIPT_SCHEMA_INVALID"
  )
  validate_mi_qc_receipt_v43(mi_qc_receipt, project_root)
  if (!inherits(mids_object, "mids") || !is.data.frame(mids_object$data) ||
      !identical(names(mids_object$data), c(mapping$target_name, ".mi_na_all_cause"))) {
    .handoff_stop("HANDOFF_V43_MIDS_RUNTIME_INVALID")
  }
  canonical <- mids_object$data[mapping$target_name]
  runtime <- build_mi_runtime_spec_v43(canonical, projection, owner, mapping)
  validate_formal_working_mids_v43(
    mids_object, runtime, projection, owner, mapping,
    as.integer(recipe_receipt$final_iteration)
  )
  formulas <- read_source_passive_formula_registry(project_root)
  reconstructed_completed <- complete_and_recalculate_mids_v43(
    mids_object, canonical, mapping, formulas
  )
  if (!identical(reconstructed_completed, completed)) {
    .handoff_stop("HANDOFF_V43_COMPLETED_LIST_IDENTITY_MISMATCH")
  }

  sha_fields <- c(
    recipe_receipt$source_epoch, recipe_receipt$request_sha256,
    recipe_receipt$recipe_epoch, recipe_receipt$recipe_projection_sha256,
    recipe_receipt$predictor_policy_sha256, recipe_receipt$candidate_projection_sha256,
    recipe_receipt$predictor_matrix_sha256,
    recipe_receipt$runtime_epoch, recipe_receipt$runtime_identity_sha256,
    semantic$final_checkpoint_sha256, semantic$source_mids_sha,
    semantic$completed_list_sha256, semantic$factor_level_sha,
    semantic$passive_formula_registry_sha256, semantic$patient_order_sha256,
    semantic$canonical_schema_sha256, semantic$canonical_column_order_sha256,
    frozen_receipt$final_checkpoint_sha256, frozen_receipt$mi_qc_receipt_sha256,
    frozen_receipt$mids_sha256, frozen_receipt$completed_list_sha256,
    frozen_receipt$factor_level_sha256, frozen_receipt$canonical_schema_sha256,
    frozen_receipt$u05_execution_identity_sha256
  )
  completed_dataset_sha <- as.character(semantic$completed_dataset_sha256)
  if (any(!vapply(as.list(c(sha_fields, completed_dataset_sha)), .handoff_is_sha256, logical(1))) ||
      length(completed_dataset_sha) != 20L) {
    .handoff_stop("HANDOFF_V43_RECEIPT_SHA256_INVALID")
  }
  qc_zero_fields <- c(
    "missing_diagnostic_n", "nonfinite_diagnostic_n", "psrf_exceed_n",
    "lag1_review_n", "standardized_shift_review_n", "logged_event_n", "hard_fail_n",
    "observed_cell_change_n", "invalid_pmm_donor_n", "remaining_missing_n",
    "nonfinite_completed_n"
  )
  actual_completed_dataset_sha <- vapply(completed, .handoff_hash_object, character(1))
  expected_predictor_matrix <- .mi_actual_predictor_matrix_v43(
    mids_object$data, projection, owner, mapping
  )
  expected_continuation <- match(
    as.integer(mi_qc_receipt$final_iteration), c(30L, 40L, 50L, 100L, 200L)
  ) - 1L
  recipe_edges_are_exact_integers <-
    is.integer(recipe_receipt$candidate_edge_n) && length(recipe_receipt$candidate_edge_n) == 1L &&
    !is.na(recipe_receipt$candidate_edge_n) &&
    is.integer(recipe_receipt$predictor_edge_n) && length(recipe_receipt$predictor_edge_n) == 1L &&
    !is.na(recipe_receipt$predictor_edge_n)
  values_ok <- c(
    identical(recipe_receipt$schema_version, "1.0.0"),
    identical(recipe_receipt$status, "PASS"),
    identical(recipe_receipt$source_id, source_receipt$source_id),
    identical(recipe_receipt$source_epoch, source_receipt$source_epoch),
    identical(recipe_receipt$recipe_id, "SRC_MI_V43_MAIN_SURVIVAL_V1"),
    identical(recipe_receipt$selected_option_id, "V22_FULL_COHORT_ANALYSIS"),
    identical(as.integer(recipe_receipt$m), 20L),
    identical(as.integer(recipe_receipt$seed), 123L),
    identical(as.integer(recipe_receipt$maxit_initial), 30L),
    identical(recipe_receipt$continuation_maxit, "40|50|100|200"),
    identical(recipe_receipt$scientific_generation_id, "MAIN_24_WORKER_SCIENTIFIC_GENERATION_APPROVED"),
    identical(recipe_receipt$rng_kind, "L'Ecuyer-CMRG|Inversion|Rejection"),
    identical(as.integer(recipe_receipt$chain_count), 20L),
    identical(as.integer(recipe_receipt$worker_pool_capacity), 24L),
    identical(recipe_receipt$chain_stream_policy, "NEXT_RNG_STREAM_FROM_MASTER_SEED"),
    identical(recipe_receipt$chain_merge_order, "CHAIN_ID_ASCENDING"),
    identical(as.integer(recipe_receipt$target_n), 37L),
    identical(recipe_receipt$predictor_policy_sha256, "6fad1a3d5c1291d0e8f7246e62284c876743d169762e1d1adcb0addf4870cb1d"),
    identical(recipe_receipt$candidate_projection_sha256, .mi_projection_identity_v43(projection)),
    recipe_edges_are_exact_integers,
    identical(recipe_receipt$candidate_edge_n, 896L),
    recipe_receipt$predictor_edge_n >= 1L,
    recipe_receipt$predictor_edge_n <= 896L,
    identical(as.integer(recipe_receipt$core_completed_column_n), 123L),
    identical(as.integer(recipe_receipt$working_mids_column_n), 124L),
    identical(recipe_receipt$contains_patient_values, FALSE),
    identical(mi_qc_receipt$status, "PASS"),
    all(vapply(mi_qc_receipt[qc_zero_fields], function(value) as.integer(value) == 0L, logical(1))),
    identical(mi_qc_receipt$request_sha256, recipe_receipt$request_sha256),
    identical(mi_qc_receipt$source_epoch, source_receipt$source_epoch),
    identical(mi_qc_receipt$recipe_epoch, recipe_receipt$recipe_epoch),
    identical(mi_qc_receipt$predictor_policy_sha256, recipe_receipt$predictor_policy_sha256),
    identical(mi_qc_receipt$candidate_projection_sha256, recipe_receipt$candidate_projection_sha256),
    identical(mi_qc_receipt$candidate_edge_n, recipe_receipt$candidate_edge_n),
    identical(mi_qc_receipt$predictor_matrix_sha256, recipe_receipt$predictor_matrix_sha256),
    identical(mi_qc_receipt$predictor_edge_n, recipe_receipt$predictor_edge_n),
    identical(mi_qc_receipt$predictor_matrix_sha256, .mi_named_matrix_identity_v43(expected_predictor_matrix)),
    identical(mi_qc_receipt$predictor_edge_n, as.integer(sum(expected_predictor_matrix))),
    identical(as.integer(mi_qc_receipt$continuation_count), as.integer(expected_continuation)),
    identical(as.integer(recipe_receipt$final_iteration), as.integer(mi_qc_receipt$final_iteration)),
    identical(as.integer(recipe_receipt$continuation_count), as.integer(expected_continuation)),
    identical(semantic$schema_version, "1.0.0"),
    identical(semantic$status, "FORMAL_MICE_FROZEN"),
    identical(semantic$source_id, source_receipt$source_id),
    identical(semantic$source_epoch, source_receipt$source_epoch),
    identical(semantic$request_sha256, recipe_receipt$request_sha256),
    identical(semantic$source_mids_sha, actual_mids_sha),
    identical(semantic$completed_list_sha256, actual_completed_sha),
    identical(semantic$factor_level_sha, actual_factor_sha),
    identical(semantic$patient_order_sha256, actual_patient_order),
    identical(semantic$canonical_schema_sha256, actual_schema_sha),
    identical(semantic$canonical_column_order_sha256, .handoff_sha256_text(names(completed[[1L]]))),
    identical(completed_dataset_sha, unname(actual_completed_dataset_sha)),
    identical(as.integer(semantic$m), 20L),
    identical(as.integer(semantic$core_completed_column_n), 123L),
    identical(as.integer(semantic$working_mids_column_n), 124L),
    identical(semantic$contains_patient_values, FALSE),
    identical(serialization$schema_version, "1.0.0"),
    identical(serialization$status, "PASS"),
    identical(serialization$source_mids_sha256, actual_mids_sha),
    identical(serialization$completed_list_sha256, actual_completed_sha),
    identical(as.integer(serialization$m), 20L),
    identical(as.integer(serialization$final_iteration), as.integer(mi_qc_receipt$final_iteration)),
    identical(as.integer(serialization$continuation_count), as.integer(expected_continuation)),
    identical(as.integer(serialization$core_completed_column_n), 123L),
    identical(as.integer(serialization$working_mids_column_n), 124L),
    identical(serialization$imp0_origin, "original_frozen_mids.rds$data"),
    identical(serialization$completed_origin, "U04_COMPLETE_AND_RECALCULATE"),
    all(vapply(serialization[c(
      "imp0_matches_canonical_pre_mi", "long_imp1_20_match_completed_list",
      "factor_identity_verified", "patient_order_verified",
      "passive_recalculation_verified"
    )], identical, logical(1), TRUE)),
    identical(serialization$contains_patient_values, FALSE),
    identical(frozen_receipt$schema_version, "1.0.0"),
    identical(frozen_receipt$status, "PASS"),
    identical(frozen_receipt$seal_scope, "CANDIDATE_BYTES_ONLY"),
    identical(frozen_receipt$registry_approval_status, "CANDIDATE_PENDING_APPROVAL"),
    identical(frozen_receipt$approval_id, as.character(approval_row$approval_id[[1L]])),
    identical(frozen_receipt$approval_basis, "AUTO_GATE_PASS"),
    identical(frozen_receipt$source_id, source_receipt$source_id),
    identical(frozen_receipt$source_epoch, source_receipt$source_epoch),
    identical(frozen_receipt$request_sha256, recipe_receipt$request_sha256),
    identical(frozen_receipt$final_checkpoint_sha256, semantic$final_checkpoint_sha256),
    identical(frozen_receipt$mi_qc_receipt_sha256, mi_qc_receipt$receipt_sha256),
    identical(frozen_receipt$mids_sha256, actual_mids_sha),
    identical(frozen_receipt$completed_list_sha256, actual_completed_sha),
    identical(frozen_receipt$factor_level_sha256, actual_factor_sha),
    identical(frozen_receipt$canonical_schema_sha256, actual_schema_sha),
    identical(frozen_receipt$u05_execution_identity_sha256, .handoff_u05_execution_identity(project_root)),
    identical(frozen_receipt$contains_patient_values, FALSE),
    is.data.frame(mids_object$data),
    identical(mids_object$predictorMatrix, expected_predictor_matrix),
    identical(
      recipe_receipt$predictor_matrix_sha256,
      .mi_named_matrix_identity_v43(mids_object$predictorMatrix)
    ),
    identical(recipe_receipt$predictor_edge_n, as.integer(sum(mids_object$predictorMatrix))),
    identical(names(mids_object$data), c(names(completed[[1L]]), ".mi_na_all_cause"))
  )
  if (!all(values_ok)) .handoff_stop("HANDOFF_V43_RECEIPT_CLOSURE_FAILED")
  TRUE
}

validate_handoff_contract <- function(
    extracted, completed, mids_object, role_registry, factor_registry, readiness,
    approval_row, project_root = ".") {
  if (!is.data.frame(approval_row) || nrow(approval_row) != 1L) .handoff_stop("HANDOFF_APPROVAL_ROW_INVALID")
  semantic <- .handoff_json_member(extracted, "completed_data_semantic_identity_receipt.json")
  serialization <- .handoff_json_member(extracted, "serialization_identity_receipt.json")
  expected_semantic <- as.character(approval_row$expected_semantic_status[[1L]])
  expected_mids_sha <- as.character(approval_row$expected_mids_sha256[[1L]])
  expected_factor_sha <- as.character(approval_row$expected_factor_sha256[[1L]])
  expected_core_n <- as.integer(approval_row$expected_core_column_n[[1L]])
  actual_mids_sha <- .handoff_file_sha256(find_handoff_member(extracted, "original_frozen_mids.rds"))
  actual_factor_sha <- .handoff_file_sha256(find_handoff_member(extracted, "factor_level_registry.csv"))
  cox_ready <- readiness$ready[match("cox", readiness$domain)]
  cox_ready_flag <- length(cox_ready) == 1L && toupper(as.character(cox_ready)) == "TRUE"

  rows <- do.call(rbind, list(
    .handoff_qc("semantic_identity", .handoff_receipt_value(semantic, "status"), expected_semantic,
      identical(.handoff_receipt_value(semantic, "status"), expected_semantic)),
    .handoff_qc("imputation_count", length(completed), 20L,
      identical(as.integer(semantic$m), 20L) && length(completed) == 20L),
    .handoff_qc("core_column_count", nrow(role_registry), expected_core_n,
      nrow(role_registry) == expected_core_n &&
        identical(as.integer(serialization$core_completed_column_n), expected_core_n)),
    .handoff_qc("mids_archive_identity", actual_mids_sha, expected_mids_sha,
      identical(actual_mids_sha, expected_mids_sha) &&
        identical(.handoff_receipt_value(semantic, "source_mids_sha"), expected_mids_sha)),
    .handoff_qc("factor_registry_identity", actual_factor_sha, expected_factor_sha,
      identical(actual_factor_sha, expected_factor_sha) &&
        identical(.handoff_receipt_value(semantic, "factor_level_sha"), expected_factor_sha)),
    .handoff_qc("serialization_identity", .handoff_receipt_value(serialization, "status"), "PASS",
      identical(.handoff_receipt_value(serialization, "status"), "PASS") &&
        isTRUE(serialization$long_imp1_20_match_completed_list)),
    .handoff_qc("cox_readiness", cox_ready_flag, TRUE, cox_ready_flag),
    .handoff_qc("imp0_available", is.data.frame(mids_object$data), TRUE, is.data.frame(mids_object$data))
  ))

  if (.handoff_protocol_is_v43(approval_row)) {
    source_receipt <- .handoff_json_member(extracted, "source_candidate_receipt.json")
    recipe_receipt <- .handoff_json_member(extracted, "source_mi_recipe_receipt.json")
    mi_qc_receipt <- .handoff_json_member(extracted, "mi_qc_receipt.json")
    frozen_receipt <- .handoff_json_member(extracted, "FROZEN_HANDOFF_RECEIPT.json")
    expected_source_sha <- as.character(approval_row$expected_source_sha256[[1L]])
    expected_source_epoch <- as.character(approval_row$source_epoch[[1L]])
    expected_patient_order <- as.character(approval_row$expected_patient_order_sha256[[1L]])
    expected_completed_sha <- as.character(approval_row$expected_completed_sha256[[1L]])
    expected_schema_sha <- as.character(approval_row$expected_schema_sha256[[1L]])
    actual_completed_sha <- .handoff_file_sha256(find_handoff_member(extracted, "original_frozen_completed_analysis_list.rds"))
    actual_patient_order <- .handoff_sha256_text(as.character(completed[[1L]]$Patient_ID))
    actual_schema_sha <- .handoff_sha256_text(paste(
      names(completed[[1L]]),
      vapply(completed[[1L]], function(value) paste(class(value), collapse = "|"), character(1)),
      sep = "\t"
    ))
    receipt_closure <- validate_v43_handoff_receipt_closure(
      source_receipt, recipe_receipt, mi_qc_receipt, frozen_receipt,
      semantic, serialization, completed, mids_object, approval_row,
      actual_mids_sha, actual_completed_sha, actual_factor_sha,
      actual_patient_order, actual_schema_sha, project_root
    )
    v43_rows <- do.call(rbind, list(
      .handoff_qc("v43_receipt_closure", receipt_closure, TRUE, isTRUE(receipt_closure)),
      .handoff_qc("source_id", .handoff_receipt_value(source_receipt, "source_id"), approval_row$source_id[[1L]],
        identical(.handoff_receipt_value(source_receipt, "source_id"), as.character(approval_row$source_id[[1L]]))),
      .handoff_qc("source_sha256", .handoff_receipt_value(source_receipt, "source_sha256"), expected_source_sha,
        identical(.handoff_receipt_value(source_receipt, "source_sha256"), expected_source_sha)),
      .handoff_qc("source_epoch", .handoff_receipt_value(source_receipt, "source_epoch"), expected_source_epoch,
        identical(.handoff_receipt_value(source_receipt, "source_epoch"), expected_source_epoch)),
      .handoff_qc("patient_order_identity", actual_patient_order, expected_patient_order,
        identical(actual_patient_order, expected_patient_order) &&
          identical(.handoff_receipt_value(source_receipt, "patient_order_sha256"), expected_patient_order)),
      .handoff_qc("canonical_schema_identity", actual_schema_sha, expected_schema_sha,
        identical(actual_schema_sha, expected_schema_sha) &&
          identical(.handoff_receipt_value(source_receipt, "canonical_schema_sha256"), expected_schema_sha)),
      .handoff_qc("completed_list_identity", actual_completed_sha, expected_completed_sha,
        identical(actual_completed_sha, expected_completed_sha) &&
          identical(.handoff_receipt_value(frozen_receipt, "completed_list_sha256"), expected_completed_sha)),
      .handoff_qc("recipe_receipt", .handoff_receipt_value(recipe_receipt, "status"), "PASS",
        identical(.handoff_receipt_value(recipe_receipt, "status"), "PASS") &&
          identical(.handoff_receipt_value(recipe_receipt, "source_epoch"), expected_source_epoch)),
      .handoff_qc("mi_qc_receipt", .handoff_receipt_value(mi_qc_receipt, "status"), "PASS|PASS_HUMAN_APPROVED",
        .handoff_receipt_value(mi_qc_receipt, "status") %in% c("PASS", "PASS_HUMAN_APPROVED") &&
          identical(.handoff_receipt_value(mi_qc_receipt, "source_epoch"), expected_source_epoch)),
      .handoff_qc("frozen_handoff_receipt", .handoff_receipt_value(frozen_receipt, "status"), "PASS",
        identical(.handoff_receipt_value(frozen_receipt, "status"), "PASS") &&
          identical(.handoff_receipt_value(frozen_receipt, "approval_id"), as.character(approval_row$approval_id[[1L]])) &&
          identical(.handoff_receipt_value(frozen_receipt, "mids_sha256"), expected_mids_sha) &&
          identical(.handoff_receipt_value(frozen_receipt, "factor_level_sha256"), expected_factor_sha))
    ))
    rows <- rbind(rows, v43_rows)
  }
  rownames(rows) <- NULL
  if (any(rows$status != "PASS")) .handoff_stop("HANDOFF_CONTRACT_VALIDATION_FAILED")
  rows
}

load_analysis_sources <- function(profile, root = ".", handoff_zip = Sys.getenv("AST_ALT_HANDOFF_ZIP", ""), run_root = root) {
  if (identical(profile, "build_validation")) {
    fixture_path <- file.path(root, "tests", "fixtures", "synthetic_mi_fixture.rds")
    source_path <- file.path(root, "tests", "fixtures", "synthetic_survival_fixture.rds")
    source(file.path(root, "R", "profile_guard.R"))
    assert_build_fixture_path(fixture_path, root)
    assert_build_fixture_path(source_path, root)
    fixture <- readRDS(fixture_path)
    completed <- fixture$completed
    imp0 <- fixture$source_data
    structure_qc <- validate_completed_analysis_list(completed, expected_m = 20L)
    return(list(
      profile = profile,
      imp0 = imp0,
      completed = completed,
      mids = fixture$synthetic_mids,
      missing_mask = fixture$missing_mask,
      logged_events = fixture$logged_events,
      structure_qc = structure_qc,
      contract_qc = data.frame(qc_item = "synthetic_contract", observed = TRUE, expected = TRUE, status = "PASS"),
      source_label = "synthetic_fixture_only",
      handoff_identity = list()
    ))
  }

  if (!identical(profile, "production")) stop("Only production may load a real handoff", call. = FALSE)
  if (!nzchar(handoff_zip)) stop("production requires --handoff-zip or AST_ALT_HANDOFF_ZIP", call. = FALSE)
  source(file.path(root, "R", "profile_guard.R"))
  assert_execution_profile(profile, "read_patient_data", root)
  approval <- resolve_approved_handoff(handoff_zip, root)
  extracted <- extract_handoff_restricted(handoff_zip, approval$row, run_root)
  completed_path <- find_handoff_member(extracted, "original_frozen_completed_analysis_list.rds")
  mids_path <- find_handoff_member(extracted, "original_frozen_mids.rds")
  role_path <- find_handoff_member(extracted, "core_column_role_registry.csv")
  factor_path <- find_handoff_member(extracted, "factor_level_registry.csv")
  readiness_path <- find_handoff_member(extracted, "DOWNSTREAM_READINESS_GATE.csv")

  completed <- readRDS(completed_path)
  mids_object <- readRDS(mids_path)
  if (is.null(mids_object$data) || !is.data.frame(mids_object$data)) stop("Frozen mids object lacks .imp=0 data", call. = FALSE)
  role_registry <- utils::read.csv(role_path, stringsAsFactors = FALSE, check.names = FALSE)
  factor_registry <- utils::read.csv(factor_path, stringsAsFactors = FALSE, check.names = FALSE)
  readiness <- utils::read.csv(readiness_path, stringsAsFactors = FALSE, check.names = FALSE)
  structure_qc <- validate_completed_analysis_list(completed, expected_m = 20L, expected_column_n = 123L, role_registry = role_registry, factor_registry = factor_registry)
  contract_qc <- validate_handoff_contract(
    extracted, completed, mids_object, role_registry, factor_registry, readiness,
    approval$row, root
  )
  list(
    profile = profile,
    imp0 = mids_object$data,
    completed = completed,
    mids = mids_object,
    missing_mask = if (!is.null(mids_object$where)) mids_object$where else is.na(mids_object$data),
    logged_events = if (!is.null(mids_object$loggedEvents)) mids_object$loggedEvents else data.frame(),
    role_registry = role_registry,
    factor_registry = factor_registry,
    readiness = readiness,
    structure_qc = structure_qc,
    contract_qc = contract_qc,
    source_label = "readonly_frozen_handoff",
    handoff_identity = approval$identity
  )
}

run_real_structure_canary <- function(sources, root = ".") {
  data <- sources$completed[[1L]]
  required <- c("All_Cause_Death", "Death_Followup_months", "AST", "ALT", "Age", "Sex")
  missing <- setdiff(required, names(data))
  if (length(missing)) stop("REAL_STRUCTURE_CANARY missing columns: ", paste(missing, collapse = ", "), call. = FALSE)
  eligible <- is.finite(data$AST) & data$AST > 0 & is.finite(data$ALT) & data$ALT > 0
  canary <- data[eligible, , drop = FALSE]
  canary$log2_AST_ALT <- log2(canary$AST / canary$ALT)
  # 构建设计矩阵但不拟合模型，用于 production 真实结构 canary。
  matrix <- stats::model.matrix(~ log2_AST_ALT + Age + Sex, data = canary)
  data.frame(
    qc_item = c("required_columns", "eligible_rows_positive", "design_matrix_finite", "design_matrix_rank"),
    observed = c(length(missing) == 0L, nrow(canary) > 0L, all(is.finite(matrix)), qr(matrix)$rank),
    expected = c("TRUE", "TRUE", "TRUE", ncol(matrix)),
    status = c(
      ifelse(length(missing) == 0L, "PASS", "FAIL"),
      ifelse(nrow(canary) > 0L, "PASS", "FAIL"),
      ifelse(all(is.finite(matrix)), "PASS", "FAIL"),
      ifelse(qr(matrix)$rank == ncol(matrix), "PASS", "FAIL")
    ),
    stringsAsFactors = FALSE
  )
}
