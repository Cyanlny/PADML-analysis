# v4.3 Main-survival MI 配方编译器：科学值只读取 active amendment，CSV 仅为确定性投影。

.mi_stop <- function(code, detail = "") {
  message <- if (nzchar(detail)) paste(code, detail, sep = ": ") else code
  stop(message, call. = FALSE)
}

.mi_sha256_file <- function(path) {
  # 中文备注：加载摘要包以验证 MI owner 与 compiled projection 的文件身份。
  if (!requireNamespace("digest", quietly = TRUE)) .mi_stop("MI_DEPENDENCY_MISSING", "digest")
  digest::digest(file = path, algo = "sha256", serialize = FALSE)
}

.mi_sha256_text <- function(text) {
  # 中文备注：加载摘要包以绑定不含患者值的 predictor-policy 与 named-matrix 身份。
  if (!requireNamespace("digest", quietly = TRUE)) .mi_stop("MI_DEPENDENCY_MISSING", "digest")
  digest::digest(enc2utf8(paste(text, collapse = "\n")), algo = "sha256", serialize = FALSE)
}

.mi_canonicalize_json_arrays <- function(value) {
  if (!is.list(value)) return(value)
  if (!is.null(names(value))) value <- value[order(names(value))]
  lapply(value, .mi_canonicalize_json_arrays)
}

.mi_policy_subset <- function(predictor) {
  rules <- predictor$target_rules
  required_rule_fields <- c(
    "target", "family", "method", "visit_order", "working_scale",
    "required_predictors", "optional_group_ids", "forbidden_predictors",
    "pair_policy", "center_policy", "derived_rule"
  )
  if (!is.data.frame(rules) || !identical(names(rules), required_rule_fields)) {
    .mi_stop("MI_PREDICTOR_POLICY_RULE_SCHEMA_INVALID")
  }
  rule_list <- lapply(seq_len(nrow(rules)), function(index) {
    setNames(lapply(required_rule_fields, function(field) {
      value <- rules[[field]][[index]]
      if (field %in% c("required_predictors", "optional_group_ids", "forbidden_predictors")) {
        return(as.list(as.character(value)))
      }
      value
    }), required_rule_fields)
  })
  list(
    predictor_groups = predictor$predictor_groups,
    always_forbidden_predictors = as.character(predictor$always_forbidden_predictors),
    target_rules = rule_list
  )
}

.mi_policy_subset_identity <- function(predictor) {
  # 中文备注：按保留 JSON array/object 边界的规范编码复算 V22 predictor-policy 子集身份。
  if (!requireNamespace("jsonlite", quietly = TRUE)) .mi_stop("MI_DEPENDENCY_MISSING", "jsonlite")
  encoded <- jsonlite::toJSON(
    .mi_canonicalize_json_arrays(.mi_policy_subset(predictor)),
    auto_unbox = TRUE, null = "null", na = "null", digits = 17, pretty = FALSE
  )
  .mi_sha256_text(as.character(encoded))
}

.mi_split_pipe <- function(value) {
  if (length(value) != 1L || is.na(value) || !nzchar(value)) return(character())
  strsplit(value, "|", fixed = TRUE)[[1L]]
}

.mi_read_csv <- function(path) {
  if (!file.exists(path) || isTRUE(file.info(path)$isdir)) .mi_stop("MI_PROJECTION_FILE_MISSING", basename(path))
  utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE, na.strings = character())
}

.mi_bool <- function(value, label) {
  if (!is.logical(value) || length(value) != 1L || is.na(value)) .mi_stop("MI_OWNER_FIELD_INVALID", label)
  value
}

.mi_character_vector <- function(value, label) {
  value <- as.character(value)
  if (!length(value) || anyNA(value) || any(!nzchar(value)) || anyDuplicated(value)) {
    .mi_stop("MI_OWNER_FIELD_INVALID", label)
  }
  value
}

.mi_load_authority_environment <- function(project_root) {
  path <- file.path(project_root, "R", "authority_engine.R")
  if (!file.exists(path)) .mi_stop("MI_AUTHORITY_ENGINE_MISSING")
  environment <- new.env(parent = globalenv())
  sys.source(path, envir = environment)
  environment
}

validate_mi_contract_v43 <- function(owner) {
  if (!is.list(owner) || !all(c("recipe", "predictor", "qc", "source", "amendment_sha256") %in% names(owner))) {
    .mi_stop("MI_OWNER_OBJECT_INVALID")
  }
  recipe <- owner$recipe
  predictor <- owner$predictor
  qc <- owner$qc
  source <- owner$source
  recipe_required <- c(
    "branch", "m", "seed", "maxit_initial", "continuation_maxit", "continuation_function",
    "continuous_target_method", "continuous_target_n", "donors", "matchtype", "trim",
    "quantify", "use_matcher", "ls_meth", "ridge", "remove_constant", "remove_collinear",
    "predictor_policy", "diagonal", "ast_alt_role", "ast_alt_components_predictor_role",
    "all_cause_death_role", "nelson_aalen_role", "raw_followup_default_predictor",
    "runtime_predictor_deletion", "quickpred_allowed", "fallback_allowed", "rng_kind",
    "chain_count", "worker_pool_capacity", "chain_stream_policy", "chain_merge_order"
  )
  predictor_required <- c(
    "decision_id", "selected_option_id", "rule_id", "policy_subset_sha256",
    "source_authority_sha256", "matrix_view", "training_mask", "factor_support_rule",
    "factor_support_min_per_locked_level", "candidate_set_rule", "predictor_groups",
    "always_forbidden_predictors", "target_rules", "auxiliary_predictor_map",
    "auxiliary_predictors", "nelson_aalen_source", "forbidden_predictor_classes",
    "continuous_target_n", "candidate_edge_n", "candidate_predictors_min",
    "candidate_predictors_max", "block_policy", "diagonal"
  )
  if (length(setdiff(recipe_required, names(recipe))) || length(setdiff(predictor_required, names(predictor)))) {
    .mi_stop("MI_OWNER_SCHEMA_INVALID")
  }
  supported_values <- c(
    identical(recipe$branch, "MAIN_SURVIVAL_MI"),
    identical(recipe$continuation_function, "mice::mice.mids"),
    identical(recipe$continuous_target_method, "pmm"),
    identical(recipe$predictor_policy, "V22_TARGET_SPECIFIC_FULL_COHORT_ANALYSIS"),
    identical(recipe$ast_alt_role, "EXPOSURE_NOT_IMPUTED"),
    identical(recipe$ast_alt_components_predictor_role, "FORBIDDEN_AS_INDEPENDENT_PREDICTORS"),
    identical(recipe$all_cause_death_role, "PREDICTOR_ONLY_AUXILIARY_NOT_IMPUTED"),
    identical(recipe$nelson_aalen_role, "PREDICTOR_ONLY_AUXILIARY_NOT_IMPUTED"),
    identical(recipe$rng_kind, "L'Ecuyer-CMRG|Inversion|Rejection"),
    identical(recipe$chain_stream_policy, "NEXT_RNG_STREAM_FROM_MASTER_SEED"),
    identical(recipe$chain_merge_order, "CHAIN_ID_ASCENDING"),
    identical(predictor$decision_id, "MAIN_V22_PREDICTOR_POLICY_REMOTE_MICE_COMPUTE_CLOSURE_V1"),
    identical(predictor$selected_option_id, "V22_FULL_COHORT_ANALYSIS"),
    identical(predictor$rule_id, "V22_TARGET_SPECIFIC_PREDICTOR_POLICY_MAIN_A2_V1"),
    identical(predictor$policy_subset_sha256, "6fad1a3d5c1291d0e8f7246e62284c876743d169762e1d1adcb0addf4870cb1d"),
    identical(predictor$source_authority_sha256, "2a4d77f30318888527f0a3bd3b10763c93c8756766f757862c786549c1d9b200"),
    identical(predictor$matrix_view, "ANALYSIS"),
    identical(predictor$training_mask, "FULL_COHORT_ALL_TRUE"),
    identical(predictor$factor_support_rule, "TARGET_OBSERVED_ALL_TRAINING_ROWS_LOCKED_LEVELS_MIN_5"),
    identical(predictor$candidate_set_rule, "REQUIRED_PLUS_OPTIONAL_GROUPS_MINUS_GLOBAL_TARGET_SELF_THEN_AUXILIARIES"),
    identical(predictor$block_policy, "V22_VISIT_ORDER_ONE_TARGET_ONE_BLOCK")
  )
  if (!all(supported_values)) .mi_stop("MI_OWNER_UNSUPPORTED_SEMANTICS")
  if (!identical(as.integer(recipe$m), 20L) || !identical(as.integer(recipe$seed), 123L) ||
      !identical(as.integer(recipe$maxit_initial), 30L) ||
      !identical(as.integer(recipe$continuation_maxit), c(40L, 50L, 100L, 200L)) ||
      !identical(as.integer(recipe$continuous_target_n), 37L) ||
      !identical(as.integer(recipe$chain_count), 20L) ||
      !identical(as.integer(recipe$worker_pool_capacity), 24L) ||
      !identical(as.integer(recipe$donors), 5L) || !identical(as.integer(recipe$matchtype), 1L) ||
      !identical(as.integer(recipe$trim), 1L) || !identical(as.numeric(recipe$ridge), 1e-5) ||
      !identical(as.integer(recipe$diagonal), 0L)) {
    .mi_stop("MI_OWNER_NUMERIC_CONTRACT_INVALID")
  }
  boolean_values <- c(
    .mi_bool(recipe$quantify, "quantify"),
    !.mi_bool(recipe$use_matcher, "use_matcher"),
    !.mi_bool(recipe$remove_constant, "remove_constant"),
    !.mi_bool(recipe$remove_collinear, "remove_collinear"),
    !.mi_bool(recipe$raw_followup_default_predictor, "raw_followup_default_predictor"),
    !.mi_bool(recipe$runtime_predictor_deletion, "runtime_predictor_deletion"),
    !.mi_bool(recipe$quickpred_allowed, "quickpred_allowed"),
    !.mi_bool(recipe$fallback_allowed, "fallback_allowed")
  )
  if (!all(boolean_values) || !identical(recipe$ls_meth, "qr")) .mi_stop("MI_OWNER_EXECUTION_CONTRACT_INVALID")
  auxiliaries <- .mi_character_vector(predictor$auxiliary_predictors, "auxiliary_predictors")
  groups <- predictor$predictor_groups
  rules <- predictor$target_rules
  expected_group_names <- c(
    "BASELINE_CLINICAL", "MEDICATIONS", "PROCEDURE_CONTEXT", "FUNCTIONAL_CONTEXT",
    "VITAL_CONTEXT", "CORE_LAB_CONTEXT", "CARDIORENAL_CONTEXT",
    "CARDIORESPIRATORY_CONTEXT", "INFLAMMATION_EXTERNAL", "PLATELET_CONTEXT",
    "NUTRITION_EXTERNAL", "COAGULATION_EXTERNAL"
  )
  rule_vectors_valid <- is.data.frame(rules) && nrow(rules) == 37L &&
    all(vapply(c("required_predictors", "optional_group_ids", "forbidden_predictors"), function(field) {
      is.list(rules[[field]]) && all(vapply(rules[[field]], function(value) {
        is.character(value) && !anyNA(value) && !anyDuplicated(value)
      }, logical(1)))
    }, logical(1)))
  if (!is.list(groups) || !identical(names(groups), expected_group_names) ||
      any(!vapply(groups, function(value) {
        is.character(value) && length(value) > 0L && !anyNA(value) && !anyDuplicated(value)
      }, logical(1))) || !isTRUE(rule_vectors_valid) ||
      !identical(as.character(rules$target), unique(as.character(rules$target))) ||
      !identical(as.integer(rules$visit_order), seq.int(10L, 370L, by = 10L)) ||
      any(as.character(rules$method) != "pmm") ||
      length(setdiff(unlist(rules$optional_group_ids, use.names = FALSE), names(groups))) ||
      !identical(.mi_policy_subset_identity(predictor), predictor$policy_subset_sha256) ||
      !identical(auxiliaries, c("AST_ALT", "All_Cause_Death", ".mi_na_all_cause")) ||
      !identical(unname(unlist(predictor$auxiliary_predictor_map, use.names = FALSE)), auxiliaries) ||
      !identical(as.integer(predictor$factor_support_min_per_locked_level), 5L) ||
      !identical(as.integer(predictor$continuous_target_n), 37L) ||
      !identical(as.integer(predictor$candidate_edge_n), 896L) ||
      !identical(as.integer(predictor$candidate_predictors_min), 20L) ||
      !identical(as.integer(predictor$candidate_predictors_max), 38L) ||
      !identical(as.integer(predictor$diagonal), 0L)) {
    .mi_stop("MI_PREDICTOR_OWNER_CONTRACT_INVALID")
  }
  if (!is.data.frame(source) || nrow(source) != 1L ||
      !identical(source$mi_recipe_id[[1L]], "SRC_MI_V43_MAIN_SURVIVAL_V1") ||
      !identical(source$row_order_rule[[1L]], "SOURCE_WORKBOOK_ORDER")) {
    .mi_stop("MI_SOURCE_LINK_INVALID")
  }
  qc_required <- c(
    "diagnostic", "psrf_threshold", "required_consecutive_iterations",
    "missing_diagnostic_n", "nonfinite_diagnostic_n", "lag1_review_abs_threshold",
    "standardized_mean_shift_review_abs_threshold", "lag1_role"
  )
  if (length(setdiff(qc_required, names(qc))) ||
      !identical(qc$diagnostic, "all") ||
      !identical(as.numeric(qc$psrf_threshold), 1.1) ||
      !identical(as.integer(qc$required_consecutive_iterations), 3L) ||
      !identical(as.integer(qc$missing_diagnostic_n), 0L) ||
      !identical(as.integer(qc$nonfinite_diagnostic_n), 0L) ||
      !identical(as.numeric(qc$lag1_review_abs_threshold), 0.8) ||
      !identical(as.numeric(qc$standardized_mean_shift_review_abs_threshold), 0.5) ||
      !identical(qc$lag1_role, "DESCRIPTIVE_REVIEW_ONLY")) {
    .mi_stop("MI_QC_OWNER_CONTRACT_INVALID")
  }
  invisible(TRUE)
}

read_mi_contract_v43 <- function(project_root = ".") {
  project_root <- normalizePath(project_root, mustWork = TRUE)
  authority <- .mi_load_authority_environment(project_root)
  index <- authority$read_contract_index(project_root)
  authority$validate_contract_index(index, project_root)
  recipe_owner <- authority$resolve_authority(index, "mi.recipe.main_survival")
  predictor_owner <- authority$resolve_authority(index, "mi.predictor_matrix.main_survival")
  expected_path <- "protocol/amendments/MAIN_V43_R00_CONFLICT_SAFE_DRIFT_SAFE_EXACT_CLOSURE_FINAL.json"
  if (!identical(recipe_owner$owner_relative_path[[1L]], expected_path) ||
      !identical(predictor_owner$owner_relative_path[[1L]], expected_path) ||
      !identical(recipe_owner$owner_pointer[[1L]], "/scientific_contract/mi_recipe") ||
      !identical(predictor_owner$owner_pointer[[1L]], "/scientific_contract/mi_predictor_rule")) {
    .mi_stop("MI_ACTIVE_OWNER_POINTER_INVALID")
  }
  amendment_path <- file.path(project_root, expected_path)
  # 中文备注：加载 JSON 包并读取唯一 active MI amendment。
  if (!requireNamespace("jsonlite", quietly = TRUE)) .mi_stop("MI_DEPENDENCY_MISSING", "jsonlite")
  amendment <- jsonlite::read_json(amendment_path, simplifyVector = TRUE)
  source_path <- file.path(project_root, "config", "source_dataset_registry.csv")
  source <- .mi_read_csv(source_path)
  source <- source[source$active %in% TRUE, , drop = FALSE]
  owner <- list(
    recipe = amendment$scientific_contract$mi_recipe,
    predictor = amendment$scientific_contract$mi_predictor_rule,
    qc = amendment$scientific_contract$mi_qc,
    source = source,
    amendment_sha256 = .mi_sha256_file(amendment_path)
  )
  validate_mi_contract_v43(owner)
  owner
}

.mi_registered_targets <- function(mapping) {
  targets <- mapping$target_name[
    mapping$mapping_kind == "DIRECT_NUMERIC" & mapping$nullable %in% TRUE
  ]
  if (length(targets) != 37L || anyDuplicated(targets)) .mi_stop("MI_TARGET_REGISTRY_INVALID")
  targets
}

.mi_projection_components <- function(owner, mapping) {
  validate_mi_contract_v43(owner)
  required_mapping <- c(
    "target_position", "target_name", "source_name", "mapping_kind", "expected_r_class",
    "ordered", "levels", "nullable", "decision_source"
  )
  if (!is.data.frame(mapping) || !identical(names(mapping), required_mapping) ||
      !identical(as.integer(mapping$target_position), seq_len(nrow(mapping))) || nrow(mapping) != 123L) {
    .mi_stop("MI_MAPPING_CONTRACT_INVALID")
  }
  registered_targets <- .mi_registered_targets(mapping)
  rules <- owner$predictor$target_rules
  targets <- as.character(rules$target[order(as.integer(rules$visit_order))])
  auxiliaries <- as.character(owner$predictor$auxiliary_predictors)
  canonical_names <- mapping$target_name
  working_names <- c(canonical_names, ".mi_na_all_cause")
  if (!setequal(targets, registered_targets) || length(setdiff(auxiliaries, working_names)) ||
      length(intersect(targets, auxiliaries))) {
    .mi_stop("MI_PREDICTOR_ROLE_OVERLAP_OR_MISSING")
  }
  methods <- ifelse(working_names %in% targets, owner$recipe$continuous_target_method, "")
  method_registry <- data.frame(
    position = seq_along(working_names), variable = working_names, method = methods,
    stringsAsFactors = FALSE, check.names = FALSE
  )
  block_registry <- data.frame(
    block_position = seq_along(targets), block_id = targets,
    target_position = match(targets, working_names), target = targets,
    method = rep(owner$recipe$continuous_target_method, length(targets)),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  groups <- owner$predictor$predictor_groups
  global_forbidden <- as.character(owner$predictor$always_forbidden_predictors)
  edge_rows <- lapply(targets, function(target) {
    index <- match(target, as.character(rules$target))
    required <- as.character(rules$required_predictors[[index]])
    optional <- unlist(groups[as.character(rules$optional_group_ids[[index]])], use.names = FALSE)
    forbidden <- unique(c(global_forbidden, as.character(rules$forbidden_predictors[[index]]), target))
    if (length(setdiff(c(required, optional, forbidden), working_names))) {
      .mi_stop("MI_PREDICTOR_POLICY_UNKNOWN_VARIABLE", target)
    }
    candidates <- unique(c(required, optional))
    candidates <- candidates[candidates %in% working_names & !candidates %in% forbidden]
    candidates <- unique(c(candidates, auxiliaries))
    predictors <- working_names[working_names %in% candidates]
    data.frame(
      target_position = match(target, working_names),
      predictor_position = match(predictors, working_names),
      target = target, predictor = predictors, value = 1L,
      stringsAsFactors = FALSE, check.names = FALSE
    )
  })
  predictor_edges <- do.call(rbind, edge_rows)
  rownames(predictor_edges) <- NULL
  predictor_edges <- predictor_edges[
    order(match(predictor_edges$target, targets), predictor_edges$predictor_position),
    , drop = FALSE
  ]
  rownames(predictor_edges) <- NULL
  list(
    target_names = targets,
    working_names = working_names,
    method_registry = method_registry,
    block_registry = block_registry,
    predictor_edges = predictor_edges
  )
}

compile_mi_projection_v43 <- function(project_root = ".", owner = NULL, mapping = NULL) {
  if (is.null(owner)) owner <- read_mi_contract_v43(project_root)
  if (is.null(mapping)) {
    if (!exists("read_source_column_mapping_registry", mode = "function")) {
      source(file.path(project_root, "R", "source_input_adapter.R"))
    }
    mapping <- read_source_column_mapping_registry(project_root)
  }
  projection <- .mi_projection_components(owner, mapping)
  validate_mi_projection_v43(projection, owner, mapping)
  projection
}

validate_mi_projection_v43 <- function(projection, owner, mapping) {
  required <- c("target_names", "working_names", "method_registry", "block_registry", "predictor_edges")
  if (!is.list(projection) || !identical(names(projection), required)) .mi_stop("MI_PROJECTION_OBJECT_INVALID")
  expected <- .mi_projection_components(owner, mapping)
  edges <- projection$predictor_edges
  if (!is.data.frame(edges) || !identical(names(edges), names(expected$predictor_edges))) {
    .mi_stop("MI_EDGE_SCHEMA_INVALID")
  }
  if (anyNA(edges) || any(!edges$target %in% projection$target_names) ||
      any(!edges$predictor %in% projection$working_names)) {
    .mi_stop("MI_EDGE_IDENTITY_INVALID")
  }
  if (nrow(edges) != as.integer(owner$predictor$candidate_edge_n)) .mi_stop("MI_EDGE_CARDINALITY_INVALID")
  if (anyDuplicated(paste(edges$target_position, edges$predictor_position, sep = "|")) ||
      any(edges$value != 1L) || any(edges$target == edges$predictor)) {
    .mi_stop("MI_EDGE_KEY_OR_DIAGONAL_INVALID")
  }
  if (any(edges$predictor %in% owner$predictor$always_forbidden_predictors)) {
    .mi_stop("MI_FORBIDDEN_PREDICTOR")
  }
  edge_position_ok <- all(edges$target_position == match(edges$target, projection$working_names)) &&
    all(edges$predictor_position == match(edges$predictor, projection$working_names))
  if (!edge_position_ok) .mi_stop("MI_EDGE_IDENTITY_INVALID")
  if (!identical(projection$target_names, expected$target_names) ||
      !identical(projection$working_names, expected$working_names)) {
    .mi_stop("MI_TARGET_OR_WORKING_ORDER_MISMATCH")
  }
  blocks <- projection$block_registry
  if (!is.data.frame(blocks) || !identical(blocks, expected$block_registry) ||
      anyDuplicated(blocks$block_id) || any(blocks$block_id != blocks$target)) {
    .mi_stop("MI_BLOCK_REGISTRY_INVALID")
  }
  if (!is.data.frame(projection$method_registry) ||
      !identical(projection$method_registry, expected$method_registry)) {
    .mi_stop("MI_METHOD_REGISTRY_INVALID")
  }
  if (!identical(edges, expected$predictor_edges)) .mi_stop("MI_PREDICTOR_SET_MISMATCH")
  counts <- table(factor(edges$target, levels = projection$target_names))
  if (min(counts) != as.integer(owner$predictor$candidate_predictors_min) ||
      max(counts) != as.integer(owner$predictor$candidate_predictors_max)) {
    .mi_stop("MI_PREDICTORS_PER_TARGET_INVALID")
  }
  invisible(TRUE)
}

.mi_expected_blot <- function(owner) {
  list(
    donors = as.integer(owner$recipe$donors),
    matchtype = as.integer(owner$recipe$matchtype),
    trim = as.integer(owner$recipe$trim),
    quantify = isTRUE(owner$recipe$quantify),
    use.matcher = isTRUE(owner$recipe$use_matcher),
    ls.meth = as.character(owner$recipe$ls_meth),
    ridge = as.numeric(owner$recipe$ridge)
  )
}

compute_mi_nelson_aalen_v43 <- function(canonical) {
  required <- c("Death_Followup_months", "All_Cause_Death")
  if (!is.data.frame(canonical) || length(setdiff(required, names(canonical)))) {
    .mi_stop("MI_NELSON_AALEN_INPUT_MISSING")
  }
  time <- as.numeric(canonical$Death_Followup_months)
  status_text <- as.character(canonical$All_Cause_Death)
  if (any(!is.finite(time)) || any(time <= 0) || anyNA(status_text) ||
      !all(status_text %in% c("0", "1"))) {
    .mi_stop("MI_NELSON_AALEN_INPUT_INVALID")
  }
  survival_data <- data.frame(time = time, status = as.integer(status_text), check.names = FALSE)
  # 中文备注：加载 mice 包并计算已批准的边际 Nelson–Aalen predictor-only 辅助量。
  if (!requireNamespace("mice", quietly = TRUE)) .mi_stop("MI_DEPENDENCY_MISSING", "mice")
  result <- suppressWarnings(mice::nelsonaalen(survival_data, time, status))
  result <- as.numeric(result)
  if (length(result) != nrow(canonical) || anyNA(result) || any(!is.finite(result)) || any(result < 0)) {
    .mi_stop("MI_NELSON_AALEN_OUTPUT_INVALID")
  }
  result
}

.mi_predictor_matrix <- function(projection) {
  matrix <- matrix(
    0L, nrow = length(projection$target_names), ncol = length(projection$working_names),
    dimnames = list(projection$target_names, projection$working_names)
  )
  row_position <- match(projection$predictor_edges$target, projection$target_names)
  matrix[cbind(row_position, projection$predictor_edges$predictor_position)] <- 1L
  matrix
}

.mi_projection_identity_v43 <- function(projection) {
  edges <- lapply(seq_len(nrow(projection$predictor_edges)), function(index) {
    list(
      target = as.character(projection$predictor_edges$target[[index]]),
      predictor = as.character(projection$predictor_edges$predictor[[index]])
    )
  })
  payload <- list(
    target_names = as.list(as.character(projection$target_names)),
    working_names = as.list(as.character(projection$working_names)),
    candidate_edges = edges
  )
  # 中文备注：加载 JSON 包并规范编码不含患者值的 candidate-edge 投影。
  if (!requireNamespace("jsonlite", quietly = TRUE)) .mi_stop("MI_DEPENDENCY_MISSING", "jsonlite")
  encoded <- jsonlite::toJSON(
    .mi_canonicalize_json_arrays(payload), auto_unbox = TRUE,
    null = "null", na = "null", digits = 17, pretty = FALSE
  )
  .mi_sha256_text(as.character(encoded))
}

.mi_named_matrix_identity_v43 <- function(value) {
  if (!is.matrix(value) || !is.numeric(value) || is.null(rownames(value)) ||
      is.null(colnames(value)) || anyNA(value) || any(!value %in% c(0, 1)) ||
      anyDuplicated(rownames(value)) || anyDuplicated(colnames(value))) {
    .mi_stop("MI_NAMED_MATRIX_IDENTITY_INVALID")
  }
  positions <- which(value == 1, arr.ind = TRUE)
  edges <- lapply(seq_len(nrow(positions)), function(index) {
    list(
      target = rownames(value)[positions[index, "row"]],
      predictor = colnames(value)[positions[index, "col"]]
    )
  })
  payload <- list(
    target_names = as.list(rownames(value)),
    predictor_names = as.list(colnames(value)),
    edges = edges
  )
  # 中文备注：加载 JSON 包并规范编码不含患者值的实际 named-matrix 身份。
  if (!requireNamespace("jsonlite", quietly = TRUE)) .mi_stop("MI_DEPENDENCY_MISSING", "jsonlite")
  encoded <- jsonlite::toJSON(
    .mi_canonicalize_json_arrays(payload), auto_unbox = TRUE,
    null = "null", na = "null", digits = 17, pretty = FALSE
  )
  .mi_sha256_text(as.character(encoded))
}

.mi_locked_levels <- function(mapping, name) {
  index <- match(name, mapping$target_name)
  if (is.na(index) || !mapping$expected_r_class[[index]] %in% c("factor", "ordered_factor", "character")) {
    .mi_stop("MI_FACTOR_SUPPORT_MAPPING_INVALID", name)
  }
  levels <- .mi_split_pipe(mapping$levels[[index]])
  if (length(levels) < 2L || anyDuplicated(levels)) .mi_stop("MI_FACTOR_SUPPORT_LEVELS_INVALID", name)
  levels
}

.mi_factor_support_ok_v43 <- function(data, target, predictor, mapping, minimum_count) {
  value <- data[[predictor]]
  if (is.numeric(value)) return(TRUE)
  if (!is.factor(value) && !is.character(value)) {
    .mi_stop("MI_PREDICTOR_CLASS_UNSUPPORTED", predictor)
  }
  locked <- .mi_locked_levels(mapping, predictor)
  character_value <- as.character(value)
  unknown <- setdiff(unique(character_value[!is.na(character_value)]), locked)
  if (length(unknown)) .mi_stop("MI_FACTOR_SUPPORT_UNKNOWN_LEVEL", predictor)
  observed <- character_value[!is.na(data[[target]])]
  counts <- table(factor(observed, levels = locked))
  length(counts) >= 2L && all(counts >= as.integer(minimum_count))
}

.mi_actual_predictor_matrix_v43 <- function(data, projection, owner, mapping) {
  if (!is.data.frame(data) || !identical(names(data), projection$working_names)) {
    .mi_stop("MI_ACTUAL_MATRIX_DATA_INVALID")
  }
  candidate <- .mi_predictor_matrix(projection)
  minimum_count <- as.integer(owner$predictor$factor_support_min_per_locked_level)
  for (target in rownames(candidate)) {
    predictors <- colnames(candidate)[candidate[target, ] == 1L]
    for (predictor in predictors) {
      if (!.mi_factor_support_ok_v43(data, target, predictor, mapping, minimum_count)) {
        candidate[target, predictor] <- 0L
      }
    }
  }
  storage.mode(candidate) <- "integer"
  candidate
}

build_mi_runtime_spec_v43 <- function(canonical, projection, owner, mapping) {
  validate_mi_projection_v43(projection, owner, mapping)
  if (!is.data.frame(canonical) || !identical(names(canonical), mapping$target_name)) {
    .mi_stop("MI_CANONICAL_DATA_SCHEMA_INVALID")
  }
  if (exists("validate_canonical_pre_mi", mode = "function")) {
    validate_canonical_pre_mi(canonical, mapping)
  }
  data <- canonical
  data$.mi_na_all_cause <- compute_mi_nelson_aalen_v43(canonical)
  targets <- projection$target_names
  blocks <- setNames(lapply(targets, function(target) target), targets)
  method <- setNames(rep(owner$recipe$continuous_target_method, length(targets)), targets)
  where <- matrix(FALSE, nrow = nrow(data), ncol = ncol(data), dimnames = list(rownames(data), names(data)))
  where[, targets] <- is.na(data[, targets, drop = FALSE])
  blot <- .mi_expected_blot(owner)
  blots <- setNames(lapply(targets, function(target) blot), targets)
  actual_matrix <- .mi_actual_predictor_matrix_v43(data, projection, owner, mapping)
  runtime <- list(
    data = data,
    method = method,
    predictor_matrix = actual_matrix,
    candidate_projection_sha256 = .mi_projection_identity_v43(projection),
    predictor_matrix_sha256 = .mi_named_matrix_identity_v43(actual_matrix),
    predictor_edge_n = as.integer(sum(actual_matrix)),
    blocks = blocks,
    where = where,
    blots = blots,
    visit_sequence = targets,
    rng_kind = c("L'Ecuyer-CMRG", "Inversion", "Rejection")
  )
  validate_mi_runtime_spec_v43(runtime, projection, owner, mapping)
  runtime
}

validate_mi_runtime_spec_v43 <- function(runtime, projection, owner, mapping) {
  required <- c(
    "data", "method", "predictor_matrix", "candidate_projection_sha256",
    "predictor_matrix_sha256", "predictor_edge_n", "blocks", "where", "blots",
    "visit_sequence", "rng_kind"
  )
  if (!is.list(runtime) || !identical(names(runtime), required)) .mi_stop("MI_RUNTIME_SPEC_INVALID")
  validate_mi_projection_v43(projection, owner, mapping)
  targets <- projection$target_names
  if (!is.data.frame(runtime$data) || !identical(names(runtime$data), projection$working_names) ||
      nrow(runtime$data) < 2L) {
    .mi_stop("MI_RUNTIME_DATA_INVALID")
  }
  expected_na <- compute_mi_nelson_aalen_v43(runtime$data[mapping$target_name])
  if (!isTRUE(all.equal(runtime$data$.mi_na_all_cause, expected_na, tolerance = 0, check.attributes = FALSE))) {
    .mi_stop("MI_NELSON_AALEN_IDENTITY_MISMATCH")
  }
  expected_method <- setNames(rep(owner$recipe$continuous_target_method, length(targets)), targets)
  expected_blocks <- setNames(lapply(targets, function(target) target), targets)
  expected_where <- matrix(
    FALSE, nrow = nrow(runtime$data), ncol = ncol(runtime$data),
    dimnames = list(rownames(runtime$data), names(runtime$data))
  )
  expected_where[, targets] <- is.na(runtime$data[, targets, drop = FALSE])
  expected_blot <- .mi_expected_blot(owner)
  expected_blots <- setNames(lapply(targets, function(target) expected_blot), targets)
  if (!identical(runtime$method, expected_method)) .mi_stop("MI_RUNTIME_METHOD_MISMATCH")
  expected_matrix <- .mi_actual_predictor_matrix_v43(runtime$data, projection, owner, mapping)
  if (!identical(runtime$predictor_matrix, expected_matrix) ||
      !identical(runtime$candidate_projection_sha256, .mi_projection_identity_v43(projection)) ||
      !identical(runtime$predictor_matrix_sha256, .mi_named_matrix_identity_v43(expected_matrix)) ||
      !identical(as.integer(runtime$predictor_edge_n), as.integer(sum(expected_matrix))) ||
      as.integer(runtime$predictor_edge_n) < 1L ||
      as.integer(runtime$predictor_edge_n) > as.integer(owner$predictor$candidate_edge_n)) {
    .mi_stop("MI_RUNTIME_PREDICTOR_MATRIX_MISMATCH")
  }
  if (!identical(runtime$blocks, expected_blocks)) .mi_stop("MI_RUNTIME_BLOCKS_MISMATCH")
  if (!identical(runtime$where, expected_where)) .mi_stop("MI_RUNTIME_WHERE_MISMATCH")
  if (!identical(runtime$blots, expected_blots)) .mi_stop("MI_BLOTS_MISMATCH")
  if (!identical(runtime$visit_sequence, targets)) .mi_stop("MI_VISIT_SEQUENCE_MISMATCH")
  if (!identical(
      runtime$rng_kind,
      c("L'Ecuyer-CMRG", "Inversion", "Rejection")
  )) {
    .mi_stop("MI_RNG_IDENTITY_INVALID")
  }
  if (any(vapply(runtime$data[targets], function(value) any(!is.na(value) & !is.finite(value)), logical(1)))) {
    .mi_stop("MI_TARGET_NONFINITE")
  }
  missing_n <- vapply(runtime$data[targets], function(value) sum(is.na(value)), integer(1))
  observed_n <- vapply(runtime$data[targets], function(value) sum(!is.na(value)), integer(1))
  if (any(missing_n == 0L) || any(observed_n < as.integer(owner$recipe$donors))) {
    .mi_stop("MI_TARGET_DONOR_OR_MISSINGNESS_INVALID")
  }
  invisible(TRUE)
}

.mi_fill_design_missing <- function(data) {
  output <- data
  for (name in names(output)) {
    value <- output[[name]]
    if (is.numeric(value)) {
      finite <- value[is.finite(value)]
      if (!length(finite)) .mi_stop("MI_DESIGN_PREDICTOR_NO_FINITE_VALUE", name)
      value[is.na(value)] <- stats::median(finite)
      if (any(!is.finite(value))) .mi_stop("MI_DESIGN_PREDICTOR_NONFINITE", name)
      output[[name]] <- value
    } else if (is.factor(value)) {
      if (!length(levels(value))) .mi_stop("MI_DESIGN_FACTOR_LEVELS_INVALID", name)
      value[is.na(value)] <- levels(value)[[1L]]
      output[[name]] <- value
    } else {
      .mi_stop("MI_DESIGN_PREDICTOR_CLASS_UNSUPPORTED", name)
    }
  }
  output
}

preflight_mi_design_v43 <- function(runtime, projection, owner, mapping) {
  validate_mi_runtime_spec_v43(runtime, projection, owner, mapping)
  targets <- names(runtime$blocks)
  rows <- lapply(targets, function(target) {
    predictors <- colnames(runtime$predictor_matrix)[runtime$predictor_matrix[target, ] == 1L]
    design_data <- .mi_fill_design_missing(runtime$data[predictors])
    # 中文备注：构建设计矩阵并执行无拟合秩检查；不调用 Cox、PMM 或其他模型拟合。
    design <- stats::model.matrix(~ ., data = design_data, na.action = stats::na.fail)
    rank <- qr(design)$rank
    deficiency <- ncol(design) - rank
    data.frame(
      target = target,
      predictor_n = length(predictors),
      design_column_n = ncol(design),
      rank = rank,
      rank_deficiency = deficiency,
      condition_number = unname(kappa(design, exact = FALSE)),
      donor_n = sum(!is.na(runtime$data[[target]])),
      missing_n = sum(is.na(runtime$data[[target]])),
      status = ifelse(deficiency == 0L, "PASS", "FAIL"),
      stringsAsFactors = FALSE
    )
  })
  result <- do.call(rbind, rows)
  rownames(result) <- NULL
  if (nrow(result) != as.integer(owner$recipe$continuous_target_n) ||
      !identical(as.integer(result$predictor_n), as.integer(rowSums(runtime$predictor_matrix))) ||
      any(result$rank_deficiency != 0L) || any(!is.finite(result$condition_number))) {
    .mi_stop("MI_NO_FIT_DESIGN_PREFLIGHT_FAILED")
  }
  result
}

.mi_with_rng_kind <- function(kind, expression) {
  previous <- RNGkind()
  on.exit(do.call(RNGkind, as.list(previous)), add = TRUE)
  do.call(RNGkind, as.list(kind))
  force(expression)
}

.mi_assert_remote_compute_context_v43 <- function() {
  hashes <- c(
    AST_ALT_VERIFIED_RUNTIME_IDENTITY_SHA256 = 64L,
    AST_ALT_REMOTE_REQUEST_SHA256 = 64L,
    AST_ALT_STATELESS_CODE_CONTENT_TREE_SHA256 = 64L
  )
  valid <- identical(Sys.getenv("AST_ALT_STATELESS_COMPUTE_NODE", unset = ""), "TRUE") &&
    identical(Sys.getenv("AST_ALT_EXECUTION_PROFILE", unset = ""), "production") &&
    identical(suppressWarnings(as.integer(Sys.getenv("AST_ALT_WORKERS", unset = ""))), 24L) &&
    all(vapply(names(hashes), function(name) {
      grepl(sprintf("^[0-9a-f]{%d}$", hashes[[name]]), Sys.getenv(name, unset = ""))
    }, logical(1)))
  if (!isTRUE(valid)) .mi_stop("MI_REMOTE_COMPUTE_CONTEXT_REQUIRED")
  invisible(TRUE)
}

run_mi_setup_v43 <- function(runtime, projection, owner, mapping, print_flag = FALSE) {
  validate_mi_runtime_spec_v43(runtime, projection, owner, mapping)
  # 中文备注：加载 mice 包并执行 U02 的 production-shaped maxit=0 设置校验，不发布任何对象。
  if (!requireNamespace("mice", quietly = TRUE)) .mi_stop("MI_DEPENDENCY_MISSING", "mice")
  .mi_with_rng_kind(runtime$rng_kind, {
    # 中文备注：开始 maxit=0 MI 设置调用；该调用不执行插补迭代。
    mice::mice(
      data = runtime$data,
      m = as.integer(owner$recipe$m),
      method = runtime$method,
      predictorMatrix = runtime$predictor_matrix,
      where = runtime$where,
      blocks = runtime$blocks,
      visitSequence = runtime$visit_sequence,
      blots = runtime$blots,
      maxit = 0L,
      printFlag = isTRUE(print_flag),
      seed = as.integer(owner$recipe$seed),
      remove.constant = isTRUE(owner$recipe$remove_constant),
      remove.collinear = isTRUE(owner$recipe$remove_collinear)
    )
  })
}

run_mi_smoke_v43 <- function(runtime, projection, owner, mapping, print_flag = FALSE) {
  validate_mi_runtime_spec_v43(runtime, projection, owner, mapping)
  .mi_assert_remote_compute_context_v43()
  # 中文备注：加载 mice 包并执行仅限 U02 的 m=1、maxit=1 合成冒烟；结果不得进入正式 handoff。
  if (!requireNamespace("mice", quietly = TRUE)) .mi_stop("MI_DEPENDENCY_MISSING", "mice")
  .mi_with_rng_kind(runtime$rng_kind, {
    # 中文备注：开始合成 PMM 冒烟调用；固定全部显式参数并禁止自动删除 predictor。
    mice::mice(
      data = runtime$data,
      m = 1L,
      method = runtime$method,
      predictorMatrix = runtime$predictor_matrix,
      where = runtime$where,
      blocks = runtime$blocks,
      visitSequence = runtime$visit_sequence,
      blots = runtime$blots,
      maxit = 1L,
      printFlag = isTRUE(print_flag),
      seed = as.integer(owner$recipe$seed),
      remove.constant = isTRUE(owner$recipe$remove_constant),
      remove.collinear = isTRUE(owner$recipe$remove_collinear)
    )
  })
}

.mi_runtime_versions <- function(project_root = ".") {
  profile <- .mi_read_csv(file.path(project_root, "config", "runtime_profile_registry.csv"))
  profile <- profile[profile$runtime_profile_id == "AUTODL_UBUNTU2204_V43", , drop = FALSE]
  if (nrow(profile) != 1L || !identical(profile$r_version[[1L]], "4.6.0")) {
    .mi_stop("MI_RUNTIME_PROFILE_INVALID")
  }
  # 中文备注：读取 lock 绑定远端 accepted V3 的 mice 版本；本地不加载或执行 MICE。
  if (!requireNamespace("jsonlite", quietly = TRUE)) .mi_stop("MI_DEPENDENCY_MISSING", "jsonlite")
  lock <- jsonlite::read_json(file.path(project_root, "renv.lock"), simplifyVector = TRUE)
  mice_version <- as.character(lock$Packages$mice$Version)
  if (!identical(mice_version, "3.19.0")) .mi_stop("MI_RUNTIME_PROFILE_INVALID")
  list(
    r_version = profile$r_version[[1L]],
    mice_version = mice_version,
    rng_kind = "L'Ecuyer-CMRG|Inversion|Rejection"
  )
}

.mi_recipe_registry_fields <- function() {
  c(
    "recipe_id", "branch", "m", "seed", "maxit_initial", "continuation_maxit",
    "continuation_function", "continuous_target_method", "continuous_target_n", "donors",
    "matchtype", "trim", "quantify", "use_matcher", "ls_meth", "ridge",
    "remove_constant", "remove_collinear", "method_policy", "method_registry_sha256",
    "predictor_matrix_source", "predictor_policy_sha256", "predictor_edges_sha256",
    "candidate_projection_sha256", "candidate_edge_n", "candidate_predictors_min",
    "candidate_predictors_max", "block_policy", "block_registry_sha256", "block_n",
    "where_policy", "passive_policy", "row_order_rule", "nelson_aalen_variable",
    "nelson_aalen_source", "quickpred_allowed", "runtime_predictor_deletion",
    "fallback_allowed", "r_version", "mice_version", "rng_kind", "chain_count",
    "worker_pool_capacity", "chain_stream_policy", "chain_merge_order", "approval_status",
    "decision_id", "selected_option_id"
  )
}

.mi_recipe_registry_row <- function(owner, projection, method_sha, edge_sha, block_sha, project_root = ".") {
  runtime <- .mi_runtime_versions(project_root)
  row <- data.frame(
    recipe_id = owner$source$mi_recipe_id[[1L]],
    branch = owner$recipe$branch,
    m = as.integer(owner$recipe$m),
    seed = as.integer(owner$recipe$seed),
    maxit_initial = as.integer(owner$recipe$maxit_initial),
    continuation_maxit = paste(as.integer(owner$recipe$continuation_maxit), collapse = "|"),
    continuation_function = owner$recipe$continuation_function,
    continuous_target_method = owner$recipe$continuous_target_method,
    continuous_target_n = as.integer(owner$recipe$continuous_target_n),
    donors = as.integer(owner$recipe$donors),
    matchtype = as.integer(owner$recipe$matchtype),
    trim = as.integer(owner$recipe$trim),
    quantify = isTRUE(owner$recipe$quantify),
    use_matcher = isTRUE(owner$recipe$use_matcher),
    ls_meth = owner$recipe$ls_meth,
    ridge = as.numeric(owner$recipe$ridge),
    remove_constant = isTRUE(owner$recipe$remove_constant),
    remove_collinear = isTRUE(owner$recipe$remove_collinear),
    method_policy = "LOCKED_WORKING_DATA_METHOD_VECTOR",
    method_registry_sha256 = method_sha,
    predictor_matrix_source = "V22_FULL_COHORT_ANALYSIS_SUPPORT_FILTER",
    predictor_policy_sha256 = owner$predictor$policy_subset_sha256,
    predictor_edges_sha256 = edge_sha,
    candidate_projection_sha256 = .mi_projection_identity_v43(projection),
    candidate_edge_n = as.integer(owner$predictor$candidate_edge_n),
    candidate_predictors_min = as.integer(owner$predictor$candidate_predictors_min),
    candidate_predictors_max = as.integer(owner$predictor$candidate_predictors_max),
    block_policy = owner$predictor$block_policy,
    block_registry_sha256 = block_sha,
    block_n = as.integer(owner$recipe$continuous_target_n),
    where_policy = "TARGET_MISSING_CELLS_ONLY",
    passive_policy = "RECALCULATE_AFTER_EACH_COMPLETED_DATASET",
    row_order_rule = owner$source$row_order_rule[[1L]],
    nelson_aalen_variable = ".mi_na_all_cause",
    nelson_aalen_source = owner$predictor$nelson_aalen_source,
    quickpred_allowed = isTRUE(owner$recipe$quickpred_allowed),
    runtime_predictor_deletion = isTRUE(owner$recipe$runtime_predictor_deletion),
    fallback_allowed = isTRUE(owner$recipe$fallback_allowed),
    r_version = runtime$r_version,
    mice_version = runtime$mice_version,
    rng_kind = runtime$rng_kind,
    chain_count = as.integer(owner$recipe$chain_count),
    worker_pool_capacity = as.integer(owner$recipe$worker_pool_capacity),
    chain_stream_policy = owner$recipe$chain_stream_policy,
    chain_merge_order = owner$recipe$chain_merge_order,
    approval_status = "HUMAN_APPROVED_COMPILED_PROJECTION",
    decision_id = owner$predictor$decision_id,
    selected_option_id = owner$predictor$selected_option_id,
    stringsAsFactors = FALSE, check.names = FALSE
  )
  row[.mi_recipe_registry_fields()]
}

.mi_write_csv_atomic <- function(data, path) {
  directory <- dirname(path)
  if (!dir.exists(directory)) dir.create(directory, recursive = TRUE, showWarnings = FALSE)
  temporary <- tempfile(pattern = paste0(".", basename(path), "."), tmpdir = directory)
  on.exit(if (file.exists(temporary)) unlink(temporary), add = TRUE)
  # 中文备注：写出由 active owner 确定性编译的 CSV 投影，不写患者级数据。
  utils::write.csv(data, temporary, row.names = FALSE, na = "")
  if (!file.rename(temporary, path)) .mi_stop("MI_PROJECTION_ATOMIC_RENAME_FAILED", basename(path))
  invisible(path)
}

write_mi_recipe_projection_v43 <- function(project_root = ".", output_config_dir = file.path(project_root, "config")) {
  owner <- read_mi_contract_v43(project_root)
  if (!exists("read_source_column_mapping_registry", mode = "function")) {
    source(file.path(project_root, "R", "source_input_adapter.R"))
  }
  mapping <- read_source_column_mapping_registry(project_root)
  projection <- compile_mi_projection_v43(project_root, owner, mapping)
  dir.create(output_config_dir, recursive = TRUE, showWarnings = FALSE)
  method_path <- file.path(output_config_dir, "source_mi_method_registry.csv")
  edge_path <- file.path(output_config_dir, "source_mi_predictor_edges.csv")
  block_path <- file.path(output_config_dir, "source_mi_block_registry.csv")
  recipe_path <- file.path(output_config_dir, "source_mi_recipe_registry.csv")
  .mi_write_csv_atomic(projection$method_registry, method_path)
  .mi_write_csv_atomic(projection$predictor_edges, edge_path)
  .mi_write_csv_atomic(projection$block_registry, block_path)
  recipe <- .mi_recipe_registry_row(
    owner, projection,
    method_sha = .mi_sha256_file(method_path),
    edge_sha = .mi_sha256_file(edge_path),
    block_sha = .mi_sha256_file(block_path), project_root = project_root
  )
  .mi_write_csv_atomic(recipe, recipe_path)
  invisible(c(recipe_path, method_path, edge_path, block_path))
}

load_compiled_mi_recipe_v43 <- function(project_root = ".", canonical_names) {
  owner <- read_mi_contract_v43(project_root)
  if (!exists("read_source_column_mapping_registry", mode = "function")) {
    source(file.path(project_root, "R", "source_input_adapter.R"))
  }
  mapping <- read_source_column_mapping_registry(project_root)
  if (!identical(canonical_names, mapping$target_name)) .mi_stop("MI_CANONICAL_NAME_ORDER_MISMATCH")
  config <- file.path(project_root, "config")
  paths <- c(
    recipe = file.path(config, "source_mi_recipe_registry.csv"),
    method = file.path(config, "source_mi_method_registry.csv"),
    edges = file.path(config, "source_mi_predictor_edges.csv"),
    blocks = file.path(config, "source_mi_block_registry.csv")
  )
  recipe <- .mi_read_csv(paths[["recipe"]])
  method <- .mi_read_csv(paths[["method"]])
  edges <- .mi_read_csv(paths[["edges"]])
  blocks <- .mi_read_csv(paths[["blocks"]])
  if (nrow(recipe) != 1L || !identical(names(recipe), .mi_recipe_registry_fields())) {
    .mi_stop("MI_RECIPE_PROJECTION_SCHEMA_INVALID")
  }
  if (!identical(recipe$method_registry_sha256[[1L]], .mi_sha256_file(paths[["method"]])) ||
      !identical(recipe$predictor_edges_sha256[[1L]], .mi_sha256_file(paths[["edges"]])) ||
      !identical(recipe$block_registry_sha256[[1L]], .mi_sha256_file(paths[["blocks"]]))) {
    .mi_stop("MI_PROJECTION_SHA256_MISMATCH")
  }
  expected_projection <- compile_mi_projection_v43(project_root, owner, mapping)
  observed_projection <- list(
    target_names = expected_projection$target_names,
    working_names = expected_projection$working_names,
    method_registry = method,
    block_registry = blocks,
    predictor_edges = edges
  )
  validate_mi_projection_v43(observed_projection, owner, mapping)
  expected_recipe <- .mi_recipe_registry_row(
    owner, expected_projection,
    method_sha = .mi_sha256_file(paths[["method"]]),
    edge_sha = .mi_sha256_file(paths[["edges"]]),
    block_sha = .mi_sha256_file(paths[["blocks"]]), project_root = project_root
  )
  if (!identical(recipe, expected_recipe)) .mi_stop("MI_RECIPE_PROJECTION_OWNER_MISMATCH")
  list(recipe = recipe, projection = observed_projection, owner = owner, mapping = mapping)
}
