# v4.3 最小控制 kernel：单一 RUN_STATE、非阻塞 lease、CAS、hash chain 和内容寻址事件。

.control_stop <- function(code, detail = "") {
  message <- if (nzchar(detail)) paste(code, detail, sep = ": ") else code
  stop(message, call. = FALSE)
}

.canonicalize_json_value <- function(value) {
  if (is.data.frame(value)) {
    return(lapply(seq_len(nrow(value)), function(index) {
      .canonicalize_json_value(as.list(value[index, , drop = FALSE]))
    }))
  }
  if (is.list(value)) {
    if (!is.null(names(value))) value <- value[order(names(value))]
    return(lapply(value, .canonicalize_json_value))
  }
  if (!is.null(names(value))) {
    value <- as.list(value[order(names(value))])
    return(lapply(value, .canonicalize_json_value))
  }
  value
}

canonical_json <- function(value) {
  # 加载 JSON 包并生成唯一规范序列化。
  if (!requireNamespace("jsonlite", quietly = TRUE)) .control_stop("CONTROL_DEPENDENCY_MISSING", "jsonlite")
  as.character(jsonlite::toJSON(
    .canonicalize_json_value(value),
    auto_unbox = TRUE,
    null = "null",
    na = "null",
    digits = 17,
    pretty = FALSE
  ))
}

.control_sha256_text <- function(text) {
  # 加载摘要包并计算规范文本 SHA-256。
  if (!requireNamespace("digest", quietly = TRUE)) .control_stop("CONTROL_DEPENDENCY_MISSING", "digest")
  digest::digest(enc2utf8(text), algo = "sha256", serialize = FALSE)
}

.control_sync_file <- function(path) {
  sync <- Sys.which("sync")
  if (!nzchar(sync)) .control_stop("CONTROL_FSYNC_UNAVAILABLE")
  args <- if (identical(Sys.info()[["sysname"]], "Linux")) c("-f", path) else character()
  status <- suppressWarnings(system2(sync, args = args, stdout = FALSE, stderr = FALSE))
  if (!identical(as.integer(status), 0L)) .control_stop("CONTROL_FSYNC_FAILED")
  invisible(TRUE)
}

.control_write_atomic <- function(path, text, mode = "0600") {
  parent <- dirname(path)
  dir.create(parent, recursive = TRUE, showWarnings = FALSE, mode = "0700")
  temporary <- tempfile(pattern = paste0(".", basename(path), "."), tmpdir = parent)
  on.exit(if (file.exists(temporary)) unlink(temporary), add = TRUE)
  connection <- file(temporary, open = "wb")
  writeBin(charToRaw(enc2utf8(text)), connection)
  flush(connection)
  close(connection)
  .control_sync_file(temporary)
  invisible(Sys.chmod(temporary, mode = mode, use_umask = FALSE))
  # 原子替换唯一控制文件，避免暴露部分 JSON。
  if (!file.rename(temporary, path)) .control_stop("CONTROL_ATOMIC_RENAME_FAILED", basename(path))
  .control_sync_file(path)
  invisible(path)
}

.control_state_fields <- function() {
  c(
    "schema_version", "run_id", "revision", "git_commit", "git_tree",
    "execution_profile", "active_stage", "active_gate", "active_task",
    "primary_next_action", "active_transaction_pointer", "source_epoch",
    "science_epoch", "execution_epoch", "runtime_epoch", "publication_epoch",
    "current_contract_identity", "current_input_identity", "current_output_identity",
    "active_conflict_id", "active_blocker_id", "current_repair_signature",
    "current_repair_attempt", "last_terminal_envelope", "previous_state_sha256",
    "state_sha256"
  )
}

.control_is_sha256 <- function(value, allow_empty = FALSE) {
  is.character(value) && length(value) == 1L && !is.na(value) &&
    ((allow_empty && !nzchar(value)) || grepl("^[0-9a-f]{64}$", value))
}

compute_run_state_sha256 <- function(state) {
  payload <- state
  payload$state_sha256 <- NULL
  .control_sha256_text(canonical_json(payload))
}

.validate_run_state <- function(state) {
  if (!is.list(state) || !identical(sort(names(state)), sort(.control_state_fields()))) {
    .control_stop("CONTROL_STATE_SCHEMA_INVALID")
  }
  for (field in c("source_epoch", "science_epoch", "execution_epoch", "runtime_epoch", "publication_epoch", "previous_state_sha256")) {
    if (!.control_is_sha256(state[[field]])) .control_stop("CONTROL_STATE_SHA_FIELD_INVALID", field)
  }
  if (!is.character(state$run_id) || length(state$run_id) != 1L || !nzchar(state$run_id) ||
      !identical(state$revision, "v4.3-r00") ||
      !is.character(state$git_commit) || !grepl("^[0-9a-f]{40}$", state$git_commit) ||
      !is.character(state$git_tree) || !grepl("^[0-9a-f]{40}$", state$git_tree) ||
      !state$execution_profile %in% c("build_validation", "production", "release_only")) {
    .control_stop("CONTROL_STATE_IDENTITY_INVALID")
  }
  for (field in c("current_contract_identity", "current_input_identity", "current_output_identity", "active_conflict_id", "active_blocker_id", "current_repair_signature")) {
    if (!.control_is_sha256(state[[field]], allow_empty = TRUE)) .control_stop("CONTROL_STATE_SHA_FIELD_INVALID", field)
  }
  if (!is.numeric(state$current_repair_attempt) || length(state$current_repair_attempt) != 1L ||
      is.na(state$current_repair_attempt) || state$current_repair_attempt < 0 ||
      state$current_repair_attempt != floor(state$current_repair_attempt)) {
    .control_stop("CONTROL_REPAIR_ATTEMPT_INVALID")
  }
  expected <- compute_run_state_sha256(state)
  if (!identical(state$state_sha256, expected)) .control_stop("CONTROL_STATE_HASH_MISMATCH")
  invisible(TRUE)
}

.control_path <- function(run_root) file.path(run_root, "control", "RUN_STATE.json")

read_run_state <- function(run_root) {
  path <- .control_path(run_root)
  if (!file.exists(path)) .control_stop("CONTROL_STATE_MISSING")
  if (file.info(path)$size > 32768L) .control_stop("CONTROL_STATE_TOO_LARGE")
  # 加载 JSON 包并读取唯一 mutable current-state。
  if (!requireNamespace("jsonlite", quietly = TRUE)) .control_stop("CONTROL_DEPENDENCY_MISSING", "jsonlite")
  state <- jsonlite::read_json(path, simplifyVector = TRUE)
  .validate_run_state(state)
  state
}

.acquire_control_lease <- function(run_root) {
  control_dir <- file.path(run_root, "control")
  dir.create(control_dir, recursive = TRUE, showWarnings = FALSE, mode = "0700")
  lease <- file.path(control_dir, "RUN_STATE.lease")
  acquired <- suppressWarnings(dir.create(lease, showWarnings = FALSE, mode = "0700"))
  if (!isTRUE(acquired)) .control_stop("CONTROL_LEASE_BUSY")
  lease
}

.write_event_envelope <- function(run_root, event) {
  text <- canonical_json(event)
  if (nchar(text, type = "bytes") > 32768L) .control_stop("CONTROL_EVENT_TOO_LARGE")
  sha <- .control_sha256_text(text)
  relative <- file.path("control", "events", paste0(sha, ".json"))
  path <- file.path(run_root, relative)
  if (file.exists(path)) {
    observed <- paste(readLines(path, warn = FALSE), collapse = "\n")
    if (!identical(observed, text)) .control_stop("CONTROL_EVENT_HASH_COLLISION")
  } else {
    # 写入不可变、内容寻址的事件信封。
    .control_write_atomic(path, text, mode = "0600")
  }
  list(relative_path = relative, sha256 = sha)
}

initialize_run_state <- function(
    run_root, run_id, revision, git_commit, git_tree, execution_profile,
    epochs, primary_next_action) {
  if (file.exists(.control_path(run_root))) .control_stop("CONTROL_STATE_ALREADY_EXISTS")
  if (!identical(sort(names(epochs)), sort(c("source", "science", "execution", "runtime", "publication"))) ||
      any(!vapply(epochs, .control_is_sha256, logical(1)))) {
    .control_stop("CONTROL_EPOCHS_INVALID")
  }
  state <- list(
    schema_version = "1.0.0",
    run_id = run_id,
    revision = revision,
    git_commit = git_commit,
    git_tree = git_tree,
    execution_profile = execution_profile,
    active_stage = "BOOTSTRAP",
    active_gate = "INITIALIZED",
    active_task = "BOOTSTRAP_READ_ONLY_AUDIT",
    primary_next_action = primary_next_action,
    active_transaction_pointer = "",
    source_epoch = unname(epochs[["source"]]),
    science_epoch = unname(epochs[["science"]]),
    execution_epoch = unname(epochs[["execution"]]),
    runtime_epoch = unname(epochs[["runtime"]]),
    publication_epoch = unname(epochs[["publication"]]),
    current_contract_identity = "",
    current_input_identity = "",
    current_output_identity = "",
    active_conflict_id = "",
    active_blocker_id = "",
    current_repair_signature = "",
    current_repair_attempt = 0L,
    last_terminal_envelope = "",
    previous_state_sha256 = paste(rep("0", 64L), collapse = ""),
    state_sha256 = ""
  )
  state$state_sha256 <- compute_run_state_sha256(state)
  .validate_run_state(state)
  text <- canonical_json(state)
  if (nchar(text, type = "bytes") > 32768L) .control_stop("CONTROL_STATE_TOO_LARGE")
  # 原子写入初始 RUN_STATE。
  .control_write_atomic(.control_path(run_root), text, mode = "0600")
  read_run_state(run_root)
}

transition_run_state <- function(
    run_root, expected_state_sha256, updates, event_type, reason_code,
    relative_path = "", artifact_sha256 = "") {
  lease <- .acquire_control_lease(run_root)
  on.exit(unlink(lease, recursive = TRUE), add = TRUE)
  before <- read_run_state(run_root)
  if (!identical(before$state_sha256, expected_state_sha256)) .control_stop("CONTROL_CAS_MISMATCH")
  if (!is.list(updates) || is.null(names(updates)) || any(!nzchar(names(updates)))) .control_stop("CONTROL_UPDATES_INVALID")
  immutable <- c(
    "schema_version", "run_id", "revision", "git_commit", "git_tree",
    "execution_profile", "source_epoch", "science_epoch", "execution_epoch",
    "runtime_epoch", "publication_epoch", "previous_state_sha256", "state_sha256"
  )
  if (any(!names(updates) %in% setdiff(.control_state_fields(), immutable))) .control_stop("CONTROL_UPDATE_FIELD_FORBIDDEN")
  event <- list(
    schema_version = "1.0.0",
    event_type = event_type,
    run_id = before$run_id,
    revision = before$revision,
    state_before_sha256 = before$state_sha256,
    transition_sha256 = .control_sha256_text(canonical_json(updates)),
    reason_code = reason_code,
    relative_path = relative_path,
    artifact_sha256 = artifact_sha256,
    previous_event = before$last_terminal_envelope,
    created_at = format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  )
  event_identity <- .write_event_envelope(run_root, event)
  after <- before
  for (name in names(updates)) after[[name]] <- updates[[name]]
  after$last_terminal_envelope <- event_identity$relative_path
  after$previous_state_sha256 <- before$state_sha256
  after$state_sha256 <- ""
  after$state_sha256 <- compute_run_state_sha256(after)
  .validate_run_state(after)
  text <- canonical_json(after)
  if (nchar(text, type = "bytes") > 32768L) .control_stop("CONTROL_STATE_TOO_LARGE")
  # CAS 成功后原子替换 RUN_STATE。
  .control_write_atomic(.control_path(run_root), text, mode = "0600")
  list(state = read_run_state(run_root), event = event_identity)
}
