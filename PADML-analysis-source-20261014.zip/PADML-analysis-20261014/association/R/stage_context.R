# 阶段上下文：分离只读协议根目录与可写运行目录，并锁定正式 handoff 身份。

.blank_handoff_context <- function() {
  list(
    handoff_id = "",
    approval_id = "",
    source_id = "",
    source_epoch = "",
    handoff_sha256 = "",
    expected_source_sha256 = "",
    expected_patient_order_sha256 = "",
    expected_mids_sha256 = "",
    expected_completed_sha256 = "",
    expected_factor_sha256 = "",
    expected_schema_sha256 = "",
    expected_core_column_n = NA_integer_,
    expected_semantic_status = "",
    protocol_revision = "",
    handoff_identity_sha256 = ""
  )
}

.blank_stage_lineage_context <- function() {
  list(
    stage = "",
    task_id = "",
    consumed_epoch_set = "",
    stage_request_semantic_sha256 = "",
    source_epoch = "",
    science_epoch = "",
    execution_epoch = "",
    runtime_epoch = "",
    publication_epoch = "",
    stage_contract_sha256 = "",
    stage_contract_file_n = NA_integer_,
    input_identity_sha256 = "",
    upstream_artifact_sha256 = "",
    exact_consumer_set_sha256 = "",
    reachable_authority_slice_sha256 = "",
    pre_stage_sentinel_sha256 = "",
    stage_capsule_sha256 = "",
    pre_stage_sentinel = list()
  )
}

.merge_stage_context <- function(base, handoff, lineage) {
  duplicate <- intersect(names(handoff), names(lineage))
  for (name in duplicate) {
    handoff_value <- handoff[[name]]
    lineage_value <- lineage[[name]]
    handoff_empty <- (is.character(handoff_value) && length(handoff_value) == 1L && !nzchar(handoff_value)) ||
      (is.numeric(handoff_value) && length(handoff_value) == 1L && is.na(handoff_value))
    lineage_empty <- (is.character(lineage_value) && length(lineage_value) == 1L && !nzchar(lineage_value)) ||
      (is.numeric(lineage_value) && length(lineage_value) == 1L && is.na(lineage_value))
    if (!handoff_empty && !lineage_empty && !identical(handoff_value, lineage_value)) {
      stop("STAGE_CONTEXT_DUPLICATE_IDENTITY_MISMATCH: ", name, call. = FALSE)
    }
    handoff[[name]] <- NULL
  }
  output <- c(base, handoff, lineage)
  if (anyDuplicated(names(output))) stop("STAGE_CONTEXT_DUPLICATE_FIELD", call. = FALSE)
  output
}

.read_stage_capsule_context <- function(run_root, profile, run_id) {
  path <- trimws(Sys.getenv("AST_ALT_STAGE_CAPSULE", unset = ""))
  expected_sha <- trimws(Sys.getenv("AST_ALT_STAGE_CAPSULE_SHA256", unset = ""))
  expected_stage <- trimws(Sys.getenv("AST_ALT_ACTIVE_STAGE", unset = ""))
  if (!nzchar(path) && !nzchar(expected_sha)) return(.blank_stage_lineage_context())
  if (!nzchar(path) || !grepl("^[0-9a-f]{64}$", expected_sha) || !file.exists(path) ||
      isTRUE(file.info(path)$isdir)) {
    stop("STAGE_CONTEXT_CAPSULE_REFERENCE_INVALID", call. = FALSE)
  }
  run_root_normalized <- normalizePath(run_root, mustWork = TRUE)
  path_normalized <- normalizePath(path, mustWork = TRUE)
  allowed_root <- paste0(
    normalizePath(file.path(run_root_normalized, "control", "capsules"), mustWork = TRUE),
    .Platform$file.sep
  )
  if (!startsWith(path_normalized, allowed_root)) {
    stop("STAGE_CONTEXT_CAPSULE_PATH_OUTSIDE_RUN", call. = FALSE)
  }
  # 加载摘要包与 JSON 包，验证内容寻址 capsule 后再读取阶段身份。
  if (!requireNamespace("digest", quietly = TRUE) || !requireNamespace("jsonlite", quietly = TRUE)) {
    stop("STAGE_CONTEXT_CAPSULE_DEPENDENCY_MISSING", call. = FALSE)
  }
  observed_sha <- digest::digest(file = path_normalized, algo = "sha256", serialize = FALSE)
  if (!identical(observed_sha, expected_sha) || !identical(basename(path_normalized), paste0(expected_sha, ".json"))) {
    stop("STAGE_CONTEXT_CAPSULE_IDENTITY_MISMATCH", call. = FALSE)
  }
  capsule <- jsonlite::read_json(path_normalized, simplifyVector = TRUE)
  lineage_required <- c(
    "protocol_revision", "execution_profile", "consumed_epoch_set",
    "stage_request_semantic_sha256", "source_epoch", "science_epoch", "execution_epoch",
    "runtime_epoch", "publication_epoch", "stage_contract_sha256",
    "stage_contract_file_n", "input_identity_sha256", "upstream_artifact_sha256",
    "exact_consumer_set_sha256", "reachable_authority_slice_sha256",
    "pre_stage_sentinel_sha256"
  )
  if (!is.list(capsule) || !identical(capsule$schema_version, "1.0.0") ||
      !is.character(capsule$stage) || length(capsule$stage) != 1L ||
      !is.character(capsule$task_id) || length(capsule$task_id) != 1L ||
      !identical(sort(names(capsule$lineage)), sort(lineage_required)) ||
      !is.list(capsule$pre_stage_sentinel) ||
      !identical(capsule$lineage$protocol_revision, "v4.3-r00") ||
      !identical(capsule$lineage$execution_profile, profile) ||
      (nzchar(expected_stage) && !identical(capsule$stage, expected_stage)) ||
      !identical(capsule$input_identity, capsule$lineage$input_identity_sha256) ||
      !is.numeric(capsule$lineage$stage_contract_file_n) ||
      length(capsule$lineage$stage_contract_file_n) != 1L ||
      is.na(capsule$lineage$stage_contract_file_n) ||
      capsule$lineage$stage_contract_file_n < 1) {
    stop("STAGE_CONTEXT_CAPSULE_SCHEMA_INVALID", call. = FALSE)
  }
  sha_fields <- setdiff(
    lineage_required,
    c("protocol_revision", "execution_profile", "consumed_epoch_set", "stage_contract_file_n")
  )
  if (any(!vapply(capsule$lineage[sha_fields], function(value) {
    is.character(value) && length(value) == 1L && grepl("^[0-9a-f]{64}$", value)
  }, logical(1)))) {
    stop("STAGE_CONTEXT_CAPSULE_LINEAGE_INVALID", call. = FALSE)
  }
  consumed <- strsplit(capsule$lineage$consumed_epoch_set, "|", fixed = TRUE)[[1L]]
  allowed_epochs <- c("source", "science", "execution", "runtime", "publication")
  if (!length(consumed) || any(!consumed %in% allowed_epochs) || anyDuplicated(consumed)) {
    stop("STAGE_CONTEXT_CAPSULE_CONSUMED_EPOCH_SET_INVALID", call. = FALSE)
  }
  if (!exists("canonical_json", mode = "function")) {
    source(file.path(Sys.getenv("AST_ALT_PROJECT_ROOT", unset = "."), "R", "control_kernel.R"))
  }
  sentinel_sha <- digest::digest(
    enc2utf8(canonical_json(capsule$pre_stage_sentinel)),
    algo = "sha256", serialize = FALSE
  )
  if (!identical(sentinel_sha, capsule$lineage$pre_stage_sentinel_sha256)) {
    stop("STAGE_CONTEXT_CAPSULE_SENTINEL_IDENTITY_MISMATCH", call. = FALSE)
  }
  list(
    stage = capsule$stage,
    task_id = capsule$task_id,
    consumed_epoch_set = capsule$lineage$consumed_epoch_set,
    stage_request_semantic_sha256 = capsule$lineage$stage_request_semantic_sha256,
    source_epoch = capsule$lineage$source_epoch,
    science_epoch = capsule$lineage$science_epoch,
    execution_epoch = capsule$lineage$execution_epoch,
    runtime_epoch = capsule$lineage$runtime_epoch,
    publication_epoch = capsule$lineage$publication_epoch,
    stage_contract_sha256 = capsule$lineage$stage_contract_sha256,
    stage_contract_file_n = as.integer(capsule$lineage$stage_contract_file_n),
    input_identity_sha256 = capsule$lineage$input_identity_sha256,
    upstream_artifact_sha256 = capsule$lineage$upstream_artifact_sha256,
    exact_consumer_set_sha256 = capsule$lineage$exact_consumer_set_sha256,
    reachable_authority_slice_sha256 = capsule$lineage$reachable_authority_slice_sha256,
    pre_stage_sentinel_sha256 = capsule$lineage$pre_stage_sentinel_sha256,
    stage_capsule_sha256 = expected_sha,
    pre_stage_sentinel = capsule$pre_stage_sentinel
  )
}

.stage_handoff_context <- function(profile, project_root) {
  if (!identical(profile, "production")) return(.blank_handoff_context())
  zip_path <- trimws(Sys.getenv("AST_ALT_HANDOFF_ZIP", unset = ""))
  if (!nzchar(zip_path)) stop("HANDOFF_PATH_REQUIRED_FOR_PRODUCTION", call. = FALSE)
  if (!exists("resolve_approved_handoff", mode = "function")) {
    source(file.path(project_root, "R", "data_handoff_engine.R"))
  }
  identity <- resolve_approved_handoff(zip_path, project_root)$identity
  expected <- names(.blank_handoff_context())
  if (!identical(sort(names(identity)), sort(expected))) {
    stop("HANDOFF_CONTEXT_IDENTITY_SCHEMA_INVALID", call. = FALSE)
  }
  source_epoch <- identity$source_epoch
  legacy_missing_source_epoch <- length(source_epoch) == 1L &&
    is.atomic(source_epoch) && is.na(source_epoch[[1L]])
  if (legacy_missing_source_epoch) {
    identity$source_epoch <- ""
  } else if (!is.character(source_epoch) || length(source_epoch) != 1L ||
      (nzchar(source_epoch) && !grepl("^[0-9a-f]{64}$", source_epoch))) {
    stop("HANDOFF_CONTEXT_SOURCE_EPOCH_INVALID", call. = FALSE)
  }
  identity[expected]
}

stage_context <- function() {
  project_root <- Sys.getenv("AST_ALT_PROJECT_ROOT", unset = normalizePath("."))
  run_root <- Sys.getenv("AST_ALT_RUN_ROOT", unset = project_root)
  profile <- Sys.getenv("AST_ALT_EXECUTION_PROFILE", unset = "build_validation")
  run_id <- Sys.getenv("AST_ALT_RUN_ID", unset = paste0(profile, "_", format(Sys.time(), "%Y%m%dT%H%M%S")))
  if (!profile %in% c("build_validation", "production", "release_only")) {
    stop("EXECUTION_PROFILE_INVALID", call. = FALSE)
  }
  project_root <- normalizePath(project_root, mustWork = TRUE)
  base <- list(
    project_root = project_root,
    run_root = normalizePath(run_root, mustWork = FALSE),
    profile = profile,
    run_id = run_id
  )
  handoff <- .stage_handoff_context(profile, project_root)
  lineage <- .read_stage_capsule_context(base$run_root, profile, run_id)
  if (nzchar(lineage$source_epoch) && nzchar(handoff$source_epoch) &&
      !identical(lineage$source_epoch, handoff$source_epoch)) {
    stop("STAGE_CONTEXT_SOURCE_EPOCH_MISMATCH", call. = FALSE)
  }
  .merge_stage_context(base, handoff, lineage)
}

stage_work_dir <- function(stage, context = stage_context()) {
  path <- file.path(context$run_root, "stage_work", stage)
  dir.create(path, recursive = TRUE, showWarnings = FALSE)
  path
}
