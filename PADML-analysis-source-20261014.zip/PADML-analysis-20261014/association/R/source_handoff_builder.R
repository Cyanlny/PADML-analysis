# v4.3 U05 builder：只将已通过 U04 的同一 formal MICE 链封装为待外部批准的受限 handoff。

.source_handoff_stop <- function(code, detail = "") {
  message <- if (nzchar(detail)) paste(code, detail, sep = ": ") else code
  stop(message, call. = FALSE)
}

.source_handoff_require <- function(project_root = ".") {
  dependencies <- list(
    "control_kernel.R" = "canonical_json",
    "authorization_engine.R" = "validate_formal_mice_authorization_v43",
    "source_input_adapter.R" = "validate_source_candidate_receipt",
    "mi_recipe_engine.R" = "compile_mi_projection_v43",
    "mi_transaction_engine.R" = "inspect_mi_transaction_v43",
    "formal_mice_engine.R" = "build_mi_transaction_request_v43",
    "mi_qc_engine_v43.R" = "evaluate_formal_mi_qc_v43",
    "data_handoff_engine.R" = c(
      "validate_completed_analysis_list", "inspect_handoff_candidate_zip_structure"
    )
  )
  for (file in names(dependencies)) {
    required <- dependencies[[file]]
    if (any(!vapply(required, exists, logical(1), mode = "function"))) {
      path <- file.path(project_root, "R", file)
      if (!file.exists(path)) .source_handoff_stop("SOURCE_HANDOFF_DEPENDENCY_MISSING", file)
      source(path)
    }
  }
  invisible(TRUE)
}

.source_handoff_sha256_file <- function(path) {
  # 中文备注：加载摘要包以绑定 U05 输入与候选归档的精确字节身份。
  if (!requireNamespace("digest", quietly = TRUE)) {
    .source_handoff_stop("SOURCE_HANDOFF_DEPENDENCY_MISSING", "digest")
  }
  digest::digest(file = path, algo = "sha256", serialize = FALSE)
}

.source_handoff_sha256_object <- function(object) {
  # 中文备注：加载摘要包，只保留患者级对象的不可逆内容身份。
  if (!requireNamespace("digest", quietly = TRUE)) {
    .source_handoff_stop("SOURCE_HANDOFF_DEPENDENCY_MISSING", "digest")
  }
  digest::digest(object, algo = "sha256", serialize = TRUE)
}

.source_handoff_is_sha256 <- function(value) {
  is.character(value) && length(value) == 1L && !is.na(value) &&
    grepl("^[0-9a-f]{64}$", value)
}

.source_handoff_write_json <- function(object, path) {
  # 中文备注：以 canonical JSON 原子写入不含患者值的 U05 身份收据。
  .control_write_atomic(path, canonical_json(object), mode = "0600")
}

.source_handoff_execution_identity <- function(project_root, relative_paths) {
  relative_paths <- sort(unique(relative_paths))
  if (any(grepl("^/|^[A-Za-z]:[/\\\\]|(^|/)\\.\\.(/|$)", relative_paths, perl = TRUE))) {
    .source_handoff_stop("SOURCE_HANDOFF_EXECUTION_IDENTITY_PATH_INVALID")
  }
  paths <- file.path(project_root, relative_paths)
  if (any(!file.exists(paths)) || any(file.info(paths)$isdir %in% TRUE)) {
    .source_handoff_stop("SOURCE_HANDOFF_EXECUTION_IDENTITY_FILE_MISSING")
  }
  hashes <- vapply(paths, .source_handoff_sha256_file, character(1))
  .source_sha256_text(paste(relative_paths, hashes, sep = "\t"))
}

.source_handoff_u05_execution_identity <- function(project_root) {
  .source_handoff_execution_identity(project_root, c(
    "R/source_handoff_builder.R", "R/data_handoff_engine.R",
    "schemas/source_candidate_receipt_schema.json",
    "schemas/mi_qc_receipt_schema_v43.json",
    "schemas/source_mi_recipe_receipt_schema_v43.json",
    "schemas/completed_data_semantic_identity_receipt_schema_v43.json",
    "schemas/serialization_identity_receipt_schema_v43.json",
    "schemas/frozen_handoff_receipt_schema_v43.json"
  ))
}

.source_handoff_u04_execution_identity <- function(project_root) {
  .source_handoff_execution_identity(project_root, c(
    "R/mi_qc_engine_v43.R", "schemas/mi_qc_receipt_schema_v43.json"
  ))
}

.source_handoff_split_levels <- function(value) {
  if (length(value) != 1L || is.na(value) || !nzchar(value)) return(character())
  strsplit(value, "|", fixed = TRUE)[[1L]]
}

build_handoff_role_registry_v43 <- function(mapping, formula_registry, projection) {
  required_mapping <- c(
    "target_position", "target_name", "source_name", "mapping_kind", "expected_r_class",
    "ordered", "levels", "nullable", "decision_source"
  )
  required_formula <- c("execution_order", "target_name", "operation", "source_names", "denominator_rule")
  if (!is.data.frame(mapping) || !identical(names(mapping), required_mapping) ||
      nrow(mapping) != 123L || !identical(as.integer(mapping$target_position), seq_len(123L)) ||
      !is.data.frame(formula_registry) || !identical(names(formula_registry), required_formula) ||
      !is.list(projection) || is.null(projection$target_names) || is.null(projection$predictor_edges)) {
    .source_handoff_stop("SOURCE_HANDOFF_ROLE_INPUT_INVALID")
  }
  variables <- mapping$target_name
  targets <- as.character(projection$target_names)
  predictors <- unique(as.character(projection$predictor_edges$predictor))
  outcomes <- c(
    "All_Cause_Death", "Death_Followup_months", "MACE", "MACE_Followup_months",
    "CV_CBV_Death"
  )
  roles <- ifelse(
    variables == "Patient_ID", "PATIENT_IDENTIFIER",
    ifelse(
      variables %in% targets, "MI_TARGET",
      ifelse(
        variables == "AST_ALT", "PRIMARY_EXPOSURE",
        ifelse(
          variables %in% outcomes, "OUTCOME_OR_FOLLOWUP",
          ifelse(mapping$mapping_kind == "PASSIVE_FORMULA", "PASSIVE_RECALCULATED",
            ifelse(variables %in% predictors, "BASELINE_PREDICTOR", "CANONICAL_ANALYSIS_VARIABLE")
          )
        )
      )
    )
  )
  mice_role <- ifelse(
    variables %in% targets, "IMPUTED_TARGET",
    ifelse(variables %in% predictors, "PREDICTOR_ONLY", "NOT_USED_BY_MICE")
  )
  formula_index <- match(variables, formula_registry$target_name)
  formula_id <- ifelse(
    is.na(formula_index), "",
    sprintf("PASSIVE_%03d", as.integer(formula_registry$execution_order[formula_index]))
  )
  formula_sha <- vapply(seq_along(variables), function(index) {
    position <- formula_index[[index]]
    if (is.na(position)) return("")
    .source_sha256_text(c(
      formula_registry$target_name[[position]], formula_registry$operation[[position]],
      formula_registry$source_names[[position]], formula_registry$denominator_rule[[position]]
    ))
  }, character(1))
  data.frame(
    variable = variables,
    column_position = as.integer(mapping$target_position),
    role = roles,
    supplemental_only = FALSE,
    formula_id = formula_id,
    formula_sha = formula_sha,
    canonical_type = mapping$expected_r_class,
    factor_levels = ifelse(is.na(mapping$levels), "", mapping$levels),
    mice_role = mice_role,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

build_handoff_factor_registry_v43 <- function(mapping, projection) {
  if (!is.list(projection) || is.null(projection$target_names) || is.null(projection$predictor_edges)) {
    .source_handoff_stop("SOURCE_HANDOFF_FACTOR_PROJECTION_INVALID")
  }
  factor_rows <- mapping$expected_r_class %in% c("factor", "ordered_factor")
  selected <- mapping[factor_rows, , drop = FALSE]
  if (!nrow(selected) || any(is.na(selected$levels) | !nzchar(selected$levels))) {
    .source_handoff_stop("SOURCE_HANDOFF_FACTOR_MAPPING_INVALID")
  }
  reference <- vapply(selected$levels, function(value) .source_handoff_split_levels(value)[[1L]], character(1))
  dictionary_hash <- vapply(seq_len(nrow(selected)), function(index) {
    .source_sha256_text(c(
      selected$target_name[[index]], selected$expected_r_class[[index]],
      as.character(selected$ordered[[index]]), selected$levels[[index]]
    ))
  }, character(1))
  targets <- as.character(projection$target_names)
  predictors <- unique(as.character(projection$predictor_edges$predictor))
  mice_role <- ifelse(
    selected$target_name %in% targets, "IMPUTED_TARGET",
    ifelse(selected$target_name %in% predictors, "PREDICTOR_ONLY", "NOT_USED_BY_MICE")
  )
  data.frame(
    variable = selected$target_name,
    rds_storage_type = selected$expected_r_class,
    csv_storage_mode = "LABEL",
    csv_value_domain = selected$levels,
    ordered = selected$ordered,
    levels = selected$levels,
    labels = selected$levels,
    reference_level = reference,
    reconstruction_rule = "factor(value, levels=locked_levels, ordered=locked_order)",
    mice_role = mice_role,
    dictionary_hash = dictionary_hash,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

.source_handoff_validate_qc_pass <- function(qc_receipt, project_root) {
  validate_mi_qc_receipt_v43(qc_receipt, project_root)
  zero_fields <- c(
    "missing_diagnostic_n", "nonfinite_diagnostic_n", "psrf_exceed_n",
    "lag1_review_n", "standardized_shift_review_n", "logged_event_n",
    "hard_fail_n", "observed_cell_change_n",
    "invalid_pmm_donor_n", "remaining_missing_n", "nonfinite_completed_n"
  )
  if (!identical(qc_receipt$status, "PASS") ||
      any(vapply(qc_receipt[zero_fields], function(value) as.integer(value) != 0L, logical(1)))) {
    .source_handoff_stop("SOURCE_HANDOFF_QC_NOT_SEALABLE", qc_receipt$status)
  }
  invisible(TRUE)
}

.source_handoff_validate_completed <- function(canonical, completed, mapping, formula_registry, projection) {
  if (!is.data.frame(canonical) || !identical(names(canonical), mapping$target_name) ||
      length(completed) != 20L || any(!vapply(completed, is.data.frame, logical(1)))) {
    .source_handoff_stop("SOURCE_HANDOFF_COMPLETED_INPUT_INVALID")
  }
  structure_qc <- evaluate_completed_structure_v43(canonical, completed, 20L)
  observed_qc <- evaluate_observed_cell_identity_v43(canonical, completed)
  donor_qc <- evaluate_pmm_donor_membership_v43(canonical, completed, projection$target_names)
  passive_ok <- vapply(completed, function(data) {
    recalculated <- recalculate_source_passive_variables(data, formula_registry)
    identical(recalculated[mapping$target_name], data[mapping$target_name])
  }, logical(1))
  if (any(structure_qc$status != "PASS") || any(observed_qc$status != "PASS") ||
      any(donor_qc$status != "PASS") || !all(passive_ok)) {
    .source_handoff_stop("SOURCE_HANDOFF_COMPLETED_QC_FAILED")
  }
  role_registry <- build_handoff_role_registry_v43(mapping, formula_registry, projection)
  factor_registry <- build_handoff_factor_registry_v43(mapping, projection)
  validate_completed_analysis_list(
    completed, expected_m = 20L, expected_column_n = 123L,
    role_registry = role_registry, factor_registry = factor_registry
  )
  list(
    structure_qc = structure_qc,
    observed_qc = observed_qc,
    donor_qc = donor_qc,
    role_registry = role_registry,
    factor_registry = factor_registry
  )
}

.source_handoff_validate_lineage <- function(
    source_receipt, canonical, request, checkpoint, mids_path, qc_receipt,
    mapping, projection, owner, project_root) {
  validate_source_candidate_receipt(source_receipt)
  validate_mi_transaction_request_v43(request)
  .source_handoff_validate_qc_pass(qc_receipt, project_root)
  required_checkpoint <- c(
    "request_sha256", "iteration", "checkpoint_sha256", "object_sha256",
    "object_class", "predictor_matrix_sha256", "predictor_edge_n",
    "continuation_count", "created_at"
  )
  if (!is.list(checkpoint) || length(setdiff(required_checkpoint, names(checkpoint))) ||
      !file.exists(mids_path) || isTRUE(file.info(mids_path)$isdir)) {
    .source_handoff_stop("SOURCE_HANDOFF_CHECKPOINT_INPUT_INVALID")
  }
  mids_sha <- .source_handoff_sha256_file(mids_path)
  patient_sha <- .source_sha256_text(as.character(canonical$Patient_ID))
  schema_sha <- .source_sha256_text(paste(
    names(canonical),
    vapply(canonical, function(value) paste(class(value), collapse = "|"), character(1)),
    sep = "\t"
  ))
  checks <- c(
    identical(request$source_id, source_receipt$source_id),
    identical(request$source_epoch, source_receipt$source_epoch),
    identical(request$source_sha256, source_receipt$source_sha256),
    identical(request$patient_order_sha256, source_receipt$patient_order_sha256),
    identical(request$canonical_schema_sha256, source_receipt$canonical_schema_sha256),
    identical(patient_sha, source_receipt$patient_order_sha256),
    identical(schema_sha, source_receipt$canonical_schema_sha256),
    identical(checkpoint$request_sha256, request$request_sha256),
    identical(qc_receipt$request_sha256, request$request_sha256),
    identical(qc_receipt$source_epoch, request$source_epoch),
    identical(qc_receipt$recipe_epoch, request$recipe_epoch),
    identical(as.integer(checkpoint$iteration), as.integer(qc_receipt$final_iteration)),
    identical(as.integer(checkpoint$continuation_count), as.integer(qc_receipt$continuation_count)),
    identical(checkpoint$object_sha256, mids_sha),
    identical(checkpoint$object_class, "mids"),
    .source_handoff_is_sha256(checkpoint$checkpoint_sha256)
  )
  if (!all(checks)) .source_handoff_stop("SOURCE_HANDOFF_LINEAGE_IDENTITY_MISMATCH")
  # 中文备注：读取已经通过 checkpoint 完整性校验的 formal mids，不从 completed data 重建 .imp=0。
  mids_object <- readRDS(mids_path)
  expected_working_names <- c(mapping$target_name, ".mi_na_all_cause")
  expected_matrix <- .mi_actual_predictor_matrix_v43(
    mids_object$data, projection, owner, mapping
  )
  matrix_sha256 <- .mi_named_matrix_identity_v43(expected_matrix)
  matrix_edge_n <- as.integer(sum(expected_matrix))
  if (!inherits(mids_object, "mids") || !is.data.frame(mids_object$data) ||
      !identical(names(mids_object$data), expected_working_names) ||
      !identical(as.integer(mids_object$m), 20L) ||
      !identical(as.integer(mids_object$iteration), as.integer(checkpoint$iteration)) ||
      !identical(mids_object$data[mapping$target_name], canonical) ||
      !identical(mids_object$predictorMatrix, expected_matrix) ||
      !identical(checkpoint$predictor_matrix_sha256, matrix_sha256) ||
      !identical(as.integer(checkpoint$predictor_edge_n), matrix_edge_n)) {
    .source_handoff_stop("SOURCE_HANDOFF_MIDS_IDENTITY_MISMATCH")
  }
  list(
    mids_object = mids_object,
    mids_sha256 = mids_sha,
    predictor_matrix_sha256 = matrix_sha256,
    predictor_edge_n = matrix_edge_n,
    patient_order_sha256 = patient_sha,
    canonical_schema_sha256 = schema_sha
  )
}

.source_handoff_readiness <- function() {
  data.frame(
    domain = c("cox", "sensitivity"),
    completed_list_loadable = TRUE,
    dictionary_resolves = TRUE,
    exclusion_or_provenance_present = TRUE,
    model_run_n = 0L,
    ready = TRUE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

.source_handoff_write_package <- function(
    package_dir, source_receipt, request, checkpoint, qc_receipt, mids_path,
    completed, mapping, formula_registry, projection, approval_id, lineage, completed_qc,
    project_root) {
  dir.create(package_dir, recursive = TRUE, showWarnings = FALSE, mode = "0700")
  mids_target <- file.path(package_dir, "original_frozen_mids.rds")
  completed_target <- file.path(package_dir, "original_frozen_completed_analysis_list.rds")
  # 中文备注：复制已验证的 formal mids checkpoint 字节，禁止重新 complete 后替代冻结 mids。
  if (!file.copy(mids_path, mids_target, overwrite = FALSE, copy.mode = TRUE)) {
    .source_handoff_stop("SOURCE_HANDOFF_MIDS_COPY_FAILED")
  }
  # 中文备注：保存 U04 已重算 passive variables 的20套 completed analysis list。
  saveRDS(completed, completed_target, version = 3, compress = "gzip")
  mids_sha <- .source_handoff_sha256_file(mids_target)
  completed_sha <- .source_handoff_sha256_file(completed_target)

  role_path <- file.path(package_dir, "core_column_role_registry.csv")
  factor_path <- file.path(package_dir, "factor_level_registry.csv")
  readiness_path <- file.path(package_dir, "DOWNSTREAM_READINESS_GATE.csv")
  # 中文备注：写出123列 canonical role registry，供下游按列位和语义验证。
  utils::write.csv(completed_qc$role_registry, role_path, row.names = FALSE, na = "")
  # 中文备注：写出锁定 factor level registry，禁止运行时推断或改 reference。
  utils::write.csv(completed_qc$factor_registry, factor_path, row.names = FALSE, na = "")
  # 中文备注：写出仅表示 handoff 技术就绪的下游 gate；外部批准仍由 registry 单独控制。
  utils::write.csv(.source_handoff_readiness(), readiness_path, row.names = FALSE, na = "")
  factor_sha <- .source_handoff_sha256_file(factor_path)

  completed_hashes <- vapply(completed, .source_handoff_sha256_object, character(1))
  semantic_receipt <- list(
    schema_version = "1.0.0",
    status = "FORMAL_MICE_FROZEN",
    source_id = source_receipt$source_id,
    source_epoch = source_receipt$source_epoch,
    request_sha256 = request$request_sha256,
    final_checkpoint_sha256 = checkpoint$checkpoint_sha256,
    source_mids_sha = mids_sha,
    completed_list_sha256 = completed_sha,
    factor_level_sha = factor_sha,
    passive_formula_registry_sha256 = source_receipt$passive_formula_registry_sha256,
    patient_order_sha256 = lineage$patient_order_sha256,
    canonical_schema_sha256 = lineage$canonical_schema_sha256,
    canonical_column_order_sha256 = .source_sha256_text(mapping$target_name),
    completed_dataset_sha256 = unname(completed_hashes),
    m = 20L,
    core_completed_column_n = 123L,
    working_mids_column_n = 124L,
    contains_patient_values = FALSE
  )
  serialization_receipt <- list(
    schema_version = "1.0.0",
    status = "PASS",
    source_mids_sha256 = mids_sha,
    completed_list_sha256 = completed_sha,
    m = 20L,
    final_iteration = as.integer(checkpoint$iteration),
    continuation_count = as.integer(checkpoint$continuation_count),
    core_completed_column_n = 123L,
    working_mids_column_n = 124L,
    imp0_origin = "original_frozen_mids.rds$data",
    completed_origin = "U04_COMPLETE_AND_RECALCULATE",
    imp0_matches_canonical_pre_mi = TRUE,
    long_imp1_20_match_completed_list = TRUE,
    factor_identity_verified = TRUE,
    patient_order_verified = TRUE,
    passive_recalculation_verified = TRUE,
    contains_patient_values = FALSE
  )
  recipe_receipt <- list(
    schema_version = "1.0.0",
    status = "PASS",
    source_id = source_receipt$source_id,
    source_epoch = source_receipt$source_epoch,
    request_sha256 = request$request_sha256,
    recipe_id = request$recipe_id,
    recipe_epoch = request$recipe_epoch,
    recipe_projection_sha256 = request$recipe_projection_sha256,
    predictor_policy_sha256 = request$predictor_policy_sha256,
    candidate_projection_sha256 = request$candidate_projection_sha256,
    candidate_edge_n = as.integer(request$candidate_edge_n),
    predictor_matrix_sha256 = lineage$predictor_matrix_sha256,
    predictor_edge_n = as.integer(lineage$predictor_edge_n),
    runtime_epoch = request$runtime_epoch,
    runtime_identity_sha256 = request$runtime_identity_sha256,
    selected_option_id = "V22_FULL_COHORT_ANALYSIS",
    m = as.integer(request$m),
    seed = as.integer(request$seed),
    maxit_initial = as.integer(request$maxit_initial),
    continuation_maxit = request$continuation_maxit,
    scientific_generation_id = request$scientific_generation_id,
    rng_kind = request$rng_kind,
    chain_count = as.integer(request$chain_count),
    worker_pool_capacity = as.integer(request$worker_pool_capacity),
    chain_stream_policy = request$chain_stream_policy,
    chain_merge_order = request$chain_merge_order,
    final_iteration = as.integer(checkpoint$iteration),
    continuation_count = as.integer(checkpoint$continuation_count),
    target_n = length(projection$target_names),
    core_completed_column_n = 123L,
    working_mids_column_n = 124L,
    contains_patient_values = FALSE
  )
  frozen_receipt <- list(
    schema_version = "1.0.0",
    status = "PASS",
    seal_scope = "CANDIDATE_BYTES_ONLY",
    registry_approval_status = "CANDIDATE_PENDING_APPROVAL",
    approval_id = approval_id,
    approval_basis = "AUTO_GATE_PASS",
    source_id = source_receipt$source_id,
    source_epoch = source_receipt$source_epoch,
    request_sha256 = request$request_sha256,
    final_checkpoint_sha256 = checkpoint$checkpoint_sha256,
    mi_qc_receipt_sha256 = qc_receipt$receipt_sha256,
    mids_sha256 = mids_sha,
    completed_list_sha256 = completed_sha,
    factor_level_sha256 = factor_sha,
    canonical_schema_sha256 = lineage$canonical_schema_sha256,
    u05_execution_identity_sha256 = .source_handoff_u05_execution_identity(project_root),
    created_at = qc_receipt$created_at,
    contains_patient_values = FALSE
  )

  # 中文备注：写入不含患者值的源数据候选身份收据。
  .source_handoff_write_json(source_receipt, file.path(package_dir, "source_candidate_receipt.json"))
  # 中文备注：写入 MI recipe、projection 与 runtime 的精确 lineage 收据。
  .source_handoff_write_json(recipe_receipt, file.path(package_dir, "source_mi_recipe_receipt.json"))
  # 中文备注：写入不可变 U04 aggregate QC 收据，不在 U05 内篡改其状态。
  .source_handoff_write_json(qc_receipt, file.path(package_dir, "mi_qc_receipt.json"))
  # 中文备注：写入 completed list 的语义身份收据。
  .source_handoff_write_json(semantic_receipt, file.path(package_dir, "completed_data_semantic_identity_receipt.json"))
  # 中文备注：写入 mids、completed 与 factor 的序列化闭包收据。
  .source_handoff_write_json(serialization_receipt, file.path(package_dir, "serialization_identity_receipt.json"))
  # 中文备注：写入仅代表候选字节冻结、仍待 registry 外部批准的 U05 收据。
  .source_handoff_write_json(frozen_receipt, file.path(package_dir, "FROZEN_HANDOFF_RECEIPT.json"))

  package_files <- sort(list.files(package_dir, recursive = TRUE, full.names = FALSE, all.files = TRUE, no.. = TRUE))
  package_files <- package_files[!file.info(file.path(package_dir, package_files))$isdir]
  manifest <- data.frame(
    relative_path = package_files,
    sha256 = vapply(file.path(package_dir, package_files), .source_handoff_sha256_file, character(1)),
    size_bytes = unname(as.numeric(file.info(file.path(package_dir, package_files))$size)),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  # 中文备注：最后写出覆盖全部非 manifest 成员的精确 PACKAGE_MANIFEST。
  utils::write.csv(manifest, file.path(package_dir, "PACKAGE_MANIFEST.csv"), row.names = FALSE, na = "")
  invisible(Sys.chmod(list.files(package_dir, full.names = TRUE), mode = "0600", use_umask = FALSE))
  list(
    mids_sha256 = mids_sha,
    completed_list_sha256 = completed_sha,
    factor_level_sha256 = factor_sha,
    semantic_receipt = semantic_receipt,
    serialization_receipt = serialization_receipt,
    recipe_receipt = recipe_receipt,
    frozen_receipt = frozen_receipt
  )
}

.source_handoff_zip_directory <- function(package_dir, zip_path) {
  members <- sort(list.files(package_dir, recursive = TRUE, full.names = FALSE, all.files = TRUE, no.. = TRUE))
  members <- members[!file.info(file.path(package_dir, members))$isdir]
  zip_executable <- unname(Sys.which("zip"))
  if (length(zip_executable) != 1L || !nzchar(zip_executable) ||
      !file.exists(zip_executable) || isTRUE(file.info(zip_executable)$isdir) ||
      file.access(zip_executable, mode = 1L) != 0L) {
    .source_handoff_stop("RUNTIME_ZIP_EXECUTABLE_UNAVAILABLE")
  }
  zip_executable <- normalizePath(zip_executable, mustWork = TRUE)
  fixed_time <- as.POSIXct("1980-01-01 00:00:00", tz = "UTC")
  invisible(Sys.setFileTime(file.path(package_dir, members), fixed_time))
  old_directory <- getwd()
  old_timezone <- Sys.getenv("TZ", unset = NA_character_)
  on.exit({
    setwd(old_directory)
    if (is.na(old_timezone)) Sys.unsetenv("TZ") else Sys.setenv(TZ = old_timezone)
  }, add = TRUE)
  Sys.setenv(TZ = "UTC")
  setwd(package_dir)
  # 中文备注：以排序成员、固定时间和无扩展属性模式生成确定性受限 ZIP。
  status <- suppressWarnings(utils::zip(
    zipfile = zip_path, files = members, flags = "-X -q", zip = zip_executable
  ))
  if (!identical(as.integer(status), 0L) || !file.exists(zip_path)) {
    .source_handoff_stop("SOURCE_HANDOFF_ZIP_BUILD_FAILED")
  }
  invisible(zip_path)
}

.source_handoff_approval_row <- function(
    source_receipt, lineage, package_identity, approval_id, handoff_sha256) {
  data.frame(
    handoff_id = paste0("HANDOFF_SRC_A_V43_", toupper(substr(handoff_sha256, 1L, 12L))),
    approval_id = approval_id,
    source_id = source_receipt$source_id,
    source_epoch = source_receipt$source_epoch,
    handoff_sha256 = handoff_sha256,
    expected_source_sha256 = source_receipt$source_sha256,
    expected_patient_order_sha256 = source_receipt$patient_order_sha256,
    expected_mids_sha256 = package_identity$mids_sha256,
    expected_completed_sha256 = package_identity$completed_list_sha256,
    expected_factor_sha256 = package_identity$factor_level_sha256,
    expected_schema_sha256 = lineage$canonical_schema_sha256,
    expected_core_column_n = 123L,
    expected_semantic_status = "FORMAL_MICE_FROZEN",
    approval_status = "CANDIDATE_PENDING_APPROVAL",
    approval_basis = "AUTO_GATE_PASS",
    protocol_revision = "v4.3-r00",
    approved_at = "",
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

.source_handoff_read_candidate_zip_receipts <- function(zip_path) {
  members <- c(
    source = "source_candidate_receipt.json",
    semantic = "completed_data_semantic_identity_receipt.json",
    frozen = "FROZEN_HANDOFF_RECEIPT.json"
  )
  listing <- tryCatch(utils::unzip(zip_path, list = TRUE), error = function(condition) NULL)
  if (is.null(listing) || !nrow(listing)) {
    .source_handoff_stop("SOURCE_HANDOFF_CANDIDATE_ZIP_SELF_CHECK_FAILED")
  }
  archive_names <- vapply(members, function(member) {
    hits <- listing$Name[basename(listing$Name) == member]
    if (length(hits) != 1L) .source_handoff_stop("SOURCE_HANDOFF_CANDIDATE_ZIP_SELF_CHECK_FAILED")
    hits[[1L]]
  }, character(1))
  extraction <- tempfile("source-handoff-receipts-")
  if (!dir.create(extraction, mode = "0700")) {
    .source_handoff_stop("SOURCE_HANDOFF_RECEIPT_EXTRACTION_FAILED")
  }
  on.exit(unlink(extraction, recursive = TRUE, force = TRUE), add = TRUE)
  # 中文备注：只解压并读取三个 aggregate identity receipt；不读取 RDS 或患者级对象。
  extracted <- tryCatch(
    suppressWarnings(utils::unzip(
      zip_path, files = unname(archive_names), exdir = extraction,
      junkpaths = TRUE, unzip = "internal"
    )),
    error = function(condition) NULL
  )
  paths <- file.path(extraction, unname(members))
  if (is.null(extracted) || length(extracted) != length(members) ||
      any(!file.exists(paths)) || any(nzchar(Sys.readlink(paths)))) {
    .source_handoff_stop("SOURCE_HANDOFF_RECEIPT_EXTRACTION_FAILED")
  }
  # 中文备注：加载 JSON 包并读取已由 ZIP manifest 锚定的 aggregate lineage receipts。
  if (!requireNamespace("jsonlite", quietly = TRUE)) {
    .source_handoff_stop("SOURCE_HANDOFF_DEPENDENCY_MISSING", "jsonlite")
  }
  setNames(lapply(paths, jsonlite::read_json, simplifyVector = TRUE), names(members))
}

.source_handoff_validate_candidate_directory <- function(
    candidate_path, expected_handoff_sha256, request = NULL,
    authorization_binding = NULL) {
  required <- c(
    "source_handoff_candidate.zip", "APPROVAL_ROW_PROPOSAL.csv", "CANDIDATE_RECEIPT.json",
    "SHA256SUMS.txt", "CANDIDATE_COMPLETE"
  )
  if (!dir.exists(candidate_path) || nzchar(Sys.readlink(candidate_path)) ||
      !identical(sort(list.files(candidate_path, all.files = TRUE, no.. = TRUE)), sort(required)) ||
      any(nzchar(Sys.readlink(file.path(candidate_path, required)))) ||
      !.source_handoff_is_sha256(expected_handoff_sha256)) {
    .source_handoff_stop("SOURCE_HANDOFF_EXISTING_CANDIDATE_INVALID")
  }
  paths <- file.path(candidate_path, required)
  if (any(file.info(paths)$isdir %in% TRUE)) {
    .source_handoff_stop("SOURCE_HANDOFF_EXISTING_CANDIDATE_INVALID")
  }
  zip_path <- file.path(candidate_path, "source_handoff_candidate.zip")
  proposal_path <- file.path(candidate_path, "APPROVAL_ROW_PROPOSAL.csv")
  receipt_path <- file.path(candidate_path, "CANDIDATE_RECEIPT.json")
  expected_sums <- c(
    paste(.source_handoff_sha256_file(zip_path), "source_handoff_candidate.zip"),
    paste(.source_handoff_sha256_file(proposal_path), "APPROVAL_ROW_PROPOSAL.csv"),
    paste(.source_handoff_sha256_file(receipt_path), "CANDIDATE_RECEIPT.json")
  )
  if (!identical(.source_handoff_sha256_file(zip_path), expected_handoff_sha256) ||
      !identical(trimws(readLines(file.path(candidate_path, "CANDIDATE_COMPLETE"), warn = FALSE)), expected_handoff_sha256) ||
      !identical(readLines(file.path(candidate_path, "SHA256SUMS.txt"), warn = FALSE), expected_sums)) {
    .source_handoff_stop("SOURCE_HANDOFF_EXISTING_CANDIDATE_INVALID")
  }
  structural_qc <- inspect_handoff_candidate_zip_structure(zip_path)
  if (any(structural_qc$status != "PASS")) {
    .source_handoff_stop("SOURCE_HANDOFF_CANDIDATE_ZIP_SELF_CHECK_FAILED")
  }
  # 中文备注：加载 aggregate candidate receipt，复验 request、H1 与 ZIP 的同一路径身份。
  if (!requireNamespace("jsonlite", quietly = TRUE)) {
    .source_handoff_stop("SOURCE_HANDOFF_DEPENDENCY_MISSING", "jsonlite")
  }
  receipt <- jsonlite::read_json(receipt_path, simplifyVector = TRUE)
  approval_row <- utils::read.csv(
    proposal_path, stringsAsFactors = FALSE, check.names = FALSE, na.strings = character()
  )
  receipt_fields <- c(
    "schema_version", "status", "source_id", "source_epoch", "request_sha256",
    "mi_qc_receipt_sha256", "handoff_sha256", "authorization_binding_sha256",
    "authorization_receipt_sha256", "authorization_file_sha256", "approval_id",
    "approval_status", "created_at", "contains_patient_values"
  )
  approval_fields <- c(
    "handoff_id", "approval_id", "source_id", "source_epoch", "handoff_sha256",
    "expected_source_sha256", "expected_patient_order_sha256", "expected_mids_sha256",
    "expected_completed_sha256", "expected_factor_sha256", "expected_schema_sha256",
    "expected_core_column_n", "expected_semantic_status", "approval_status",
    "approval_basis", "protocol_revision", "approved_at"
  )
  checks <- c(
    is.list(receipt) && identical(sort(names(receipt)), sort(receipt_fields)),
    identical(names(approval_row), approval_fields),
    identical(receipt$schema_version, "1.0.0"),
    identical(receipt$status, "CANDIDATE_SEALED_PENDING_EXTERNAL_APPROVAL"),
    identical(receipt$handoff_sha256, expected_handoff_sha256),
    identical(receipt$approval_status, "CANDIDATE_PENDING_APPROVAL"),
    identical(receipt$contains_patient_values, FALSE),
    nrow(approval_row) == 1L,
    identical(as.character(approval_row$handoff_id[[1L]]), paste0(
      "HANDOFF_SRC_A_V43_", toupper(substr(expected_handoff_sha256, 1L, 12L))
    )),
    identical(as.character(approval_row$handoff_sha256[[1L]]), expected_handoff_sha256),
    identical(as.character(approval_row$approval_status[[1L]]), "CANDIDATE_PENDING_APPROVAL"),
    identical(as.character(approval_row$approval_basis[[1L]]), "AUTO_GATE_PASS"),
    identical(as.character(approval_row$expected_semantic_status[[1L]]), "FORMAL_MICE_FROZEN"),
    identical(as.integer(approval_row$expected_core_column_n[[1L]]), 123L),
    identical(as.character(approval_row$protocol_revision[[1L]]), "v4.3-r00"),
    is.na(approval_row$approved_at[[1L]]) ||
      identical(as.character(approval_row$approved_at[[1L]]), "")
  )
  if (!is.null(authorization_binding) && is.null(request)) {
    .source_handoff_stop("SOURCE_HANDOFF_EXISTING_CANDIDATE_INVALID")
  }
  if (!is.null(request)) {
    validate_mi_transaction_request_v43(request)
    zip_receipts <- .source_handoff_read_candidate_zip_receipts(zip_path)
    validate_source_candidate_receipt(zip_receipts$source)
    frozen <- zip_receipts$frozen
    semantic <- zip_receipts$semantic
    checks <- c(checks,
      identical(source_candidate_receipt_identity_v43(zip_receipts$source), request$canonical_input_sha256),
      identical(zip_receipts$source$source_id, request$source_id),
      identical(zip_receipts$source$source_sha256, request$source_sha256),
      identical(zip_receipts$source$source_epoch, request$source_epoch),
      identical(zip_receipts$source$patient_order_sha256, request$patient_order_sha256),
      identical(zip_receipts$source$canonical_schema_sha256, request$canonical_schema_sha256),
      identical(receipt$request_sha256, request$request_sha256),
      identical(receipt$source_id, request$source_id),
      identical(receipt$source_epoch, request$source_epoch),
      identical(frozen$status, "PASS"),
      identical(frozen$seal_scope, "CANDIDATE_BYTES_ONLY"),
      identical(frozen$registry_approval_status, "CANDIDATE_PENDING_APPROVAL"),
      identical(frozen$approval_basis, "AUTO_GATE_PASS"),
      identical(frozen$source_id, request$source_id),
      identical(frozen$source_epoch, request$source_epoch),
      identical(frozen$request_sha256, request$request_sha256),
      identical(frozen$mi_qc_receipt_sha256, receipt$mi_qc_receipt_sha256),
      identical(frozen$created_at, receipt$created_at),
      identical(frozen$contains_patient_values, FALSE),
      identical(semantic$status, "FORMAL_MICE_FROZEN"),
      identical(semantic$source_id, request$source_id),
      identical(semantic$source_epoch, request$source_epoch),
      identical(semantic$request_sha256, request$request_sha256),
      identical(semantic$patient_order_sha256, request$patient_order_sha256),
      identical(semantic$canonical_schema_sha256, request$canonical_schema_sha256),
      identical(semantic$source_mids_sha, frozen$mids_sha256),
      identical(semantic$completed_list_sha256, frozen$completed_list_sha256),
      identical(semantic$factor_level_sha, frozen$factor_level_sha256),
      identical(as.character(approval_row$source_id[[1L]]), request$source_id),
      identical(as.character(approval_row$source_epoch[[1L]]), request$source_epoch),
      identical(as.character(approval_row$expected_source_sha256[[1L]]), request$source_sha256),
      identical(as.character(approval_row$expected_patient_order_sha256[[1L]]), request$patient_order_sha256),
      identical(as.character(approval_row$expected_mids_sha256[[1L]]), frozen$mids_sha256),
      identical(as.character(approval_row$expected_completed_sha256[[1L]]), frozen$completed_list_sha256),
      identical(as.character(approval_row$expected_factor_sha256[[1L]]), frozen$factor_level_sha256),
      identical(as.character(approval_row$expected_schema_sha256[[1L]]), frozen$canonical_schema_sha256)
    )
  }
  if (!is.null(authorization_binding)) {
    checks <- c(checks,
      identical(authorization_binding$request_sha256, request$request_sha256),
      identical(authorization_binding$source_id, request$source_id),
      identical(authorization_binding$source_sha256, request$source_sha256),
      identical(authorization_binding$source_epoch, request$source_epoch),
      identical(receipt$authorization_binding_sha256, authorization_binding$binding_sha256),
      identical(receipt$authorization_receipt_sha256, authorization_binding$authorization_receipt_sha256),
      identical(receipt$authorization_file_sha256, authorization_binding$authorization_file_sha256),
      identical(receipt$approval_id, authorization_binding$decision_id),
      identical(as.character(approval_row$approval_id[[1L]]), authorization_binding$decision_id),
      identical(frozen$approval_id, authorization_binding$decision_id)
    )
  }
  if (!all(checks)) .source_handoff_stop("SOURCE_HANDOFF_EXISTING_CANDIDATE_INVALID")
  list(
    candidate_path = candidate_path,
    zip_path = zip_path,
    approval_proposal_path = proposal_path,
    handoff_sha256 = expected_handoff_sha256,
    approval_row = approval_row,
    candidate_receipt = receipt
  )
}

.source_handoff_publish_candidate <- function(
    temporary_zip, source_receipt, request, qc_receipt, approval_row,
    authorization_binding, candidate_root) {
  handoff_sha <- .source_handoff_sha256_file(temporary_zip)
  base <- file.path(
    candidate_root, "handoff_candidates", source_receipt$source_epoch, request$request_sha256
  )
  target <- file.path(base, handoff_sha)
  if (dir.exists(base)) {
    existing <- list.dirs(base, recursive = FALSE, full.names = TRUE)
    complete <- existing[file.exists(file.path(existing, "CANDIDATE_COMPLETE"))]
    if (length(complete)) {
      if (length(complete) != 1L || !identical(basename(complete), handoff_sha)) {
        .source_handoff_stop("SOURCE_HANDOFF_DIFFERENT_RESULT_REJECTED")
      }
      return(.source_handoff_validate_candidate_directory(
        complete, handoff_sha, request, authorization_binding
      ))
    }
  }
  dir.create(base, recursive = TRUE, showWarnings = FALSE, mode = "0700")
  staging <- tempfile(pattern = ".handoff_candidate_staging_", tmpdir = base)
  if (!dir.create(staging, mode = "0700")) .source_handoff_stop("SOURCE_HANDOFF_STAGING_CREATE_FAILED")
  on.exit(if (dir.exists(staging)) unlink(staging, recursive = TRUE), add = TRUE)
  zip_target <- file.path(staging, "source_handoff_candidate.zip")
  # 中文备注：复制确定性 ZIP 到原子候选目录；外部 registry 尚未被修改。
  if (!file.copy(temporary_zip, zip_target, overwrite = FALSE, copy.mode = TRUE)) {
    .source_handoff_stop("SOURCE_HANDOFF_CANDIDATE_COPY_FAILED")
  }
  # 中文备注：写出供人工批准时显式合并的 registry 行提案，绝不自行置为 APPROVED。
  utils::write.csv(approval_row, file.path(staging, "APPROVAL_ROW_PROPOSAL.csv"), row.names = FALSE, na = "")
  candidate_receipt <- list(
    schema_version = "1.0.0",
    status = "CANDIDATE_SEALED_PENDING_EXTERNAL_APPROVAL",
    source_id = source_receipt$source_id,
    source_epoch = source_receipt$source_epoch,
    request_sha256 = request$request_sha256,
    mi_qc_receipt_sha256 = qc_receipt$receipt_sha256,
    handoff_sha256 = handoff_sha,
    authorization_binding_sha256 = authorization_binding$binding_sha256,
    authorization_receipt_sha256 = authorization_binding$authorization_receipt_sha256,
    authorization_file_sha256 = authorization_binding$authorization_file_sha256,
    approval_id = approval_row$approval_id[[1L]],
    approval_status = approval_row$approval_status[[1L]],
    created_at = qc_receipt$created_at,
    contains_patient_values = FALSE
  )
  # 中文备注：写出候选 seal 的 aggregate 身份收据。
  .source_handoff_write_json(candidate_receipt, file.path(staging, "CANDIDATE_RECEIPT.json"))
  sums <- c(
    paste(handoff_sha, "source_handoff_candidate.zip"),
    paste(.source_handoff_sha256_file(file.path(staging, "APPROVAL_ROW_PROPOSAL.csv")), "APPROVAL_ROW_PROPOSAL.csv"),
    paste(.source_handoff_sha256_file(file.path(staging, "CANDIDATE_RECEIPT.json")), "CANDIDATE_RECEIPT.json")
  )
  # 中文备注：写出候选目录三项内容的精确 SHA-256 清单。
  .control_write_atomic(file.path(staging, "SHA256SUMS.txt"), paste(sums, collapse = "\n"), mode = "0600")
  # 中文备注：最后写入完成哨兵，避免下游读取部分候选。
  .control_write_atomic(file.path(staging, "CANDIDATE_COMPLETE"), handoff_sha, mode = "0600")
  # 中文备注：原子发布已完整写入并校验清单的受限 U05 候选目录。
  if (!file.rename(staging, target)) .source_handoff_stop("SOURCE_HANDOFF_ATOMIC_PUBLISH_FAILED")
  .source_handoff_validate_candidate_directory(
    target, handoff_sha, request, authorization_binding
  )
}

assemble_source_handoff_package_v43 <- function(
    source_receipt, canonical, request, checkpoint, mids_path, completed, qc_receipt,
    mapping, formula_registry, projection, authorization, authorization_file_sha256,
    candidate_root,
    project_root = ".") {
  .source_handoff_require(project_root)
  candidate_root <- assert_restricted_candidate_root(candidate_root, project_root)
  validate_formal_mice_authorization_v43(authorization, request = request)
  authorization_binding <- .mi_tx_expected_authorization_binding(
    request, authorization, authorization_file_sha256, project_root
  )
  lineage <- .source_handoff_validate_lineage(
    source_receipt, canonical, request, checkpoint, mids_path, qc_receipt,
    mapping, projection, read_mi_contract_v43(project_root), project_root
  )
  completed_qc <- .source_handoff_validate_completed(
    canonical, completed, mapping, formula_registry, projection
  )
  staging_root <- tempfile(pattern = "source_handoff_package_v43_")
  if (!dir.create(staging_root, mode = "0700")) .source_handoff_stop("SOURCE_HANDOFF_PACKAGE_STAGING_FAILED")
  on.exit(if (dir.exists(staging_root)) unlink(staging_root, recursive = TRUE), add = TRUE)
  package_dir <- file.path(staging_root, "handoff_restricted")
  package_identity <- .source_handoff_write_package(
    package_dir, source_receipt, request, checkpoint, qc_receipt, mids_path,
    completed, mapping, formula_registry, projection, authorization$decision_id,
    lineage, completed_qc, project_root
  )
  temporary_zip <- tempfile(pattern = "source_handoff_candidate_v43_", fileext = ".zip")
  on.exit(if (file.exists(temporary_zip)) unlink(temporary_zip), add = TRUE)
  .source_handoff_zip_directory(package_dir, temporary_zip)
  structural_qc <- inspect_handoff_candidate_zip_structure(temporary_zip)
  if (any(structural_qc$status != "PASS")) {
    .source_handoff_stop("SOURCE_HANDOFF_CANDIDATE_ZIP_SELF_CHECK_FAILED")
  }
  handoff_sha <- .source_handoff_sha256_file(temporary_zip)
  approval_row <- .source_handoff_approval_row(
    source_receipt, lineage, package_identity, authorization$decision_id, handoff_sha
  )
  .source_handoff_publish_candidate(
    temporary_zip, source_receipt, request, qc_receipt, approval_row,
    authorization_binding, candidate_root
  )
}

.source_handoff_read_qc_bundle <- function(path, checkpoint, request, project_root) {
  aggregate_members <- c(
    "mi_convergence_diagnostics.csv", "mi_convergence_summary.csv",
    "mi_distribution_qc.csv", "mi_observed_cell_qc.csv", "mi_donor_qc.csv",
    "mi_completed_structure_qc.csv", "mi_logged_events.csv"
  )
  required <- c(
    "mi_qc_receipt.json", "completed_analysis_list.rds", aggregate_members,
    "U04_BUNDLE_RECEIPT.json", "SHA256SUMS.txt", "BUNDLE_COMPLETE"
  )
  observed <- sort(list.files(path, all.files = TRUE, no.. = TRUE))
  if (!identical(observed, sort(required))) .source_handoff_stop("SOURCE_HANDOFF_U04_BUNDLE_CLOSURE_FAILED")
  # 中文备注：加载 JSON 包并读取受限 U04 bundle 的 aggregate 收据。
  if (!requireNamespace("jsonlite", quietly = TRUE)) {
    .source_handoff_stop("SOURCE_HANDOFF_DEPENDENCY_MISSING", "jsonlite")
  }
  qc <- jsonlite::read_json(file.path(path, "mi_qc_receipt.json"), simplifyVector = TRUE)
  bundle <- jsonlite::read_json(file.path(path, "U04_BUNDLE_RECEIPT.json"), simplifyVector = TRUE)
  validate_mi_qc_receipt_v43(qc, project_root)
  completed_sha <- .source_handoff_sha256_file(file.path(path, "completed_analysis_list.rds"))
  bundle_payload <- bundle[names(bundle) != "bundle_sha256"]
  checks <- c(
    identical(bundle$status, "SEALED"),
    identical(bundle$request_sha256, request$request_sha256),
    identical(bundle$checkpoint_sha256, checkpoint$checkpoint_sha256),
    identical(bundle$mi_qc_receipt_sha256, qc$receipt_sha256),
    identical(bundle$completed_list_sha256, completed_sha),
    identical(as.integer(bundle$aggregate_artifact_n), length(aggregate_members)),
    identical(bundle$u04_execution_identity_sha256, .source_handoff_u04_execution_identity(project_root)),
    identical(bundle$bundle_sha256, .control_sha256_text(canonical_json(bundle_payload))),
    identical(trimws(readLines(file.path(path, "BUNDLE_COMPLETE"), warn = FALSE)), bundle$bundle_sha256)
  )
  hashed_members <- c("mi_qc_receipt.json", "completed_analysis_list.rds", aggregate_members, "U04_BUNDLE_RECEIPT.json")
  expected_sums <- paste(
    vapply(file.path(path, hashed_members), .source_handoff_sha256_file, character(1)),
    hashed_members
  )
  if (!all(checks) || !identical(readLines(file.path(path, "SHA256SUMS.txt"), warn = FALSE), expected_sums)) {
    .source_handoff_stop("SOURCE_HANDOFF_U04_BUNDLE_INTEGRITY_FAILED")
  }
  # 中文备注：读取已经通过 U04 bundle hash 校验的20套 completed analysis list。
  completed <- readRDS(file.path(path, "completed_analysis_list.rds"))
  list(receipt = qc, bundle = bundle, completed = completed, path = path)
}

.source_handoff_publish_qc_bundle <- function(
    transaction_path, checkpoint, request, qc_result, project_root) {
  qc_root <- file.path(transaction_path, "qc")
  target <- file.path(qc_root, checkpoint$checkpoint_sha256)
  if (dir.exists(target)) {
    return(.source_handoff_read_qc_bundle(target, checkpoint, request, project_root))
  }
  dir.create(qc_root, recursive = TRUE, showWarnings = FALSE, mode = "0700")
  staging <- tempfile(pattern = ".u04_staging_", tmpdir = qc_root)
  if (!dir.create(staging, mode = "0700")) .source_handoff_stop("SOURCE_HANDOFF_U04_STAGING_FAILED")
  on.exit(if (dir.exists(staging)) unlink(staging, recursive = TRUE), add = TRUE)
  # 中文备注：写入 U04 immutable aggregate QC receipt。
  .source_handoff_write_json(qc_result$receipt, file.path(staging, "mi_qc_receipt.json"))
  # 中文备注：保存 U04 已重算 passive variables 的受限 completed list。
  saveRDS(qc_result$completed, file.path(staging, "completed_analysis_list.rds"), version = 3, compress = "gzip")
  completed_sha <- .source_handoff_sha256_file(file.path(staging, "completed_analysis_list.rds"))
  aggregate <- list(
    mi_convergence_diagnostics.csv = qc_result$convergence_diagnostics,
    mi_convergence_summary.csv = as.data.frame(qc_result$convergence_summary, stringsAsFactors = FALSE),
    mi_distribution_qc.csv = qc_result$distribution_qc,
    mi_observed_cell_qc.csv = qc_result$observed_cell_qc,
    mi_donor_qc.csv = qc_result$donor_qc,
    mi_completed_structure_qc.csv = qc_result$structure_qc,
    mi_logged_events.csv = qc_result$logged_events
  )
  if (any(!vapply(aggregate, is.data.frame, logical(1)))) {
    .source_handoff_stop("SOURCE_HANDOFF_U04_AGGREGATE_INVALID")
  }
  if (!ncol(aggregate$mi_logged_events.csv)) {
    aggregate$mi_logged_events.csv <- data.frame(event_n = integer(), stringsAsFactors = FALSE)
  }
  for (name in names(aggregate)) {
    # 中文备注：写出不含患者值的 U04 aggregate 诊断表，保留完整审计细节。
    utils::write.csv(aggregate[[name]], file.path(staging, name), row.names = FALSE, na = "")
  }
  bundle_payload <- list(
    schema_version = "1.0.0",
    status = "SEALED",
    request_sha256 = request$request_sha256,
    checkpoint_sha256 = checkpoint$checkpoint_sha256,
    checkpoint_object_sha256 = checkpoint$object_sha256,
    final_iteration = as.integer(checkpoint$iteration),
    mi_qc_receipt_sha256 = qc_result$receipt$receipt_sha256,
    completed_list_sha256 = completed_sha,
    aggregate_artifact_n = length(aggregate),
    u04_execution_identity_sha256 = .source_handoff_u04_execution_identity(project_root),
    created_at = qc_result$receipt$created_at,
    contains_patient_values = FALSE
  )
  bundle <- bundle_payload
  bundle$bundle_sha256 <- .control_sha256_text(canonical_json(bundle_payload))
  # 中文备注：写入将 U04 receipt、checkpoint 与 completed list 绑定的 bundle 收据。
  .source_handoff_write_json(bundle, file.path(staging, "U04_BUNDLE_RECEIPT.json"))
  hashed_members <- c(
    "mi_qc_receipt.json", "completed_analysis_list.rds", names(aggregate),
    "U04_BUNDLE_RECEIPT.json"
  )
  sums <- paste(
    vapply(file.path(staging, hashed_members), .source_handoff_sha256_file, character(1)),
    hashed_members
  )
  # 中文备注：写出 U04 bundle 精确 SHA-256 清单。
  .control_write_atomic(file.path(staging, "SHA256SUMS.txt"), paste(sums, collapse = "\n"), mode = "0600")
  # 中文备注：最后写出 U04 bundle 完成哨兵。
  .control_write_atomic(file.path(staging, "BUNDLE_COMPLETE"), bundle$bundle_sha256, mode = "0600")
  # 中文备注：原子发布包含完整 aggregate QC 与受限 completed list 的 U04 bundle。
  if (!file.rename(staging, target)) .source_handoff_stop("SOURCE_HANDOFF_U04_ATOMIC_PUBLISH_FAILED")
  .source_handoff_read_qc_bundle(target, checkpoint, request, project_root)
}

.source_handoff_terminal <- function(
    reason_code, request, transaction_path = "", primary_next_action = reason_code,
    detail = list()) {
  c(list(
    mode = "build-candidate",
    status = "EXTERNAL_INPUT_BLOCKED",
    reason_code = reason_code,
    request_sha256 = request$request_sha256,
    transaction_pointer = if (nzchar(transaction_path)) file.path("mi_transactions", basename(transaction_path)) else "",
    primary_next_action = primary_next_action
  ), detail)
}

.source_handoff_validate_audit_path <- function(audit, audit_path, candidate_root) {
  if (!is.list(audit) || !all(c("receipt", "canonical", "mapping", "formula_registry") %in% names(audit)) ||
      !dir.exists(audit_path)) {
    .source_handoff_stop("SOURCE_HANDOFF_AUDIT_INPUT_INVALID")
  }
  normalized_audit <- normalizePath(audit_path, mustWork = TRUE)
  normalized_root <- paste0(normalizePath(candidate_root, mustWork = TRUE), .Platform$file.sep)
  if (!startsWith(paste0(normalized_audit, .Platform$file.sep), normalized_root)) {
    .source_handoff_stop("SOURCE_HANDOFF_AUDIT_PATH_OUTSIDE_CANDIDATE_ROOT")
  }
  receipt_path <- file.path(audit_path, "source_candidate_receipt.json")
  sentinel <- file.path(audit_path, "SOURCE_AUDIT_COMPLETE")
  if (!file.exists(receipt_path) || !file.exists(sentinel)) {
    .source_handoff_stop("SOURCE_HANDOFF_AUDIT_INCOMPLETE")
  }
  # 中文备注：加载 JSON 包并验证 audit receipt 与内存 source identity 相同。
  if (!requireNamespace("jsonlite", quietly = TRUE)) {
    .source_handoff_stop("SOURCE_HANDOFF_DEPENDENCY_MISSING", "jsonlite")
  }
  observed <- jsonlite::read_json(receipt_path, simplifyVector = TRUE)
  if (!identical(
      source_candidate_receipt_identity_v43(observed),
      source_candidate_receipt_identity_v43(audit$receipt)
  )) {
    .source_handoff_stop("SOURCE_HANDOFF_AUDIT_RECEIPT_MISMATCH")
  }
  invisible(TRUE)
}

build_source_handoff_candidate <- function(
    audit, audit_path, candidate_root, authorization, authorization_file_sha256,
    project_root = ".") {
  .source_handoff_require(project_root)
  candidate_root <- assert_restricted_candidate_root(candidate_root, project_root)
  dir.create(candidate_root, recursive = TRUE, showWarnings = FALSE, mode = "0700")
  .source_handoff_validate_audit_path(audit, audit_path, candidate_root)
  owner <- read_mi_contract_v43(project_root)
  projection <- load_compiled_mi_recipe_v43(project_root, audit$mapping$target_name)$projection
  runtime <- build_mi_runtime_spec_v43(audit$canonical, projection, owner, audit$mapping)
  current_request <- build_mi_transaction_request_v43(
    audit$receipt, runtime, projection, owner, audit$mapping, project_root
  )
  approval_id <- authorization$decision_id
  transaction_root <- file.path(candidate_root, "mi_transactions")
  resolved <- .resolve_formal_mice_authorized_request_v43(
    transaction_root, authorization, current_request, audit$receipt
  )
  request <- resolved$request
  transaction_path <- resolved$transaction_path
  if (!dir.exists(transaction_path)) {
    return(.source_handoff_terminal(
      "FORMAL_MICE_RUN_REQUIRED", request, transaction_path,
      "REQUEST_EXACT_RUN_FORMAL_MICE_HANDOFF_AUTHORIZATION"
    ))
  }
  if (!identical(request, current_request)) {
    validate_formal_mice_repair_bridge_v43(
      request, current_request, transaction_path, project_root
    )
  }
  state <- inspect_mi_transaction_v43(transaction_path, request)
  validate_mi_transaction_authorization_v43(
    transaction_path, request, authorization, authorization_file_sha256, project_root
  )
  if (identical(state$status, "ACTIVE")) {
    return(.source_handoff_terminal(
      "FORMAL_MICE_TRANSACTION_ACTIVE", request, transaction_path,
      "WAIT_OR_RECONCILE_EXISTING_FORMAL_MICE_TRANSACTION"
    ))
  }
  if (identical(state$status, "RECOVERY_READY")) {
    return(.source_handoff_terminal(
      "FORMAL_MICE_RECOVERY_READY", request, transaction_path,
      "RESUME_EXACT_RECOVERED_FORMAL_MICE_REQUEST"
    ))
  }
  if (identical(state$status, "UNKNOWN")) {
    return(.source_handoff_terminal(
      "MI_TRANSACTION_RECONCILIATION_REQUIRED", request, transaction_path,
      "RECONCILE_EXISTING_TRANSACTION_WITHOUT_RERUN"
    ))
  }
  if (identical(state$status, "FAILED_TYPED")) {
    return(.source_handoff_terminal(
      "FORMAL_MICE_FAILED_TYPED", request, transaction_path,
      "CENTRALIZED_BOUNDED_REPAIR_REVIEW",
      list(failure_signature = state$failure$failure_signature)
    ))
  }
  if (identical(state$status, "FROZEN")) {
    if (!identical(state$frozen$approval_id, approval_id)) {
      .source_handoff_stop("SOURCE_HANDOFF_FROZEN_APPROVAL_ID_MISMATCH")
    }
    candidate_path <- file.path(
      candidate_root, "handoff_candidates", request$source_epoch,
      request$request_sha256, state$frozen$handoff_candidate_sha256
    )
    candidate <- .source_handoff_validate_candidate_directory(
      candidate_path, state$frozen$handoff_candidate_sha256,
      request, state$authorization_binding
    )
    return(c(list(
      mode = "build-candidate",
      status = "CANDIDATE_SEALED_PENDING_EXTERNAL_APPROVAL",
      reason_code = "FROZEN_REPLAY",
      request_sha256 = request$request_sha256,
      primary_next_action = "EXTERNAL_HANDOFF_REGISTRY_APPROVAL"
    ), candidate))
  }
  checkpoint <- tail(state$checkpoints, 1L)[[1L]]
  mids_path <- file.path(checkpoint$checkpoint_path, "mids_checkpoint.rds")
  # 中文备注：读取通过 transaction checkpoint hash 校验的 formal mids，执行 U04 QC，不新增 MICE 拟合。
  mids_object <- readRDS(mids_path)
  validate_formal_working_mids_v43(
    mids_object, runtime, projection, owner, audit$mapping, checkpoint$iteration
  )
  qc_path <- file.path(transaction_path, "qc", checkpoint$checkpoint_sha256)
  qc_bundle <- if (dir.exists(qc_path)) {
    .source_handoff_read_qc_bundle(qc_path, checkpoint, request, project_root)
  } else {
    # 中文备注：开始对当前 formal MICE checkpoint 执行 U04 aggregate QC。
    qc_result <- evaluate_formal_mi_qc_v43(
      mids_object = mids_object,
      canonical = audit$canonical,
      runtime = runtime,
      projection = projection,
      owner = owner,
      mapping = audit$mapping,
      formula_registry = audit$formula_registry,
      request = request,
      transaction_path = transaction_path,
      project_root = project_root
    )
    .source_handoff_publish_qc_bundle(
      transaction_path, checkpoint, request, qc_result, project_root
    )
  }
  status <- qc_bundle$receipt$status
  if (!identical(status, "PASS")) {
    reason <- switch(
      status,
      CONTINUE_TO_40 = "FORMAL_MICE_CONTINUATION_TO_40_REQUIRED",
      CONTINUE_TO_50 = "FORMAL_MICE_CONTINUATION_TO_50_REQUIRED",
      CONTINUE_TO_100 = "FORMAL_MICE_CONTINUATION_TO_100_REQUIRED",
      CONTINUE_TO_200 = "FORMAL_MICE_CONTINUATION_TO_200_REQUIRED",
      HUMAN_REVIEW_REQUIRED = "MI_QC_HUMAN_REVIEW_REQUIRED",
      PROTOCOL_REVIEW_REQUIRED = "MI_QC_PROTOCOL_REVIEW_REQUIRED",
      FAIL = "MI_QC_FAILED",
      "MI_QC_TERMINAL_UNKNOWN"
    )
    return(.source_handoff_terminal(
      reason, request, transaction_path,
      if (status %in% c(
        "CONTINUE_TO_40", "CONTINUE_TO_50", "CONTINUE_TO_100", "CONTINUE_TO_200"
      )) {
        "REQUEST_AUTHORIZED_SAME_MIDS_CONTINUATION"
      } else {
        "REVIEW_TYPED_MI_QC_TERMINAL"
      },
      list(mi_qc_receipt_sha256 = qc_bundle$receipt$receipt_sha256)
    ))
  }
  candidate <- assemble_source_handoff_package_v43(
    source_receipt = audit$receipt,
    canonical = audit$canonical,
    request = request,
    checkpoint = checkpoint,
    mids_path = mids_path,
    completed = qc_bundle$completed,
    qc_receipt = qc_bundle$receipt,
    mapping = audit$mapping,
    formula_registry = audit$formula_registry,
    projection = projection,
    authorization = authorization,
    authorization_file_sha256 = authorization_file_sha256,
    candidate_root = candidate_root,
    project_root = project_root
  )
  publish_mi_frozen_terminal_v43(
    transaction_path = transaction_path,
    request = request,
    final_checkpoint_sha256 = checkpoint$checkpoint_sha256,
    final_iteration = checkpoint$iteration,
    mi_qc_receipt_sha256 = qc_bundle$receipt$receipt_sha256,
    frozen_mids_sha256 = checkpoint$object_sha256,
    completed_list_sha256 = candidate$approval_row$expected_completed_sha256[[1L]],
    handoff_candidate_sha256 = candidate$handoff_sha256,
    approval_id = approval_id,
    approval_basis = "HUMAN_APPROVAL"
  )
  c(list(
    mode = "build-candidate",
    status = "CANDIDATE_SEALED_PENDING_EXTERNAL_APPROVAL",
    reason_code = "U05_CANDIDATE_SEALED",
    request_sha256 = request$request_sha256,
    primary_next_action = "EXTERNAL_HANDOFF_REGISTRY_APPROVAL"
  ), candidate)
}
