# v4.3 formal MICE exactly-once transaction：状态由不可变 request/checkpoint/terminal 与临时 lease 派生。

.mi_tx_stop <- function(code, detail = "") {
  message <- if (nzchar(detail)) paste(code, detail, sep = ": ") else code
  stop(message, call. = FALSE)
}

.mi_tx_require_control_kernel <- function(project_root = ".") {
  required <- c("canonical_json", ".control_sha256_text", ".control_write_atomic")
  if (!all(vapply(required, exists, logical(1), mode = "function"))) {
    path <- file.path(project_root, "R", "control_kernel.R")
    if (!file.exists(path)) .mi_tx_stop("MI_TRANSACTION_CONTROL_KERNEL_MISSING")
    source(path)
  }
  invisible(TRUE)
}

.mi_tx_sha256_file <- function(path) {
  # 中文备注：加载摘要包以验证受限 checkpoint 与 receipt 的内容身份。
  if (!requireNamespace("digest", quietly = TRUE)) .mi_tx_stop("MI_TRANSACTION_DEPENDENCY_MISSING", "digest")
  digest::digest(file = path, algo = "sha256", serialize = FALSE)
}

.mi_tx_is_sha256 <- function(value, allow_empty = FALSE) {
  is.character(value) && length(value) == 1L && !is.na(value) &&
    ((allow_empty && !nzchar(value)) || grepl("^[0-9a-f]{64}$", value))
}

.mi_tx_iteration_plan_v43 <- function() c(30L, 40L, 50L, 100L, 200L)

.mi_tx_request_payload_fields <- function() {
  c(
    "schema_version", "transaction_type", "source_id", "source_epoch", "source_sha256",
    "patient_order_sha256", "canonical_schema_sha256", "canonical_input_sha256",
    "recipe_id", "recipe_epoch", "recipe_projection_sha256",
    "predictor_policy_sha256", "candidate_projection_sha256", "candidate_edge_n",
    "runtime_epoch",
    "runtime_identity_sha256", "runtime_admission_identity_sha256",
    "m", "seed", "maxit_initial", "continuation_maxit", "scientific_generation_id",
    "rng_kind", "chain_count", "worker_pool_capacity", "chain_stream_policy",
    "chain_merge_order"
  )
}

finalize_mi_transaction_request_v43 <- function(payload) {
  .mi_tx_require_control_kernel()
  fields <- .mi_tx_request_payload_fields()
  if (!is.list(payload) || !identical(names(payload), fields)) .mi_tx_stop("MI_TRANSACTION_REQUEST_SCHEMA_INVALID")
  sha_fields <- c(
    "source_epoch", "source_sha256", "patient_order_sha256", "canonical_schema_sha256",
    "canonical_input_sha256", "recipe_epoch", "recipe_projection_sha256", "runtime_epoch",
    "predictor_policy_sha256", "candidate_projection_sha256",
    "runtime_identity_sha256", "runtime_admission_identity_sha256"
  )
  if (any(!vapply(payload[sha_fields], .mi_tx_is_sha256, logical(1)))) {
    .mi_tx_stop("MI_TRANSACTION_REQUEST_SHA_INVALID")
  }
  if (!identical(payload$schema_version, "1.0.0") ||
      !identical(payload$transaction_type, "FORMAL_MICE_V43") ||
      !grepl("^[A-Z][A-Z0-9_]{2,127}$", payload$source_id) ||
      !identical(payload$recipe_id, "SRC_MI_V43_MAIN_SURVIVAL_V1") ||
      !identical(as.integer(payload$candidate_edge_n), 896L) ||
      !identical(as.integer(payload$m), 20L) ||
      !identical(as.integer(payload$seed), 123L) ||
      !identical(as.integer(payload$maxit_initial), 30L) ||
      !identical(payload$continuation_maxit, "40|50|100|200") ||
      !identical(payload$scientific_generation_id, "MAIN_24_WORKER_SCIENTIFIC_GENERATION_APPROVED") ||
      !identical(payload$rng_kind, "L'Ecuyer-CMRG|Inversion|Rejection") ||
      !identical(as.integer(payload$chain_count), 20L) ||
      !identical(as.integer(payload$worker_pool_capacity), 24L) ||
      !identical(payload$chain_stream_policy, "NEXT_RNG_STREAM_FROM_MASTER_SEED") ||
      !identical(payload$chain_merge_order, "CHAIN_ID_ASCENDING")) {
    .mi_tx_stop("MI_TRANSACTION_REQUEST_CONTRACT_INVALID")
  }
  payload$m <- as.integer(payload$m)
  payload$seed <- as.integer(payload$seed)
  payload$maxit_initial <- as.integer(payload$maxit_initial)
  payload$candidate_edge_n <- as.integer(payload$candidate_edge_n)
  payload$chain_count <- as.integer(payload$chain_count)
  payload$worker_pool_capacity <- as.integer(payload$worker_pool_capacity)
  payload$request_sha256 <- .control_sha256_text(canonical_json(payload))
  payload
}

validate_mi_transaction_request_v43 <- function(request) {
  .mi_tx_require_control_kernel()
  fields <- c(.mi_tx_request_payload_fields(), "request_sha256")
  if (!is.list(request) || !identical(sort(names(request)), sort(fields)) ||
      !.mi_tx_is_sha256(request$request_sha256)) {
    .mi_tx_stop("MI_TRANSACTION_REQUEST_SCHEMA_INVALID")
  }
  request <- request[fields]
  payload <- request[.mi_tx_request_payload_fields()]
  expected <- finalize_mi_transaction_request_v43(payload)
  if (!identical(request, expected)) .mi_tx_stop("MI_TRANSACTION_REQUEST_IDENTITY_MISMATCH")
  invisible(TRUE)
}

.mi_tx_require_authorization <- function(project_root = ".") {
  if (!exists("validate_formal_mice_authorization_v43", mode = "function")) {
    path <- file.path(project_root, "R", "authorization_engine.R")
    if (!file.exists(path)) .mi_tx_stop("MI_TRANSACTION_AUTHORIZATION_ENGINE_MISSING")
    source(path)
  }
  invisible(TRUE)
}

.mi_tx_authorization_binding_fields <- function() {
  c(
    "schema_version", "request_sha256", "decision_id", "authorization_receipt_sha256",
    "authorization_file_sha256", "source_id", "source_sha256", "source_epoch",
    "approved_at", "binding_sha256"
  )
}

.mi_tx_expected_authorization_binding <- function(
    request, authorization, authorization_file_sha256, project_root = ".") {
  .mi_tx_require_control_kernel(project_root)
  .mi_tx_require_authorization(project_root)
  validate_mi_transaction_request_v43(request)
  validate_formal_mice_authorization_v43(authorization, request = request)
  if (!.mi_tx_is_sha256(authorization_file_sha256)) {
    .mi_tx_stop("MI_TRANSACTION_AUTHORIZATION_FILE_SHA_INVALID")
  }
  payload <- list(
    schema_version = "1.0.0",
    request_sha256 = request$request_sha256,
    decision_id = authorization$decision_id,
    authorization_receipt_sha256 = authorization$receipt_sha256,
    authorization_file_sha256 = authorization_file_sha256,
    source_id = request$source_id,
    source_sha256 = request$source_sha256,
    source_epoch = request$source_epoch,
    approved_at = authorization$approved_at
  )
  payload$binding_sha256 <- .control_sha256_text(canonical_json(payload))
  payload
}

.mi_tx_validate_authorization_binding <- function(path, request) {
  .mi_tx_require_authorization()
  if (!file.exists(path) || isTRUE(file.info(path)$isdir) || nzchar(Sys.readlink(path))) {
    .mi_tx_stop("MI_TRANSACTION_AUTHORIZATION_BINDING_MISSING")
  }
  binding <- .mi_tx_read_json(path)
  fields <- .mi_tx_authorization_binding_fields()
  if (!is.list(binding) || !identical(sort(names(binding)), sort(fields))) {
    .mi_tx_stop("MI_TRANSACTION_AUTHORIZATION_BINDING_INVALID")
  }
  binding <- binding[fields]
  sha_fields <- c(
    "request_sha256", "authorization_receipt_sha256", "authorization_file_sha256",
    "source_sha256", "source_epoch", "binding_sha256"
  )
  if (!identical(binding$schema_version, "1.0.0") ||
      !identical(binding$request_sha256, request$request_sha256) ||
      !identical(binding$source_id, request$source_id) ||
      !identical(binding$source_sha256, request$source_sha256) ||
      !identical(binding$source_epoch, request$source_epoch) ||
      any(!vapply(binding[sha_fields], .mi_tx_is_sha256, logical(1))) ||
      !grepl("^[A-Za-z0-9][A-Za-z0-9._-]{2,127}$", binding$decision_id) ||
      !exists(".formal_authorization_is_utc_second", mode = "function") ||
      !.formal_authorization_is_utc_second(binding$approved_at)) {
    .mi_tx_stop("MI_TRANSACTION_AUTHORIZATION_BINDING_INVALID")
  }
  payload <- binding[names(binding) != "binding_sha256"]
  if (!identical(binding$binding_sha256, .control_sha256_text(canonical_json(payload)))) {
    .mi_tx_stop("MI_TRANSACTION_AUTHORIZATION_BINDING_INVALID")
  }
  binding
}

.mi_tx_bind_authorization <- function(
    transaction_path, request, authorization, authorization_file_sha256,
    project_root = ".") {
  expected <- .mi_tx_expected_authorization_binding(
    request, authorization, authorization_file_sha256, project_root
  )
  path <- file.path(transaction_path, "H1_AUTHORIZATION_BINDING.json")
  if (file.exists(path)) {
    observed <- .mi_tx_validate_authorization_binding(path, request)
    if (!identical(observed, expected)) .mi_tx_stop("MI_TRANSACTION_AUTHORIZATION_BINDING_CONFLICT")
    return(observed)
  }
  state_members <- c(
    file.path(transaction_path, "ACTIVE.lease"),
    file.path(transaction_path, "FROZEN_RECEIPT.json"),
    file.path(transaction_path, "FAILURE_RECEIPT.json"),
    file.path(transaction_path, "checkpoints")
  )
  if (any(file.exists(state_members) | dir.exists(state_members))) {
    .mi_tx_stop("MI_TRANSACTION_AUTHORIZATION_BINDING_MISSING")
  }
  # 中文备注：原子写入 H1 语义与文件 SHA 绑定，供 U02-U05 全链复验。
  .control_write_atomic(path, canonical_json(expected), mode = "0600")
  .mi_tx_validate_authorization_binding(path, request)
}

validate_mi_transaction_authorization_v43 <- function(
    transaction_path, request, authorization, authorization_file_sha256,
    project_root = ".") {
  expected <- .mi_tx_expected_authorization_binding(
    request, authorization, authorization_file_sha256, project_root
  )
  observed <- .mi_tx_validate_authorization_binding(
    file.path(transaction_path, "H1_AUTHORIZATION_BINDING.json"), request
  )
  if (!identical(observed, expected)) .mi_tx_stop("MI_TRANSACTION_AUTHORIZATION_BINDING_CONFLICT")
  observed
}

.mi_tx_assert_root <- function(transaction_root) {
  normalized <- normalizePath(transaction_root, mustWork = FALSE)
  portable <- gsub("\\\\", "/", normalized)
  if (!grepl("(^|/)(restricted_cache|candidate_cache)(/|$)", portable)) {
    .mi_tx_stop("MI_TRANSACTION_ROOT_NOT_RESTRICTED")
  }
  normalized
}

.mi_tx_read_json <- function(path) {
  # 中文备注：加载 JSON 包并读取不可变 transaction receipt。
  if (!requireNamespace("jsonlite", quietly = TRUE)) .mi_tx_stop("MI_TRANSACTION_DEPENDENCY_MISSING", "jsonlite")
  jsonlite::read_json(path, simplifyVector = TRUE)
}

.mi_tx_publish_request <- function(transaction_root, request) {
  transaction_root <- .mi_tx_assert_root(transaction_root)
  dir.create(transaction_root, recursive = TRUE, showWarnings = FALSE, mode = "0700")
  target <- file.path(transaction_root, request$request_sha256)
  if (dir.exists(target)) return(target)
  staging <- tempfile(pattern = ".request_staging_", tmpdir = transaction_root)
  if (!dir.create(staging, mode = "0700")) .mi_tx_stop("MI_TRANSACTION_REQUEST_STAGING_FAILED")
  on.exit(if (dir.exists(staging)) unlink(staging, recursive = TRUE), add = TRUE)
  .control_write_atomic(file.path(staging, "REQUEST.json"), canonical_json(request), mode = "0600")
  .control_write_atomic(file.path(staging, "REQUEST_COMPLETE"), request$request_sha256, mode = "0600")
  if (!file.rename(staging, target)) {
    if (!dir.exists(target)) .mi_tx_stop("MI_TRANSACTION_REQUEST_ATOMIC_PUBLISH_FAILED")
  }
  target
}

.mi_tx_validate_request_directory <- function(transaction_path, request) {
  request_path <- file.path(transaction_path, "REQUEST.json")
  sentinel <- file.path(transaction_path, "REQUEST_COMPLETE")
  if (!file.exists(request_path) || !file.exists(sentinel)) .mi_tx_stop("MI_TRANSACTION_REQUEST_INCOMPLETE")
  observed <- .mi_tx_read_json(request_path)
  validate_mi_transaction_request_v43(observed)
  observed <- observed[c(.mi_tx_request_payload_fields(), "request_sha256")]
  if (!identical(observed, request) ||
      !identical(trimws(readLines(sentinel, warn = FALSE)), request$request_sha256) ||
      !identical(basename(transaction_path), request$request_sha256)) {
    .mi_tx_stop("MI_TRANSACTION_REQUEST_IDENTITY_MISMATCH")
  }
  invisible(TRUE)
}

.mi_tx_checkpoint_receipt_fields <- function() {
  c(
    "schema_version", "request_sha256", "iteration", "parent_checkpoint_sha256",
    "object_sha256", "object_class", "predictor_matrix_sha256", "predictor_edge_n",
    "m", "continuation_count", "call_kind",
    "created_at", "checkpoint_sha256"
  )
}

.mi_tx_validate_checkpoint <- function(checkpoint_path, request) {
  required_members <- c("mids_checkpoint.rds", "CHECKPOINT_RECEIPT.json", "SHA256SUMS.txt", "BUNDLE_COMPLETE")
  observed_members <- sort(list.files(checkpoint_path, all.files = TRUE, no.. = TRUE))
  if (!identical(observed_members, sort(required_members))) .mi_tx_stop("MI_CHECKPOINT_MEMBER_CLOSURE_FAILED")
  receipt_path <- file.path(checkpoint_path, "CHECKPOINT_RECEIPT.json")
  object_path <- file.path(checkpoint_path, "mids_checkpoint.rds")
  receipt <- .mi_tx_read_json(receipt_path)
  receipt_fields <- .mi_tx_checkpoint_receipt_fields()
  if (!is.list(receipt) || !identical(sort(names(receipt)), sort(receipt_fields))) {
    .mi_tx_stop("MI_CHECKPOINT_RECEIPT_INVALID")
  }
  receipt <- receipt[receipt_fields]
  if (
      !identical(receipt$schema_version, "1.0.0") ||
      !identical(receipt$request_sha256, request$request_sha256) ||
      !as.integer(receipt$iteration) %in% .mi_tx_iteration_plan_v43() ||
      !.mi_tx_is_sha256(receipt$parent_checkpoint_sha256, allow_empty = TRUE) ||
      !.mi_tx_is_sha256(receipt$object_sha256) ||
      !.mi_tx_is_sha256(receipt$predictor_matrix_sha256) ||
      as.integer(receipt$predictor_edge_n) < 1L ||
      as.integer(receipt$predictor_edge_n) > as.integer(request$candidate_edge_n) ||
      !.mi_tx_is_sha256(receipt$checkpoint_sha256) ||
      !identical(as.integer(receipt$m), 20L) ||
      !identical(as.integer(receipt$continuation_count), match(as.integer(receipt$iteration), .mi_tx_iteration_plan_v43()) - 1L) ||
      !identical(receipt$call_kind, if (as.integer(receipt$iteration) == 30L) "INITIAL_MICE" else "MICE_MIDS_CONTINUATION") ||
      !grepl("^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$", receipt$created_at)) {
    .mi_tx_stop("MI_CHECKPOINT_RECEIPT_INVALID")
  }
  expected_payload <- receipt[names(receipt) != "checkpoint_sha256"]
  expected_checkpoint_sha <- .control_sha256_text(canonical_json(expected_payload))
  if (!identical(receipt$checkpoint_sha256, expected_checkpoint_sha) ||
      !identical(receipt$object_sha256, .mi_tx_sha256_file(object_path)) ||
      !identical(trimws(readLines(file.path(checkpoint_path, "BUNDLE_COMPLETE"), warn = FALSE)), receipt$checkpoint_sha256) ||
      !identical(basename(checkpoint_path), sprintf("iter_%03d", as.integer(receipt$iteration)))) {
    .mi_tx_stop("MI_CHECKPOINT_INTEGRITY_FAILED")
  }
  expected_sums <- c(
    paste(receipt$object_sha256, "mids_checkpoint.rds"),
    paste(.mi_tx_sha256_file(receipt_path), "CHECKPOINT_RECEIPT.json")
  )
  observed_sums <- readLines(file.path(checkpoint_path, "SHA256SUMS.txt"), warn = FALSE)
  if (!identical(observed_sums, expected_sums)) .mi_tx_stop("MI_CHECKPOINT_INTEGRITY_FAILED")
  receipt$checkpoint_path <- checkpoint_path
  receipt
}

.mi_tx_checkpoint_chain <- function(transaction_path, request) {
  root <- file.path(transaction_path, "checkpoints")
  if (!dir.exists(root)) return(list())
  directories <- list.dirs(root, recursive = FALSE, full.names = TRUE)
  if (length(directories) && any(!grepl("^iter_(030|040|050|100|200)$", basename(directories)))) {
    .mi_tx_stop("MI_CHECKPOINT_DIRECTORY_INVALID")
  }
  if (!length(directories)) return(list())
  receipts <- lapply(directories[order(basename(directories))], .mi_tx_validate_checkpoint, request = request)
  iterations <- vapply(receipts, function(receipt) as.integer(receipt$iteration), integer(1))
  expected_prefix <- .mi_tx_iteration_plan_v43()[seq_along(iterations)]
  if (!identical(iterations, expected_prefix)) .mi_tx_stop("MI_CHECKPOINT_CHAIN_INVALID")
  for (index in seq_along(receipts)) {
    expected_parent <- if (index == 1L) "" else receipts[[index - 1L]]$checkpoint_sha256
    if (!identical(receipts[[index]]$parent_checkpoint_sha256, expected_parent)) {
      .mi_tx_stop("MI_CHECKPOINT_CHAIN_INVALID")
    }
  }
  receipts
}

.mi_tx_frozen_fields <- function() {
  c(
    "schema_version", "request_sha256", "final_iteration", "final_checkpoint_sha256",
    "mi_qc_receipt_sha256", "frozen_mids_sha256", "completed_list_sha256",
    "handoff_candidate_sha256", "authorization_binding_sha256",
    "authorization_receipt_sha256", "authorization_file_sha256",
    "approval_id", "approval_basis", "status",
    "created_at", "receipt_sha256"
  )
}

.mi_tx_failure_fields <- function() {
  c(
    "schema_version", "request_sha256", "desired_iteration", "failure_code",
    "message_sha256", "failure_signature", "status", "created_at", "receipt_sha256"
  )
}

.mi_tx_validate_failure <- function(path, request) {
  receipt <- .mi_tx_read_json(path)
  fields <- .mi_tx_failure_fields()
  if (!is.list(receipt) || !identical(sort(names(receipt)), sort(fields))) {
    .mi_tx_stop("MI_FAILURE_RECEIPT_INVALID")
  }
  receipt <- receipt[fields]
  if (!identical(receipt$schema_version, "1.0.0") ||
      !identical(receipt$request_sha256, request$request_sha256) ||
      !as.integer(receipt$desired_iteration) %in% .mi_tx_iteration_plan_v43() ||
      !grepl("^[A-Z][A-Z0-9_]{2,127}$", receipt$failure_code) ||
      any(!vapply(receipt[c("message_sha256", "failure_signature", "receipt_sha256")], .mi_tx_is_sha256, logical(1))) ||
      !identical(receipt$status, "FAILED_TYPED") ||
      !grepl("^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$", receipt$created_at)) {
    .mi_tx_stop("MI_FAILURE_RECEIPT_INVALID")
  }
  payload <- receipt[names(receipt) != "receipt_sha256"]
  if (!identical(receipt$receipt_sha256, .control_sha256_text(canonical_json(payload)))) {
    .mi_tx_stop("MI_FAILURE_RECEIPT_INVALID")
  }
  receipt
}

.mi_tx_validate_frozen <- function(path, request, checkpoints) {
  receipt <- .mi_tx_read_json(path)
  frozen_fields <- .mi_tx_frozen_fields()
  if (!is.list(receipt) || !identical(sort(names(receipt)), sort(frozen_fields))) {
    .mi_tx_stop("MI_FROZEN_RECEIPT_INVALID")
  }
  receipt <- receipt[frozen_fields]
  if (
      !identical(receipt$schema_version, "1.0.0") ||
      !identical(receipt$request_sha256, request$request_sha256) ||
      !as.integer(receipt$final_iteration) %in% .mi_tx_iteration_plan_v43() ||
      any(!vapply(receipt[c(
        "final_checkpoint_sha256", "mi_qc_receipt_sha256", "frozen_mids_sha256",
        "completed_list_sha256", "handoff_candidate_sha256", "authorization_binding_sha256",
        "authorization_receipt_sha256", "authorization_file_sha256", "receipt_sha256"
      )], .mi_tx_is_sha256, logical(1))) ||
      !nzchar(receipt$approval_id) ||
      !receipt$approval_basis %in% c("AUTO_GATE_PASS", "HUMAN_APPROVAL") ||
      !identical(receipt$status, "FROZEN") ||
      !grepl("^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$", receipt$created_at)) {
    .mi_tx_stop("MI_FROZEN_RECEIPT_INVALID")
  }
  payload <- receipt[names(receipt) != "receipt_sha256"]
  if (!identical(receipt$receipt_sha256, .control_sha256_text(canonical_json(payload)))) {
    .mi_tx_stop("MI_FROZEN_RECEIPT_INVALID")
  }
  matched <- vapply(checkpoints, function(checkpoint) {
    identical(checkpoint$checkpoint_sha256, receipt$final_checkpoint_sha256) &&
      identical(as.integer(checkpoint$iteration), as.integer(receipt$final_iteration))
  }, logical(1))
  if (sum(matched) != 1L) .mi_tx_stop("MI_FROZEN_CHECKPOINT_IDENTITY_INVALID")
  receipt
}

.mi_tx_lease_fields <- function() {
  c(
    "schema_version", "request_sha256", "desired_iteration", "owner_pid",
    "started_at", "updated_at", "lease_id", "receipt_sha256"
  )
}

.mi_tx_validate_lease <- function(path, request) {
  members <- if (dir.exists(path)) list.files(path, all.files = TRUE, no.. = TRUE) else character()
  if (!identical(members, "LEASE.json")) .mi_tx_stop("MI_TRANSACTION_LEASE_INVALID")
  receipt <- .mi_tx_read_json(file.path(path, "LEASE.json"))
  fields <- .mi_tx_lease_fields()
  if (!is.list(receipt) || !identical(sort(names(receipt)), sort(fields))) {
    .mi_tx_stop("MI_TRANSACTION_LEASE_INVALID")
  }
  receipt <- receipt[fields]
  if (!identical(receipt$schema_version, "1.0.0") ||
      !identical(receipt$request_sha256, request$request_sha256) ||
      !as.integer(receipt$desired_iteration) %in% .mi_tx_iteration_plan_v43() ||
      length(receipt$owner_pid) != 1L || is.na(as.integer(receipt$owner_pid)) ||
      as.integer(receipt$owner_pid) < 1L ||
      !exists(".formal_authorization_is_utc_second", mode = "function") ||
      !.formal_authorization_is_utc_second(receipt$started_at) ||
      !.formal_authorization_is_utc_second(receipt$updated_at) ||
      !.mi_tx_is_sha256(receipt$lease_id) || !.mi_tx_is_sha256(receipt$receipt_sha256)) {
    .mi_tx_stop("MI_TRANSACTION_LEASE_INVALID")
  }
  payload <- receipt[names(receipt) != "receipt_sha256"]
  if (!identical(receipt$receipt_sha256, .control_sha256_text(canonical_json(payload)))) {
    .mi_tx_stop("MI_TRANSACTION_LEASE_INVALID")
  }
  receipt
}

.mi_tx_recovery_fields <- function() {
  c(
    "schema_version", "request_sha256", "desired_iteration", "recovered_lease_sha256",
    "authorization_binding_sha256", "recovered_at", "status", "receipt_sha256"
  )
}

.mi_tx_recovery_receipts <- function(transaction_path, request, authorization_binding) {
  root <- file.path(transaction_path, "lease_recoveries")
  if (!dir.exists(root)) return(list())
  directories <- list.dirs(root, recursive = FALSE, full.names = TRUE)
  if (!length(directories)) return(list())
  lapply(directories[order(basename(directories))], function(directory) {
    lease <- .mi_tx_validate_lease(file.path(directory, "recovered_lease"), request)
    path <- file.path(directory, "RECOVERY_RECEIPT.json")
    if (!file.exists(path) || nzchar(Sys.readlink(path))) .mi_tx_stop("MI_TRANSACTION_RECOVERY_INVALID")
    receipt <- .mi_tx_read_json(path)
    fields <- .mi_tx_recovery_fields()
    if (!is.list(receipt) || !identical(sort(names(receipt)), sort(fields))) {
      .mi_tx_stop("MI_TRANSACTION_RECOVERY_INVALID")
    }
    receipt <- receipt[fields]
    payload <- receipt[names(receipt) != "receipt_sha256"]
    if (!identical(receipt$schema_version, "1.0.0") ||
        !identical(receipt$request_sha256, request$request_sha256) ||
        !identical(as.integer(receipt$desired_iteration), as.integer(lease$desired_iteration)) ||
        !identical(receipt$recovered_lease_sha256, lease$receipt_sha256) ||
        !identical(receipt$authorization_binding_sha256, authorization_binding$binding_sha256) ||
        !.formal_authorization_is_utc_second(receipt$recovered_at) ||
        !identical(receipt$status, "STALE_LEASE_RECOVERED") ||
        !.mi_tx_is_sha256(receipt$receipt_sha256) ||
        !identical(receipt$receipt_sha256, .control_sha256_text(canonical_json(payload))) ||
        !identical(basename(directory), lease$receipt_sha256)) {
      .mi_tx_stop("MI_TRANSACTION_RECOVERY_INVALID")
    }
    receipt
  })
}

.mi_tx_failure_recovery_fields <- function() {
  c(
    "schema_version", "request_sha256", "failure_signature",
    "failure_receipt_sha256", "authorization_binding_sha256",
    "repair_owner_identity_sha256", "repair_round", "recovered_at",
    "status", "receipt_sha256"
  )
}

.mi_tx_failure_recovery_receipts <- function(
    transaction_path, request, authorization_binding) {
  root <- file.path(transaction_path, "failure_recoveries")
  if (!dir.exists(root)) return(list())
  signature_roots <- list.dirs(root, recursive = FALSE, full.names = TRUE)
  if (!length(signature_roots)) return(list())
  if (any(!vapply(basename(signature_roots), .mi_tx_is_sha256, logical(1)))) {
    .mi_tx_stop("MI_FAILURE_RECOVERY_INVALID")
  }
  recovered <- lapply(signature_roots[order(basename(signature_roots))], function(signature_root) {
    rounds <- list.dirs(signature_root, recursive = FALSE, full.names = TRUE)
    if (!length(rounds) || length(rounds) > 2L ||
        any(!grepl("^round_00[12]$", basename(rounds)))) {
      .mi_tx_stop("MI_FAILURE_RECOVERY_INVALID")
    }
    lapply(rounds[order(basename(rounds))], function(directory) {
      members <- sort(list.files(directory, all.files = TRUE, no.. = TRUE))
      if (!identical(members, c("FAILURE_RECEIPT.json", "RECOVERY_RECEIPT.json"))) {
        .mi_tx_stop("MI_FAILURE_RECOVERY_INVALID")
      }
      failure <- .mi_tx_validate_failure(file.path(directory, "FAILURE_RECEIPT.json"), request)
      receipt <- .mi_tx_read_json(file.path(directory, "RECOVERY_RECEIPT.json"))
      fields <- .mi_tx_failure_recovery_fields()
      if (!is.list(receipt) || !identical(sort(names(receipt)), sort(fields))) {
        .mi_tx_stop("MI_FAILURE_RECOVERY_INVALID")
      }
      receipt <- receipt[fields]
      payload <- receipt[names(receipt) != "receipt_sha256"]
      expected_round <- as.integer(sub("^round_", "", basename(directory)))
      expected_message_sha <- .control_sha256_text("MI_FORMAL_MIDS_CHAIN_IDENTITY_INVALID")
      if (!identical(receipt$schema_version, "1.0.0") ||
          !identical(receipt$request_sha256, request$request_sha256) ||
          !identical(receipt$failure_signature, failure$failure_signature) ||
          !identical(receipt$failure_signature, basename(signature_root)) ||
          !identical(receipt$failure_receipt_sha256, failure$receipt_sha256) ||
          !identical(receipt$authorization_binding_sha256, authorization_binding$binding_sha256) ||
          !identical(as.integer(receipt$repair_round), expected_round) ||
          !identical(failure$failure_code, "MICE_STEP_ERROR") ||
          !identical(failure$message_sha256, expected_message_sha) ||
          !.mi_tx_is_sha256(receipt$repair_owner_identity_sha256) ||
          !exists(".formal_authorization_is_utc_second", mode = "function") ||
          !.formal_authorization_is_utc_second(receipt$recovered_at) ||
          !identical(receipt$status, "TECHNICAL_FAILURE_RECOVERED") ||
          !.mi_tx_is_sha256(receipt$receipt_sha256) ||
          !identical(receipt$receipt_sha256, .control_sha256_text(canonical_json(payload)))) {
        .mi_tx_stop("MI_FAILURE_RECOVERY_INVALID")
      }
      list(failure = failure, recovery = receipt)
    })
  })
  unlist(recovered, recursive = FALSE, use.names = FALSE)
}

.mi_tx_process_alive <- function(pid) {
  pid <- suppressWarnings(as.integer(pid))
  if (length(pid) != 1L || is.na(pid) || pid < 1L) return(NA)
  if (identical(pid, as.integer(Sys.getpid()))) return(TRUE)
  tryCatch(
    isTRUE(tools::pskill(pid, signal = 0L)),
    error = function(error) NA,
    warning = function(warning) NA
  )
}

inspect_mi_transaction_v43 <- function(transaction_path, request) {
  validate_mi_transaction_request_v43(request)
  .mi_tx_validate_request_directory(transaction_path, request)
  .mi_tx_require_authorization()
  authorization_binding <- .mi_tx_validate_authorization_binding(
    file.path(transaction_path, "H1_AUTHORIZATION_BINDING.json"), request
  )
  checkpoints <- .mi_tx_checkpoint_chain(transaction_path, request)
  frozen_path <- file.path(transaction_path, "FROZEN_RECEIPT.json")
  frozen <- if (file.exists(frozen_path)) .mi_tx_validate_frozen(frozen_path, request, checkpoints) else NULL
  if (!is.null(frozen) && !all(c(
    identical(frozen$authorization_binding_sha256, authorization_binding$binding_sha256),
    identical(frozen$authorization_receipt_sha256, authorization_binding$authorization_receipt_sha256),
    identical(frozen$authorization_file_sha256, authorization_binding$authorization_file_sha256),
    identical(frozen$approval_id, authorization_binding$decision_id),
    identical(frozen$approval_basis, "HUMAN_APPROVAL")
  ))) .mi_tx_stop("MI_FROZEN_AUTHORIZATION_BINDING_INVALID")
  failure_path <- file.path(transaction_path, "FAILURE_RECEIPT.json")
  failure <- if (file.exists(failure_path)) .mi_tx_validate_failure(failure_path, request) else NULL
  if (!is.null(frozen) && !is.null(failure)) .mi_tx_stop("MI_TRANSACTION_TERMINAL_CONFLICT")
  lease_path <- file.path(transaction_path, "ACTIVE.lease")
  lease <- if (dir.exists(lease_path)) .mi_tx_validate_lease(lease_path, request) else NULL
  recoveries <- .mi_tx_recovery_receipts(transaction_path, request, authorization_binding)
  failure_recoveries <- .mi_tx_failure_recovery_receipts(
    transaction_path, request, authorization_binding
  )
  highest_iteration <- if (length(checkpoints)) as.integer(tail(checkpoints, 1L)[[1L]]$iteration) else 0L
  pending_recovery <- Filter(
    function(receipt) as.integer(receipt$desired_iteration) > highest_iteration,
    recoveries
  )
  status <- if (!is.null(frozen)) {
    "FROZEN"
  } else if (!is.null(failure)) {
    "FAILED_TYPED"
  } else if (!is.null(lease)) {
    "ACTIVE"
  } else if (length(pending_recovery)) {
    "RECOVERY_READY"
  } else if (length(checkpoints)) {
    "CHECKPOINTED"
  } else {
    "UNKNOWN"
  }
  list(
    status = status,
    highest_iteration = highest_iteration,
    checkpoints = checkpoints,
    frozen = frozen,
    failure = failure,
    lease_path = lease_path,
    lease = lease,
    recoveries = recoveries,
    failure_recoveries = failure_recoveries,
    pending_recovery = if (length(pending_recovery)) tail(pending_recovery, 1L)[[1L]] else NULL,
    authorization_binding = authorization_binding
  )
}

.mi_tx_acquire_lease <- function(transaction_path, request, desired_iteration) {
  lease <- file.path(transaction_path, "ACTIVE.lease")
  staging <- tempfile(pattern = ".lease_staging_", tmpdir = transaction_path)
  if (!isTRUE(dir.create(staging, showWarnings = FALSE, mode = "0700"))) {
    .mi_tx_stop("MI_TRANSACTION_LEASE_STAGING_FAILED")
  }
  on.exit(if (dir.exists(staging)) unlink(staging, recursive = TRUE), add = TRUE)
  now <- format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  payload <- list(
    schema_version = "1.0.0",
    request_sha256 = request$request_sha256,
    desired_iteration = as.integer(desired_iteration),
    owner_pid = as.integer(Sys.getpid()),
    started_at = now,
    updated_at = now,
    lease_id = .control_sha256_text(c(
      request$request_sha256, as.character(desired_iteration), as.character(Sys.getpid()),
      now, basename(staging)
    ))
  )
  receipt <- payload
  receipt$receipt_sha256 <- .control_sha256_text(canonical_json(payload))
  # 中文备注：先在 staging 中原子写入 owned lease receipt，再发布唯一 ACTIVE lease。
  .control_write_atomic(file.path(staging, "LEASE.json"), canonical_json(receipt), mode = "0600")
  if (!file.rename(staging, lease)) .mi_tx_stop("MI_TRANSACTION_ACTIVE")
  list(path = lease, receipt = .mi_tx_validate_lease(lease, request))
}

admit_mi_transaction_v43 <- function(
    transaction_root, request, desired_iteration, authorization,
    authorization_file_sha256, project_root = ".") {
  validate_mi_transaction_request_v43(request)
  desired_iteration <- as.integer(desired_iteration)
  if (length(desired_iteration) != 1L || is.na(desired_iteration) ||
      !desired_iteration %in% .mi_tx_iteration_plan_v43()) {
    .mi_tx_stop("MI_DESIRED_ITERATION_INVALID")
  }
  transaction_root <- .mi_tx_assert_root(transaction_root)
  transaction_path <- file.path(transaction_root, request$request_sha256)
  existed <- dir.exists(transaction_path)
  if (!existed && desired_iteration != 30L) .mi_tx_stop("MI_CONTINUATION_SEQUENCE_INVALID")
  if (!existed) transaction_path <- .mi_tx_publish_request(transaction_root, request)
  .mi_tx_validate_request_directory(transaction_path, request)
  authorization_binding <- .mi_tx_bind_authorization(
    transaction_path, request, authorization, authorization_file_sha256, project_root
  )
  if (!existed) {
    lease <- .mi_tx_acquire_lease(transaction_path, request, desired_iteration)
    return(list(
      action = "START_INITIAL", transaction_path = transaction_path,
      lease_path = lease$path, lease = lease$receipt, desired_iteration = desired_iteration,
      request = request, authorization_binding = authorization_binding
    ))
  }
  state <- inspect_mi_transaction_v43(transaction_path, request)
  if (identical(state$status, "FROZEN")) {
    return(list(
      action = "FROZEN", transaction_path = transaction_path, lease_path = state$lease_path,
      desired_iteration = desired_iteration, request = request, frozen = state$frozen
    ))
  }
  if (identical(state$status, "FAILED_TYPED")) {
    return(list(
      action = "FAILED_TYPED", transaction_path = transaction_path, lease_path = state$lease_path,
      desired_iteration = desired_iteration, request = request, failure = state$failure
    ))
  }
  if (identical(state$status, "ACTIVE")) {
    return(list(
      action = "ACTIVE", transaction_path = transaction_path, lease_path = state$lease_path,
      lease = state$lease, desired_iteration = desired_iteration, request = request,
      authorization_binding = state$authorization_binding
    ))
  }
  if (identical(state$status, "RECOVERY_READY")) {
    if (!identical(as.integer(state$pending_recovery$desired_iteration), desired_iteration)) {
      .mi_tx_stop("MI_RECOVERY_ITERATION_MISMATCH")
    }
    action <- if (desired_iteration == 30L) "START_INITIAL" else "START_CONTINUATION"
    lease <- .mi_tx_acquire_lease(transaction_path, request, desired_iteration)
    admission <- list(
      action = action, transaction_path = transaction_path, lease_path = lease$path,
      lease = lease$receipt, desired_iteration = desired_iteration, request = request,
      authorization_binding = state$authorization_binding
    )
    if (identical(action, "START_CONTINUATION")) {
      admission$checkpoint <- tail(state$checkpoints, 1L)[[1L]]
    }
    return(admission)
  }
  if (identical(state$status, "UNKNOWN")) {
    return(list(
      action = "RECONCILIATION_REQUIRED", transaction_path = transaction_path,
      lease_path = state$lease_path, desired_iteration = desired_iteration, request = request
    ))
  }
  iterations <- vapply(state$checkpoints, function(receipt) as.integer(receipt$iteration), integer(1))
  if (desired_iteration %in% iterations) {
    checkpoint <- state$checkpoints[[match(desired_iteration, iterations)]]
    return(list(
      action = "REUSE_CHECKPOINT", transaction_path = transaction_path,
      lease_path = state$lease_path, desired_iteration = desired_iteration,
      request = request, checkpoint = checkpoint
    ))
  }
  expected_next <- c(`30` = 40L, `40` = 50L, `50` = 100L, `100` = 200L)[[as.character(state$highest_iteration)]]
  if (is.null(expected_next) || !identical(desired_iteration, expected_next)) {
    .mi_tx_stop("MI_CONTINUATION_SEQUENCE_INVALID")
  }
  lease <- .mi_tx_acquire_lease(transaction_path, request, desired_iteration)
  list(
    action = "START_CONTINUATION", transaction_path = transaction_path,
    lease_path = lease$path, lease = lease$receipt, desired_iteration = desired_iteration,
    request = request, checkpoint = tail(state$checkpoints, 1L)[[1L]],
    authorization_binding = state$authorization_binding
  )
}

.publish_mi_checkpoint_v43 <- function(
    admission, object, iteration, predictor_matrix_sha256, predictor_edge_n,
    object_class = class(object)[[1L]]) {
  .mi_tx_require_control_kernel()
  if (!is.list(admission) || !admission$action %in% c("START_INITIAL", "START_CONTINUATION") ||
      !dir.exists(admission$lease_path)) {
    .mi_tx_stop("MI_CHECKPOINT_ADMISSION_INVALID")
  }
  request <- admission$request
  validate_mi_transaction_request_v43(request)
  iteration <- as.integer(iteration)
  if (!identical(iteration, as.integer(admission$desired_iteration))) .mi_tx_stop("MI_CHECKPOINT_ITERATION_MISMATCH")
  if (!.mi_tx_is_sha256(predictor_matrix_sha256) ||
      as.integer(predictor_edge_n) < 1L ||
      as.integer(predictor_edge_n) > as.integer(request$candidate_edge_n)) {
    .mi_tx_stop("MI_CHECKPOINT_PREDICTOR_IDENTITY_INVALID")
  }
  checkpoints <- .mi_tx_checkpoint_chain(admission$transaction_path, request)
  expected_parent <- if (length(checkpoints)) tail(checkpoints, 1L)[[1L]]$checkpoint_sha256 else ""
  expected_previous <- c(`30` = 0L, `40` = 30L, `50` = 40L, `100` = 50L, `200` = 100L)[[as.character(iteration)]]
  highest <- if (length(checkpoints)) as.integer(tail(checkpoints, 1L)[[1L]]$iteration) else 0L
  if (is.null(expected_previous) || !identical(highest, expected_previous)) {
    .mi_tx_stop("MI_CHECKPOINT_CHAIN_INVALID")
  }
  checkpoint_root <- file.path(admission$transaction_path, "checkpoints")
  dir.create(checkpoint_root, recursive = TRUE, showWarnings = FALSE, mode = "0700")
  target <- file.path(checkpoint_root, sprintf("iter_%03d", iteration))
  if (dir.exists(target)) .mi_tx_stop("MI_CHECKPOINT_RESULT_CONFLICT")
  staging <- tempfile(pattern = ".checkpoint_staging_", tmpdir = checkpoint_root)
  if (!dir.create(staging, mode = "0700")) .mi_tx_stop("MI_CHECKPOINT_STAGING_FAILED")
  on.exit(if (dir.exists(staging)) unlink(staging, recursive = TRUE), add = TRUE)
  object_path <- file.path(staging, "mids_checkpoint.rds")
  # 中文备注：保存受限 formal MICE checkpoint；该对象永久排除于 public/review/release。
  saveRDS(object, object_path, version = 3, compress = "gzip")
  object_sha <- .mi_tx_sha256_file(object_path)
  payload <- list(
    schema_version = "1.0.0",
    request_sha256 = request$request_sha256,
    iteration = iteration,
    parent_checkpoint_sha256 = expected_parent,
    object_sha256 = object_sha,
    object_class = as.character(object_class),
    predictor_matrix_sha256 = predictor_matrix_sha256,
    predictor_edge_n = as.integer(predictor_edge_n),
    m = as.integer(request$m),
    continuation_count = match(iteration, .mi_tx_iteration_plan_v43()) - 1L,
    call_kind = if (iteration == 30L) "INITIAL_MICE" else "MICE_MIDS_CONTINUATION",
    created_at = format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  )
  receipt <- payload
  receipt$checkpoint_sha256 <- .control_sha256_text(canonical_json(payload))
  receipt_path <- file.path(staging, "CHECKPOINT_RECEIPT.json")
  .control_write_atomic(receipt_path, canonical_json(receipt), mode = "0600")
  sums <- c(
    paste(object_sha, "mids_checkpoint.rds"),
    paste(.mi_tx_sha256_file(receipt_path), "CHECKPOINT_RECEIPT.json")
  )
  .control_write_atomic(file.path(staging, "SHA256SUMS.txt"), paste(sums, collapse = "\n"), mode = "0600")
  .control_write_atomic(file.path(staging, "BUNDLE_COMPLETE"), receipt$checkpoint_sha256, mode = "0600")
  if (!file.rename(staging, target)) .mi_tx_stop("MI_CHECKPOINT_ATOMIC_PUBLISH_FAILED")
  validated <- .mi_tx_validate_checkpoint(target, request)
  if (unlink(admission$lease_path, recursive = TRUE) != 0L) .mi_tx_stop("MI_TRANSACTION_LEASE_RELEASE_FAILED")
  validated
}

publish_mi_frozen_terminal_v43 <- function(
    transaction_path, request, final_checkpoint_sha256, final_iteration,
    mi_qc_receipt_sha256, frozen_mids_sha256, completed_list_sha256,
    handoff_candidate_sha256, approval_id, approval_basis) {
  .mi_tx_require_control_kernel()
  state <- inspect_mi_transaction_v43(transaction_path, request)
  path <- file.path(transaction_path, "FROZEN_RECEIPT.json")
  if (identical(state$status, "ACTIVE")) .mi_tx_stop("MI_FROZEN_WHILE_ACTIVE_FORBIDDEN")
  requested_identity <- list(
    final_iteration = as.integer(final_iteration),
    final_checkpoint_sha256 = final_checkpoint_sha256,
    mi_qc_receipt_sha256 = mi_qc_receipt_sha256,
    frozen_mids_sha256 = frozen_mids_sha256,
    completed_list_sha256 = completed_list_sha256,
    handoff_candidate_sha256 = handoff_candidate_sha256,
    authorization_binding_sha256 = state$authorization_binding$binding_sha256,
    authorization_receipt_sha256 = state$authorization_binding$authorization_receipt_sha256,
    authorization_file_sha256 = state$authorization_binding$authorization_file_sha256,
    approval_id = as.character(approval_id),
    approval_basis = as.character(approval_basis)
  )
  if (identical(state$status, "FROZEN")) {
    observed_identity <- state$frozen[names(requested_identity)]
    if (!identical(observed_identity, requested_identity)) .mi_tx_stop("MI_FROZEN_RESULT_CONFLICT")
    return(state$frozen)
  }
  payload <- list(
    schema_version = "1.0.0",
    request_sha256 = request$request_sha256,
    final_iteration = as.integer(final_iteration),
    final_checkpoint_sha256 = final_checkpoint_sha256,
    mi_qc_receipt_sha256 = mi_qc_receipt_sha256,
    frozen_mids_sha256 = frozen_mids_sha256,
    completed_list_sha256 = completed_list_sha256,
    handoff_candidate_sha256 = handoff_candidate_sha256,
    authorization_binding_sha256 = state$authorization_binding$binding_sha256,
    authorization_receipt_sha256 = state$authorization_binding$authorization_receipt_sha256,
    authorization_file_sha256 = state$authorization_binding$authorization_file_sha256,
    approval_id = as.character(approval_id),
    approval_basis = as.character(approval_basis),
    status = "FROZEN",
    created_at = format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  )
  receipt <- payload
  receipt$receipt_sha256 <- .control_sha256_text(canonical_json(payload))
  if (file.exists(path)) {
    existing <- .mi_tx_validate_frozen(path, request, state$checkpoints)
    if (!identical(existing[names(requested_identity)], requested_identity)) {
      .mi_tx_stop("MI_FROZEN_RESULT_CONFLICT")
    }
    return(existing)
  }
  .control_write_atomic(path, canonical_json(receipt), mode = "0600")
  .mi_tx_validate_frozen(path, request, state$checkpoints)
}

publish_mi_failure_terminal_v43 <- function(admission, failure_code, message) {
  .mi_tx_require_control_kernel()
  if (!is.list(admission) || !admission$action %in% c("START_INITIAL", "START_CONTINUATION") ||
      !dir.exists(admission$lease_path) ||
      !grepl("^[A-Z][A-Z0-9_]{2,127}$", failure_code)) {
    .mi_tx_stop("MI_FAILURE_ADMISSION_INVALID")
  }
  message_sha <- .control_sha256_text(enc2utf8(as.character(message)))
  failure_signature <- .control_sha256_text(canonical_json(list(
    request_sha256 = admission$request$request_sha256,
    desired_iteration = as.integer(admission$desired_iteration),
    failure_code = failure_code,
    message_sha256 = message_sha
  )))
  payload <- list(
    schema_version = "1.0.0",
    request_sha256 = admission$request$request_sha256,
    desired_iteration = as.integer(admission$desired_iteration),
    failure_code = failure_code,
    message_sha256 = message_sha,
    failure_signature = failure_signature,
    status = "FAILED_TYPED",
    created_at = format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  )
  receipt <- payload
  receipt$receipt_sha256 <- .control_sha256_text(canonical_json(payload))
  path <- file.path(admission$transaction_path, "FAILURE_RECEIPT.json")
  if (file.exists(path)) {
    existing <- .mi_tx_validate_failure(path, admission$request)
    if (!identical(existing, receipt)) .mi_tx_stop("MI_FAILURE_RESULT_CONFLICT")
  } else {
    .control_write_atomic(path, canonical_json(receipt), mode = "0600")
  }
  if (unlink(admission$lease_path, recursive = TRUE) != 0L) .mi_tx_stop("MI_TRANSACTION_LEASE_RELEASE_FAILED")
  .mi_tx_validate_failure(path, admission$request)
}

reconcile_mi_transaction_v43 <- function(transaction_path, request) {
  state <- inspect_mi_transaction_v43(transaction_path, request)
  if (!identical(state$status, "UNKNOWN")) {
    return(list(status = paste0("DERIVED_", state$status), highest_iteration = state$highest_iteration))
  }
  checkpoint_root <- file.path(transaction_path, "checkpoints")
  partial <- if (dir.exists(checkpoint_root)) {
    list.dirs(checkpoint_root, recursive = FALSE, full.names = FALSE)
  } else character()
  status <- if (length(partial)) {
    "UNKNOWN_PARTIAL_STAGING_QUARANTINE_REQUIRED"
  } else {
    "UNKNOWN_NO_RECOVERABLE_CHECKPOINT"
  }
  list(status = status, highest_iteration = 0L)
}

.mi_tx_repair_owner_identity_v43 <- function(project_root = ".") {
  owner_paths <- c("R/formal_mice_engine.R", "R/mi_transaction_engine.R")
  owner_files <- file.path(project_root, owner_paths)
  if (any(!file.exists(owner_files) | file.info(owner_files)$isdir)) {
    .mi_tx_stop("MI_FAILURE_REPAIR_OWNER_MISSING")
  }
  .control_sha256_text(
    paste(owner_paths, vapply(owner_files, .mi_tx_sha256_file, character(1)), sep = "=")
  )
}

recover_mi_chain_identity_failure_v43 <- function(
    transaction_path, request, authorization, authorization_file_sha256,
    expected_failure_signature, project_root = ".") {
  validate_mi_transaction_authorization_v43(
    transaction_path, request, authorization, authorization_file_sha256, project_root
  )
  state <- inspect_mi_transaction_v43(transaction_path, request)
  if (!identical(state$status, "FAILED_TYPED") || is.null(state$failure)) {
    return(list(status = paste0("DERIVED_", state$status), highest_iteration = state$highest_iteration))
  }
  failure <- state$failure
  expected_message_sha <- .control_sha256_text("MI_FORMAL_MIDS_CHAIN_IDENTITY_INVALID")
  expected_next <- c(`30` = 40L, `40` = 50L, `50` = 100L, `100` = 200L)[[as.character(state$highest_iteration)]]
  if (!.mi_tx_is_sha256(expected_failure_signature) ||
      !identical(failure$failure_signature, expected_failure_signature) ||
      !identical(failure$failure_code, "MICE_STEP_ERROR") ||
      !identical(failure$message_sha256, expected_message_sha) ||
      is.null(expected_next) ||
      !identical(as.integer(failure$desired_iteration), expected_next)) {
    .mi_tx_stop("MI_FAILURE_RECOVERY_NOT_AUTHORIZED")
  }
  prior <- Filter(
    function(item) identical(item$failure$failure_signature, failure$failure_signature),
    state$failure_recoveries
  )
  repair_round <- length(prior) + 1L
  if (repair_round > 2L) .mi_tx_stop("MI_FAILURE_REPAIR_LIMIT_EXHAUSTED")
  repair_owner_identity <- .mi_tx_repair_owner_identity_v43(project_root)
  signature_root <- file.path(
    transaction_path, "failure_recoveries", failure$failure_signature
  )
  dir.create(signature_root, recursive = TRUE, showWarnings = FALSE, mode = "0700")
  if (!dir.exists(signature_root) || nzchar(Sys.readlink(signature_root))) {
    .mi_tx_stop("MI_FAILURE_RECOVERY_ROOT_INVALID")
  }
  target <- file.path(signature_root, sprintf("round_%03d", repair_round))
  if (dir.exists(target) || file.exists(target)) .mi_tx_stop("MI_FAILURE_RECOVERY_CONFLICT")
  staging <- tempfile(pattern = ".failure_recovery_staging_", tmpdir = signature_root)
  if (!dir.create(staging, mode = "0700")) .mi_tx_stop("MI_FAILURE_RECOVERY_STAGING_FAILED")
  moved_failure <- file.path(staging, "FAILURE_RECEIPT.json")
  source_failure <- file.path(transaction_path, "FAILURE_RECEIPT.json")
  moved <- FALSE
  on.exit({
    if (moved && file.exists(moved_failure) && !file.exists(source_failure)) {
      file.rename(moved_failure, source_failure)
    }
    if (dir.exists(staging)) unlink(staging, recursive = TRUE)
  }, add = TRUE)
  if (!file.rename(source_failure, moved_failure)) {
    .mi_tx_stop("MI_FAILURE_RECOVERY_MOVE_FAILED")
  }
  moved <- TRUE
  payload <- list(
    schema_version = "1.0.0",
    request_sha256 = request$request_sha256,
    failure_signature = failure$failure_signature,
    failure_receipt_sha256 = failure$receipt_sha256,
    authorization_binding_sha256 = state$authorization_binding$binding_sha256,
    repair_owner_identity_sha256 = repair_owner_identity,
    repair_round = as.integer(repair_round),
    recovered_at = format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
    status = "TECHNICAL_FAILURE_RECOVERED"
  )
  receipt <- payload
  receipt$receipt_sha256 <- .control_sha256_text(canonical_json(payload))
  .control_write_atomic(
    file.path(staging, "RECOVERY_RECEIPT.json"), canonical_json(receipt), mode = "0600"
  )
  if (!file.rename(staging, target)) .mi_tx_stop("MI_FAILURE_RECOVERY_ATOMIC_PUBLISH_FAILED")
  moved <- FALSE
  recovered <- .mi_tx_failure_recovery_receipts(
    transaction_path, request, state$authorization_binding
  )
  if (length(recovered) != length(state$failure_recoveries) + 1L) {
    .mi_tx_stop("MI_FAILURE_RECOVERY_INVALID")
  }
  list(
    status = "TECHNICAL_FAILURE_RECOVERED",
    repair_round = as.integer(repair_round),
    highest_iteration = state$highest_iteration,
    desired_iteration = as.integer(failure$desired_iteration)
  )
}

recover_mi_transaction_lease_v43 <- function(
    transaction_path, request, authorization, authorization_file_sha256,
    expected_lease_sha256, project_root = ".") {
  validate_mi_transaction_authorization_v43(
    transaction_path, request, authorization, authorization_file_sha256, project_root
  )
  state <- inspect_mi_transaction_v43(transaction_path, request)
  if (!identical(state$status, "ACTIVE") || is.null(state$lease)) {
    return(list(status = paste0("DERIVED_", state$status), highest_iteration = state$highest_iteration))
  }
  if (!.mi_tx_is_sha256(expected_lease_sha256) ||
      !identical(state$lease$receipt_sha256, expected_lease_sha256)) {
    .mi_tx_stop("MI_TRANSACTION_RECOVERY_LEASE_IDENTITY_MISMATCH")
  }
  alive <- .mi_tx_process_alive(state$lease$owner_pid)
  if (!identical(alive, FALSE)) .mi_tx_stop("MI_TRANSACTION_ACTIVE")
  root <- file.path(transaction_path, "lease_recoveries")
  dir.create(root, recursive = TRUE, showWarnings = FALSE, mode = "0700")
  target <- file.path(root, expected_lease_sha256)
  if (dir.exists(target)) .mi_tx_stop("MI_TRANSACTION_RECOVERY_CONFLICT")
  staging <- tempfile(pattern = ".recovery_staging_", tmpdir = root)
  if (!dir.create(staging, mode = "0700")) .mi_tx_stop("MI_TRANSACTION_RECOVERY_STAGING_FAILED")
  on.exit(if (dir.exists(staging)) unlink(staging, recursive = TRUE), add = TRUE)
  recovered_lease <- file.path(staging, "recovered_lease")
  if (!file.rename(state$lease_path, recovered_lease)) {
    .mi_tx_stop("MI_TRANSACTION_RECOVERY_LEASE_MOVE_FAILED")
  }
  moved <- TRUE
  on.exit({
    if (moved && dir.exists(recovered_lease) && !dir.exists(state$lease_path)) {
      file.rename(recovered_lease, state$lease_path)
    }
  }, add = TRUE)
  recovered_at <- format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  payload <- list(
    schema_version = "1.0.0",
    request_sha256 = request$request_sha256,
    desired_iteration = as.integer(state$lease$desired_iteration),
    recovered_lease_sha256 = expected_lease_sha256,
    authorization_binding_sha256 = state$authorization_binding$binding_sha256,
    recovered_at = recovered_at,
    status = "STALE_LEASE_RECOVERED"
  )
  receipt <- payload
  receipt$receipt_sha256 <- .control_sha256_text(canonical_json(payload))
  # 中文备注：原子写入 stale lease 恢复收据，不终止任何来源不明进程。
  .control_write_atomic(
    file.path(staging, "RECOVERY_RECEIPT.json"), canonical_json(receipt), mode = "0600"
  )
  if (!file.rename(staging, target)) .mi_tx_stop("MI_TRANSACTION_RECOVERY_ATOMIC_PUBLISH_FAILED")
  moved <- FALSE
  validated <- .mi_tx_recovery_receipts(
    transaction_path, request, state$authorization_binding
  )
  list(
    status = "RECOVERY_READY",
    desired_iteration = as.integer(state$lease$desired_iteration),
    recovered_lease_sha256 = expected_lease_sha256,
    recovery_receipt_sha256 = tail(validated, 1L)[[1L]]$receipt_sha256
  )
}
