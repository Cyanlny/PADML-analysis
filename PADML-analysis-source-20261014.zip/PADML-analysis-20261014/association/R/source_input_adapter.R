# 可替换原始数据入口：Excel 只进入上游候选构建层，正式分析仍只读取批准 handoff。

.source_stop <- function(code, detail = "") {
  message <- if (nzchar(detail)) paste(code, detail, sep = ": ") else code
  stop(message, call. = FALSE)
}

.source_sha256_file <- function(path) {
  # 中文备注：加载摘要包以在读取工作簿之前验证不可变文件身份。
  if (!requireNamespace("digest", quietly = TRUE)) .source_stop("SOURCE_DEPENDENCY_MISSING", "digest")
  digest::digest(file = path, algo = "sha256", serialize = FALSE)
}

.source_sha256_text <- function(text) {
  # 中文备注：加载摘要包并计算不含路径与患者明文的规范文本身份。
  if (!requireNamespace("digest", quietly = TRUE)) .source_stop("SOURCE_DEPENDENCY_MISSING", "digest")
  digest::digest(enc2utf8(paste(text, collapse = "\n")), algo = "sha256", serialize = FALSE)
}

.source_hash_data_frame <- function(data) {
  # 中文备注：加载 JSON 包，将 registry 规范化后计算内容身份。
  if (!requireNamespace("jsonlite", quietly = TRUE)) .source_stop("SOURCE_DEPENDENCY_MISSING", "jsonlite")
  normalized <- data
  normalized[] <- lapply(normalized, function(value) {
    value <- as.character(value)
    value[is.na(value)] <- "<NA>"
    enc2utf8(value)
  })
  .source_sha256_text(jsonlite::toJSON(normalized, dataframe = "rows", auto_unbox = TRUE, pretty = FALSE))
}

.source_hash_object <- function(object) {
  # 加载 JSON 包，将收据规范化为稳定内容身份。
  if (!requireNamespace("jsonlite", quietly = TRUE)) .source_stop("SOURCE_DEPENDENCY_MISSING", "jsonlite")
  .source_sha256_text(jsonlite::toJSON(
    object, auto_unbox = TRUE, pretty = FALSE, null = "null", na = "null", digits = NA
  ))
}

.source_csv <- function(root, name) {
  path <- file.path(root, "config", name)
  if (!file.exists(path)) .source_stop("SOURCE_REGISTRY_MISSING", name)
  utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE, na.strings = "")
}

read_source_dataset_registry <- function(root = ".") {
  registry <- .source_csv(root, "source_dataset_registry.csv")
  required <- c(
    "source_id", "source_revision", "path_env", "expected_sha256", "sheet_name", "header_row",
    "expected_row_n", "expected_column_n", "expected_header_sha256", "source_classification",
    "allowed_modes", "row_order_rule", "preprocessing_policy_id", "mi_recipe_id", "active"
  )
  if (!identical(names(registry), required)) .source_stop("SOURCE_REGISTRY_SCHEMA_INVALID")
  if (!nrow(registry) || anyDuplicated(registry$source_id)) .source_stop("SOURCE_REGISTRY_KEY_INVALID")
  if (any(grepl("^/|^[A-Za-z]:[/\\\\]", registry$path_env))) .source_stop("SOURCE_REGISTRY_ABSOLUTE_PATH_FORBIDDEN")
  if (any(!grepl("^[A-Z][A-Z0-9_]*$", registry$path_env))) .source_stop("SOURCE_REGISTRY_ENV_INVALID")
  if (any(!grepl("^[0-9a-f]{64}$", registry$expected_sha256)) ||
      any(!grepl("^[0-9a-f]{64}$", registry$expected_header_sha256))) {
    .source_stop("SOURCE_REGISTRY_SHA256_INVALID")
  }
  active <- registry$active %in% TRUE
  if (sum(active) != 1L) .source_stop("SOURCE_ACTIVE_REGISTRY_CARDINALITY_INVALID")
  if (!identical(registry$source_classification[active], "PATIENT_LEVEL_RESTRICTED")) {
    .source_stop("SOURCE_CLASSIFICATION_INVALID")
  }
  registry
}

select_source_registry_row <- function(registry, source_id) {
  rows <- registry[registry$source_id == source_id & registry$active %in% TRUE, , drop = FALSE]
  if (nrow(rows) != 1L) .source_stop("SOURCE_ID_NOT_ACTIVE")
  rows
}

read_source_column_mapping_registry <- function(root = ".") {
  mapping <- .source_csv(root, "source_column_mapping_registry.csv")
  required <- c(
    "target_position", "target_name", "source_name", "mapping_kind", "expected_r_class",
    "ordered", "levels", "nullable", "decision_source"
  )
  if (!identical(names(mapping), required)) .source_stop("SOURCE_MAPPING_SCHEMA_INVALID")
  mapping$target_position <- as.integer(mapping$target_position)
  if (!nrow(mapping) || anyDuplicated(mapping$target_name) ||
      !identical(mapping$target_position, seq_len(nrow(mapping)))) {
    .source_stop("SOURCE_MAPPING_KEY_INVALID")
  }
  allowed_kinds <- c("DIRECT", "DIRECT_NUMERIC", "FACTOR", "FACTOR_LABEL", "CANONICAL_FACTOR", "PASSIVE_FORMULA")
  if (any(!mapping$mapping_kind %in% allowed_kinds)) .source_stop("SOURCE_MAPPING_KIND_INVALID")
  mapping
}

read_source_preprocessing_registry <- function(root = ".") {
  registry <- .source_csv(root, "source_preprocessing_registry.csv")
  required <- c(
    "policy_id", "execution_order", "rule_id", "variable", "operation", "parameter_1",
    "parameter_2", "decision_source", "approval_status"
  )
  if (!identical(names(registry), required)) .source_stop("SOURCE_PREPROCESSING_SCHEMA_INVALID")
  registry$execution_order <- as.integer(registry$execution_order)
  if (!nrow(registry) || anyDuplicated(paste(registry$policy_id, registry$rule_id, sep = "|"))) {
    .source_stop("SOURCE_PREPROCESSING_KEY_INVALID")
  }
  registry <- registry[order(registry$policy_id, registry$execution_order), , drop = FALSE]
  validate_source_preprocessing_contract(registry)
  registry
}

validate_source_preprocessing_contract <- function(registry) {
  expected <- data.frame(
    execution_order = seq_len(13L),
    rule_id = c(
      "ELIGIBLE_AST_ALT", "HEIGHT_91_TO_NA", "WEIGHT_16_TO_NA", "SBP_OUTSIDE_RANGE",
      "DBP_OUTSIDE_RANGE", "BP_PAIR_INVALID_TO_NA", "HR_RR_FIVE_BRANCH", "PT_DECIMAL_SHIFT",
      "PT_INVALID_LOW_TO_NA", "ANEMIA_BINARY", "HYPERHCY_BINARY", "CANONICAL_MAPPING",
      "PASSIVE_RECALCULATION"
    ),
    operation = c(
      "FILTER_EXPOSURE_ELIGIBLE", "SET_EXACT_VALUE_TO_NA", "SET_EXACT_VALUE_TO_NA",
      "SET_OUTSIDE_RANGE_TO_NA", "SET_OUTSIDE_RANGE_TO_NA", "SET_PAIR_TO_NA_IF_SBP_LE_DBP",
      "APPLY_HR_RR_STATE_MACHINE", "MAP_EXACT_VALUES_TO_VALUES", "SET_EXACT_VALUES_TO_NA",
      "RECODE_ZERO_VS_POSITIVE", "RECODE_ZERO_VS_POSITIVE", "APPLY_LOCKED_CANONICAL_MAPPING",
      "RECALCULATE_FROM_LOCKED_FORMULA_REGISTRY"
    ),
    stringsAsFactors = FALSE
  )
  if (nrow(registry) != nrow(expected) ||
      !identical(as.integer(registry$execution_order), expected$execution_order) ||
      !identical(registry$rule_id, expected$rule_id) ||
      !identical(registry$operation, expected$operation)) {
    .source_stop("SOURCE_PREPROCESSING_IMPLEMENTATION_CONTRACT_MISMATCH")
  }
  if (length(unique(registry$policy_id)) != 1L || !identical(unique(registry$policy_id), "SRC_PREP_V43_V1")) {
    .source_stop("SOURCE_PREPROCESSING_POLICY_INVALID")
  }
  invisible(TRUE)
}

read_source_passive_formula_registry <- function(root = ".") {
  registry <- .source_csv(root, "source_passive_formula_registry.csv")
  required <- c("execution_order", "target_name", "operation", "source_names", "denominator_rule")
  if (!identical(names(registry), required)) .source_stop("SOURCE_FORMULA_SCHEMA_INVALID")
  registry$execution_order <- as.integer(registry$execution_order)
  if (!nrow(registry) || anyDuplicated(registry$target_name)) .source_stop("SOURCE_FORMULA_KEY_INVALID")
  registry[order(registry$execution_order, seq_len(nrow(registry))), , drop = FALSE]
}

resolve_source_path <- function(cli_path = "", env_path = Sys.getenv("AST_ALT_SOURCE_XLSX", "")) {
  cli_path <- trimws(ifelse(is.na(cli_path), "", cli_path))
  env_path <- trimws(ifelse(is.na(env_path), "", env_path))
  if (nzchar(cli_path) && nzchar(env_path) && !identical(cli_path, env_path)) {
    .source_stop("SOURCE_PATH_AMBIGUOUS")
  }
  path <- if (nzchar(cli_path)) cli_path else env_path
  if (!nzchar(path)) .source_stop("SOURCE_PATH_REQUIRED")
  path
}

preflight_source_file <- function(path, expected_sha256) {
  if (!file.exists(path)) .source_stop("SOURCE_FILE_NOT_FOUND")
  info <- file.info(path)
  if (is.na(info$isdir) || isTRUE(info$isdir)) .source_stop("SOURCE_FILE_NOT_REGULAR")
  if (!grepl("\\.xlsx$", path, ignore.case = TRUE)) .source_stop("SOURCE_EXTENSION_INVALID")
  observed <- .source_sha256_file(path)
  if (!identical(observed, expected_sha256)) .source_stop("SOURCE_SHA256_MISMATCH")
  list(
    sha256 = observed,
    size_bytes = unname(as.numeric(info$size)),
    mtime_utc = format(info$mtime, "%Y-%m-%dT%H:%M:%OS6Z", tz = "UTC")
  )
}

.split_pipe <- function(value) {
  if (length(value) != 1L || is.na(value) || !nzchar(value)) return(character())
  strsplit(value, "|", fixed = TRUE)[[1L]]
}

required_source_columns <- function(mapping) {
  unique(unlist(lapply(mapping$source_name, .split_pipe), use.names = FALSE))
}

.strict_numeric <- function(value, variable) {
  if (is.numeric(value) || is.integer(value)) return(as.numeric(value))
  raw <- as.character(value)
  raw[!nzchar(trimws(raw))] <- NA_character_
  converted <- suppressWarnings(as.numeric(raw))
  if (any(!is.na(raw) & is.na(converted))) .source_stop("SOURCE_NUMERIC_PARSE_FAILED", variable)
  converted
}

.strict_code <- function(value, allowed, variable) {
  code <- trimws(as.character(value))
  code[is.na(value) | !nzchar(code)] <- NA_character_
  bad <- !is.na(code) & !code %in% allowed
  if (any(bad)) .source_stop("SOURCE_LEVEL_INVALID", variable)
  code
}

.source_header_sha <- function(names_value) .source_sha256_text(names_value)

validate_source_frame <- function(data, registry_row, mapping) {
  if (!is.data.frame(data)) .source_stop("SOURCE_FRAME_INVALID")
  if (any(is.na(names(data)) | !nzchar(names(data))) || anyDuplicated(names(data))) {
    .source_stop("SOURCE_HEADER_INVALID")
  }
  if (nrow(data) != as.integer(registry_row$expected_row_n[[1L]]) ||
      ncol(data) != as.integer(registry_row$expected_column_n[[1L]])) {
    .source_stop("SOURCE_DIMENSION_MISMATCH")
  }
  if (!identical(.source_header_sha(names(data)), registry_row$expected_header_sha256[[1L]])) {
    .source_stop("SOURCE_HEADER_SHA256_MISMATCH")
  }
  missing <- setdiff(required_source_columns(mapping), names(data))
  if (length(missing)) .source_stop("SOURCE_REQUIRED_COLUMNS_MISSING", paste(missing, collapse = "|"))
  ids <- as.character(data$Patient_ID)
  if (any(is.na(ids) | !nzchar(trimws(ids)))) .source_stop("SOURCE_PATIENT_ID_MISSING")
  if (anyDuplicated(ids)) .source_stop("SOURCE_PATIENT_ID_DUPLICATE")
  ast <- .strict_numeric(data$AST, "AST")
  alt <- .strict_numeric(data$ALT, "ALT")
  data.frame(
    qc_item = c("row_n", "column_n", "header_sha256", "required_columns", "patient_id_complete_unique", "ast_alt_parse"),
    observed = c(nrow(data), ncol(data), .source_header_sha(names(data)), length(missing), TRUE, TRUE),
    expected = c(registry_row$expected_row_n, registry_row$expected_column_n, registry_row$expected_header_sha256, 0, TRUE, TRUE),
    status = "PASS", stringsAsFactors = FALSE
  )
}

read_source_workbook <- function(path, registry_row, mapping) {
  identity <- preflight_source_file(path, registry_row$expected_sha256[[1L]])
  # 中文备注：加载 readxl 包，只读取 registry 指定的单一工作表，不自动选择首表。
  if (!requireNamespace("readxl", quietly = TRUE)) .source_stop("SOURCE_DEPENDENCY_MISSING", "readxl")
  sheets <- readxl::excel_sheets(path)
  sheet <- registry_row$sheet_name[[1L]]
  if (sum(sheets == sheet) != 1L) .source_stop("SOURCE_SHEET_MISMATCH")
  header <- readxl::read_xlsx(path, sheet = sheet, n_max = 0L, .name_repair = "minimal")
  if (!identical(.source_header_sha(names(header)), registry_row$expected_header_sha256[[1L]])) {
    .source_stop("SOURCE_HEADER_SHA256_MISMATCH")
  }
  column_types <- rep("guess", length(names(header)))
  column_types[names(header) == "Patient_ID"] <- "text"
  column_types[names(header) %in% c("AST", "ALT")] <- "numeric"
  # 中文备注：读取候选患者级源数据，仅在受限上游适配器内存中保存。
  data <- as.data.frame(readxl::read_xlsx(
    path, sheet = sheet, col_types = column_types,
    guess_max = as.integer(registry_row$expected_row_n[[1L]]), .name_repair = "minimal"
  ), check.names = FALSE)
  after <- preflight_source_file(path, registry_row$expected_sha256[[1L]])
  if (!identical(identity, after)) .source_stop("SOURCE_MID_READ_DRIFT")
  qc <- validate_source_frame(data, registry_row, mapping)
  list(data = data, identity = identity, qc = qc)
}

.changed_numeric <- function(before, after, tolerance = 0) {
  before <- as.numeric(before)
  after <- as.numeric(after)
  xor(is.na(before), is.na(after)) |
    (!is.na(before) & !is.na(after) & abs(before - after) > tolerance)
}

.audit_rule <- function(rule_id, trigger, changed_cell_n, status = "PASS") {
  data.frame(
    rule_id = rule_id, trigger_row_n = as.integer(sum(trigger)),
    changed_cell_n = as.integer(changed_cell_n), status = status,
    stringsAsFactors = FALSE
  )
}

.apply_hr_rr_state_machine <- function(hr, rr) {
  output_hr <- hr
  output_rr <- rr
  state <- character(length(hr))
  for (index in seq_along(hr)) {
    h <- hr[[index]]
    r <- rr[[index]]
    if (is.na(h) && is.na(r)) {
      state[[index]] <- "BOTH_MISSING"
    } else if (is.na(h) || is.na(r)) {
      state[[index]] <- "ONE_MISSING_NO_SWAP"
      if (!is.na(h) && !(h >= 30 && h <= 220)) output_hr[[index]] <- NA_real_
      if (!is.na(r) && !(r >= 5 && r <= 60)) output_rr[[index]] <- NA_real_
    } else if (h >= 30 && h <= 220 && r >= 5 && r <= 60) {
      state[[index]] <- "UNCHANGED_VALID"
    } else if (r >= 30 && r <= 220 && h >= 5 && h <= 60) {
      state[[index]] <- "SWAP"
      output_hr[[index]] <- r
      output_rr[[index]] <- h
    } else {
      state[[index]] <- "SET_BOTH_NA"
      output_hr[[index]] <- NA_real_
      output_rr[[index]] <- NA_real_
    }
  }
  list(hr = output_hr, rr = output_rr, state = state)
}

apply_source_preprocessing <- function(data, preprocessing_registry) {
  # 中文备注：开始执行 registry 固化的上游数据修正规则；不拟合模型、不运行插补。
  validate_source_preprocessing_contract(preprocessing_registry)
  policy_ids <- unique(preprocessing_registry$policy_id)
  if (length(policy_ids) != 1L) .source_stop("SOURCE_PREPROCESSING_POLICY_AMBIGUOUS")
  required <- c("Patient_ID", "AST", "ALT", "Height_cm", "Weight_kg", "SBP", "DBP", "HR", "RR", "PT_Activity", "Anemia", "Hyperhcy")
  if (length(setdiff(required, names(data)))) .source_stop("SOURCE_PREPROCESSING_COLUMNS_MISSING")
  output <- data
  for (variable in c("AST", "ALT", "Height_cm", "Weight_kg", "SBP", "DBP", "HR", "RR", "PT_Activity", "Anemia", "Hyperhcy")) {
    output[[variable]] <- .strict_numeric(output[[variable]], variable)
  }
  eligible <- is.finite(output$AST) & output$AST > 0 & is.finite(output$ALT) & output$ALT > 0
  audit <- list(.audit_rule("ELIGIBLE_AST_ALT", !eligible, sum(!eligible)))
  output <- output[eligible, , drop = FALSE]

  height_trigger <- !is.na(output$Height_cm) & abs(output$Height_cm - 91) <= 1e-12
  height_before <- output$Height_cm
  output$Height_cm[height_trigger] <- NA_real_
  audit[[length(audit) + 1L]] <- .audit_rule("HEIGHT_91_TO_NA", height_trigger, sum(.changed_numeric(height_before, output$Height_cm)))

  weight_trigger <- !is.na(output$Weight_kg) & abs(output$Weight_kg - 16) <= 1e-12
  weight_before <- output$Weight_kg
  output$Weight_kg[weight_trigger] <- NA_real_
  audit[[length(audit) + 1L]] <- .audit_rule("WEIGHT_16_TO_NA", weight_trigger, sum(.changed_numeric(weight_before, output$Weight_kg)))

  sbp_range <- !is.na(output$SBP) & (output$SBP < 50 | output$SBP > 300)
  sbp_before <- output$SBP
  output$SBP[sbp_range] <- NA_real_
  audit[[length(audit) + 1L]] <- .audit_rule("SBP_OUTSIDE_RANGE", sbp_range, sum(.changed_numeric(sbp_before, output$SBP)))

  dbp_range <- !is.na(output$DBP) & (output$DBP < 30 | output$DBP > 200)
  dbp_before <- output$DBP
  output$DBP[dbp_range] <- NA_real_
  audit[[length(audit) + 1L]] <- .audit_rule("DBP_OUTSIDE_RANGE", dbp_range, sum(.changed_numeric(dbp_before, output$DBP)))

  pair_trigger <- !is.na(output$SBP) & !is.na(output$DBP) & output$SBP <= output$DBP
  pair_before_sbp <- output$SBP
  pair_before_dbp <- output$DBP
  output$SBP[pair_trigger] <- NA_real_
  output$DBP[pair_trigger] <- NA_real_
  pair_changed <- sum(.changed_numeric(pair_before_sbp, output$SBP)) + sum(.changed_numeric(pair_before_dbp, output$DBP))
  audit[[length(audit) + 1L]] <- .audit_rule("BP_PAIR_INVALID_TO_NA", pair_trigger, pair_changed)

  hr_before <- output$HR
  rr_before <- output$RR
  hr_rr <- .apply_hr_rr_state_machine(output$HR, output$RR)
  output$HR <- hr_rr$hr
  output$RR <- hr_rr$rr
  hr_rr_changed <- sum(.changed_numeric(hr_before, output$HR)) + sum(.changed_numeric(rr_before, output$RR))
  audit[[length(audit) + 1L]] <- .audit_rule("HR_RR_FIVE_BRANCH", hr_rr$state != "UNCHANGED_VALID", hr_rr_changed)

  pt_before <- output$PT_Activity
  for (pair in list(c(999, 99.9), c(1113, 111.3), c(967, 96.7))) {
    trigger <- !is.na(pt_before) & abs(pt_before - pair[[1L]]) <= 1e-12
    output$PT_Activity[trigger] <- pair[[2L]]
  }
  decimal_changed <- sum(.changed_numeric(pt_before, output$PT_Activity, 1e-12))
  audit[[length(audit) + 1L]] <- .audit_rule("PT_DECIMAL_SHIFT", .changed_numeric(pt_before, output$PT_Activity, 1e-12), decimal_changed)
  pt_low_trigger <- Reduce(`|`, lapply(c(0.9, 0.97, 1.3, 7.8), function(value) {
    !is.na(pt_before) & abs(pt_before - value) <= 1e-12
  }))
  pt_low_before <- output$PT_Activity
  output$PT_Activity[pt_low_trigger] <- NA_real_
  audit[[length(audit) + 1L]] <- .audit_rule("PT_INVALID_LOW_TO_NA", pt_low_trigger, sum(.changed_numeric(pt_low_before, output$PT_Activity)))

  if (any(!is.na(output$Anemia) & (!(output$Anemia %in% 0:3) | output$Anemia != floor(output$Anemia)))) {
    .source_stop("SOURCE_LEVEL_INVALID", "Anemia")
  }
  anemia_before <- output$Anemia
  output$Anemia <- ifelse(is.na(output$Anemia), NA_integer_, ifelse(output$Anemia == 0, 0L, 1L))
  audit[[length(audit) + 1L]] <- .audit_rule("ANEMIA_BINARY", !is.na(anemia_before) & anemia_before > 0, sum(.changed_numeric(anemia_before, output$Anemia)))

  if (any(!is.na(output$Hyperhcy) & (!(output$Hyperhcy %in% 0:4) | output$Hyperhcy != floor(output$Hyperhcy)))) {
    .source_stop("SOURCE_LEVEL_INVALID", "Hyperhcy")
  }
  hyper_before <- output$Hyperhcy
  output$Hyperhcy <- ifelse(is.na(output$Hyperhcy), NA_integer_, ifelse(output$Hyperhcy == 0, 0L, 1L))
  audit[[length(audit) + 1L]] <- .audit_rule("HYPERHCY_BINARY", !is.na(hyper_before) & hyper_before > 0, sum(.changed_numeric(hyper_before, output$Hyperhcy)))

  list(
    data = output,
    audit = do.call(rbind, audit),
    eligible_n = nrow(output), excluded_n = sum(!eligible),
    row_order_rule = "SOURCE_WORKBOOK_ORDER",
    preprocessing_policy_id = policy_ids[[1L]]
  )
}

.factor_codes <- function(value, codes, labels = codes, ordered = FALSE, variable) {
  code <- .strict_code(value, codes, variable)
  factor(code, levels = codes, labels = labels, ordered = ordered)
}

.canonical_factor <- function(target, source_value) {
  if (target == "Rutherford_cat") {
    code <- .strict_code(source_value, as.character(0:6), "Rutherford")
    value <- ifelse(is.na(code), NA_character_, ifelse(as.integer(code) <= 2L, "Grade 0-2", ifelse(as.integer(code) <= 4L, "Grade 3-4", "Grade 5-6")))
    return(ordered(value, levels = c("Grade 0-2", "Grade 3-4", "Grade 5-6")))
  }
  if (target == "HTN_bin") {
    code <- .strict_code(source_value, as.character(0:4), "HTN")
    return(factor(ifelse(is.na(code), NA_character_, ifelse(code == "0", "0", "1")), levels = c("0", "1")))
  }
  if (target == "HF_NYHA_bin") {
    code <- .strict_code(source_value, as.character(0:5), "HF_NYHA")
    return(factor(ifelse(is.na(code), NA_character_, ifelse(code == "0", "No", "Yes")), levels = c("No", "Yes")))
  }
  if (target == "CKD_bin") {
    code <- .strict_code(source_value, as.character(0:6), "CKD_Stage")
    return(factor(ifelse(is.na(code), NA_character_, ifelse(code == "0", "0", "1")), levels = c("0", "1")))
  }
  four_level <- function(value, variable) {
    code <- .strict_code(value, as.character(0:7), variable)
    factor(
      ifelse(is.na(code), NA_character_, ifelse(code == "0", "None", ifelse(code %in% as.character(1:4), "Procedure", ifelse(code == "6", "Amputation", "Other")))),
      levels = c("None", "Procedure", "Amputation", "Other")
    )
  }
  if (target == "Prior_LE_Surgery_cat") return(four_level(source_value, "Prior_LE_Surgery"))
  if (target == "Surgery_Type_cat") return(four_level(source_value, "Surgery_Type"))
  if (target == "Anesthesia_cat") {
    return(.factor_codes(source_value, as.character(0:3), c("None", "Local", "Nerve block", "General"), FALSE, "Anesthesia"))
  }
  if (target == "Anemia") return(.factor_codes(source_value, c("0", "1"), c("No anemia", "Anemia"), FALSE, "Anemia"))
  if (target == "Hyperhcy") return(.factor_codes(source_value, c("0", "1"), c("No hyperhomocysteinemia", "Hyperhomocysteinemia"), FALSE, "Hyperhcy"))
  .source_stop("SOURCE_CANONICAL_MAPPING_UNSUPPORTED", target)
}

.compute_passive <- function(data, operation) {
  n <- nrow(data)
  numeric_value <- function(name) .strict_numeric(data[[name]], name)
  value <- switch(operation,
    BMI = numeric_value("Weight_kg") / (numeric_value("Height_cm") / 100)^2,
    PWR = numeric_value("PLT") / numeric_value("WBC"),
    HGB_CREAT = numeric_value("HGB") / numeric_value("Creatinine"),
    PLT_CREAT = numeric_value("PLT") / numeric_value("Creatinine"),
    NLR = numeric_value("NEUT") / numeric_value("LYMPH"),
    NRR = numeric_value("NEUT") / numeric_value("RBC"),
    SII = numeric_value("PLT") * numeric_value("NEUT") / numeric_value("LYMPH"),
    DNLR = numeric_value("NEUT") / (numeric_value("WBC") - numeric_value("LYMPH")),
    PNR = numeric_value("PLT") / numeric_value("NEUT"),
    LMR = numeric_value("LYMPH") / numeric_value("MONO"),
    MLR = numeric_value("MONO") / numeric_value("LYMPH"),
    AISI = numeric_value("NEUT") * numeric_value("PLT") * numeric_value("MONO") / numeric_value("LYMPH"),
    SIRI = numeric_value("NEUT") * numeric_value("MONO") / numeric_value("LYMPH"),
    NMLR = (numeric_value("NEUT") + numeric_value("MONO")) / numeric_value("LYMPH"),
    PNI = numeric_value("ALB") + 5 * numeric_value("LYMPH"),
    FIB4 = numeric_value("Age") * numeric_value("AST") / (numeric_value("PLT") * sqrt(numeric_value("ALT"))),
    APRI = (numeric_value("AST") / 40) / numeric_value("PLT") * 100,
    AST_PLT = numeric_value("AST") / numeric_value("PLT"),
    HRR = numeric_value("HGB") / numeric_value("RDW_CV"),
    RPR = numeric_value("RDW_CV") / numeric_value("PLT"),
    MCHC_RDW = numeric_value("MCHC") / numeric_value("RDW_CV"),
    RDW_MCV = numeric_value("RDW_CV") / numeric_value("MCV"),
    RDWI = numeric_value("MCV") * numeric_value("RDW_CV") / numeric_value("HGB"),
    HCT_RDW = numeric_value("HCT") / numeric_value("RDW_CV"),
    RAR = numeric_value("RDW_SD") / numeric_value("ALB"),
    MPVLR = numeric_value("MPV") / numeric_value("PLT"),
    HALP = numeric_value("HGB") * numeric_value("ALB") * numeric_value("LYMPH") / numeric_value("PLT"),
    NAR = numeric_value("NEUT") / numeric_value("ALB") * 10,
    NPAR = (numeric_value("NEUT") / numeric_value("WBC")) / (numeric_value("ALB") / 10),
    PAR = numeric_value("PLT") / numeric_value("ALB"),
    WBC_ALB = numeric_value("WBC") / numeric_value("ALB"),
    MAR = numeric_value("MONO") / numeric_value("ALB"),
    INR_PLT = numeric_value("INR") / numeric_value("PLT"),
    DFR = numeric_value("D_Dimer") / numeric_value("FIB"),
    FAR = numeric_value("FIB") / numeric_value("ALB"),
    FPR = numeric_value("FIB") / numeric_value("PLT") * 100,
    GAR = numeric_value("FBG") * 180.2 / numeric_value("ALB"),
    APTT_FIB = numeric_value("APTT") / numeric_value("FIB"),
    UCR = numeric_value("Urea") * 247.52 / numeric_value("Creatinine"),
    BAR = numeric_value("Urea") / numeric_value("ALB"),
    ANLR = numeric_value("ALB") / numeric_value("NLR"),
    ALI = numeric_value("BMI") * numeric_value("ALB") / numeric_value("NLR"),
    EGFR = {
      age <- numeric_value("Age")
      creatinine <- numeric_value("Creatinine")
      sex <- as.character(data$Sex)
      female <- ifelse(sex == "Female", 1, ifelse(sex == "Male", 0, NA_real_))
      scr <- creatinine / 88.4
      kappa <- ifelse(female == 1, 0.7, 0.9)
      alpha <- ifelse(female == 1, -0.241, -0.302)
      142 * pmin(scr / kappa, 1)^alpha * pmax(scr / kappa, 1)^(-1.2) * 0.9938^age * 1.012^female
    },
    AST_ALT = numeric_value("AST") / numeric_value("ALT"),
    .source_stop("SOURCE_FORMULA_OPERATION_INVALID", operation)
  )
  value <- as.numeric(value)
  if (length(value) != n) .source_stop("SOURCE_FORMULA_LENGTH_INVALID", operation)
  value[!is.finite(value)] <- NA_real_
  value
}

recalculate_source_passive_variables <- function(data, formula_registry) {
  output <- data
  for (index in seq_len(nrow(formula_registry))) {
    row <- formula_registry[index, , drop = FALSE]
    sources <- .split_pipe(row$source_names[[1L]])
    if (length(setdiff(sources, names(output)))) .source_stop("SOURCE_FORMULA_INPUT_MISSING", row$target_name[[1L]])
    # 中文备注：按锁定顺序执行一个被动公式；公式操作来自枚举，不执行 registry 文本。
    output[[row$target_name[[1L]]]] <- .compute_passive(output, row$operation[[1L]])
  }
  output
}

build_canonical_pre_mi <- function(data, mapping, formula_registry) {
  required <- required_source_columns(mapping)
  missing <- setdiff(required, names(data))
  if (length(missing)) .source_stop("SOURCE_REQUIRED_COLUMNS_MISSING", paste(missing, collapse = "|"))
  output <- vector("list", nrow(mapping))
  names(output) <- mapping$target_name
  for (index in seq_len(nrow(mapping))) {
    row <- mapping[index, , drop = FALSE]
    target <- row$target_name[[1L]]
    source <- row$source_name[[1L]]
    kind <- row$mapping_kind[[1L]]
    if (kind == "DIRECT") {
      output[[target]] <- as.character(data[[source]])
    } else if (kind == "DIRECT_NUMERIC") {
      output[[target]] <- .strict_numeric(data[[source]], source)
    } else if (kind == "FACTOR_LABEL") {
      if (target != "Sex") .source_stop("SOURCE_FACTOR_LABEL_UNSUPPORTED", target)
      output[[target]] <- .factor_codes(data[[source]], c("0", "1"), c("Male", "Female"), FALSE, source)
    } else if (kind == "FACTOR") {
      if (target == "ASA") {
        output[[target]] <- .factor_codes(data[[source]], as.character(0:4), paste("ASA", 0:4), TRUE, source)
      } else if (target == "GPS") {
        output[[target]] <- .factor_codes(data[[source]], as.character(0:2), paste("GPS", 0:2), TRUE, source)
      } else if (target == "CONUT") {
        output[[target]] <- .factor_codes(data[[source]], as.character(0:12), paste("CONUT", 0:12), TRUE, source)
      } else {
        levels <- .split_pipe(row$levels[[1L]])
        output[[target]] <- .factor_codes(data[[source]], levels, levels, isTRUE(row$ordered[[1L]]), source)
      }
    } else if (kind == "CANONICAL_FACTOR") {
      output[[target]] <- .canonical_factor(target, data[[source]])
    } else if (kind == "PASSIVE_FORMULA") {
      output[[target]] <- rep(NA_real_, nrow(data))
    } else {
      .source_stop("SOURCE_MAPPING_KIND_INVALID", kind)
    }
  }
  output <- as.data.frame(output, stringsAsFactors = FALSE, check.names = FALSE)
  output <- recalculate_source_passive_variables(output, formula_registry)
  output[mapping$target_name]
}

validate_canonical_pre_mi <- function(data, mapping) {
  if (!identical(names(data), mapping$target_name)) .source_stop("SOURCE_CANONICAL_COLUMN_ORDER_MISMATCH")
  rows <- lapply(seq_len(nrow(mapping)), function(index) {
    row <- mapping[index, , drop = FALSE]
    variable <- row$target_name[[1L]]
    value <- data[[variable]]
    expected <- row$expected_r_class[[1L]]
    class_ok <- switch(expected,
      character = is.character(value), numeric = is.numeric(value) && !is.factor(value),
      factor = is.factor(value) && !is.ordered(value), ordered_factor = is.ordered(value), FALSE
    )
    level_ok <- TRUE
    expected_levels <- .split_pipe(row$levels[[1L]])
    if (length(expected_levels) && is.factor(value)) level_ok <- identical(levels(value), expected_levels)
    missing_ok <- isTRUE(row$nullable[[1L]]) || !anyNA(value)
    data.frame(
      variable = variable, class_ok = class_ok, levels_ok = level_ok,
      missing_ok = missing_ok,
      status = ifelse(class_ok && level_ok && missing_ok, "PASS", "FAIL"),
      stringsAsFactors = FALSE
    )
  })
  result <- do.call(rbind, rows)
  ids <- as.character(data$Patient_ID)
  if (any(is.na(ids) | !nzchar(ids)) || anyDuplicated(ids)) .source_stop("SOURCE_CANONICAL_PATIENT_ID_INVALID")
  for (event in c("All_Cause_Death", "CV_CBV_Death", "MACE")) {
    if (anyNA(data[[event]]) || !all(as.character(data[[event]]) %in% c("0", "1"))) {
      .source_stop("SOURCE_EVENT_DOMAIN_INVALID", event)
    }
  }
  for (time in c("Death_Followup_months", "MACE_Followup_months")) {
    value <- .strict_numeric(data[[time]], time)
    if (any(!is.finite(value)) || any(value <= 0)) .source_stop("SOURCE_FOLLOWUP_DOMAIN_INVALID", time)
  }
  if (any(.strict_numeric(data$AST, "AST") <= 0) || any(.strict_numeric(data$ALT, "ALT") <= 0)) {
    .source_stop("SOURCE_EXPOSURE_DOMAIN_INVALID")
  }
  if (any(result$status != "PASS")) {
    .source_stop("SOURCE_CANONICAL_TYPE_OR_LEVEL_INVALID", paste(result$variable[result$status != "PASS"], collapse = "|"))
  }
  result
}

.source_candidate_receipt_fields <- function() {
  c(
    "schema_version", "source_id", "source_revision", "source_sha256", "source_size_bytes",
    "sheet_name", "raw_row_n", "raw_column_n", "eligible_row_n", "excluded_row_n",
    "canonical_column_n", "ignored_column_n", "preprocessing_policy_id", "preprocessing_rule_n",
    "preprocessing_audit_row_n", "preprocessing_changed_cell_n", "preprocessing_registry_sha256",
    "mapping_registry_sha256", "passive_formula_registry_sha256", "mi_recipe_id", "row_order_rule",
    "patient_order_sha256", "source_epoch", "canonical_schema_sha256", "status",
    "contains_patient_level_data"
  )
}

validate_source_candidate_receipt <- function(receipt) {
  fields <- .source_candidate_receipt_fields()
  if (!is.list(receipt) || !identical(sort(names(receipt)), sort(fields))) {
    .source_stop("SOURCE_RECEIPT_SCHEMA_INVALID")
  }
  receipt <- receipt[fields]
  sha_fields <- c(
    "source_sha256", "preprocessing_registry_sha256", "mapping_registry_sha256",
    "passive_formula_registry_sha256", "patient_order_sha256", "source_epoch",
    "canonical_schema_sha256"
  )
  if (any(!vapply(receipt[sha_fields], function(value) {
    length(value) == 1L && !is.na(value) && grepl("^[0-9a-f]{64}$", as.character(value))
  }, logical(1)))) .source_stop("SOURCE_RECEIPT_SHA256_INVALID")
  integer_fields <- c(
    "source_size_bytes", "raw_row_n", "raw_column_n", "eligible_row_n", "excluded_row_n",
    "canonical_column_n", "ignored_column_n", "preprocessing_rule_n",
    "preprocessing_audit_row_n", "preprocessing_changed_cell_n"
  )
  integer_ok <- vapply(receipt[integer_fields], function(value) {
    is.numeric(value) && length(value) == 1L && !is.na(value) && is.finite(value) &&
      identical(as.numeric(value), floor(as.numeric(value)))
  }, logical(1))
  if (any(!integer_ok) || as.numeric(receipt$source_size_bytes) < 1 ||
      as.numeric(receipt$ignored_column_n) < 0 ||
      as.numeric(receipt$preprocessing_changed_cell_n) < 0 ||
      !is.character(receipt$source_revision) || length(receipt$source_revision) != 1L ||
      is.na(receipt$source_revision) || !nzchar(receipt$source_revision)) {
    .source_stop("SOURCE_RECEIPT_SCHEMA_INVALID")
  }
  expected_epoch <- .source_sha256_text(c(
    receipt$source_sha256, receipt$mapping_registry_sha256,
    receipt$preprocessing_registry_sha256, receipt$patient_order_sha256
  ))
  counts_ok <- identical(as.integer(receipt$raw_row_n), 2247L) &&
    identical(as.integer(receipt$raw_column_n), 195L) &&
    identical(as.integer(receipt$eligible_row_n), 2124L) &&
    identical(as.integer(receipt$excluded_row_n), 123L) &&
    identical(as.integer(receipt$canonical_column_n), 123L) &&
    identical(as.integer(receipt$preprocessing_rule_n), 13L) &&
    identical(as.integer(receipt$preprocessing_audit_row_n), 11L)
  constants_ok <- identical(receipt$schema_version, "1.0.0") &&
    identical(receipt$source_id, "SRC_A_XLSX_V43") &&
    identical(receipt$sheet_name, "Analysis_Data") &&
    identical(receipt$preprocessing_policy_id, "SRC_PREP_V43_V1") &&
    identical(receipt$mi_recipe_id, "SRC_MI_V43_MAIN_SURVIVAL_V1") &&
    identical(receipt$row_order_rule, "SOURCE_WORKBOOK_ORDER") &&
    identical(receipt$status, "AUDIT_PASS_CANDIDATE_UNAPPROVED") &&
    identical(receipt$contains_patient_level_data, FALSE)
  if (!counts_ok || !constants_ok || !identical(receipt$source_epoch, expected_epoch)) {
    .source_stop("SOURCE_RECEIPT_CONTRACT_MISMATCH")
  }
  invisible(TRUE)
}

source_candidate_receipt_identity_v43 <- function(receipt) {
  validate_source_candidate_receipt(receipt)
  .source_hash_object(receipt[.source_candidate_receipt_fields()])
}

validate_source_candidate_receipt_current_owner_v43 <- function(receipt, project_root = ".") {
  validate_source_candidate_receipt(receipt)
  registry_row <- select_source_registry_row(
    read_source_dataset_registry(project_root), receipt$source_id
  )
  expected <- c(
    source_revision = registry_row$source_revision[[1L]],
    source_sha256 = registry_row$expected_sha256[[1L]],
    preprocessing_policy_id = registry_row$preprocessing_policy_id[[1L]],
    mi_recipe_id = registry_row$mi_recipe_id[[1L]],
    row_order_rule = registry_row$row_order_rule[[1L]],
    preprocessing_registry_sha256 = .source_hash_data_frame(
      read_source_preprocessing_registry(project_root)
    ),
    mapping_registry_sha256 = .source_hash_data_frame(
      read_source_column_mapping_registry(project_root)
    ),
    passive_formula_registry_sha256 = .source_hash_data_frame(
      read_source_passive_formula_registry(project_root)
    )
  )
  observed <- vapply(names(expected), function(field) as.character(receipt[[field]]), character(1))
  if (!identical(unname(observed), unname(expected))) {
    .source_stop("SOURCE_RECEIPT_CURRENT_OWNER_MISMATCH")
  }
  invisible(TRUE)
}

make_source_candidate_receipt <- function(
  registry_row, source_path, raw_row_n, raw_column_n, eligible_row_n, excluded_row_n,
  canonical_column_n, ignored_column_n, preprocessing_audit, mapping,
  preprocessing_registry, formula_registry, canonical
) {
  mapping_sha <- .source_hash_data_frame(mapping)
  preprocessing_sha <- .source_hash_data_frame(preprocessing_registry)
  passive_sha <- .source_hash_data_frame(formula_registry)
  patient_order_sha <- .source_sha256_text(as.character(canonical$Patient_ID))
  source_sha <- .source_sha256_file(source_path)
  source_epoch <- .source_sha256_text(c(source_sha, mapping_sha, preprocessing_sha, patient_order_sha))
  receipt <- list(
    schema_version = "1.0.0",
    source_id = registry_row$source_id[[1L]],
    source_revision = registry_row$source_revision[[1L]],
    source_sha256 = source_sha,
    source_size_bytes = unname(file.info(source_path)$size),
    sheet_name = registry_row$sheet_name[[1L]],
    raw_row_n = as.integer(raw_row_n), raw_column_n = as.integer(raw_column_n),
    eligible_row_n = as.integer(eligible_row_n), excluded_row_n = as.integer(excluded_row_n),
    canonical_column_n = as.integer(canonical_column_n), ignored_column_n = as.integer(ignored_column_n),
    preprocessing_policy_id = registry_row$preprocessing_policy_id[[1L]],
    preprocessing_rule_n = as.integer(nrow(preprocessing_registry)),
    preprocessing_audit_row_n = as.integer(nrow(preprocessing_audit)),
    preprocessing_changed_cell_n = as.integer(sum(preprocessing_audit$changed_cell_n)),
    preprocessing_registry_sha256 = preprocessing_sha,
    mapping_registry_sha256 = mapping_sha,
    passive_formula_registry_sha256 = passive_sha,
    mi_recipe_id = registry_row$mi_recipe_id[[1L]],
    row_order_rule = registry_row$row_order_rule[[1L]],
    patient_order_sha256 = patient_order_sha,
    source_epoch = source_epoch,
    canonical_schema_sha256 = .source_sha256_text(paste(names(canonical), vapply(canonical, function(value) paste(class(value), collapse = "|"), character(1)), sep = "\t")),
    status = "AUDIT_PASS_CANDIDATE_UNAPPROVED",
    contains_patient_level_data = FALSE
  )
  validate_source_candidate_receipt(receipt)
  receipt
}

load_locked_source_mi_recipe <- function(root = ".", canonical_names) {
  engine_path <- file.path(root, "R", "mi_recipe_engine.R")
  if (!file.exists(engine_path)) .source_stop("SOURCE_MI_ENGINE_MISSING")
  if (!exists("load_compiled_mi_recipe_v43", mode = "function")) source(engine_path)
  locked <- load_compiled_mi_recipe_v43(root, canonical_names)
  registry <- locked$recipe
  projection <- locked$projection
  list(
    recipe_id = registry$recipe_id[[1L]], m = as.integer(registry$m[[1L]]),
    maxit = as.integer(registry$maxit_initial[[1L]]), seed = as.integer(registry$seed[[1L]]),
    continuation_maxit = as.integer(.split_pipe(registry$continuation_maxit[[1L]])),
    ridge = as.numeric(registry$ridge[[1L]]),
    method = setNames(projection$method_registry$method, projection$method_registry$variable),
    predictor_matrix = .mi_predictor_matrix(projection),
    blocks = projection$block_registry,
    where_policy = registry$where_policy[[1L]],
    passive_policy = registry$passive_policy[[1L]], row_order_rule = registry$row_order_rule[[1L]],
    approval_status = registry$approval_status[[1L]],
    decision_id = registry$decision_id[[1L]], selected_option_id = registry$selected_option_id[[1L]]
  )
}

assert_candidate_build_authorized <- function(mode, approval_id = "") {
  if (identical(mode, "AUDIT_ONLY")) return(list(status = "AUDIT_ONLY", approval_id = ""))
  if (!identical(mode, "BUILD_CANDIDATE_HANDOFF")) .source_stop("SOURCE_MODE_INVALID")
  if (!nzchar(trimws(approval_id))) .source_stop("SOURCE_BUILD_APPROVAL_REQUIRED")
  if (!grepl("^[A-Za-z0-9][A-Za-z0-9._-]{2,127}$", approval_id)) .source_stop("SOURCE_BUILD_APPROVAL_ID_INVALID")
  list(status = "BUILD_AUTHORIZED", approval_id = approval_id)
}

parse_prepare_source_args <- function(
    args = commandArgs(trailingOnly = TRUE),
    env_source = Sys.getenv("AST_ALT_SOURCE_XLSX", "")) {
  value_flags <- c(
    "--mode" = "mode",
    "--source-id" = "source_id",
    "--source-xlsx" = "source_xlsx",
    "--candidate-root" = "candidate_root",
    "--approval-id" = "approval_id",
    "--source-epoch" = "source_epoch",
    "--source-receipt-sha256" = "source_receipt_sha256",
    "--authorization-receipt" = "authorization_receipt",
    "--authorization-file-sha256" = "authorization_file_sha256"
  )
  values <- list(
    mode = "audit", source_id = "", source_xlsx = "", candidate_root = "", approval_id = "",
    source_epoch = "", source_receipt_sha256 = "", authorization_receipt = "",
    authorization_file_sha256 = ""
  )
  seen <- character()
  position <- 1L
  while (position <= length(args)) {
    token <- args[[position]]
    if (!token %in% names(value_flags)) .source_stop("SOURCE_CLI_ARGUMENT_UNKNOWN", token)
    if (token %in% seen) .source_stop("SOURCE_CLI_ARGUMENT_DUPLICATE", token)
    if (position == length(args) || startsWith(args[[position + 1L]], "--")) {
      .source_stop("SOURCE_CLI_ARGUMENT_VALUE_MISSING", token)
    }
    seen <- c(seen, token)
    values[[unname(value_flags[[token]])]] <- args[[position + 1L]]
    position <- position + 2L
  }
  if (!values$mode %in% c("audit", "build-candidate")) .source_stop("SOURCE_MODE_INVALID")
  if (!grepl("^[A-Z][A-Z0-9_]{2,127}$", values$source_id)) .source_stop("SOURCE_ID_REQUIRED_OR_INVALID")
  if (!nzchar(trimws(values$candidate_root))) .source_stop("SOURCE_CANDIDATE_ROOT_REQUIRED")
  values$source_xlsx <- resolve_source_path(values$source_xlsx, env_source)
  control_values <- c(
    values$approval_id, values$source_epoch, values$source_receipt_sha256,
    values$authorization_receipt, values$authorization_file_sha256
  )
  if (identical(values$mode, "audit") && any(nzchar(control_values))) {
    .source_stop("SOURCE_APPROVAL_FORBIDDEN_FOR_AUDIT")
  }
  if (identical(values$mode, "build-candidate")) {
    assert_candidate_build_authorized("BUILD_CANDIDATE_HANDOFF", values$approval_id)
    required <- c(
      source_epoch = values$source_epoch,
      source_receipt_sha256 = values$source_receipt_sha256,
      authorization_receipt = values$authorization_receipt,
      authorization_file_sha256 = values$authorization_file_sha256
    )
    if (any(!nzchar(required))) .source_stop("SOURCE_BUILD_H1_ARGUMENT_REQUIRED")
    sha_values <- required[c("source_epoch", "source_receipt_sha256", "authorization_file_sha256")]
    if (any(!grepl("^[0-9a-f]{64}$", sha_values))) .source_stop("SOURCE_BUILD_H1_SHA256_INVALID")
  }
  values
}

assert_restricted_candidate_root <- function(candidate_root, project_root = ".") {
  project_root <- normalizePath(project_root, mustWork = TRUE)
  candidate_root <- normalizePath(candidate_root, mustWork = FALSE)
  broad_forbidden <- unique(c(normalizePath("/", mustWork = TRUE), normalizePath(Sys.getenv("HOME"), mustWork = TRUE), project_root))
  if (candidate_root %in% broad_forbidden) .source_stop("SOURCE_CANDIDATE_ROOT_TOO_BROAD")
  portable_path <- gsub("\\\\", "/", candidate_root)
  if (!grepl("(^|/)(candidate_cache|restricted_cache)(/|$)", portable_path)) {
    .source_stop("SOURCE_CANDIDATE_ROOT_NOT_RESTRICTED")
  }
  candidate_root
}

audit_source_workbook <- function(source_id, source_path, project_root = ".") {
  registry <- read_source_dataset_registry(project_root)
  registry_row <- select_source_registry_row(registry, source_id)
  if (!"AUDIT_ONLY" %in% .split_pipe(registry_row$allowed_modes[[1L]])) .source_stop("SOURCE_MODE_NOT_ALLOWED")
  mapping <- read_source_column_mapping_registry(project_root)
  preprocessing_registry <- read_source_preprocessing_registry(project_root)
  formula_registry <- read_source_passive_formula_registry(project_root)
  workbook <- read_source_workbook(source_path, registry_row, mapping)
  prepared <- apply_source_preprocessing(workbook$data, preprocessing_registry)
  if (!identical(prepared$row_order_rule, registry_row$row_order_rule[[1L]])) .source_stop("SOURCE_ROW_ORDER_RULE_MISMATCH")
  canonical <- build_canonical_pre_mi(prepared$data, mapping, formula_registry)
  canonical_qc <- validate_canonical_pre_mi(canonical, mapping)
  ignored_column_n <- length(setdiff(names(workbook$data), required_source_columns(mapping)))
  receipt <- make_source_candidate_receipt(
    registry_row = registry_row,
    source_path = source_path,
    raw_row_n = nrow(workbook$data),
    raw_column_n = ncol(workbook$data),
    eligible_row_n = prepared$eligible_n,
    excluded_row_n = prepared$excluded_n,
    canonical_column_n = ncol(canonical),
    ignored_column_n = ignored_column_n,
    preprocessing_audit = prepared$audit,
    mapping = mapping,
    preprocessing_registry = preprocessing_registry,
    formula_registry = formula_registry,
    canonical = canonical
  )
  list(
    registry_row = registry_row,
    canonical = canonical,
    receipt = receipt,
    source_qc = workbook$qc,
    canonical_qc = canonical_qc,
    preprocessing_audit = prepared$audit,
    mapping = mapping,
    preprocessing_registry = preprocessing_registry,
    formula_registry = formula_registry
  )
}

publish_source_audit <- function(audit, candidate_root, project_root = ".") {
  validate_source_candidate_receipt(audit$receipt)
  candidate_root <- assert_restricted_candidate_root(candidate_root, project_root)
  dir.create(candidate_root, recursive = TRUE, showWarnings = FALSE, mode = "0700")
  invisible(Sys.chmod(candidate_root, mode = "0700", use_umask = FALSE))
  receipt_sha <- source_candidate_receipt_identity_v43(audit$receipt)
  target <- file.path(candidate_root, paste0("source_audit_", audit$receipt$source_epoch, "_", receipt_sha))
  if (dir.exists(target)) {
    complete <- file.path(target, "SOURCE_AUDIT_COMPLETE")
    receipt_path <- file.path(target, "source_candidate_receipt.json")
    if (!file.exists(complete) || !file.exists(receipt_path)) .source_stop("SOURCE_AUDIT_EXISTING_INCOMPLETE")
    # 加载 JSON 包并验证内容寻址审计重放身份。
    if (!requireNamespace("jsonlite", quietly = TRUE)) .source_stop("SOURCE_DEPENDENCY_MISSING", "jsonlite")
    existing <- jsonlite::read_json(receipt_path, simplifyVector = TRUE)
    if (!identical(source_candidate_receipt_identity_v43(existing), receipt_sha)) .source_stop("SOURCE_AUDIT_REPLAY_IDENTITY_MISMATCH")
    return(target)
  }
  staging <- tempfile(pattern = ".source_audit_staging_", tmpdir = candidate_root)
  if (!dir.create(staging, mode = "0700")) .source_stop("SOURCE_AUDIT_STAGING_CREATE_FAILED")
  on.exit(if (dir.exists(staging)) unlink(staging, recursive = TRUE), add = TRUE)
  # 输出不含患者标识与绝对路径的源数据聚合审计。
  utils::write.csv(audit$source_qc, file.path(staging, "source_schema_qc.csv"), row.names = FALSE)
  # 输出 registry 规则的聚合触发与修改计数。
  utils::write.csv(audit$preprocessing_audit, file.path(staging, "source_preprocessing_audit.csv"), row.names = FALSE)
  # 输出 canonical 列级类型闭包，不输出任何患者值。
  utils::write.csv(audit$canonical_qc, file.path(staging, "canonical_schema_qc.csv"), row.names = FALSE)
  # 加载 JSON 包并写入不含路径与患者值的源审计收据。
  if (!requireNamespace("jsonlite", quietly = TRUE)) .source_stop("SOURCE_DEPENDENCY_MISSING", "jsonlite")
  jsonlite::write_json(audit$receipt, file.path(staging, "source_candidate_receipt.json"), auto_unbox = TRUE, pretty = TRUE)
  writeLines(c(audit$receipt$source_epoch, receipt_sha), file.path(staging, "SOURCE_AUDIT_COMPLETE"), useBytes = TRUE)
  invisible(Sys.chmod(list.files(staging, full.names = TRUE), mode = "0600", use_umask = FALSE))
  if (!file.rename(staging, target)) .source_stop("SOURCE_AUDIT_ATOMIC_PUBLISH_FAILED")
  invisible(Sys.chmod(target, mode = "0700", use_umask = FALSE))
  target
}

select_source_candidate_receipt_v43 <- function(
    candidate_root, source_epoch, receipt_identity_sha256, expected_source_sha256,
    project_root = ".") {
  sha_ok <- function(value) {
    is.character(value) && length(value) == 1L && !is.na(value) &&
      grepl("^[0-9a-f]{64}$", value)
  }
  if (any(!vapply(
    list(source_epoch, receipt_identity_sha256, expected_source_sha256),
    sha_ok, logical(1)
  ))) .source_stop("SOURCE_AUDIT_SELECTOR_SHA_INVALID")
  candidate_root <- assert_restricted_candidate_root(candidate_root, project_root)
  if (!dir.exists(candidate_root) || nzchar(Sys.readlink(candidate_root))) {
    .source_stop("SOURCE_AUDIT_ROOT_INVALID")
  }
  directory_name <- paste0("source_audit_", source_epoch, "_", receipt_identity_sha256)
  target <- file.path(candidate_root, directory_name)
  if (!dir.exists(target) || nzchar(Sys.readlink(target))) {
    .source_stop("SOURCE_AUDIT_RECEIPT_NOT_FOUND")
  }
  normalized_root <- paste0(normalizePath(candidate_root, mustWork = TRUE), .Platform$file.sep)
  normalized_target <- paste0(normalizePath(target, mustWork = TRUE), .Platform$file.sep)
  if (!startsWith(normalized_target, normalized_root) || !identical(basename(target), directory_name)) {
    .source_stop("SOURCE_AUDIT_SELECTOR_PATH_INVALID")
  }
  receipt_path <- file.path(target, "source_candidate_receipt.json")
  sentinel_path <- file.path(target, "SOURCE_AUDIT_COMPLETE")
  if (any(!file.exists(c(receipt_path, sentinel_path))) ||
      any(nzchar(Sys.readlink(c(receipt_path, sentinel_path)))) ||
      isTRUE(file.info(receipt_path)$size > 65536L) ||
      isTRUE(file.info(sentinel_path)$size > 1024L)) {
    .source_stop("SOURCE_AUDIT_RECEIPT_INCOMPLETE")
  }
  # 中文备注：加载 JSON 包并只读取 aggregate source receipt，不读取工作簿或患者值。
  if (!requireNamespace("jsonlite", quietly = TRUE)) .source_stop("SOURCE_DEPENDENCY_MISSING", "jsonlite")
  receipt <- jsonlite::read_json(receipt_path, simplifyVector = TRUE)
  validate_source_candidate_receipt_current_owner_v43(receipt, project_root)
  observed_identity <- source_candidate_receipt_identity_v43(receipt)
  sentinel <- readLines(sentinel_path, warn = FALSE, encoding = "UTF-8")
  if (!identical(observed_identity, receipt_identity_sha256) ||
      !identical(receipt$source_epoch, source_epoch) ||
      !identical(receipt$source_sha256, expected_source_sha256) ||
      !identical(sentinel, c(source_epoch, receipt_identity_sha256))) {
    .source_stop("SOURCE_AUDIT_RECEIPT_IDENTITY_MISMATCH")
  }
  list(
    receipt = receipt,
    receipt_identity_sha256 = observed_identity,
    receipt_file_sha256 = .source_sha256_file(receipt_path),
    audit_path = normalizePath(target, mustWork = TRUE)
  )
}

prepare_source_handoff_main <- function(args = commandArgs(trailingOnly = TRUE), project_root = ".") {
  parsed <- parse_prepare_source_args(args)
  if (identical(parsed$mode, "audit")) {
    audit <- audit_source_workbook(parsed$source_id, parsed$source_xlsx, project_root)
    if (!"AUDIT_ONLY" %in% .split_pipe(audit$registry_row$allowed_modes[[1L]])) {
      .source_stop("SOURCE_MODE_NOT_ALLOWED")
    }
    audit_path <- publish_source_audit(audit, parsed$candidate_root, project_root)
    return(invisible(list(
      mode = "audit", audit_path = audit_path, source_epoch = audit$receipt$source_epoch
    )))
  }
  registry_row <- select_source_registry_row(
    read_source_dataset_registry(project_root), parsed$source_id
  )
  if (!"BUILD_CANDIDATE_HANDOFF" %in% .split_pipe(registry_row$allowed_modes[[1L]])) {
    .source_stop("SOURCE_MODE_NOT_ALLOWED")
  }
  selected <- select_source_candidate_receipt_v43(
    candidate_root = parsed$candidate_root,
    source_epoch = parsed$source_epoch,
    receipt_identity_sha256 = parsed$source_receipt_sha256,
    expected_source_sha256 = registry_row$expected_sha256[[1L]],
    project_root = project_root
  )
  source(file.path(project_root, "R", "authorization_engine.R"))
  source(file.path(project_root, "R", "mi_recipe_engine.R"))
  source(file.path(project_root, "R", "mi_transaction_engine.R"))
  source(file.path(project_root, "R", "formal_mice_engine.R"))
  current_request <- build_mi_transaction_request_proposal_v43(
    selected$receipt, project_root
  )
  authorization_path <- if (grepl("^/|^[A-Za-z]:[/\\\\]", parsed$authorization_receipt)) {
    parsed$authorization_receipt
  } else {
    file.path(project_root, parsed$authorization_receipt)
  }
  authorization <- load_formal_mice_authorization_v43(
    normalizePath(authorization_path, mustWork = TRUE),
    parsed$authorization_file_sha256,
    source_receipt = selected$receipt
  )
  if (!identical(authorization$decision_id, parsed$approval_id)) {
    .source_stop("SOURCE_BUILD_APPROVAL_H1_DECISION_MISMATCH")
  }
  resolved <- .resolve_formal_mice_authorized_request_v43(
    file.path(parsed$candidate_root, "mi_transactions"),
    authorization, current_request, selected$receipt
  )
  if (!identical(resolved$request, current_request)) {
    validate_formal_mice_repair_bridge_v43(
      resolved$request, current_request, resolved$transaction_path, project_root
    )
  }
  # H1 已绑定 exact proposal 后，才允许重新读取患者级源并确认审计身份未漂移。
  audit <- audit_source_workbook(parsed$source_id, parsed$source_xlsx, project_root)
  if (!identical(
      source_candidate_receipt_identity_v43(audit$receipt),
      selected$receipt_identity_sha256
  )) .source_stop("SOURCE_BUILD_REAUDIT_IDENTITY_MISMATCH")
  audit_path <- publish_source_audit(audit, parsed$candidate_root, project_root)
  if (!identical(normalizePath(audit_path), selected$audit_path)) {
    .source_stop("SOURCE_BUILD_AUDIT_PATH_MISMATCH")
  }
  builder_path <- file.path(project_root, "R", "source_handoff_builder.R")
  if (!file.exists(builder_path)) .source_stop("SOURCE_HANDOFF_BUILDER_MISSING")
  source(builder_path)
  if (!exists("build_source_handoff_candidate", mode = "function")) .source_stop("SOURCE_HANDOFF_BUILDER_INTERFACE_MISSING")
  build_source_handoff_candidate(
    audit = audit,
    audit_path = audit_path,
    candidate_root = parsed$candidate_root,
    authorization = authorization,
    authorization_file_sha256 = parsed$authorization_file_sha256,
    project_root = project_root
  )
}

read_approved_handoff_registry <- function(root = ".") {
  path <- file.path(root, "reference", "approved_upstream_handoff.csv")
  if (!file.exists(path)) .source_stop("HANDOFF_APPROVAL_REGISTRY_MISSING")
  registry <- utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE, na.strings = "")
  required <- c(
    "handoff_id", "approval_id", "source_id", "source_epoch", "handoff_sha256",
    "expected_source_sha256", "expected_patient_order_sha256", "expected_mids_sha256",
    "expected_completed_sha256", "expected_factor_sha256", "expected_schema_sha256",
    "expected_core_column_n", "expected_semantic_status", "approval_status", "approval_basis",
    "protocol_revision", "approved_at"
  )
  if (!identical(names(registry), required) || anyDuplicated(registry$handoff_id)) {
    .source_stop("HANDOFF_APPROVAL_REGISTRY_INVALID")
  }
  approved <- registry$approval_status == "APPROVED"
  sha_columns <- c("handoff_sha256", "expected_mids_sha256", "expected_factor_sha256")
  if (any(vapply(registry[approved, sha_columns, drop = FALSE], function(value) any(!grepl("^[0-9a-f]{64}$", value)), logical(1)))) {
    .source_stop("HANDOFF_APPROVAL_SHA256_INVALID")
  }
  if (any(!nzchar(registry$approval_id[approved])) || anyDuplicated(registry$approval_id[approved]) ||
      anyDuplicated(registry$handoff_sha256[approved]) ||
      any(!is.finite(as.numeric(registry$expected_core_column_n[approved])) | as.numeric(registry$expected_core_column_n[approved]) <= 0) ||
      any(!nzchar(registry$expected_semantic_status[approved]))) {
    .source_stop("HANDOFF_APPROVAL_IDENTITY_INVALID")
  }
  v43_approved <- approved & registry$protocol_revision == "v4.3-r00"
  required_v43_sha <- c(
    "source_epoch", "expected_source_sha256", "expected_patient_order_sha256",
    "expected_completed_sha256", "expected_schema_sha256"
  )
  if (any(vapply(registry[v43_approved, required_v43_sha, drop = FALSE], function(value) any(!grepl("^[0-9a-f]{64}$", value)), logical(1))) ||
      any(!grepl("^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$", registry$approved_at[v43_approved]))) {
    .source_stop("HANDOFF_V43_APPROVAL_RECEIPT_INVALID")
  }
  registry
}

match_approved_handoff <- function(zip_path, approval_registry) {
  if (!file.exists(zip_path) || isTRUE(file.info(zip_path)$isdir)) .source_stop("HANDOFF_FILE_NOT_FOUND")
  observed_sha <- .source_sha256_file(zip_path)
  matched <- approval_registry[
    approval_registry$approval_status == "APPROVED" & approval_registry$handoff_sha256 == observed_sha,
    , drop = FALSE
  ]
  if (nrow(matched) != 1L) .source_stop("HANDOFF_NOT_APPROVED")
  matched
}

handoff_identity_from_approval_row <- function(matched) {
  if (!is.data.frame(matched) || nrow(matched) != 1L || matched$approval_status[[1L]] != "APPROVED") {
    .source_stop("HANDOFF_APPROVAL_ROW_INVALID")
  }
  fields <- c(
    "handoff_id", "approval_id", "source_id", "source_epoch", "handoff_sha256",
    "expected_source_sha256", "expected_patient_order_sha256", "expected_mids_sha256",
    "expected_completed_sha256", "expected_factor_sha256", "expected_schema_sha256",
    "expected_core_column_n", "expected_semantic_status", "protocol_revision"
  )
  identity <- as.list(matched[1L, fields, drop = FALSE])
  identity$expected_core_column_n <- as.integer(identity$expected_core_column_n)
  identity$handoff_identity_sha256 <- .source_sha256_text(paste(fields, vapply(identity[fields], as.character, character(1)), sep = "="))
  identity
}

approved_handoff_identity <- function(zip_path, approval_registry) {
  handoff_identity_from_approval_row(match_approved_handoff(zip_path, approval_registry))
}
