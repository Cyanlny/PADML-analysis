# 模型签名模块：规范化科学配置并生成稳定身份。
normalize_formula_terms <- function(formula_text) {
  parts <- strsplit(gsub("\\s+", "", formula_text), "~", fixed = FALSE)[[1L]]
  if (length(parts) != 2L) stop("Formula must contain one ~", call. = FALSE)
  rhs <- strsplit(parts[[2L]], "\\+")[[1L]]
  rhs <- sort(unique(rhs[nzchar(rhs)]), method = "radix")
  paste(parts[[1L]], paste(rhs, collapse = "+"), sep = "~")
}

model_signature_sha256 <- function(endpoint, population, exposure, exposure_scale,
                                   formula_text, factor_references, ties_method,
                                   time_origin, time_function, tve_terms, contrast,
                                   pooling_method, confidence_level,
                                   scientific_config_revision) {
  # 加载摘要包以生成模型科学签名。
  if (!requireNamespace("digest", quietly = TRUE)) stop("digest is required", call. = FALSE)
  payload <- c(
    endpoint = endpoint,
    population = population,
    exposure = exposure,
    exposure_scale = exposure_scale,
    formula = normalize_formula_terms(formula_text),
    factor_references = paste(sort(factor_references, method = "radix"), collapse = "|"),
    ties_method = ties_method,
    time_origin = time_origin,
    time_function = time_function,
    tve_terms = paste(sort(tve_terms, method = "radix"), collapse = "|"),
    contrast = contrast,
    pooling_method = pooling_method,
    confidence_level = format(confidence_level, digits = 17),
    scientific_config_revision = scientific_config_revision
  )
  digest::digest(paste(names(payload), payload, sep = "=", collapse = "\n"), algo = "sha256", serialize = FALSE)
}

