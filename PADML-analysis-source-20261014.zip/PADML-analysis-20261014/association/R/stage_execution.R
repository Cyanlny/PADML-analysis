# 阶段执行编排：将分析对象转换为公开/受限 artifact、QC 和审核包。

qc_record <- function(qc_id, stage, check, observed, expected, status = "PASS", severity = "INFO", details = "") {
  data.frame(
    qc_id = qc_id, stage = stage, check = check, observed = as.character(observed), expected = as.character(expected),
    status = status, severity = severity, details = details, stringsAsFactors = FALSE
  )
}

scientific_config_hash <- function(project_root = ".") {
  if (!exists("read_contract_index", mode = "function") ||
      !exists("authority_digests", mode = "function")) {
    source(file.path(project_root, "R", "authority_engine.R"))
  }
  authority_digests(read_contract_index(project_root), project_root)$scientific_value_digest
}

.required_stage_artifact <- function(stage, context, require_restricted = FALSE) {
  compute_node <- identical(Sys.getenv("AST_ALT_STATELESS_COMPUTE_NODE", unset = ""), "TRUE")
  release_only <- identical(context$profile, "release_only")
  if (release_only && isTRUE(require_restricted)) {
    stop("RELEASE_ONLY_RESTRICTED_ARTIFACT_FORBIDDEN: ", stage, call. = FALSE)
  }
  if (compute_node || release_only) {
    public <- file.path(context$run_root, "approved_cache", "public", stage)
    restricted <- file.path(context$run_root, "approved_cache", "restricted", stage)
    validate_bundle_complete(public, expected_stage = stage, expected_classification = "PUBLIC_AGGREGATE")
    public_lock <- read_stage_lock(public)
    if (!public_lock$approval_basis %in% c("AUTO_GATE_PASS", "HUMAN_APPROVAL") ||
        isTRUE(public_lock$human_review_required)) {
      stop("STATELESS_UPSTREAM_NOT_LOCALLY_APPROVED: ", stage, call. = FALSE)
    }
    if (!release_only && dir.exists(restricted)) {
      validate_bundle_complete(restricted, expected_stage = stage)
      restricted_lock <- read_stage_lock(restricted)
      if (!identical(restricted_lock$approval_basis, public_lock$approval_basis) ||
          isTRUE(restricted_lock$human_review_required)) {
        stop("STATELESS_RESTRICTED_UPSTREAM_NOT_LOCALLY_APPROVED: ", stage, call. = FALSE)
      }
    } else if (isTRUE(require_restricted)) {
      stop("UPSTREAM_RESTRICTED_ARTIFACT_REQUIRED: ", stage, call. = FALSE)
    }
    restricted_present <- !release_only && dir.exists(restricted)
    artifact_semantic <- sha256_text(c(
      paste0("stage=", stage), paste0("public=", public_lock$bundle_sha256),
      paste0("restricted=", if (restricted_present) read_stage_lock(restricted)$bundle_sha256 else "")
    ))
    public_lock_sha <- file_sha256(file.path(public, "stage_lock.json"))
    return(list(
      path = "", sha256 = if (release_only) public_lock_sha else artifact_semantic,
      envelope = list(
        public_bundle_relative_path = file.path("approved_cache", "public", stage),
        stage_request_semantic_sha256 = public_lock$stage_request_semantic_sha256,
        artifact_semantic_sha256 = artifact_semantic
      ),
      public_bundle = public,
      restricted_bundle = if (restricted_present) restricted else "",
      review_package = ""
    ))
  }
  if (!exists("read_stage_artifact_envelope", mode = "function")) {
    source(file.path(context$project_root, "R", "epoch_guard.R"))
  }
  artifact <- read_stage_artifact_envelope(stage, context$run_root, verify_bundles = TRUE)
  if (isTRUE(require_restricted) && !nzchar(artifact$restricted_bundle)) {
    stop("UPSTREAM_RESTRICTED_ARTIFACT_REQUIRED: ", stage, call. = FALSE)
  }
  artifact
}

effective_scientific_config <- function(stage, context = stage_context()) {
  previous <- previous_stage_id(stage, context)
  if (nzchar(previous)) {
    previous_bundle <- if (nzchar(context$stage_capsule_sha256)) {
      .required_stage_artifact(previous, context)$public_bundle
    } else {
      file.path(context$run_root, "approved_cache", "public", previous)
    }
    if (dir.exists(previous_bundle)) {
      lock <- read_stage_lock(previous_bundle)
      return(list(
        sha256 = lock$scientific_config_sha256,
        revision = if (!is.null(lock$scientific_config_revision)) lock$scientific_config_revision else "v4.3-r00"
      ))
    }
  }
  list(sha256 = scientific_config_hash(context$project_root), revision = "v4.3-r00")
}

stage_bundle_lineage <- function(stage, context, pre_seal_sentinel_sha256) {
  required <- c(
    "stage_request_semantic_sha256", "source_epoch", "science_epoch", "execution_epoch", "runtime_epoch",
    "publication_epoch", "stage_contract_sha256", "input_identity_sha256",
    "upstream_artifact_sha256", "exact_consumer_set_sha256",
    "reachable_authority_slice_sha256", "stage_capsule_sha256",
    "pre_stage_sentinel_sha256"
  )
  if (!identical(context$stage, stage) || any(!vapply(context[required], function(value) {
    is.character(value) && length(value) == 1L && grepl("^[0-9a-f]{64}$", value)
  }, logical(1))) || !is.character(context$consumed_epoch_set) ||
      length(context$consumed_epoch_set) != 1L ||
      !grepl("^(source|science|execution|runtime|publication)(\\|(source|science|execution|runtime|publication))*$", context$consumed_epoch_set)) {
    stop("STAGE_BUNDLE_LINEAGE_CONTEXT_INVALID", call. = FALSE)
  }
  list(
    consumed_epoch_set = context$consumed_epoch_set,
    stage_request_semantic_sha256 = context$stage_request_semantic_sha256,
    source_epoch = context$source_epoch,
    science_epoch = context$science_epoch,
    execution_epoch = context$execution_epoch,
    runtime_epoch = context$runtime_epoch,
    publication_epoch = context$publication_epoch,
    source_handoff_sha256 = if (nzchar(context$handoff_sha256)) {
      context$handoff_sha256
    } else {
      Sys.getenv("AST_ALT_FROZEN_SOURCE_HANDOFF_SHA256", unset = "")
    },
    stage_contract_sha256 = context$stage_contract_sha256,
    input_identity_sha256 = context$input_identity_sha256,
    upstream_artifact_sha256 = context$upstream_artifact_sha256,
    exact_consumer_set_sha256 = context$exact_consumer_set_sha256,
    reachable_authority_slice_sha256 = context$reachable_authority_slice_sha256,
    stage_capsule_sha256 = context$stage_capsule_sha256,
    pre_stage_sentinel_sha256 = context$pre_stage_sentinel_sha256,
    pre_seal_sentinel_sha256 = pre_seal_sentinel_sha256
  )
}

write_stage_csv <- function(data, stage, file_name, context = stage_context()) {
  path <- file.path(stage_work_dir(stage, context), file_name)
  # 输出阶段 canonical 或 QC CSV。
  utils::write.csv(data, path, row.names = FALSE, na = "")
  path
}

write_stage_csv_gz <- function(data, stage, file_name, context = stage_context()) {
  path <- file.path(stage_work_dir(stage, context), file_name)
  connection <- gzfile(path, open = "wt", encoding = "UTF-8")
  on.exit(close(connection), add = TRUE)
  # 输出权威长表CSV.GZ；不建立第二权威Parquet副本。
  utils::write.csv(data, connection, row.names = FALSE, na = "")
  path
}

write_stage_json <- function(object, stage, file_name, context = stage_context()) {
  path <- file.path(stage_work_dir(stage, context), file_name)
  # 加载JSON包并输出不含患者标识的机器审核摘要。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  jsonlite::write_json(object, path, auto_unbox = TRUE, pretty = TRUE, na = "null")
  path
}

write_stage_rds <- function(object, stage, file_name, context = stage_context(), restricted = TRUE) {
  path <- file.path(stage_work_dir(stage, context), file_name)
  # 保存阶段 RDS；患者级对象仅允许进入受限 bundle。
  saveRDS(object, path, compress = "xz")
  if (restricted) invisible(Sys.chmod(path, mode = "0600", use_umask = FALSE))
  path
}

stage_output_manifest <- function(files, stage) {
  if (!length(files)) return(data.frame())
  data.frame(
    stage = stage, file_name = basename(files), format = toupper(tools::file_ext(files)),
    size_bytes = file.info(files)$size,
    sha256 = vapply(files, file_sha256, character(1)),
    exists = file.exists(files), stringsAsFactors = FALSE
  )
}

expected_stage_outputs <- function(stage, context = stage_context()) {
  registry <- utils::read.csv(file.path(context$project_root, "config", "output_registry.csv"), stringsAsFactors = FALSE, check.names = FALSE)
  subset <- registry[registry$producer_stage == stage | registry$publication_stage == stage, , drop = FALSE]
  if (!nrow(subset)) subset <- registry[registry$stage == stage, , drop = FALSE]
  if (!nrow(subset)) {
    return(data.frame(
      output_id = character(), file_name = character(), required = logical(), expected_source_file = character(),
      actual_exists = logical(), producer_stage = character(), stringsAsFactors = FALSE
    ))
  }
  data.frame(
    output_id = subset$output_id, file_name = subset$file_name, required = subset$required,
    expected_source_file = subset$source_canonical_file,
    actual_exists = FALSE, producer_stage = if ("producer_stage" %in% names(subset)) subset$producer_stage else subset$stage,
    stringsAsFactors = FALSE
  )
}

warning_frame <- function(stage, warning_code = character(), class = character(), message_cn = character(), required_action = character()) {
  if (!length(warning_code)) return(data.frame(warning_code = character(), stage = character(), class = character(), message_cn = character(), required_action = character(), stringsAsFactors = FALSE))
  data.frame(warning_code = warning_code, stage = stage, class = class, message_cn = message_cn, required_action = required_action, stringsAsFactors = FALSE)
}

.a07_attempt_bundle_root <- function(stage, context) {
  if (!identical(context$profile, "release_only")) return(context$run_root)
  request_sha256 <- context$stage_request_semantic_sha256
  if (!identical(stage, "A07") || !is.character(request_sha256) ||
      length(request_sha256) != 1L || !grepl("^[0-9a-f]{64}$", request_sha256)) {
    stop("RELEASE_ONLY_ATTEMPT_IDENTITY_INVALID", call. = FALSE)
  }
  file.path(context$run_root, "stage_work", stage, "attempts", request_sha256)
}

publish_stage_analysis <- function(
    stage, status, public_files, restricted_files = character(), qc_results,
    warnings = data.frame(), key_results = data.frame(), config_diff = data.frame(),
    deviations = data.frame(), cache_audit = data.frame(), review_sections = list(), context = stage_context()) {
  source(file.path(context$project_root, "R", "bundle_manager.R"))
  source(file.path(context$project_root, "R", "review_pack.R"))
  source(file.path(context$project_root, "R", "stage_gate.R"))
  source(file.path(context$project_root, "R", "epoch_guard.R"))
  gate_columns <- c("qc_id", "stage", "check", "observed", "expected", "status", "severity", "details")
  if (!is.data.frame(qc_results) || !nrow(qc_results) || !identical(names(qc_results), gate_columns)) {
    stop("LOCAL_GATE_QC_SCHEMA_INVALID", call. = FALSE)
  }
  gate_warnings <- if (is.data.frame(warnings) && ncol(warnings)) warnings else warning_frame(stage)
  warning_columns <- c("warning_code", "stage", "class", "message_cn", "required_action")
  if (!identical(names(gate_warnings), warning_columns)) {
    stop("LOCAL_GATE_WARNING_SCHEMA_INVALID", call. = FALSE)
  }
  # 输出本阶段完整 QC，供本地主控独立形成批准门禁。
  local_gate_qc_file <- write_stage_csv(qc_results, stage, "LOCAL_GATE_QC.csv", context)
  # 输出本阶段完整 warning，供本地主控识别自动通过与人工批准边界。
  local_gate_warning_file <- write_stage_csv(
    gate_warnings, stage, "LOCAL_GATE_WARNINGS.csv", context
  )
  local_gate_files <- c(local_gate_qc_file, local_gate_warning_file)
  public_files <- unique(c(public_files, local_gate_files))
  # 在发布任何 bundle 前重新计算实际消费身份并写入 PRE_SEAL 事件，禁止跨 epoch seal。
  pre_seal <- record_pre_seal_drift(context)
  compute_node <- identical(Sys.getenv("AST_ALT_STATELESS_COMPUTE_NODE", unset = ""), "TRUE")
  release_only <- identical(context$profile, "release_only")
  if (release_only && length(restricted_files)) {
    stop("RELEASE_ONLY_RESTRICTED_OUTPUT_FORBIDDEN", call. = FALSE)
  }
  pass <- status %in% c("PASS_AUTO_CONTINUE", "PASS_WITH_NONBLOCKING_WARNINGS")
  published_status <- status
  cache_root <- if (compute_node || release_only || !pass) "candidate_cache" else "approved_cache"
  approval_basis <- if (pass) "AUTO_GATE_PASS" else "PENDING_HUMAN_REVIEW"
  human_review_required <- !pass
  scientific_config <- effective_scientific_config(stage, context)
  lineage <- stage_bundle_lineage(stage, context, pre_seal$sha256)
  schema_suffix <- if (identical(stage, "A03")) "_R02" else ""
  bundle_root <- .a07_attempt_bundle_root(stage, context)
  public_bundle <- publish_bundle_atomic(
    stage, public_files, "PUBLIC_AGGREGATE", bundle_root,
    stage_status = published_status, approval_basis = approval_basis, human_review_required = human_review_required,
    scientific_config_sha256 = scientific_config$sha256, scientific_config_revision = scientific_config$revision,
    lineage = lineage,
    bundle_schema_version = paste0(stage, "_PUBLIC_BUNDLE_V2", schema_suffix),
    replace_existing = identical(context$profile, "build_validation"), cache_root_name = cache_root
  )
  restricted_bundle <- ""
  if (length(restricted_files)) {
    restricted_bundle <- publish_bundle_atomic(
      stage, restricted_files, "PATIENT_LEVEL_RESTRICTED", bundle_root,
      stage_status = published_status, approval_basis = approval_basis, human_review_required = human_review_required,
      scientific_config_sha256 = scientific_config$sha256, scientific_config_revision = scientific_config$revision,
      lineage = lineage,
      bundle_schema_version = paste0(stage, "_RESTRICTED_BUNDLE_V2", schema_suffix),
      replace_existing = identical(context$profile, "build_validation"), cache_root_name = cache_root
    )
  }
  manifest <- stage_output_manifest(public_files, stage)
  expected <- expected_stage_outputs(stage, context)
  if (nrow(expected)) expected$actual_exists <- expected$expected_source_file %in% manifest$file_name
  if (compute_node || release_only) {
    return(write_stage_result(
      stage, published_status, public_bundle, restricted_bundle, "",
      candidate = TRUE, root = context$run_root
    ))
  }
  lock_path <- file.path(public_bundle, "stage_lock.json")
  stage_pack <- build_stage_review_pack(
    stage = stage, status = status, qc_results = qc_results, warnings = warnings,
    key_results = key_results, output_manifest = manifest, expected_outputs = expected,
    config_diff = config_diff, deviations = deviations, cache_audit = cache_audit,
    stage_lock_path = lock_path, review_sections = review_sections,
    root = context$run_root, run_id = context$run_id
  )
  stage_archive <- build_stage_review_archive(stage_pack, stage, context$run_root)
  consolidated <- build_consolidated_review_package(context$run_root, stage, context$run_id)
  if (!file.exists(consolidated)) stop("Consolidated review package is missing", call. = FALSE)
  write_stage_result(
    stage, status, public_bundle, restricted_bundle, stage_archive,
    candidate = !pass, root = context$run_root
  )
}

previous_stage_id <- function(stage, context = stage_context()) {
  registry <- utils::read.csv(file.path(context$project_root, "config", "task_registry.csv"), stringsAsFactors = FALSE, check.names = FALSE)
  dependency <- registry$dependency[match(stage, registry$stage)]
  if (!length(dependency) || is.na(dependency) || dependency == "none") "" else dependency
}

validate_previous_public_bundle <- function(stage, context = stage_context()) {
  previous <- previous_stage_id(stage, context)
  if (!nzchar(previous)) return(data.frame(previous_stage = "none", status = "PASS"))
  artifact <- .required_stage_artifact(previous, context)
  data.frame(
    previous_stage = previous,
    bundle_path = artifact$envelope$public_bundle_relative_path,
    artifact_envelope_sha256 = artifact$sha256,
    stage_request_semantic_sha256 = artifact$envelope$stage_request_semantic_sha256,
    status = "PASS",
    stringsAsFactors = FALSE
  )
}

load_previous_analysis_state <- function(stage, context = stage_context()) {
  previous <- previous_stage_id(stage, context)
  if (!nzchar(previous)) stop("Stage has no previous restricted state", call. = FALSE)
  artifact <- .required_stage_artifact(previous, context, require_restricted = TRUE)
  path <- artifact$restricted_bundle
  validate_bundle_complete(
    path, expected_stage = previous,
    expected_classification = "PATIENT_LEVEL_RESTRICTED"
  )
  readRDS(read_bundle_file(path, "analysis_state.rds"))
}

run_p00_preflight <- function(context = stage_context()) {
  profile_registry <- utils::read.csv(file.path(context$project_root, "config", "execution_profile_registry.csv"), stringsAsFactors = FALSE)
  budget <- yaml::read_yaml(file.path(context$project_root, "config", "runtime_budget.yml"))
  profile_ok <- context$profile %in% profile_registry$profile
  handoff_qc <- if (context$profile == "production") {
    approval <- resolve_approved_handoff(Sys.getenv("AST_ALT_HANDOFF_ZIP", ""), context$project_root)
    if (!identical(approval$identity$handoff_identity_sha256, context$handoff_identity_sha256)) {
      stop("HANDOFF_CONTEXT_IDENTITY_DRIFT", call. = FALSE)
    }
    inspect_handoff_zip_structure(Sys.getenv("AST_ALT_HANDOFF_ZIP", ""), approval$row)
  } else {
    data.frame(member = "synthetic_fixture", present_n = 1L, status = "PASS")
  }
  # 中文备注：加载正式冻结 handoff，仅执行 registry、资源与真实结构 canary，不拟合任何模型。
  sources <- load_analysis_sources(
    context$profile, context$project_root,
    Sys.getenv("AST_ALT_HANDOFF_ZIP", ""), context$run_root
  )
  structure <- if (context$profile == "production") {
    run_real_structure_canary(sources, context$project_root)
  } else {
    data.frame(qc_item = "synthetic_structure", observed = TRUE, expected = TRUE, status = "PASS")
  }
  required <- c(
    "warning_registry.csv", "table1_method_registry.csv", "model_registry.csv", "endpoint_registry.csv",
    "estimand_registry.csv", "output_registry.csv", "qc_gate_registry.csv", "multiparameter_pooling_registry.csv",
    "collinearity_registry.csv", "collinearity_decision_matrix.csv"
  )
  present <- file.exists(file.path(context$project_root, "config", required))
  registries <- data.frame(
    registry = required, present = present,
    status = ifelse(present, "PASS", "FAIL"), stringsAsFactors = FALSE
  )
  model <- utils::read.csv(file.path(context$project_root, "config", "model_registry.csv"), stringsAsFactors = FALSE)
  endpoint <- utils::read.csv(file.path(context$project_root, "config", "endpoint_registry.csv"), stringsAsFactors = FALSE)
  formula_checks <- do.call(rbind, lapply(model$model_id, function(id) {
    text <- build_cox_formula_text(id, endpoint[1, , drop = FALSE], "log2_AST_ALT", context$project_root)
    data.frame(
      model_id = id, formula = text,
      parse_status = ifelse(inherits(try(stats::as.formula(text), silent = TRUE), "try-error"), "FAIL", "PASS"),
      stringsAsFactors = FALSE
    )
  }))
  df_output <- system2("df", c("-Pk", context$run_root), stdout = TRUE)
  df_fields <- strsplit(trimws(df_output[[2L]]), "[[:space:]]+")[[1L]]
  # 中文备注：df -Pk 的第 4 列为可用空间（KiB），最后一列是挂载路径。
  disk_free_gb <- as.numeric(df_fields[[4L]]) / 1024 / 1024
  minimum_disk <- as.numeric(budget$minimum_free_disk_gb)
  qc <- rbind(
    qc_record("P00_PROFILE", "P00", "execution_profile", profile_ok, TRUE, ifelse(profile_ok, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("P00_HANDOFF", "P00", "handoff_structure", all(handoff_qc$status == "PASS"), TRUE, ifelse(all(handoff_qc$status == "PASS"), "PASS", "FAIL"), "HARD_STOP"),
    qc_record("P00_RESOURCE", "P00", "free_disk_gb", round(disk_free_gb, 2), minimum_disk, ifelse(disk_free_gb >= minimum_disk || context$profile == "build_validation", "PASS", "WARNING"), ifelse(disk_free_gb >= minimum_disk || context$profile == "build_validation", "INFO", "BLOCKING_WARNING")),
    qc_record("P00_REGISTRY", "P00", "required_registries", all(present), TRUE, ifelse(all(present), "PASS", "FAIL"), "HARD_STOP"),
    qc_record("P00_FORMULA", "P00", "model_formula_parse", all(formula_checks$parse_status == "PASS"), TRUE, ifelse(all(formula_checks$parse_status == "PASS"), "PASS", "FAIL"), "HARD_STOP"),
    qc_record("P00_STRUCTURE", "P00", "production_real_structure_canary_no_fit", all(structure$status == "PASS"), TRUE, ifelse(all(structure$status == "PASS"), "PASS", "FAIL"), "HARD_STOP"),
    qc_record("P00_HANDOFF_CONTRACT", "P00", "handoff_contract", all(sources$contract_qc$status == "PASS"), TRUE, ifelse(all(sources$contract_qc$status == "PASS"), "PASS", "FAIL"), "HARD_STOP"),
    qc_record("P00_G12", "P00", "g12_centering", abs(g12(12)), "<=1e-15", ifelse(abs(g12(12)) <= 1e-15, "PASS", "FAIL"), "HARD_STOP")
  )
  list(
    qc = qc, handoff_qc = handoff_qc, budget = budget,
    registries = registries, formula_checks = formula_checks,
    structure = structure, contract = sources$contract_qc
  )
}

run_a01_analysis <- function(sources, context = stage_context()) {
  exposure <- freeze_exposure_identity(sources)
  table1_registry <- utils::read.csv(file.path(context$project_root, "config", "table1_method_registry.csv"), stringsAsFactors = FALSE, check.names = FALSE)
  table1 <- summarize_table1(exposure$imp0_eligible, table1_registry)
  endpoint_registry <- utils::read.csv(file.path(context$project_root, "config", "endpoint_registry.csv"), stringsAsFactors = FALSE, check.names = FALSE)
  riskset <- compute_riskset_results(exposure$imp0_eligible, endpoint_registry)
  km <- compute_km_canonical(exposure$imp0_eligible)
  list(sources = sources, exposure = exposure, table1 = table1, riskset = riskset, km = km, endpoint_registry = endpoint_registry)
}

qc_a01_analysis <- function(analysis) {
  identity_pass <- all(analysis$exposure$identity_qc$status == "PASS")
  exposure_pass <- all(analysis$exposure$exposure_summary$status[analysis$exposure$exposure_summary$metric %in% c("max_identity_difference", "tertile_mismatch_n")] == "PASS")
  missing_table1 <- sum(analysis$table1$estimate_status != "ESTIMABLE")
  rbind(
    qc_record("A01_HANDOFF", "A01", "source_contract", all(analysis$sources$contract_qc$status == "PASS"), TRUE, ifelse(all(analysis$sources$contract_qc$status == "PASS"), "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A01_IDENTITY", "A01", "patient_identity_across_imputations", identity_pass, TRUE, ifelse(identity_pass, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A01_EXPOSURE", "A01", "frozen_original_exposure_identity", exposure_pass, TRUE, ifelse(exposure_pass, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A01_TERTILE", "A01", "tertile_mismatch_n", analysis$exposure$exposure_summary$value[analysis$exposure$exposure_summary$metric == "tertile_mismatch_n"], 0, ifelse(exposure_pass, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A01_TABLE1", "A01", "table1_registry_coverage", missing_table1, 0, ifelse(missing_table1 == 0L, "PASS", "WARNING"), ifelse(missing_table1 == 0L, "INFO", "BLOCKING_WARNING")),
    qc_record("A01_RISKSET", "A01", "riskset_four_timepoints", nrow(analysis$riskset), ">=4", ifelse(nrow(analysis$riskset) >= 4L, "PASS", "FAIL"), "HARD_STOP")
  )
}

materialize_a01 <- function(analysis, context = stage_context()) {
  stage <- "A01"
  public <- c(
    write_stage_csv(analysis$sources$contract_qc, stage, "source_contract_qc.csv", context),
    write_stage_csv(analysis$sources$structure_qc, stage, "completed_data_structure_qc.csv", context),
    write_stage_csv(analysis$exposure$exposure_summary, stage, "exposure_identity_summary.csv", context),
    write_stage_csv(analysis$exposure$exposure_scale, stage, "exposure_scale_lock.csv", context),
    write_stage_csv(analysis$exposure$identity_qc, stage, "patient_identity_consistency_aggregate.csv", context),
    write_stage_csv(analysis$riskset, stage, "riskset_results.csv", context),
    write_stage_csv(analysis$table1, stage, "table1_results.csv", context),
    write_stage_csv(analysis$km$curve, stage, "km_curve_results.csv", context),
    write_stage_csv(analysis$km$logrank, stage, "km_logrank_results.csv", context)
  )
  private_path <- file.path(stage_work_dir(stage, context), "frozen_exposure_identity_private.rds")
  write_private_identity(analysis$exposure$private_identity, private_path)
  state <- list(
    sources = analysis$sources,
    exposure = analysis$exposure,
    table1 = analysis$table1,
    riskset = analysis$riskset,
    km = analysis$km,
    endpoint_registry = analysis$endpoint_registry
  )
  restricted <- c(write_stage_rds(state, stage, "analysis_state.rds", context), private_path)
  list(public_files = public, restricted_files = restricted, state = state)
}

run_a02_analysis <- function(state, context = stage_context()) {
  owner <- read_a02_mi_qc_owner(context$project_root)
  target_names <- a02_imputed_target_names(state$sources$mids)
  list(
    distribution_qc = run_imputation_distribution_qc(
      state$sources, state$exposure$completed, target_names, owner
    ),
    structure_qc = run_imputation_structure_qc(
      state$exposure$completed, expected_m = as.integer(owner$recipe$m)
    ),
    logged_events = summarize_logged_events(state$sources$logged_events),
    chain_diagnostics = compute_mids_chain_diagnostics(state$sources$mids, context$project_root)
  )
}

qc_a02_analysis <- function(analysis) {
  structure_pass <- all(analysis$structure_qc$status == "PASS")
  illegal <- sum(analysis$distribution_qc$illegal_level_n, na.rm = TRUE)
  remaining <- sum(analysis$distribution_qc$remaining_missing_n, na.rm = TRUE)
  logged <- nrow(analysis$logged_events)
  chain_pass <- all(analysis$chain_diagnostics$psrf_status == "PASS")
  chain_missing_nonfinite <- sum(
    is.na(analysis$chain_diagnostics$psrf) |
      is.na(analysis$chain_diagnostics$lag1_autocorrelation) |
      (!is.na(analysis$chain_diagnostics$psrf) & !is.finite(analysis$chain_diagnostics$psrf)) |
      (!is.na(analysis$chain_diagnostics$lag1_autocorrelation) &
        !is.finite(analysis$chain_diagnostics$lag1_autocorrelation)),
    na.rm = TRUE
  )
  lag1_review_n <- sum(analysis$chain_diagnostics$lag1_review_flag == "MANUAL_REVIEW", na.rm = TRUE)
  shift_review_n <- sum(analysis$distribution_qc$review_flag == "MANUAL_REVIEW", na.rm = TRUE)
  rbind(
    qc_record("A02_STRUCTURE", "A02", "completed_dataset_structure", structure_pass, TRUE, ifelse(structure_pass, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A02_LEVELS", "A02", "new_illegal_factor_levels", illegal, 0, ifelse(illegal == 0L, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A02_MISSING", "A02", "remaining_missingness", remaining, 0, ifelse(remaining == 0L, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A02_CHAIN", "A02", "chain_mean_sd_psrf", chain_pass, TRUE, ifelse(chain_pass, "PASS", "WARNING"), ifelse(chain_pass, "INFO", "BLOCKING_WARNING")),
    qc_record("A02_CHAIN_FINITE", "A02", "chain_diagnostic_missing_or_nonfinite", chain_missing_nonfinite, 0, ifelse(chain_missing_nonfinite == 0L, "PASS", "WARNING"), ifelse(chain_missing_nonfinite == 0L, "INFO", "BLOCKING_WARNING")),
    qc_record("A02_AUTOCORRELATION", "A02", "chain_lag1_autocorrelation_manual_review", lag1_review_n, 0, ifelse(lag1_review_n == 0L, "PASS", "WARNING"), ifelse(lag1_review_n == 0L, "INFO", "BLOCKING_WARNING")),
    qc_record("A02_SHIFT", "A02", "standardized_mean_shift_manual_review", shift_review_n, 0, ifelse(shift_review_n == 0L, "PASS", "WARNING"), ifelse(shift_review_n == 0L, "INFO", "BLOCKING_WARNING")),
    qc_record("A02_LOGGED", "A02", "logged_events_review", logged, 0, ifelse(logged == 0L, "PASS", "WARNING"), ifelse(logged == 0L, "INFO", "BLOCKING_WARNING"))
  )
}

materialize_a02 <- function(previous_state, analysis, context = stage_context()) {
  stage <- "A02"
  public <- c(
    write_stage_csv(analysis$distribution_qc, stage, "imputation_qc_results.csv", context),
    write_stage_csv(analysis$structure_qc, stage, "imputation_structure_qc.csv", context),
    write_stage_csv(analysis$logged_events, stage, "imputation_logged_events.csv", context),
    write_stage_csv(analysis$chain_diagnostics, stage, "imputation_chain_diagnostics.csv", context)
  )
  previous_state$imputation_qc <- analysis
  restricted <- write_stage_rds(previous_state, stage, "analysis_state.rds", context)
  list(public_files = public, restricted_files = restricted, state = previous_state)
}

qc_a03_analysis <- function(analysis, profile = "production", project_root = ".") {
  completeness <- aggregate(converged ~ model_id + exposure_form, analysis$fixed$diagnostics, sum)
  all_complete <- all(completeness$converged == 20L)
  fit_count_pass <- analysis$fixed$observed_fixed_cox_fit_count == 200L
  design_qc <- analysis$collinearity$design_qc
  condition_block <- any(design_qc$design_status %in% c("EXACT_ALIAS", "NUMERIC_RANK_DEFICIENCY", "ILL_CONDITIONED_FULL_RANK"), na.rm = TRUE)
  d1_consistent <- all(analysis$collinearity$parameter_consistency$d1_parameter_set_consistency)
  receipt <- analysis$collinearity$receipt
  missing_design_pass <- receipt$vif_missing_design_count[[1L]] == 0L
  no_modification <- all(c(
    receipt$predictor_deletion_count[[1L]], receipt$predictor_recode_count[[1L]],
    receipt$reference_level_change_count[[1L]], receipt$formula_change_count[[1L]]
  ) == 0L)
  fixed_signature <- unique(analysis$fixed$diagnostics[c("fit_id", "model_signature_sha256")])
  ph_signature <- unique(analysis$ph$per_imputation_term[c("fit_id", "model_signature_sha256")])
  names(ph_signature)[[2L]] <- "ph_model_signature_sha256"
  diagnostic_signature <- unique(analysis$collinearity$diagnostic_linkage[c("fit_id", "model_signature_sha256")])
  names(diagnostic_signature)[[2L]] <- "diagnostic_model_signature_sha256"
  signature_linkage <- merge(fixed_signature, ph_signature, by = "fit_id", all = TRUE)
  signature_linkage <- merge(signature_linkage, diagnostic_signature, by = "fit_id", all = TRUE)
  signature_pass <- nrow(signature_linkage) == 200L && !anyDuplicated(signature_linkage$fit_id) &&
    all(stats::complete.cases(signature_linkage)) &&
    all(signature_linkage$model_signature_sha256 == signature_linkage$ph_model_signature_sha256) &&
    all(signature_linkage$model_signature_sha256 == signature_linkage$diagnostic_model_signature_sha256)
  rubin_df_audit <- evaluate_rubin_df_contract_v43(
    analysis$fixed$canonical, project_root, "A03/fixed_cox_results.csv"
  )
  rubin_df_pass <- identical(rubin_df_audit$status, "PASS")
  schoenfeld_public_safe <- is.data.frame(analysis$schoenfeld$public_trend) &&
    !any(c("event_index", "event_time", "scaled_residual", "Patient_ID") %in%
      names(analysis$schoenfeld$public_trend))
  schoenfeld_fit_count <- if (
      length(analysis$schoenfeld$fit_count_added) == 1L &&
      is.finite(analysis$schoenfeld$fit_count_added)
    ) as.integer(analysis$schoenfeld$fit_count_added) else NA_integer_
  schoenfeld_no_refit <- identical(schoenfeld_fit_count, 0L)
  diagnostic_registry <- utils::read.csv(
    file.path(project_root, "config", "diagnostic_extension_registry.csv"),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  expected_schoenfeld <- diagnostic_registry[
    diagnostic_registry$producer_stage == "A03", , drop = FALSE
  ]
  expected_schoenfeld_key <- paste(
    expected_schoenfeld$diagnostic_id, expected_schoenfeld$series_id, sep = "\r"
  )
  observed_schoenfeld_key <- if (is.data.frame(analysis$schoenfeld$status)) {
    paste(
      analysis$schoenfeld$status$diagnostic_id,
      analysis$schoenfeld$status$series_id, sep = "\r"
    )
  } else character()
  trend_schoenfeld_key <- if (is.data.frame(analysis$schoenfeld$public_trend) &&
      nrow(analysis$schoenfeld$public_trend)) {
    paste(
      analysis$schoenfeld$public_trend$diagnostic_id,
      analysis$schoenfeld$public_trend$series_id, sep = "\r"
    )
  } else character()
  observed_trend_n <- table(factor(trend_schoenfeld_key, levels = expected_schoenfeld_key))
  status_order <- match(expected_schoenfeld_key, observed_schoenfeld_key)
  expected_trend_n <- if (all(is.finite(status_order))) {
    ifelse(
      nzchar(analysis$schoenfeld$status$resolved_term[status_order]),
      as.integer(expected_schoenfeld$public_grid_n), 0L
    )
  } else rep(NA_integer_, nrow(expected_schoenfeld))
  schoenfeld_closure <- nrow(expected_schoenfeld) > 0L &&
    length(observed_schoenfeld_key) == length(expected_schoenfeld_key) &&
    !anyDuplicated(observed_schoenfeld_key) &&
    identical(sort(observed_schoenfeld_key), sort(expected_schoenfeld_key)) &&
    all(as.integer(observed_trend_n) == expected_trend_n) &&
    all(analysis$schoenfeld$public_trend$data_classification == "PUBLIC_AGGREGATE")
  schoenfeld_estimable <- schoenfeld_closure &&
    all(analysis$schoenfeld$status$status == "ESTIMABLE") &&
    all(
      analysis$schoenfeld$status$valid_imputation_n[status_order] >=
        expected_schoenfeld$minimum_valid_imputations
    )
  candidate <- analysis$ph$trigger_summary[
    analysis$ph$trigger_summary$triggered & !analysis$ph$trigger_summary$parent_term %in% c("log2_AST_ALT", "AST_ALT_Tertile", "Rutherford_cat"),
    , drop = FALSE
  ]
  qc <- rbind(
    qc_record("A03_COMPLETENESS", "A03", "M1_M5_20_of_20", all_complete, TRUE, ifelse(all_complete, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A03_FIT_COUNT", "A03", "planned_fixed_cox_fit_count_without_refit", analysis$fixed$observed_fixed_cox_fit_count, 200, ifelse(fit_count_pass, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A03_CONDITION", "A03", "design_condition_number_and_rank", safe_maximum(design_qc$design_condition_number_2), "full_rank_and_condition_review", ifelse(condition_block, "WARNING", "PASS"), ifelse(condition_block, "BLOCKING_WARNING", "INFO")),
    qc_record("A03_D1_PARAMETER_SET", "A03", "d1_parameter_set_consistency", d1_consistent, TRUE, ifelse(d1_consistent, "PASS", "WARNING"), ifelse(d1_consistent, "INFO", "BLOCKING_WARNING")),
    qc_record("A03_VIF_COVERAGE", "A03", "vif_missing_design_count", receipt$vif_missing_design_count[[1L]], 0, ifelse(missing_design_pass, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A03_NO_SELECTION", "A03", "vif_diagnostic_selection_effect", no_modification, TRUE, ifelse(no_modification, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A03_NO_REFIT", "A03", "diagnostic_triggered_additional_fit_count", receipt$ph_triggered_additional_fit_count[[1L]] + receipt$vif_triggered_additional_fit_count[[1L]] + receipt$design_diagnostic_triggered_fit_count[[1L]], 0, ifelse(receipt$refit_count[[1L]] == 0L, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A03_SCHOENFELD_NO_REFIT", "A03", "schoenfeld_additional_cox_fit_count", schoenfeld_fit_count, 0, ifelse(schoenfeld_no_refit, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A03_SCHOENFELD_PRIVACY", "A03", "public_schoenfeld_event_level_field_count", !schoenfeld_public_safe, FALSE, ifelse(schoenfeld_public_safe, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A03_SCHOENFELD_CLOSURE", "A03", "registered_series_status_and_120_point_grid_closure", schoenfeld_closure, TRUE, ifelse(schoenfeld_closure, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A03_SCHOENFELD_ESTIMABILITY", "A03", "registered_series_minimum_16_imputations", schoenfeld_estimable, TRUE, ifelse(schoenfeld_estimable, "PASS", "WARNING"), ifelse(schoenfeld_estimable, "INFO", "BLOCKING_WARNING")),
    qc_record("A03_SIGNATURE_LINKAGE", "A03", "fixed_ph_collinearity_model_signature_identity", signature_pass, TRUE, ifelse(signature_pass, "PASS", "FAIL"), "HARD_STOP"),
    qc_record(
      "QC029", "A03", "rubin_df_valid", rubin_df_audit$invalid_row_n, 0,
      ifelse(rubin_df_pass, "PASS", "FAIL"), "HARD_STOP",
      paste0(
        "RUBIN_DF_1A;finite=", rubin_df_audit$finite_rubin_df_row_n,
        ";exact_zero_between_positive_infinity=",
        rubin_df_audit$zero_between_positive_infinite_rubin_df_row_n,
        ";selection_sha256=", rubin_df_audit$selection_sha256
      )
    ),
    qc_record("A03_PH_CANDIDATE", "A03", "new_nuisance_tve_candidate_n", nrow(candidate), 0,
      ifelse(nrow(candidate) == 0L, "PASS", "WARNING"),
      ifelse(nrow(candidate) == 0L, "INFO", ifelse(profile == "build_validation", "NONBLOCKING_WARNING", "BLOCKING_WARNING")))
  )
  list(qc = qc, candidate = candidate, rubin_df_audit = rubin_df_audit)
}

materialize_a03 <- function(
    previous_state, analysis, candidate, context = stage_context(), rubin_df_audit = NULL) {
  stage <- "A03"
  fixed_result_path <- write_stage_csv(
    analysis$fixed$canonical, stage, "fixed_cox_results.csv", context
  )
  rubin_df_receipt <- finalize_rubin_df_qc_receipt_v43(
    rubin_df_audit, fixed_result_path, context$project_root
  )
  public <- c(
    fixed_result_path,
    write_stage_json(rubin_df_receipt, stage, "rubin_df_qc_receipt.json", context),
    write_stage_csv(analysis$fixed$diagnostics, stage, "fixed_cox_diagnostics.csv", context),
    write_stage_csv(analysis$ph$per_imputation_term, stage, "ph_per_imputation_term_results.csv", context),
    write_stage_csv(analysis$ph$parent_joint, stage, "ph_parent_joint_results.csv", context),
    write_stage_csv(analysis$ph$per_imputation_dummy, stage, "ph_per_imputation_dummy_results.csv", context),
    write_stage_csv(analysis$ph$dummy_direction_summary, stage, "ph_dummy_direction_summary.csv", context),
    write_stage_csv(analysis$ph$trigger_summary, stage, "ph_trigger_summary.csv", context),
    write_stage_csv(analysis$schoenfeld$public_trend, stage, "schoenfeld_trend_a03.csv", context),
    write_stage_csv(analysis$schoenfeld$status, stage, "schoenfeld_status_a03.csv", context),
    write_stage_csv(analysis$collinearity$design_qc, stage, "design_matrix_qc.csv", context),
    write_stage_csv_gz(analysis$collinearity$long, stage, "collinearity_per_imputation.csv.gz", context),
    write_stage_csv(analysis$collinearity$summary, stage, "multicollinearity_summary.csv", context),
    write_stage_csv(analysis$collinearity$s10, stage, "collinearity_s10_results.csv", context),
    write_stage_csv(analysis$collinearity$exception_publication, stage, "collinearity_exception_publication.csv", context),
    write_stage_csv(analysis$collinearity$model_fit_status, stage, "model_fit_status.csv", context),
    write_stage_csv(analysis$collinearity$diagnostic_linkage, stage, "model_diagnostic_linkage.csv", context),
    write_stage_csv(analysis$collinearity$design_request_registry, stage, "unique_design_matrix_request_registry.csv", context),
    write_stage_csv(analysis$collinearity$fit_request_registry, stage, "unique_fit_diagnostic_request_registry.csv", context),
    write_stage_csv(analysis$collinearity$parameter_consistency, stage, "coefficient_parameter_consistency.csv", context),
    write_stage_json(as.list(analysis$collinearity$receipt[1L, , drop = FALSE]), stage, "vif_summary_receipt.json", context),
    write_stage_json(split(analysis$collinearity$failure_summary, seq_len(nrow(analysis$collinearity$failure_summary))), stage, "vif_failure_summary.json", context),
    write_stage_csv(candidate, stage, "ph_nuisance_registry_candidate.csv", context),
    write_stage_csv(if (nrow(candidate)) transform(candidate, proposed_revision = "r02_A03_APPROVED", candidate_status = "PENDING_HUMAN_APPROVAL") else candidate, stage, "scientific_config_candidate.csv", context),
    write_stage_csv(if (nrow(candidate)) transform(candidate, change_type = "ADD_NUISANCE_TVE", previous_value = "fixed_effect_only", proposed_value = "fixed_plus_g12_time_interaction") else candidate, stage, "scientific_config_diff_A03.csv", context)
  )
  # 中文备注：跨阶段状态只携带 canonical 结果与诊断；完整模型仅进入受限 Layer 1。
  previous_state$fixed_stage <- list(canonical = analysis$fixed$canonical, diagnostics = analysis$fixed$diagnostics)
  previous_state$ph_stage <- analysis$ph
  previous_state$schoenfeld_stage_a03 <- list(
    public_trend = analysis$schoenfeld$public_trend,
    status = analysis$schoenfeld$status
  )
  previous_state$collinearity_stage <- list(
    summary = analysis$collinearity$summary,
    receipt = analysis$collinearity$receipt,
    parameter_consistency = analysis$collinearity$parameter_consistency
  )
  compact_fixed_collections <- lapply(analysis$fixed$collections, compact_cox_collection)
  restricted <- c(
    write_stage_rds(previous_state, stage, "analysis_state.rds", context),
    write_stage_rds(compact_fixed_collections, stage, "fixed_model_objects_layer1.rds", context),
    write_stage_rds(list(
      event_level = analysis$schoenfeld$restricted_event_level,
      zph_objects = analysis$schoenfeld$restricted_zph_objects
    ), stage, "schoenfeld_a03_layer1.rds", context)
  )
  list(public_files = public, restricted_files = restricted, state = previous_state)
}

approved_nuisance_tve_terms <- function(context = stage_context()) {
  bundle <- .required_stage_artifact("A03", context)$public_bundle
  lock <- read_stage_lock(bundle)
  if (!identical(lock$approval_basis, "HUMAN_APPROVAL")) return(character())
  candidate_path <- tryCatch(read_bundle_file(bundle, "ph_nuisance_registry_candidate.csv"), error = function(e) "")
  if (!nzchar(candidate_path)) return(character())
  candidate <- utils::read.csv(candidate_path, stringsAsFactors = FALSE, check.names = FALSE)
  unique(candidate$parent_term[candidate$triggered])
}

combine_a04_analysis <- function(tve, rcs, nuisance_terms) {
  if (!is.list(tve) || !is.list(rcs) || !is.character(nuisance_terms)) {
    stop("A04_DYNAMIC_BRANCH_RESULT_INVALID", call. = FALSE)
  }
  list(tve = tve, rcs = rcs, nuisance_terms = nuisance_terms)
}

qc_a04_analysis <- function(analysis, exposure_scale) {
  complete <- all(analysis$tve$diagnostics$status == "PASS")
  projection <- read_rutherford_tve_projection(
    Sys.getenv("AST_ALT_PROJECT_ROOT", unset = ".")
  )
  rutherford <- analysis$tve$canonical[
    analysis$tve$canonical$exposure_parameterization %in%
      unname(projection$source_collection_to_parameterization),
    , drop = FALSE
  ]
  expected_rutherford <- expand.grid(
    exposure_parameterization = unname(
      projection$source_collection_to_parameterization
    ),
    contrast = unname(projection$contrasts),
    time_month = projection$time_months,
    stringsAsFactors = FALSE
  )
  row_key <- function(data) {
    do.call(paste, c(data, sep = "\r"))
  }
  rutherford_projection_complete <-
    nrow(rutherford) == projection$expected_row_n &&
    !anyDuplicated(rutherford$estimand_id) &&
    identical(
      sort(row_key(rutherford[c(
        "exposure_parameterization", "contrast", "time_month"
      )])),
      sort(row_key(expected_rutherford))
    ) &&
    nrow(analysis$tve$rutherford_per_imputation) ==
      length(projection$source_collection_to_parameterization) *
        length(projection$contrasts) * length(projection$time_months) * 20L &&
    !any(grepl(
      "Rutherford", analysis$tve$per_imputation$contrast,
      fixed = TRUE
    ))
  continuous <- analysis$tve$canonical[analysis$tve$canonical$exposure_parameterization == "log2_AST_ALT", , drop = FALSE]
  keys <- unique(continuous[c("model_id", "time_month")])
  identity_rows <- lapply(seq_len(nrow(keys)), function(i) {
    subset <- continuous[continuous$model_id == keys$model_id[[i]] & continuous$time_month == keys$time_month[[i]], , drop = FALSE]
    doubling <- subset$beta[subset$contrast == "per_doubling"]
    sd <- subset$beta[subset$contrast == "per_1_SD"]
    iqr <- subset$beta[subset$contrast == "per_IQR"]
    if (!length(doubling) || !length(sd) || !length(iqr)) return(data.frame(model_id = keys$model_id[[i]], time_month = keys$time_month[[i]], max_difference = Inf, status = "FAIL"))
    difference <- max(abs(sd - exposure_scale$log2_sd[[1L]] * doubling), abs(iqr - exposure_scale$log2_iqr[[1L]] * doubling))
    data.frame(model_id = keys$model_id[[i]], time_month = keys$time_month[[i]], max_difference = difference, status = ifelse(difference <= 1e-10, "PASS", "FAIL"))
  })
  identity <- do.call(rbind, identity_rows)
  rbind(
    qc_record("A04_TVE_COMPLETE", "A04", "TVE_20_of_20", complete, TRUE, ifelse(complete, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A04_RUTHERFORD_TVE", "A04", "RUTH_TVE_1C_exact_16_rows", rutherford_projection_complete, TRUE, ifelse(rutherford_projection_complete, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A04_G12", "A04", "g12_at_12", abs(g12(12)), "<=1e-15", ifelse(abs(g12(12)) <= 1e-15, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A04_SCALE", "A04", "continuous_scale_identity", max(identity$max_difference), "<=1e-10", ifelse(all(identity$status == "PASS"), "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A04_RCS", "A04", "rcs_numeric_contract", all(analysis$rcs$qc$status == "PASS"), TRUE, ifelse(all(analysis$rcs$qc$status == "PASS"), "PASS", "FAIL"), "HARD_STOP"),
    qc_record(
      "A04_RCS_CUTOFF", "A04", "rcs_cutoff_candidate_status_recorded",
      nrow(analysis$rcs$cutoff$candidate), 1,
      ifelse(nrow(analysis$rcs$cutoff$candidate) == 1L, "PASS", "FAIL"), "HARD_STOP"
    )
  )
}

a04_rcs_model_signature_sha256 <- function(analysis, context = stage_context()) {
  if (!requireNamespace("digest", quietly = TRUE)) stop("digest is required", call. = FALSE)
  if (!exists("normalize_formula_terms", mode = "function")) {
    source(file.path(context$project_root, "R", "model_signature.R"))
  }
  formula_text <- analysis$rcs$collections$formulas[["full"]]
  if (!is.character(formula_text) || length(formula_text) != 1L || !nzchar(formula_text)) {
    stop("A04_RCS_MODEL_SIGNATURE_FORMULA_MISSING", call. = FALSE)
  }
  spec <- analysis$rcs$spec
  config <- effective_scientific_config("A04", context)
  payload <- c(
    signature_schema = "RCS_MODEL_SIGNATURE_V1",
    endpoint = paste(sort(unique(analysis$rcs$curve$endpoint)), collapse = "|"),
    model_id = paste(sort(unique(analysis$rcs$curve$model_id)), collapse = "|"),
    formula = normalize_formula_terms(formula_text),
    knots = paste(format(as.numeric(spec$knots), digits = 17, scientific = FALSE), collapse = "|"),
    reference = format(as.numeric(spec$reference), digits = 17, scientific = FALSE),
    grid_n = as.character(length(spec$grid)),
    grid_sha256 = digest::digest(
      paste(format(as.numeric(spec$grid), digits = 17, scientific = FALSE), collapse = "|"),
      algo = "sha256", serialize = FALSE
    ),
    quantile_type = as.character(spec$quantile_type),
    ties_method = "efron",
    pooling_method = "RUBIN_LINEAR_CONTRAST",
    science_epoch = config$sha256,
    scientific_config_revision = config$revision
  )
  digest::digest(
    paste(names(payload), payload, sep = "=", collapse = "\n"),
    algo = "sha256", serialize = FALSE
  )
}

canonical_model_signature_set_sha256_v43 <- function(signatures, scope_id) {
  signatures <- sort(unique(as.character(signatures)), method = "radix")
  if (!length(signatures) || any(!grepl("^[0-9a-f]{64}$", signatures)) ||
      !is.character(scope_id) || length(scope_id) != 1L || !nzchar(scope_id) ||
      grepl("[\r\n]", scope_id)) {
    stop("CANONICAL_MODEL_SIGNATURE_SET_INVALID", call. = FALSE)
  }
  if (length(signatures) == 1L) return(signatures[[1L]])
  # 加载摘要包，将多 estimand signature 规范聚合为一个诊断 source identity。
  if (!requireNamespace("digest", quietly = TRUE)) stop("digest is required", call. = FALSE)
  digest::digest(
    paste(c("CANONICAL_MODEL_SIGNATURE_SET_V1", paste0("scope=", scope_id),
      paste0("member=", signatures)), collapse = "\n"),
    algo = "sha256", serialize = FALSE
  )
}

.bind_canonical_model_signature_column_v43 <- function(
    data, expected, conflict_code) {
  if (!is.data.frame(data) || length(expected) != nrow(data) ||
      any(!grepl("^[0-9a-f]{64}$", expected))) {
    stop("CANONICAL_MODEL_SIGNATURE_BINDING_INVALID", call. = FALSE)
  }
  if ("model_signature_sha256" %in% names(data)) {
    observed <- as.character(data$model_signature_sha256)
    conflict <- !is.na(observed) & nzchar(observed) & observed != expected
    if (any(conflict)) stop(conflict_code, call. = FALSE)
  }
  data$model_signature_sha256 <- expected
  data
}

bind_a04_publication_model_signatures_v43 <- function(analysis, rcs_signature) {
  canonical <- analysis$tve$canonical
  diagnostics <- analysis$tve$diagnostics
  required_canonical <- c(
    "model_id", "exposure_parameterization", "model_signature_sha256"
  )
  required_diagnostics <- c("model_id", "exposure_form")
  if (!is.data.frame(canonical) || !is.data.frame(diagnostics) ||
      !all(required_canonical %in% names(canonical)) ||
      !all(required_diagnostics %in% names(diagnostics)) ||
      !grepl("^[0-9a-f]{64}$", rcs_signature)) {
    stop("A04_PUBLICATION_MODEL_SIGNATURE_INPUT_INVALID", call. = FALSE)
  }
  diagnostic_signatures <- vapply(seq_len(nrow(diagnostics)), function(index) {
    keep <- canonical$model_id == diagnostics$model_id[[index]] &
      canonical$exposure_parameterization == diagnostics$exposure_form[[index]]
    keep[is.na(keep)] <- FALSE
    canonical_model_signature_set_sha256_v43(
      canonical$model_signature_sha256[keep],
      paste("A04_TVE_DIAGNOSTIC", diagnostics$model_id[[index]],
        diagnostics$exposure_form[[index]], sep = "/")
    )
  }, character(1))
  list(
    tve_diagnostics = .bind_canonical_model_signature_column_v43(
      diagnostics, diagnostic_signatures, "A04_TVE_DIAGNOSTIC_MODEL_SIGNATURE_CONFLICT"
    ),
    rcs_curve = .bind_canonical_model_signature_column_v43(
      analysis$rcs$curve, rep(rcs_signature, nrow(analysis$rcs$curve)),
      "A04_RCS_MODEL_SIGNATURE_CONFLICT"
    ),
    rcs_qc = .bind_canonical_model_signature_column_v43(
      analysis$rcs$qc, rep(rcs_signature, nrow(analysis$rcs$qc)),
      "A04_RCS_QC_MODEL_SIGNATURE_CONFLICT"
    )
  )
}

bind_a05_publication_model_signatures_v43 <- function(analysis) {
  estimates <- analysis$estimates
  if (!is.data.frame(estimates) ||
      !all(c("subgroup_id", "model_signature_sha256") %in% names(estimates)) ||
      any(is.na(estimates$subgroup_id) | !nzchar(as.character(estimates$subgroup_id)))) {
    stop("A05_PUBLICATION_MODEL_SIGNATURE_INPUT_INVALID", call. = FALSE)
  }
  bind_subgroup_source <- function(data) {
    if (!is.data.frame(data) || !"subgroup_id" %in% names(data)) {
      stop("A05_PUBLICATION_MODEL_SIGNATURE_INPUT_INVALID", call. = FALSE)
    }
    expected <- vapply(as.character(data$subgroup_id), function(subgroup_id) {
      canonical_model_signature_set_sha256_v43(
        estimates$model_signature_sha256[as.character(estimates$subgroup_id) == subgroup_id],
        paste("A05_SUBGROUP", subgroup_id, sep = "/")
      )
    }, character(1))
    .bind_canonical_model_signature_column_v43(
      data, expected, "A05_PUBLICATION_MODEL_SIGNATURE_CONFLICT"
    )
  }
  list(
    interactions = bind_subgroup_source(analysis$interactions),
    information = bind_subgroup_source(analysis$information)
  )
}

build_a04_rcs_cutoff_figure_data <- function(analysis, publication_curve) {
  candidate <- analysis$rcs$cutoff$candidate
  derivative <- analysis$rcs$cutoff$derivative_grid
  if (!is.data.frame(candidate) || nrow(candidate) != 1L ||
      !is.data.frame(publication_curve) || nrow(publication_curve) != 200L ||
      !is.data.frame(derivative) || nrow(derivative) != 200L) {
    stop("A04_RCS_CUTOFF_FIGURE_DATA_INPUT_INVALID", call. = FALSE)
  }
  common <- list(
    cutoff_ast_alt = candidate$cutoff_ast_alt[[1L]],
    cutoff_status = candidate$status[[1L]],
    analysis_n = publication_curve$analysis_n[[1L]],
    event_n = publication_curve$event_n[[1L]],
    model_signature_sha256 = publication_curve$model_signature_sha256[[1L]]
  )
  shape <- data.frame(
    panel = "RCS_LOG_HR", point_index = seq_len(nrow(publication_curve)),
    x_ast_alt = publication_curve$x_ast_alt, y_value = publication_curve$hr,
    lower_value = publication_curve$lower_95_ci,
    upper_value = publication_curve$upper_95_ci,
    cutoff_ast_alt = common$cutoff_ast_alt, cutoff_status = common$cutoff_status,
    analysis_n = common$analysis_n, event_n = common$event_n,
    model_signature_sha256 = common$model_signature_sha256,
    estimate_status = publication_curve$estimate_status,
    not_estimable_reason_code = ifelse(
      publication_curve$estimate_status == "ESTIMABLE", "", "RCS_CURVE_NOT_ESTIMABLE"
    ),
    stringsAsFactors = FALSE
  )
  derivative_rows <- data.frame(
    panel = "RCS_ANALYTIC_DERIVATIVE", point_index = seq_len(nrow(derivative)),
    x_ast_alt = derivative$x_ast_alt,
    y_value = derivative$pooled_log_hr_derivative,
    lower_value = NA_real_, upper_value = NA_real_,
    cutoff_ast_alt = common$cutoff_ast_alt, cutoff_status = common$cutoff_status,
    analysis_n = common$analysis_n, event_n = common$event_n,
    model_signature_sha256 = common$model_signature_sha256,
    estimate_status = "ESTIMABLE", not_estimable_reason_code = "",
    stringsAsFactors = FALSE
  )
  rbind(shape, derivative_rows)
}

materialize_a04 <- function(previous_state, analysis, context = stage_context()) {
  stage <- "A04"
  rcs_signature <- a04_rcs_model_signature_sha256(analysis, context)
  publication_sources <- bind_a04_publication_model_signatures_v43(
    analysis, rcs_signature
  )
  rcs_cutoff_figure_data <- build_a04_rcs_cutoff_figure_data(
    analysis, publication_sources$rcs_curve
  )
  # 中文备注：写出 A04 批准候选的 Layer 2 canonical 与 RCS 双面板固定 figure-data。
  public <- c(
    write_stage_csv(analysis$tve$canonical, stage, "tve_results.csv", context),
    write_stage_csv(publication_sources$tve_diagnostics, stage, "tve_model_diagnostics.csv", context),
    write_stage_csv(publication_sources$rcs_curve, stage, "rcs_curve_results.csv", context),
    write_stage_csv(analysis$rcs$tests, stage, "rcs_test_results.csv", context),
    write_stage_csv(publication_sources$rcs_qc, stage, "rcs_qc_results.csv", context),
    write_stage_csv(analysis$rcs$cutoff$candidate, stage, "rcs_cutoff_candidate.csv", context),
    write_stage_csv(analysis$rcs$cutoff$derivative_grid, stage, "rcs_derivative_grid.csv", context),
    write_stage_csv(rcs_cutoff_figure_data, stage, "rcs_cutoff_figure_data.csv", context),
    write_stage_csv(
      if (length(analysis$nuisance_terms)) {
        data.frame(parent_term = analysis$nuisance_terms, approval_basis = "HUMAN_APPROVAL", stringsAsFactors = FALSE)
      } else {
        data.frame(parent_term = character(), approval_basis = character(), stringsAsFactors = FALSE)
      },
      stage, "approved_nuisance_tve_terms.csv", context
    )
  )
  primary_tve <- analysis$tve$canonical[
    analysis$tve$canonical$exposure_parameterization %in%
      c("AST_ALT_Tertile", "log2_AST_ALT"),
    , drop = FALSE
  ]
  rutherford_tve <- analysis$tve$canonical[
    grepl(
      "^Rutherford_TVE_ADJUSTED_",
      analysis$tve$canonical$exposure_parameterization
    ),
    , drop = FALSE
  ]
  # 中文备注：A06 只继承原 AST/ALT canonical 与 per-imputation 对比；Rutherford publication 行隔离保存且不改变敏感性定义。
  previous_state$tve_stage <- list(
    canonical = primary_tve,
    rutherford_canonical = rutherford_tve,
    per_imputation = analysis$tve$per_imputation,
    diagnostics = analysis$tve$diagnostics
  )
  previous_state$rcs_stage <- list(
    spec = analysis$rcs$spec, curve = analysis$rcs$curve,
    tests = analysis$rcs$tests, qc = analysis$rcs$qc,
    cutoff = analysis$rcs$cutoff
  )
  restricted <- c(
    write_stage_rds(previous_state, stage, "analysis_state.rds", context),
    write_stage_rds(analysis$tve$collections, stage, "tve_model_objects_layer1.rds", context),
    write_stage_rds(analysis$rcs$collections, stage, "rcs_model_objects_layer1.rds", context)
  )
  list(public_files = public, restricted_files = restricted, state = previous_state)
}

run_a05_analysis <- function(state, context = stage_context()) {
  primary <- state$endpoint_registry[state$endpoint_registry$endpoint_id == "EP01", , drop = FALSE]
  run_subgroup_stage(state$exposure$completed, primary, state$exposure$exposure_scale, context$project_root)
}

qc_a05_analysis <- function(analysis, context = stage_context()) {
  expected_subgroups <- nrow(read_subgroup_registry(context$project_root))
  represented <- length(unique(analysis$interactions$subgroup_id))
  not_estimable <- sum(analysis$interactions$estimate_status != "ESTIMABLE")
  branches_pass <- nrow(analysis$branch_coverage) == expected_subgroups &&
    all(analysis$branch_coverage$branch_status == "PASS")
  rbind(
    qc_record("A05_BRANCHES", "A05", "registered_subgroup_branch_completion", branches_pass, TRUE, ifelse(branches_pass, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A05_COVERAGE", "A05", "registered_subgroup_coverage", represented, expected_subgroups, ifelse(represented == expected_subgroups, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A05_INTERACTION", "A05", "not_estimable_interactions", not_estimable, 0, ifelse(not_estimable == 0L, "PASS", "WARNING"), ifelse(not_estimable == 0L, "INFO", "NONBLOCKING_WARNING"))
  )
}

materialize_a05 <- function(previous_state, analysis, context = stage_context()) {
  stage <- "A05"
  publication_sources <- bind_a05_publication_model_signatures_v43(analysis)
  public <- c(
    write_stage_csv(analysis$estimates, stage, "subgroup_results.csv", context),
    write_stage_csv(publication_sources$interactions, stage, "subgroup_interaction_results.csv", context),
    write_stage_csv(publication_sources$information, stage, "subgroup_information_audit.csv", context)
  )
  previous_state$subgroup_stage <- analysis
  restricted <- write_stage_rds(previous_state, stage, "analysis_state.rds", context)
  list(public_files = public, restricted_files = restricted, state = previous_state)
}

run_a06_analysis <- function(state, context = stage_context()) {
  run_sensitivity_stage(state, context)
}

qc_a06_analysis <- function(analysis, context = stage_context()) {
  loio_rounds <- length(unique(analysis$loio$omitted_imputation))
  loio_retained_pass <- nrow(analysis$loio) > 0L && all(analysis$loio$valid_imputation_n == 19L)
  loco_centers <- if (nrow(analysis$loco)) length(unique(analysis$loco$omitted_center)) else 0L
  coverage_pass <- nrow(analysis$coverage) == nrow(read_sensitivity_registry(context$project_root)) &&
    all(analysis$coverage$status == "PASS")
  required_ids <- sensitivity_required_ids(context$project_root)
  branch_status <- analysis$branch_coverage$analysis_status[match(required_ids, analysis$branch_coverage$sensitivity_id)]
  required_estimable <- length(branch_status) == length(required_ids) && all(branch_status == "ESTIMABLE")
  branch_failure_n <- sum(analysis$branch_coverage$branch_status == "FAILED_TYPED")
  estimand_registry <- utils::read.csv(file.path(context$project_root, "config", "estimand_registry.csv"), stringsAsFactors = FALSE, check.names = FALSE)
  expected_secondary <- sort(estimand_registry$estimand_id[estimand_registry$endpoint_role == "supplementary"], method = "radix")
  observed_secondary <- sort(as.character(analysis$secondary$estimand_id), method = "radix")
  secondary_closure <- identical(expected_secondary, observed_secondary) && !anyDuplicated(observed_secondary)
  component_contrasts <- c("AST_CONDITIONAL_PER_DOUBLING", "ALT_CONDITIONAL_PER_DOUBLING", "AST_ALT_JOINT_D1")
  component_closure <- identical(
    sort(unique(as.character(analysis$standard$contrast[analysis$standard$sensitivity_id == "B03"])), method = "radix"),
    sort(component_contrasts, method = "radix")
  )
  rcs_variants <- sort(unique(as.character(analysis$rcs$analysis_variant)), method = "radix")
  rcs_closure <- identical(rcs_variants, sort(c("MI_FULL", "COMPLETE_CASE", "P1_P99_RESTRICTED"), method = "radix")) &&
    all(analysis$rcs$analysis_status == "ESTIMABLE")
  expected_component_fits <- c(
    B03_FULL_INITIAL_FIT_N = 20L,
    B03_REDUCED_INITIAL_FIT_N = 20L,
    B03_SCHOENFELD_ADDITIONAL_FIT_N = 0L
  )
  component_fit_receipt <- analysis$diagnostics[
    analysis$diagnostics$sensitivity_id == "B03" &
      analysis$diagnostics$metric %in% names(expected_component_fits),
    , drop = FALSE
  ]
  observed_component_fits <- setNames(
    as.integer(component_fit_receipt$value), component_fit_receipt$metric
  )
  component_fit_lock <- nrow(component_fit_receipt) == length(expected_component_fits) &&
    !anyDuplicated(component_fit_receipt$metric) &&
    identical(observed_component_fits[names(expected_component_fits)], expected_component_fits) &&
    all(component_fit_receipt$status == "PASS")
  schoenfeld_public_safe <- is.data.frame(analysis$schoenfeld_trend) &&
    !any(c("Patient_ID", "event_index", "event_time", "scaled_residual") %in%
      names(analysis$schoenfeld_trend)) &&
    all(analysis$schoenfeld_trend$data_classification == "PUBLIC_AGGREGATE")
  diagnostic_registry <- utils::read.csv(
    file.path(context$project_root, "config", "diagnostic_extension_registry.csv"),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  expected_schoenfeld <- diagnostic_registry[
    diagnostic_registry$producer_stage == "A06", , drop = FALSE
  ]
  expected_schoenfeld_key <- paste(
    expected_schoenfeld$diagnostic_id, expected_schoenfeld$series_id, sep = "\r"
  )
  observed_schoenfeld_key <- paste(
    analysis$schoenfeld_status$diagnostic_id,
    analysis$schoenfeld_status$series_id, sep = "\r"
  )
  trend_schoenfeld_key <- paste(
    analysis$schoenfeld_trend$diagnostic_id,
    analysis$schoenfeld_trend$series_id, sep = "\r"
  )
  status_order <- match(expected_schoenfeld_key, observed_schoenfeld_key)
  expected_trend_n <- if (all(is.finite(status_order))) {
    ifelse(
      nzchar(analysis$schoenfeld_status$resolved_term[status_order]),
      as.integer(expected_schoenfeld$public_grid_n), 0L
    )
  } else rep(NA_integer_, nrow(expected_schoenfeld))
  observed_trend_n <- table(factor(trend_schoenfeld_key, levels = expected_schoenfeld_key))
  schoenfeld_closure <- length(observed_schoenfeld_key) == length(expected_schoenfeld_key) &&
    !anyDuplicated(observed_schoenfeld_key) &&
    identical(sort(observed_schoenfeld_key), sort(expected_schoenfeld_key)) &&
    all(as.integer(observed_trend_n) == expected_trend_n)
  schoenfeld_estimable <- schoenfeld_closure &&
    all(analysis$schoenfeld_status$status == "ESTIMABLE") &&
    all(
      analysis$schoenfeld_status$valid_imputation_n[status_order] >=
        expected_schoenfeld$minimum_valid_imputations
    )
  registered_times <- c(6, 12, 24, 36)
  roc_time_counts <- if (is.list(analysis$ipcw) && is.data.frame(analysis$ipcw$public_roc)) {
    table(factor(analysis$ipcw$public_roc$time_month, levels = registered_times))
  } else integer()
  ipcw_closure <- is.list(analysis$ipcw) &&
    nrow(analysis$ipcw$summary) == 4L && !anyDuplicated(analysis$ipcw$summary$time_month) &&
    identical(sort(unique(analysis$ipcw$summary$time_month), method = "radix"), registered_times) &&
    length(roc_time_counts) == 4L && all(as.integer(roc_time_counts) == 101L) &&
    all(vapply(registered_times, function(time_month) {
      grid <- analysis$ipcw$public_roc$fpr[analysis$ipcw$public_roc$time_month == time_month]
      isTRUE(all.equal(as.numeric(grid), seq(0, 1, length.out = 101L), tolerance = 1e-12))
    }, logical(1)))
  ipcw_blocking <- is.data.frame(analysis$ipcw$gate) &&
    any(analysis$ipcw$gate$warning_class == "BLOCKING_WARNING")
  ipcw_fail <- !is.data.frame(analysis$ipcw$gate) ||
    any(analysis$ipcw$gate$warning_class == "FAIL")
  expected_cutoff_sources <- c("IPCW_M06", "IPCW_M12", "IPCW_M24", "IPCW_M36", "RCS_STABLE")
  km_closure <- is.list(analysis$cutoff_km) &&
    nrow(analysis$cutoff_km$status) == 5L &&
    identical(
      sort(unique(as.character(analysis$cutoff_km$status$cutoff_source)), method = "radix"),
      sort(expected_cutoff_sources, method = "radix")
    )
  rbind(
    qc_record("A06_BRANCH_EXECUTION", "A06", "typed_branch_failure_count", branch_failure_n, 0, ifelse(branch_failure_n == 0L, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A06_COVERAGE", "A06", "exact_registered_sensitivity_coverage", coverage_pass, TRUE, ifelse(coverage_pass, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A06_REQUIRED_ESTIMABLE", "A06", "required_sensitivity_branch_estimability", required_estimable, TRUE, ifelse(required_estimable, "PASS", "WARNING"), ifelse(required_estimable, "INFO", "BLOCKING_WARNING")),
    qc_record("A06_LOIO", "A06", "leave_one_imputation_out_rounds", loio_rounds, 20, ifelse(loio_rounds == 20L && loio_retained_pass, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A06_LOCO", "A06", "leave_one_center_out_coverage", loco_centers, ">=1", ifelse(loco_centers >= 1L, "PASS", "WARNING"), ifelse(loco_centers >= 1L, "INFO", "NONBLOCKING_WARNING")),
    qc_record("A06_COMPONENT", "A06", "joint_component_conditional_and_D1_closure", component_closure, TRUE, ifelse(component_closure, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A06_COMPONENT_FIT_LOCK", "A06", "B03_20_full_20_reduced_zero_schoenfeld_refits", component_fit_lock, TRUE, ifelse(component_fit_lock, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A06_SCHOENFELD_PRIVACY", "A06", "public_schoenfeld_event_level_field_count", !schoenfeld_public_safe, FALSE, ifelse(schoenfeld_public_safe, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A06_SCHOENFELD_CLOSURE", "A06", "registered_series_status_and_120_point_grid_closure", schoenfeld_closure, TRUE, ifelse(schoenfeld_closure, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A06_SCHOENFELD_ESTIMABILITY", "A06", "registered_series_minimum_16_imputations", schoenfeld_estimable, TRUE, ifelse(schoenfeld_estimable, "PASS", "WARNING"), ifelse(schoenfeld_estimable, "INFO", "BLOCKING_WARNING")),
    qc_record("A06_RCS", "A06", "full_MI_CC_p1_p99_frozen_RCS_numeric_contract", rcs_closure, TRUE, ifelse(rcs_closure, "PASS", "WARNING"), ifelse(rcs_closure, "INFO", "BLOCKING_WARNING")),
    qc_record("A06_IPCW", "A06", "four_timepoint_101_grid_IPCW_closure", ipcw_closure, TRUE, ifelse(ipcw_closure, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A06_IPCW_VALIDITY", "A06", "registered_IPCW_validity_gate_failure_count", ipcw_fail, FALSE, ifelse(ipcw_fail, "FAIL", "PASS"), "HARD_STOP"),
    qc_record("A06_IPCW_CENSOR_SURVIVAL", "A06", "minimum_censor_survival_warning", ipcw_blocking, FALSE, ifelse(ipcw_blocking, "WARNING", "PASS"), ifelse(ipcw_blocking, "BLOCKING_WARNING", "INFO")),
    qc_record("A06_CUTOFF_KM", "A06", "five_registered_cutoff_KM_status_pages", km_closure, TRUE, ifelse(km_closure, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A06_SECONDARY", "A06", "exact_registered_secondary_estimand_closure", secondary_closure, length(expected_secondary), ifelse(secondary_closure, "PASS", "FAIL"), "HARD_STOP")
  )
}

validate_a06_publication_model_signatures_v43 <- function(
    analysis, project_root = ".") {
  registry <- utils::read.csv(
    file.path(project_root, "config", "canonical_file_registry.csv"),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  sources <- list(
    sensitivity_results.csv = analysis$standard,
    secondary_endpoint_results.csv = analysis$secondary
  )
  for (source_file in names(sources)) {
    contract <- registry[
      registry$source_canonical_file == source_file & registry$producer_stage == "A06",
      , drop = FALSE
    ]
    data <- sources[[source_file]]
    if (nrow(contract) != 1L || !isTRUE(contract$required_model_signature[[1L]]) ||
        !is.data.frame(data) || !nrow(data) ||
        !"model_signature_sha256" %in% names(data) ||
        any(!grepl("^[0-9a-f]{64}$", as.character(data$model_signature_sha256)))) {
      stop("A06_PUBLICATION_MODEL_SIGNATURE_CLOSURE_INVALID: ", source_file, call. = FALSE)
    }
  }
  invisible(TRUE)
}

materialize_a06 <- function(previous_state, analysis, context = stage_context()) {
  stage <- "A06"
  validate_a06_publication_model_signatures_v43(
    analysis, context$project_root
  )
  # 中文备注：写出 A06 探索性诊断的公开聚合 canonical；不得包含事件级 residual 或患者阈值网格。
  public <- c(
    write_stage_csv(analysis$standard, stage, "sensitivity_results.csv", context),
    write_stage_csv(analysis$loio, stage, "loio_results.csv", context),
    write_stage_csv(analysis$loco, stage, "loco_results.csv", context),
    write_stage_csv(analysis$secondary, stage, "secondary_endpoint_results.csv", context),
    write_stage_csv(analysis$rcs, stage, "rcs_sensitivity_results.csv", context),
    write_stage_csv(analysis$schoenfeld_trend, stage, "schoenfeld_trend_a06.csv", context),
    write_stage_csv(analysis$schoenfeld_status, stage, "schoenfeld_status_a06.csv", context),
    write_stage_csv(analysis$schoenfeld_status_all, stage, "schoenfeld_status_all.csv", context),
    write_stage_csv(analysis$rcs_cutoff_stability, stage, "rcs_cutoff_stability.csv", context),
    write_stage_csv(analysis$ipcw$summary, stage, "ipcw_roc_summary.csv", context),
    write_stage_csv(analysis$ipcw$public_roc, stage, "ipcw_roc_curve.csv", context),
    write_stage_csv(analysis$ipcw$gate, stage, "ipcw_roc_gate.csv", context),
    write_stage_csv(analysis$cutoff_km$status, stage, "cutoff_km_status.csv", context),
    write_stage_csv(analysis$cutoff_km$statistics, stage, "cutoff_km_statistics.csv", context),
    write_stage_csv(analysis$cutoff_km$curve, stage, "cutoff_km_curve.csv", context),
    write_stage_csv(analysis$cutoff_km$risk_table, stage, "cutoff_km_riskset.csv", context),
    write_stage_csv(analysis$cutoff_km$publication, stage, "cutoff_km_publication.csv", context),
    write_stage_csv(analysis$coverage, stage, "sensitivity_coverage.csv", context),
    write_stage_csv(analysis$diagnostics, stage, "sensitivity_diagnostics.csv", context),
    write_stage_csv(analysis$branch_coverage, stage, "sensitivity_branch_status.csv", context),
    write_stage_csv(analysis$branch_errors, stage, "sensitivity_branch_errors.csv", context)
  )
  previous_state$sensitivity_stage <- analysis
  component_layer1 <- file.path(
    context$run_root, "stage_work", "A06", "schoenfeld_component_layer1.rds"
  )
  restricted <- c(
    write_stage_rds(previous_state, stage, "analysis_state.rds", context),
    write_stage_rds(analysis$ipcw$restricted, stage, "ipcw_roc_layer1.rds", context),
    if (file.exists(component_layer1)) component_layer1 else character()
  )
  list(public_files = public, restricted_files = restricted, state = previous_state)
}

run_a07_release <- function(canonical_manifest, context = stage_context()) {
  if (!is.data.frame(canonical_manifest) || !nrow(canonical_manifest)) {
    stop("A07_CANONICAL_MANIFEST_REQUIRED", call. = FALSE)
  }
  source(file.path(context$project_root, "R", "release_manager.R"))
  # 从批准的 Layer 2 canonical CSV 构建正式 release，不读取受限模型对象。
  release_dir <- build_release_from_canonical(context$run_root, context$project_root)
  manifest <- utils::read.csv(file.path(release_dir, "manifest", "publication_output_manifest.csv"), stringsAsFactors = FALSE, check.names = FALSE)
  list(release_dir = release_dir, manifest = manifest)
}

qc_a07_release <- function(analysis, context = stage_context()) {
  if (!exists(".publication_receipt_sha256", mode = "function")) {
    source(file.path(context$project_root, "R", "publication_renderer.R"))
  }
  registry <- utils::read.csv(file.path(context$project_root, "config", "output_registry.csv"), stringsAsFactors = FALSE, check.names = FALSE)
  counts_expected <- table(registry$location)
  counts_actual <- table(registry$location[match(analysis$manifest$output_id, registry$output_id)])
  all_exists <- all(analysis$manifest$exists)
  figure_rows <- analysis$manifest$format == "SVG"
  sidecars <- all(nzchar(analysis$manifest$figure_data_sha256[figure_rows]))
  release_files <- list.files(analysis$release_dir, recursive = TRUE, full.names = TRUE)
  forbidden_paths <- any(grepl("restricted_cache|patient_level|/raw/", release_files))
  text_files <- release_files[grepl("\\.(csv|html|md|txt|json)$", release_files, ignore.case = TRUE)]
  text <- paste(unlist(lapply(text_files, function(path) {
    value <- paste(readLines(path, warn = FALSE), collapse = "\n")
    if (grepl("\\.html$", path, ignore.case = TRUE)) {
      value <- gsub("(?s)<pre\\b[^>]*>.*?</pre>", "", value, perl = TRUE)
      value <- gsub("(?s)<code\\b[^>]*>.*?</code>", "", value, perl = TRUE)
    }
    value
  })), collapse = "\n")
  identifier_leak <- grepl("(^|[,\"'])Patient_ID([,\"']|$)", text)
  absolute_path <- grepl(paste0("/", "Users", "/|/", "Volumes", "/|[A-Za-z]:\\\\"), text)
  required_report_files <- c(
    "AST_ALT_Cox_Full_Report.qmd",
    "AST_ALT_Cox_Full_Report.html",
    "AST_ALT_Cox_Executive_Review.qmd",
    "AST_ALT_Cox_Executive_Review.html"
  )
  report_files_complete <- all(file.exists(file.path(analysis$release_dir, required_report_files)))
  qmd_path <- file.path(analysis$release_dir, "AST_ALT_Cox_Full_Report.qmd")
  qmd_text <- if (file.exists(qmd_path)) paste(readLines(qmd_path, warn = FALSE), collapse = "\n") else ""
  execute_disabled <- grepl("execute:[[:space:]]*\n[[:space:]]*enabled:[[:space:]]*false", qmd_text)
  link_qc_path <- file.path(analysis$release_dir, "audit", "qc_html_link_integrity.csv")
  link_qc <- if (file.exists(link_qc_path)) utils::read.csv(link_qc_path, stringsAsFactors = FALSE, check.names = FALSE) else data.frame(status = "FAIL")
  links_pass <- nrow(link_qc) > 0L && all(link_qc$status == "PASS")
  code_manifest_path <- file.path(analysis$release_dir, "manifest", "code_source_manifest.csv")
  code_manifest <- if (file.exists(code_manifest_path)) utils::read.csv(code_manifest_path, stringsAsFactors = FALSE, check.names = FALSE) else data.frame()
  code_manifest_valid <- nrow(code_manifest) > 0L && all(c("source_file", "source_file_sha256", "appendix_file") %in% names(code_manifest)) && all(nzchar(code_manifest$source_file_sha256))
  source_receipt_path <- file.path(
    analysis$release_dir, "audit", "publication_source_integrity_receipts.csv"
  )
  source_receipts <- if (file.exists(source_receipt_path)) {
    utils::read.csv(source_receipt_path, stringsAsFactors = FALSE, check.names = FALSE)
  } else data.frame()
  source_receipts_valid <- nrow(source_receipts) > 0L &&
    all(c(
      "source_file", "source_sha256", "validated_whole_file_key",
      "whole_file_duplicate_key_count", "schema_status", "key_status", "type_status",
      "finite_status", "typed_na_status", "receipt_sha256", "status"
    ) %in% names(source_receipts)) &&
    all(source_receipts$status == "PASS") &&
    all(source_receipts$whole_file_duplicate_key_count == 0L) &&
    all(grepl("^[0-9a-f]{64}$", source_receipts$source_sha256)) &&
    all(grepl("^[0-9a-f]{64}$", source_receipts$receipt_sha256)) &&
    exists(".publication_receipt_sha256", mode = "function") &&
    all(vapply(seq_len(nrow(source_receipts)), function(index) {
      identical(
        source_receipts$receipt_sha256[[index]],
        .publication_receipt_sha256(source_receipts[index, , drop = FALSE])
      )
    }, logical(1)))
  logical_closure <- nrow(registry) == 77L &&
    sum(registry$format == "CSV") == 42L && sum(registry$format == "SVG") == 35L &&
    nrow(analysis$manifest) == 77L && !anyDuplicated(analysis$manifest$output_id) &&
    identical(sort(analysis$manifest$output_id), sort(registry$output_id))
  table_files <- list.files(file.path(analysis$release_dir, "tables"), full.names = TRUE)
  figure_files <- list.files(file.path(analysis$release_dir, "figures"), full.names = TRUE)
  figure_extensions <- tolower(tools::file_ext(figure_files))
  physical_closure <- length(table_files) == 42L &&
    all(tolower(tools::file_ext(table_files)) == "csv") &&
    length(figure_files) == 105L &&
    identical(
      unname(as.integer(table(factor(figure_extensions, levels = c("svg", "pdf", "png"))))),
      c(35L, 35L, 35L)
    )
  required_multiformat_columns <- c(
    "file_name", "output_sha256", "pdf_file", "pdf_sha256", "png_file", "png_sha256"
  )
  figure_manifest <- analysis$manifest[analysis$manifest$format == "SVG", , drop = FALSE]
  multiformat_sha_closure <- nrow(figure_manifest) == 35L &&
    all(required_multiformat_columns %in% names(figure_manifest)) &&
    all(vapply(seq_len(nrow(figure_manifest)), function(index) {
      row <- figure_manifest[index, , drop = FALSE]
      paths <- file.path(
        analysis$release_dir, "figures",
        c(row$file_name[[1L]], row$pdf_file[[1L]], row$png_file[[1L]])
      )
      hashes <- c(
        row$output_sha256[[1L]], row$pdf_sha256[[1L]], row$png_sha256[[1L]]
      )
      all(file.exists(paths)) && all(grepl("^[0-9a-f]{64}$", hashes)) &&
        identical(unname(vapply(paths, file_sha256, character(1))), unname(hashes))
    }, logical(1)))
  rbind(
    qc_record("A07_OUTPUT", "A07", "registered_outputs_exist", all_exists, TRUE, ifelse(all_exists, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A07_COUNTS", "A07", "output_registry_count", nrow(analysis$manifest), nrow(registry), ifelse(nrow(analysis$manifest) == nrow(registry), "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A07_SIDECAR", "A07", "figure_data_hash_sidecars", sidecars, TRUE, ifelse(sidecars, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A07_PRIVACY", "A07", "release_privacy_scan", identifier_leak || absolute_path || forbidden_paths, FALSE, ifelse(identifier_leak || absolute_path || forbidden_paths, "FAIL", "PASS"), "HARD_STOP"),
    qc_record("A07_REPORT_FILES", "A07", "full_and_executive_qmd_html_exist", report_files_complete, TRUE, ifelse(report_files_complete, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A07_QMD", "A07", "qmd_execution_disabled", execute_disabled, TRUE, ifelse(execute_disabled, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A07_HTML_LINKS", "A07", "release_html_links_resolve", links_pass, TRUE, ifelse(links_pass, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A07_CODE_MANIFEST", "A07", "static_code_appendix_manifest", code_manifest_valid, TRUE, ifelse(code_manifest_valid, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A07_SOURCE_RECEIPTS", "A07", "publication_source_schema_key_type_finite_typed_na_receipts", source_receipts_valid, TRUE, ifelse(source_receipts_valid, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A07_LOGICAL_OUTPUT_CLOSURE", "A07", "42_tables_35_figures_77_logical_outputs", logical_closure, TRUE, ifelse(logical_closure, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A07_PHYSICAL_OUTPUT_CLOSURE", "A07", "42_csv_35_each_svg_pdf_png_147_primary_files", physical_closure, TRUE, ifelse(physical_closure, "PASS", "FAIL"), "HARD_STOP"),
    qc_record("A07_MULTIFORMAT_SHA_CLOSURE", "A07", "svg_pdf_png_manifest_hash_closure", multiformat_sha_closure, TRUE, ifelse(multiformat_sha_closure, "PASS", "FAIL"), "HARD_STOP")
  )
}

materialize_a07 <- function(analysis, qc, context = stage_context()) {
  stage <- "A07"
  completeness_path <- file.path(analysis$release_dir, "tables", "Supp_TableS32_Output_Completeness.csv")
  if (!file.exists(completeness_path)) stop("A07_ST32_MISSING_AFTER_RENDER", call. = FALSE)
  # 读取 renderer 已哈希的 ST32；materialize 阶段禁止再次改写正式 publication artifact。
  completeness <- utils::read.csv(completeness_path, stringsAsFactors = FALSE, check.names = FALSE)
  public <- c(
    write_stage_csv(analysis$manifest, stage, "publication_output_manifest.csv", context),
    write_stage_csv(completeness, stage, "output_completeness.csv", context),
    write_stage_csv(qc, stage, "release_qc_results.csv", context),
    file.path(analysis$release_dir, "AST_ALT_Cox_Full_Report.html")
  )
  list(public_files = public[file.exists(public)], restricted_files = character())
}
