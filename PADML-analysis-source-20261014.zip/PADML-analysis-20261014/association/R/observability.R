# v4.3 阶段可观测性：原子 heartbeat、幂等分支 receipt 与只读状态投影。

.observability_stop <- function(code, detail = "") {
  message <- if (nzchar(detail)) paste(code, detail, sep = ": ") else code
  stop(message, call. = FALSE)
}

.observability_now <- function(now = Sys.time()) {
  format(as.POSIXct(now, tz = "UTC"), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
}

.observability_parse_time <- function(value, field) {
  if (!is.character(value) || length(value) != 1L || is.na(value) ||
      !grepl("^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$", value)) {
    .observability_stop("STAGE_OBSERVABILITY_TIME_INVALID", field)
  }
  parsed <- as.POSIXct(value, format = "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  if (is.na(parsed)) .observability_stop("STAGE_OBSERVABILITY_TIME_INVALID", field)
  parsed
}

.observability_scalar_string <- function(value, allow_empty = FALSE) {
  is.character(value) && length(value) == 1L && !is.na(value) &&
    (isTRUE(allow_empty) || nzchar(value)) && !grepl("[\r\n]", value)
}

.observability_sha256 <- function(value, allow_empty = FALSE) {
  .observability_scalar_string(value, allow_empty = allow_empty) &&
    ((isTRUE(allow_empty) && !nzchar(value)) || grepl("^[0-9a-f]{64}$", value))
}

.observability_integer <- function(value, allow_null = FALSE) {
  if (isTRUE(allow_null) && is.null(value)) return(TRUE)
  is.numeric(value) && length(value) == 1L && !is.na(value) && is.finite(value) &&
    value >= 0 && value == floor(value)
}

.observability_require_control <- function() {
  required <- c("canonical_json", ".control_sha256_text", ".control_write_atomic")
  target_environment <- environment(.observability_require_control)
  available <- vapply(required, function(name) {
    exists(name, envir = target_environment, inherits = TRUE, mode = "function")
  }, logical(1))
  if (any(!available)) {
    .observability_stop("STAGE_OBSERVABILITY_CONTROL_KERNEL_REQUIRED")
  }
  invisible(TRUE)
}

.stage_heartbeat_fields <- function() {
  c(
    "schema_version", "sequence", "run_id", "stage", "target", "branch_id",
    "completed", "total", "stage_request_sha256", "started_at",
    "last_progress_at", "updated_at", "status", "warning_status",
    "failure_code", "next_checkpoint"
  )
}

validate_stage_heartbeat <- function(heartbeat) {
  fields <- .stage_heartbeat_fields()
  if (!is.list(heartbeat) || !identical(sort(names(heartbeat)), sort(fields)) ||
      !identical(heartbeat$schema_version, "1.0.0") ||
      !.observability_integer(heartbeat$sequence) || heartbeat$sequence < 1L ||
      !.observability_scalar_string(heartbeat$run_id) ||
      !grepl("^[A-Za-z0-9._-]+$", heartbeat$run_id) ||
      !.observability_scalar_string(heartbeat$stage) ||
      !grepl("^(BOOTSTRAP|DRY_RUN|REMOTE|U0[0-5]|P0[0-2]|A0[1-7])$", heartbeat$stage) ||
      !.observability_scalar_string(heartbeat$target) || nchar(heartbeat$target) > 128L ||
      !.observability_scalar_string(heartbeat$branch_id, allow_empty = TRUE) || nchar(heartbeat$branch_id) > 128L ||
      !.observability_integer(heartbeat$completed) ||
      !.observability_integer(heartbeat$total, allow_null = TRUE) ||
      (!is.null(heartbeat$total) && heartbeat$completed > heartbeat$total) ||
      !.observability_sha256(heartbeat$stage_request_sha256, allow_empty = TRUE) ||
      !.observability_scalar_string(heartbeat$status) ||
      !grepl("^[A-Z0-9_]+$", heartbeat$status) ||
      !heartbeat$warning_status %in% c(
        "NONE", "INFO", "NONBLOCKING_WARNING", "BLOCKING_WARNING", "UNKNOWN"
      ) ||
      !.observability_scalar_string(heartbeat$failure_code, allow_empty = TRUE) ||
      (nzchar(heartbeat$failure_code) && !grepl("^[A-Z0-9_]+$", heartbeat$failure_code)) ||
      !.observability_scalar_string(heartbeat$next_checkpoint, allow_empty = TRUE) ||
      (nzchar(heartbeat$next_checkpoint) && !grepl("^[A-Z0-9_]+$", heartbeat$next_checkpoint))) {
    .observability_stop("STAGE_HEARTBEAT_SCHEMA_INVALID")
  }
  invisible(lapply(
    c("started_at", "last_progress_at", "updated_at"),
    function(field) .observability_parse_time(heartbeat[[field]], field)
  ))
  if (.observability_parse_time(heartbeat$last_progress_at, "last_progress_at") <
      .observability_parse_time(heartbeat$started_at, "started_at") ||
      .observability_parse_time(heartbeat$updated_at, "updated_at") <
      .observability_parse_time(heartbeat$last_progress_at, "last_progress_at")) {
    .observability_stop("STAGE_HEARTBEAT_TIME_ORDER_INVALID")
  }
  invisible(TRUE)
}

read_stage_heartbeat <- function(root = ".", required = TRUE) {
  path <- file.path(root, "runtime", "stage_heartbeat.json")
  if (!file.exists(path)) {
    if (isTRUE(required)) .observability_stop("STAGE_HEARTBEAT_MISSING")
    return(NULL)
  }
  if (isTRUE(file.info(path)$isdir) || file.info(path)$size > 32768L) {
    .observability_stop("STAGE_HEARTBEAT_FILE_INVALID")
  }
  if (!requireNamespace("jsonlite", quietly = TRUE)) {
    .observability_stop("STAGE_OBSERVABILITY_DEPENDENCY_MISSING", "jsonlite")
  }
  heartbeat <- jsonlite::read_json(path, simplifyVector = TRUE)
  validate_stage_heartbeat(heartbeat)
  heartbeat
}

.stage_progress_receipt_fields <- function() {
  c(
    "schema_version", "run_id", "stage", "target", "branch_type", "branch_id",
    "stage_request_sha256", "result_sha256", "status", "completed_at",
    "receipt_sha256"
  )
}

compute_stage_progress_receipt_sha256 <- function(receipt) {
  .observability_require_control()
  payload <- receipt
  payload$receipt_sha256 <- NULL
  .control_sha256_text(canonical_json(payload))
}

validate_stage_progress_receipt <- function(receipt) {
  if (!is.list(receipt) ||
      !identical(sort(names(receipt)), sort(.stage_progress_receipt_fields())) ||
      !identical(receipt$schema_version, "1.0.0") ||
      !.observability_scalar_string(receipt$run_id) ||
      !grepl("^[A-Za-z0-9._-]+$", receipt$run_id) ||
      !.observability_scalar_string(receipt$stage) ||
      !grepl("^(A05|A06)$", receipt$stage) ||
      !.observability_scalar_string(receipt$target) || nchar(receipt$target) > 128L ||
      !.observability_scalar_string(receipt$branch_type) ||
      !grepl("^[A-Za-z][A-Za-z0-9_]*$", receipt$branch_type) ||
      !.observability_scalar_string(receipt$branch_id) ||
      !grepl("^[A-Za-z0-9._-]+$", receipt$branch_id) ||
      !.observability_sha256(receipt$stage_request_sha256) ||
      !.observability_sha256(receipt$result_sha256) ||
      !identical(receipt$status, "COMPLETED") ||
      !.observability_sha256(receipt$receipt_sha256)) {
    .observability_stop("STAGE_PROGRESS_RECEIPT_SCHEMA_INVALID")
  }
  .observability_parse_time(receipt$completed_at, "completed_at")
  if (!identical(receipt$receipt_sha256, compute_stage_progress_receipt_sha256(receipt))) {
    .observability_stop("STAGE_PROGRESS_RECEIPT_HASH_MISMATCH")
  }
  invisible(TRUE)
}

.stage_progress_directory <- function(root, stage, stage_request_sha256, branch_type = "") {
  path <- file.path(root, "runtime", "progress", stage, stage_request_sha256)
  if (nzchar(branch_type)) path <- file.path(path, branch_type)
  path
}

write_stage_branch_progress_receipt <- function(
    run_id, stage, target, branch_type, branch_id, stage_request_sha256,
    result_sha256, root = ".", now = Sys.time()) {
  .observability_require_control()
  receipt <- list(
    schema_version = "1.0.0",
    run_id = run_id,
    stage = stage,
    target = target,
    branch_type = branch_type,
    branch_id = branch_id,
    stage_request_sha256 = stage_request_sha256,
    result_sha256 = result_sha256,
    status = "COMPLETED",
    completed_at = .observability_now(now),
    receipt_sha256 = ""
  )
  receipt$receipt_sha256 <- compute_stage_progress_receipt_sha256(receipt)
  validate_stage_progress_receipt(receipt)
  path <- file.path(
    .stage_progress_directory(root, stage, stage_request_sha256, branch_type),
    paste0(branch_id, ".json")
  )
  if (file.exists(path)) {
    if (!requireNamespace("jsonlite", quietly = TRUE)) {
      .observability_stop("STAGE_OBSERVABILITY_DEPENDENCY_MISSING", "jsonlite")
    }
    existing <- jsonlite::read_json(path, simplifyVector = TRUE)
    validate_stage_progress_receipt(existing)
    semantic_fields <- setdiff(.stage_progress_receipt_fields(), c("completed_at", "receipt_sha256"))
    if (!identical(existing[semantic_fields], receipt[semantic_fields])) {
      .observability_stop("STAGE_PROGRESS_RECEIPT_CONFLICT", paste(stage, branch_id, sep = "/"))
    }
    return(c(existing, list(path = path)))
  }
  # 写入每分支唯一 receipt；同语义 replay 返回原 receipt，不重复计数。
  .control_write_atomic(path, canonical_json(receipt), mode = "0600")
  c(receipt, list(path = path))
}

.stage_progress_registry_contract <- function(stage, project_root) {
  if (is.null(project_root)) return(NULL)
  project_root <- normalizePath(project_root, mustWork = TRUE)
  specification <- if (identical(stage, "A05")) {
    list(file = "subgroup_registry.csv", key = "subgroup_id", branch_type = "subgroup_id")
  } else if (identical(stage, "A06")) {
    list(file = "sensitivity_registry.csv", key = "sensitivity_id", branch_type = "sensitivity_id")
  } else {
    return(NULL)
  }
  path <- file.path(project_root, "config", specification$file)
  if (!file.exists(path)) .observability_stop("STAGE_PROGRESS_REGISTRY_MISSING", specification$file)
  registry <- utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE)
  if (!specification$key %in% names(registry) || !nrow(registry)) {
    .observability_stop("STAGE_PROGRESS_REGISTRY_SCHEMA_INVALID", specification$file)
  }
  ids <- as.character(registry[[specification$key]])
  if (any(is.na(ids) | !nzchar(ids)) || anyDuplicated(ids)) {
    .observability_stop("STAGE_PROGRESS_REGISTRY_KEY_INVALID", specification$file)
  }
  list(branch_type = specification$branch_type, ids = ids)
}

.read_stage_progress_receipts <- function(root, heartbeat, project_root = NULL) {
  if (!nzchar(heartbeat$stage_request_sha256) || !heartbeat$stage %in% c("A05", "A06")) {
    return(list(
      receipts = list(), completed = 0L, branch_id = "", last_progress_at = "",
      contract_bound = FALSE, expected_total = NULL, complete = FALSE
    ))
  }
  directory <- .stage_progress_directory(
    root, heartbeat$stage, heartbeat$stage_request_sha256
  )
  contract <- .stage_progress_registry_contract(heartbeat$stage, project_root)
  if (!is.null(contract) && !is.null(heartbeat$total) &&
      !identical(as.integer(heartbeat$total), as.integer(length(contract$ids)))) {
    .observability_stop("STAGE_PROGRESS_TOTAL_REGISTRY_MISMATCH")
  }
  paths <- if (dir.exists(directory)) {
    sort(list.files(directory, pattern = "[.]json$", recursive = TRUE, full.names = TRUE), method = "radix")
  } else character()
  if (!length(paths)) {
    return(list(
      receipts = list(), completed = 0L, branch_id = "", last_progress_at = "",
      contract_bound = !is.null(contract),
      expected_total = if (is.null(contract)) NULL else as.integer(length(contract$ids)),
      complete = FALSE
    ))
  }
  if (!requireNamespace("jsonlite", quietly = TRUE)) {
    .observability_stop("STAGE_OBSERVABILITY_DEPENDENCY_MISSING", "jsonlite")
  }
  receipts <- lapply(paths, function(path) {
    if (isTRUE(file.info(path)$isdir) || file.info(path)$size > 32768L) {
      .observability_stop("STAGE_PROGRESS_RECEIPT_FILE_INVALID")
    }
    value <- jsonlite::read_json(path, simplifyVector = TRUE)
    validate_stage_progress_receipt(value)
    if (!identical(value$run_id, heartbeat$run_id) ||
        !identical(value$stage, heartbeat$stage) ||
        !identical(value$target, heartbeat$target) ||
        !identical(value$stage_request_sha256, heartbeat$stage_request_sha256)) {
      .observability_stop("STAGE_PROGRESS_RECEIPT_CONTEXT_MISMATCH")
    }
    if (!is.null(contract) &&
        (!identical(value$branch_type, contract$branch_type) ||
         !value$branch_id %in% contract$ids)) {
      .observability_stop("STAGE_PROGRESS_RECEIPT_UNREGISTERED_BRANCH", value$branch_id)
    }
    value
  })
  keys <- vapply(receipts, function(value) paste(value$branch_type, value$branch_id, sep = "/"), character(1))
  if (anyDuplicated(keys)) .observability_stop("STAGE_PROGRESS_RECEIPT_DUPLICATE_BRANCH")
  completed_at <- vapply(receipts, `[[`, character(1), "completed_at")
  order_index <- order(completed_at, keys, method = "radix")
  latest <- receipts[[tail(order_index, 1L)]]
  if (!is.null(heartbeat$total) && length(receipts) > heartbeat$total) {
    .observability_stop("STAGE_PROGRESS_RECEIPT_COUNT_EXCEEDS_TOTAL")
  }
  list(
    receipts = receipts,
    completed = as.integer(length(receipts)),
    branch_id = latest$branch_id,
    last_progress_at = latest$completed_at,
    contract_bound = !is.null(contract),
    expected_total = if (is.null(contract)) NULL else as.integer(length(contract$ids)),
    complete = !is.null(contract) && setequal(
      vapply(receipts, `[[`, character(1), "branch_id"), contract$ids
    )
  )
}

.stage_observability_success_status <- function(status) {
  status %in% c(
    "PASS_AUTO_CONTINUE", "PASS_WITH_NONBLOCKING_WARNINGS", "PASS_HUMAN_APPROVED"
  )
}

write_stage_heartbeat <- function(
    run_id, stage, target, branch_id = "", completed = NULL, total = NULL,
    stage_request_sha256 = "", status = "RUNNING", warning_status = "NONE",
    failure_code = "", next_checkpoint = "", root = ".", now = Sys.time(),
    project_root = NULL) {
  .observability_require_control()
  existing <- read_stage_heartbeat(root, required = FALSE)
  same_run <- !is.null(existing) && identical(existing$run_id, run_id)
  same_stage <- same_run && identical(existing$stage, stage)
  if (same_stage && !nzchar(stage_request_sha256)) {
    stage_request_sha256 <- existing$stage_request_sha256
  }
  same_context <- same_stage && identical(existing$stage_request_sha256, stage_request_sha256)
  if (same_context && is.null(total)) total <- existing$total
  provisional <- list(
    run_id = run_id, stage = stage, stage_request_sha256 = stage_request_sha256,
    total = total
  )
  progress <- if (nzchar(stage_request_sha256) && stage %in% c("A05", "A06")) {
    .read_stage_progress_receipts(root, c(provisional, list(
      schema_version = "1.0.0", sequence = 1L, target = target,
      branch_id = branch_id, completed = 0L, started_at = .observability_now(now),
      last_progress_at = .observability_now(now), updated_at = .observability_now(now),
      status = status, warning_status = warning_status, failure_code = failure_code,
      next_checkpoint = next_checkpoint
    )), project_root = project_root)
  } else {
    list(
      completed = 0L, branch_id = "", last_progress_at = "",
      contract_bound = FALSE, expected_total = NULL, complete = FALSE
    )
  }
  completed_value <- if (is.null(completed)) 0L else as.integer(completed)
  if (isTRUE(progress$contract_bound)) {
    if (is.null(total) || !identical(as.integer(total), progress$expected_total)) {
      .observability_stop("STAGE_PROGRESS_TOTAL_REGISTRY_MISMATCH")
    }
    # A05/A06 的完成数只以已验证的 registry 分支 receipt 为真源。
    completed_value <- progress$completed
    if (.stage_observability_success_status(status) && !isTRUE(progress$complete)) {
      .observability_stop("STAGE_PROGRESS_RECEIPT_CLOSURE_INCOMPLETE")
    }
  } else {
    if (same_context) completed_value <- max(completed_value, as.integer(existing$completed))
    completed_value <- max(completed_value, progress$completed)
  }
  if (!is.null(total) && completed_value > total) {
    .observability_stop("STAGE_HEARTBEAT_COMPLETED_EXCEEDS_TOTAL")
  }
  branch_value <- if (nzchar(progress$branch_id)) progress$branch_id else branch_id
  now_text <- .observability_now(now)
  started_at <- if (same_context) existing$started_at else now_text
  prior_completed <- if (same_context) as.integer(existing$completed) else -1L
  progressed <- !same_context || completed_value > prior_completed ||
    !identical(target, existing$target) || !identical(branch_value, existing$branch_id) ||
    !identical(status, existing$status) || nzchar(failure_code)
  last_progress_at <- if (same_context && !progressed) existing$last_progress_at else now_text
  if (nzchar(progress$last_progress_at) &&
      .observability_parse_time(progress$last_progress_at, "progress_completed_at") >
      .observability_parse_time(last_progress_at, "last_progress_at")) {
    last_progress_at <- progress$last_progress_at
  }
  heartbeat <- list(
    schema_version = "1.0.0",
    sequence = if (same_run) as.integer(existing$sequence) + 1L else 1L,
    run_id = run_id,
    stage = stage,
    target = target,
    branch_id = branch_value,
    completed = completed_value,
    total = if (is.null(total)) NULL else as.integer(total),
    stage_request_sha256 = stage_request_sha256,
    started_at = started_at,
    last_progress_at = last_progress_at,
    updated_at = now_text,
    status = status,
    warning_status = warning_status,
    failure_code = failure_code,
    next_checkpoint = next_checkpoint
  )
  validate_stage_heartbeat(heartbeat)
  path <- file.path(root, "runtime", "stage_heartbeat.json")
  # 原子替换非权威 heartbeat；RUN_STATE 继续是唯一 mutable authority。
  .control_write_atomic(path, canonical_json(heartbeat), mode = "0600")
  read_stage_heartbeat(root)
}

read_stage_observability_snapshot <- function(
    root = ".", now = Sys.time(), max_age_seconds = 120, project_root = NULL) {
  heartbeat <- read_stage_heartbeat(root)
  progress <- .read_stage_progress_receipts(root, heartbeat, project_root = project_root)
  snapshot <- heartbeat
  snapshot$completed <- if (isTRUE(progress$contract_bound)) {
    progress$completed
  } else {
    max(as.integer(heartbeat$completed), progress$completed)
  }
  if (isTRUE(progress$contract_bound) &&
      .stage_observability_success_status(snapshot$status) && !isTRUE(progress$complete)) {
    .observability_stop("STAGE_PROGRESS_RECEIPT_CLOSURE_INCOMPLETE")
  }
  if (!is.null(snapshot$total) && snapshot$completed > snapshot$total) {
    .observability_stop("STAGE_OBSERVABILITY_COMPLETED_EXCEEDS_TOTAL")
  }
  if (nzchar(progress$branch_id)) snapshot$branch_id <- progress$branch_id
  if (nzchar(progress$last_progress_at) &&
      .observability_parse_time(progress$last_progress_at, "progress_completed_at") >
      .observability_parse_time(snapshot$last_progress_at, "last_progress_at")) {
    snapshot$last_progress_at <- progress$last_progress_at
  }
  if (nzchar(progress$last_progress_at) &&
      .observability_parse_time(progress$last_progress_at, "progress_completed_at") >
      .observability_parse_time(snapshot$updated_at, "updated_at")) {
    snapshot$updated_at <- progress$last_progress_at
  }
  now_value <- as.POSIXct(now, tz = "UTC")
  snapshot$elapsed_seconds <- max(0, as.numeric(difftime(
    now_value, .observability_parse_time(snapshot$started_at, "started_at"), units = "secs"
  )))
  snapshot$seconds_since_progress <- max(0, as.numeric(difftime(
    now_value, .observability_parse_time(snapshot$last_progress_at, "last_progress_at"), units = "secs"
  )))
  update_age <- max(0, as.numeric(difftime(
    now_value, .observability_parse_time(snapshot$updated_at, "updated_at"), units = "secs"
  )))
  snapshot$heartbeat_fresh <- is.finite(update_age) && update_age <= max_age_seconds
  snapshot
}

stage_observability_plan <- function(stage, project_root = ".") {
  if (identical(stage, "A05")) {
    registry <- utils::read.csv(
      file.path(project_root, "config", "subgroup_registry.csv"),
      stringsAsFactors = FALSE, check.names = FALSE
    )
    return(list(
      target = "A05_subgroup_branch", total = as.integer(nrow(registry)),
      next_checkpoint = "A05_BRANCH_COMPLETE"
    ))
  }
  if (identical(stage, "A06")) {
    registry <- utils::read.csv(
      file.path(project_root, "config", "sensitivity_registry.csv"),
      stringsAsFactors = FALSE, check.names = FALSE
    )
    return(list(
      target = "A06_sensitivity_branch", total = as.integer(nrow(registry)),
      next_checkpoint = "A06_BRANCH_COMPLETE"
    ))
  }
  list(target = "tar_make", total = NULL, next_checkpoint = paste0(stage, "_STAGE_RESULT"))
}

stage_branch_result_sha256 <- function(value) {
  .observability_require_control()
  .control_sha256_text(canonical_json(value))
}
