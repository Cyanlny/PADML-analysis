# Bundle 发布模块：先写 staging 并通过完整性检查，再原子发布。

.bundle_utc_now_rfc3339 <- function() {
  format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
}

.bundle_scalar_string <- function(value) {
  is.character(value) && length(value) == 1L && !is.na(value)
}

.bundle_sha256_string <- function(value) {
  .bundle_scalar_string(value) && grepl("^[0-9a-f]{64}$", value)
}

.bundle_rfc3339 <- function(value) {
  if (!.bundle_scalar_string(value)) return(FALSE)
  pattern <- "^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(\\.[0-9]+)?(Z|[+-][0-9]{2}:[0-9]{2})$"
  if (!grepl(pattern, value, perl = TRUE)) return(FALSE)
  if (!grepl("Z$", value)) {
    offset <- substr(value, nchar(value) - 5L, nchar(value))
    if (as.integer(substr(offset, 2L, 3L)) > 23L || as.integer(substr(offset, 5L, 6L)) > 59L) return(FALSE)
  }
  normalized <- if (grepl("Z$", value)) {
    sub("Z$", "+0000", value)
  } else {
    sub("([+-][0-9]{2}):([0-9]{2})$", "\\1\\2", value, perl = TRUE)
  }
  parsed <- suppressWarnings(strptime(normalized, format = "%Y-%m-%dT%H:%M:%OS%z", tz = "UTC"))
  length(parsed) == 1L && !is.na(parsed)
}

.bundle_schema_path <- function(file_name) {
  project_root <- Sys.getenv("AST_ALT_PROJECT_ROOT", unset = "")
  candidates <- unique(c(
    if (nzchar(project_root)) file.path(project_root, "schemas", file_name) else character(),
    file.path(getwd(), "schemas", file_name)
  ))
  existing <- candidates[file.exists(candidates)]
  if (!length(existing)) stop("Control-plane schema is missing: ", file_name, call. = FALSE)
  normalizePath(existing[[1L]], mustWork = TRUE)
}

.bundle_validate_flat_schema <- function(object, schema, label) {
  if (!is.list(object) || is.data.frame(object) || is.null(names(object)) || any(!nzchar(names(object)))) {
    stop(label, " must be a JSON object", call. = FALSE)
  }
  if (anyDuplicated(names(object))) stop(label, " contains duplicate properties", call. = FALSE)
  required <- as.character(schema$required)
  allowed <- names(schema$properties)
  missing <- setdiff(required, names(object))
  unknown <- setdiff(names(object), allowed)
  if (length(missing)) stop(label, " missing required properties: ", paste(missing, collapse = ", "), call. = FALSE)
  if (isFALSE(schema$additionalProperties) && length(unknown)) {
    stop(label, " contains unknown properties: ", paste(unknown, collapse = ", "), call. = FALSE)
  }
  for (name in intersect(names(object), allowed)) {
    value <- object[[name]]
    rule <- schema$properties[[name]]
    type <- if (is.null(rule$type)) "" else as.character(rule$type)
    if (identical(type, "string") && !.bundle_scalar_string(value)) stop(label, " property type mismatch: ", name, call. = FALSE)
    if (identical(type, "boolean") && !(is.logical(value) && length(value) == 1L && !is.na(value))) {
      stop(label, " property type mismatch: ", name, call. = FALSE)
    }
    if (!is.null(rule$enum) && !(length(value) == 1L && !is.na(value) && value %in% as.character(rule$enum))) {
      stop(label, " property enum mismatch: ", name, call. = FALSE)
    }
    if (!is.null(rule$const) && !identical(value, rule$const)) stop(label, " property const mismatch: ", name, call. = FALSE)
    if (!is.null(rule$minLength) && .bundle_scalar_string(value) &&
        nchar(trimws(value), type = "chars") < as.integer(rule$minLength)) {
      stop(label, " property is empty: ", name, call. = FALSE)
    }
    if (!is.null(rule$pattern) && .bundle_scalar_string(value) && !grepl(rule$pattern, value, perl = TRUE)) {
      stop(label, " property pattern mismatch: ", name, call. = FALSE)
    }
    if (!is.null(rule$format) && identical(rule$format, "date-time") && !.bundle_rfc3339(value)) {
      stop(label, " property is not RFC3339: ", name, call. = FALSE)
    }
  }
  invisible(TRUE)
}

sha256_text <- function(text) {
  # 加载摘要包并计算规范文本的 SHA-256。
  if (!requireNamespace("digest", quietly = TRUE)) stop("digest is required", call. = FALSE)
  digest::digest(enc2utf8(paste(text, collapse = "\n")), algo = "sha256", serialize = FALSE)
}

file_sha256 <- function(path) {
  # 加载摘要包以计算文件哈希。
  if (!requireNamespace("digest", quietly = TRUE)) stop("digest is required", call. = FALSE)
  digest::digest(file = path, algo = "sha256")
}

bundle_tabular_dimensions <- function(path) {
  if (!grepl("\\.csv$", path, ignore.case = TRUE)) {
    return(c(row_count = NA_real_, column_count = NA_real_))
  }
  data <- tryCatch(
    utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(error) NULL
  )
  if (is.null(data)) {
    c(row_count = NA_real_, column_count = NA_real_)
  } else {
    c(row_count = nrow(data), column_count = ncol(data))
  }
}

bundle_manifest_columns <- function() {
  c(
    "protocol_version", "scientific_config_sha256", "scientific_config_revision", "bundle_schema_version",
    "consumed_epoch_set", "stage_request_semantic_sha256",
    "source_epoch", "science_epoch", "execution_epoch", "runtime_epoch", "publication_epoch",
    "source_handoff_sha256", "stage_contract_sha256", "input_identity_sha256",
    "upstream_artifact_sha256", "exact_consumer_set_sha256",
    "reachable_authority_slice_sha256", "stage_capsule_sha256",
    "pre_stage_sentinel_sha256", "pre_seal_sentinel_sha256",
    "producer_stage", "consumer_stages", "data_classification", "file_name",
    "relative_path", "sha256", "size_bytes", "row_count", "column_count", "created_at"
  )
}

.bundle_lineage_fields <- function() {
  c(
    "consumed_epoch_set", "stage_request_semantic_sha256",
    "source_epoch", "science_epoch", "execution_epoch", "runtime_epoch", "publication_epoch",
    "source_handoff_sha256", "stage_contract_sha256", "input_identity_sha256",
    "upstream_artifact_sha256", "exact_consumer_set_sha256",
    "reachable_authority_slice_sha256", "stage_capsule_sha256",
    "pre_stage_sentinel_sha256", "pre_seal_sentinel_sha256"
  )
}

.default_bundle_lineage <- function() {
  fields <- .bundle_lineage_fields()
  output <- setNames(lapply(fields, function(field) sha256_text(paste0("SYNTHETIC_ONLY_", field))), fields)
  output$consumed_epoch_set <- "source|science|execution|runtime|publication"
  output
}

.validate_bundle_lineage <- function(lineage) {
  fields <- .bundle_lineage_fields()
  if (is.atomic(lineage) && !is.null(names(lineage))) lineage <- as.list(lineage)
  sha_fields <- setdiff(fields, "consumed_epoch_set")
  if (!is.list(lineage) || !identical(sort(names(lineage)), sort(fields)) ||
      any(!vapply(lineage[sha_fields], .bundle_sha256_string, logical(1))) ||
      !.bundle_scalar_string(lineage$consumed_epoch_set) ||
      !grepl("^(source|science|execution|runtime|publication)(\\|(source|science|execution|runtime|publication))*$", lineage$consumed_epoch_set)) {
    stop("Bundle lineage must contain exact 64hex identity fields", call. = FALSE)
  }
  lineage[fields]
}

.registered_bundle_consumers <- function(stage) {
  project_root <- Sys.getenv("AST_ALT_PROJECT_ROOT", unset = normalizePath(".", mustWork = TRUE))
  path <- file.path(project_root, "config", "task_registry.csv")
  if (!file.exists(path)) stop("Bundle consumer registry is missing", call. = FALSE)
  registry <- utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE)
  downstream <- registry$stage[registry$dependency == stage]
  if (!length(downstream)) return("TERMINAL")
  paste(sort(unique(downstream)), collapse = "|")
}

.canonical_manifest_value <- function(value) {
  if (is.numeric(value) || is.integer(value)) {
    return(ifelse(is.na(value), "<NA>", format(value, scientific = FALSE, trim = TRUE, digits = 17L)))
  }
  if (is.logical(value)) return(ifelse(is.na(value), "<NA>", ifelse(value, "true", "false")))
  value <- as.character(value)
  value[is.na(value)] <- "<NA>"
  enc2utf8(value)
}

canonical_bundle_identity <- function(manifest) {
  identity_columns <- setdiff(bundle_manifest_columns(), "created_at")
  if (!all(identity_columns %in% names(manifest))) stop("Bundle manifest identity columns are missing", call. = FALSE)
  ordered <- manifest[order(as.character(manifest$relative_path), as.character(manifest$file_name)), identity_columns, drop = FALSE]
  normalized <- as.data.frame(lapply(ordered, .canonical_manifest_value), stringsAsFactors = FALSE, check.names = FALSE)
  # 加载 JSON 包并生成排除时间戳的规范 bundle 身份。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  canonical <- jsonlite::toJSON(
    normalized, dataframe = "rows", auto_unbox = TRUE, na = "null",
    null = "null", digits = NA, pretty = FALSE
  )
  sha256_text(as.character(canonical))
}

.validate_stage_lock_object <- function(lock) {
  # 加载 JSON 包并读取阶段锁 Schema。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  schema <- jsonlite::read_json(.bundle_schema_path("stage_lock_schema.json"), simplifyVector = TRUE)
  .bundle_validate_flat_schema(lock, schema, "Stage lock")
  auto_status <- c("PASS_AUTO_CONTINUE", "PASS_WITH_NONBLOCKING_WARNINGS")
  pending_status <- c(
    "WARNING_WAITING_FOR_HUMAN_REVIEW",
    "SCIENTIFIC_CONFIG_CANDIDATE_WAITING_FOR_HUMAN_REVIEW",
    "RESOURCE_GATE_WAITING_FOR_HUMAN_REVIEW",
    "FAIL_WAITING_FOR_HUMAN_REVIEW",
    "STOP_PROJECT"
  )
  if (identical(lock$approval_basis, "AUTO_GATE_PASS") &&
      (!lock$stage_status %in% auto_status || isTRUE(lock$human_review_required))) {
    stop("Stage lock auto-approval state is inconsistent", call. = FALSE)
  }
  if (identical(lock$approval_basis, "PENDING_HUMAN_REVIEW") &&
      (!lock$stage_status %in% pending_status || !isTRUE(lock$human_review_required))) {
    stop("Stage lock pending-review state is inconsistent", call. = FALSE)
  }
  if (identical(lock$approval_basis, "HUMAN_APPROVAL") &&
      (!identical(lock$stage_status, "PASS_HUMAN_APPROVED") || isTRUE(lock$human_review_required))) {
    stop("Stage lock human-approval state is inconsistent", call. = FALSE)
  }
  invisible(TRUE)
}

.validate_decision_for_promotion <- function(path, expected_stage, expected_lock_sha256) {
  if (!file.exists(path)) stop("Promotion decision file is missing", call. = FALSE)
  # 加载 JSON 包并严格验证晋级决定 Schema。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  decision <- jsonlite::read_json(path, simplifyVector = TRUE)
  schema <- jsonlite::read_json(.bundle_schema_path("review_decision_schema.json"), simplifyVector = TRUE)
  .bundle_validate_flat_schema(decision, schema, "Review decision")
  if (!identical(decision$stage, expected_stage)) stop("Promotion decision stage mismatch", call. = FALSE)
  if (!identical(decision$approved_stage_lock_sha256, expected_lock_sha256)) {
    stop("Promotion decision lock mismatch", call. = FALSE)
  }
  if (!identical(decision$decision, "APPROVE_NEXT_STAGE")) {
    stop("Promotion requires APPROVE_NEXT_STAGE", call. = FALSE)
  }
  decision
}

.validate_manifest_structure <- function(manifest, path) {
  required_columns <- bundle_manifest_columns()
  if (!identical(names(manifest), required_columns)) stop("Bundle manifest schema mismatch", call. = FALSE)
  if (!nrow(manifest)) stop("Bundle manifest must contain at least one artifact", call. = FALSE)
  if (anyDuplicated(manifest$file_name) || anyDuplicated(manifest$relative_path)) {
    stop("Bundle manifest paths must be unique", call. = FALSE)
  }
  if (any(is.na(manifest$file_name)) || any(is.na(manifest$relative_path))) {
    stop("Bundle manifest path is missing", call. = FALSE)
  }
  unsafe <- !grepl("^[A-Za-z0-9][A-Za-z0-9._-]*$", manifest$relative_path) |
    manifest$relative_path != manifest$file_name |
    basename(manifest$relative_path) != manifest$relative_path |
    manifest$relative_path %in% c(
      "bundle_manifest.csv", "SHA256SUMS.txt", "stage_lock.json", "BUNDLE_COMPLETE",
      "candidate_stage_lock.json", "candidate_bundle_manifest.csv", "approval_decision.json"
    )
  if (any(unsafe)) stop("Bundle manifest relative path is unsafe", call. = FALSE)
  if (any(!grepl("^[0-9a-f]{64}$", manifest$sha256))) stop("Bundle manifest SHA256 schema mismatch", call. = FALSE)
  if (any(!vapply(as.character(manifest$created_at), .bundle_rfc3339, logical(1)))) {
    stop("Bundle manifest created_at is not RFC3339", call. = FALSE)
  }
  shared <- c(
    "protocol_version", "scientific_config_sha256", "scientific_config_revision", "bundle_schema_version",
    .bundle_lineage_fields(),
    "producer_stage", "consumer_stages", "data_classification"
  )
  if (any(vapply(manifest[shared], function(value) length(unique(value)) != 1L, logical(1)))) {
    stop("Bundle manifest shared metadata is inconsistent", call. = FALSE)
  }
  if (any(!grepl("^[0-9a-f]{64}$", manifest$scientific_config_sha256))) {
    stop("Bundle manifest scientific config SHA256 mismatch", call. = FALSE)
  }
  if (!identical(unique(manifest$protocol_version), "v4.3-r00")) stop("Bundle manifest protocol version mismatch", call. = FALSE)
  lineage_sha_fields <- setdiff(.bundle_lineage_fields(), "consumed_epoch_set")
  if (any(vapply(manifest[lineage_sha_fields], function(value) {
    any(!grepl("^[0-9a-f]{64}$", as.character(value)))
  }, logical(1)))) stop("Bundle manifest lineage identity mismatch", call. = FALSE)
  root <- normalizePath(path, mustWork = TRUE)
  artifact_paths <- file.path(root, manifest$relative_path)
  if (any(!file.exists(artifact_paths)) || any(file.info(artifact_paths)$isdir)) {
    stop("Bundle manifest artifact is missing or not a file", call. = FALSE)
  }
  if (any(nzchar(Sys.readlink(artifact_paths)))) stop("Bundle manifest artifact symlink is forbidden", call. = FALSE)
  normalized_artifacts <- vapply(artifact_paths, normalizePath, character(1), mustWork = TRUE)
  root_prefix <- paste0(root, .Platform$file.sep)
  if (any(!startsWith(normalized_artifacts, root_prefix))) stop("Bundle manifest path escapes bundle root", call. = FALSE)
  observed_size <- as.numeric(file.info(artifact_paths)$size)
  if (!identical(unname(observed_size), unname(as.numeric(manifest$size_bytes)))) {
    stop("Bundle artifact size validation failed", call. = FALSE)
  }
  observed_sha <- vapply(artifact_paths, file_sha256, character(1))
  if (!identical(unname(observed_sha), unname(as.character(manifest$sha256)))) {
    stop("Bundle SHA256 validation failed", call. = FALSE)
  }
  observed_dimensions <- lapply(artifact_paths, bundle_tabular_dimensions)
  row_count <- vapply(observed_dimensions, `[[`, numeric(1), "row_count")
  column_count <- vapply(observed_dimensions, `[[`, numeric(1), "column_count")
  same_numeric <- function(observed, expected) {
    expected <- as.numeric(expected)
    all((is.na(observed) & is.na(expected)) | (!is.na(observed) & !is.na(expected) & observed == expected))
  }
  if (!same_numeric(row_count, manifest$row_count) || !same_numeric(column_count, manifest$column_count)) {
    stop("Bundle tabular dimension validation failed", call. = FALSE)
  }
  invisible(artifact_paths)
}

.validate_lock_manifest_alignment <- function(lock, manifest, manifest_path) {
  checks <- c(
    stage = identical(lock$stage, unique(manifest$producer_stage)),
    config_sha = identical(lock$scientific_config_sha256, unique(manifest$scientific_config_sha256)),
    revision = identical(lock$scientific_config_revision, unique(manifest$scientific_config_revision)),
    schema = identical(lock$bundle_schema_version, unique(manifest$bundle_schema_version)),
    classification = identical(lock$data_classification, unique(manifest$data_classification)),
    lineage = all(vapply(.bundle_lineage_fields(), function(field) {
      identical(lock[[field]], unique(manifest[[field]]))
    }, logical(1))),
    identity = identical(lock$bundle_sha256, canonical_bundle_identity(manifest)),
    manifest_file = identical(lock$bundle_manifest_sha256, file_sha256(manifest_path))
  )
  if (!all(checks)) stop("Bundle lock and manifest identity mismatch: ", paste(names(checks)[!checks], collapse = ", "), call. = FALSE)
  invisible(TRUE)
}

.lock_semantic_identity <- function(lock) {
  fields <- sort(setdiff(names(lock), c("created_at", "bundle_manifest_sha256")))
  normalized <- lock[fields]
  # 加载 JSON 包并计算忽略创建时间的锁语义身份。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  sha256_text(as.character(jsonlite::toJSON(
    normalized, auto_unbox = TRUE, null = "null", na = "null", digits = NA, pretty = FALSE
  )))
}

publish_bundle_atomic <- function(
    stage, files, classification = "PUBLIC_AGGREGATE", root = ".",
    stage_status = "PASS_AUTO_CONTINUE", approval_basis = "AUTO_GATE_PASS",
    human_review_required = FALSE, scientific_config_sha256 = NULL,
    scientific_config_revision = "v4.3-r00", bundle_schema_version = paste0(stage, "_BUNDLE_V43"),
    consumer_stages = NULL, replace_existing = FALSE, lineage = NULL,
    cache_root_name = "approved_cache") {
  classifications <- c("PUBLIC_AGGREGATE", "RESTRICTED_AGGREGATE", "PATIENT_LEVEL_RESTRICTED")
  if (!classification %in% classifications) stop("Invalid data classification", call. = FALSE)
  if (!.bundle_scalar_string(stage) || !grepl("^[A-Z][0-9]{2}$", stage)) stop("Invalid producer stage", call. = FALSE)
  if (!length(files)) stop("Bundle requires at least one input file", call. = FALSE)
  files <- normalizePath(files, mustWork = TRUE)
  if (any(file.info(files)$isdir) || any(nzchar(Sys.readlink(files)))) stop("Bundle inputs must be regular non-symlink files", call. = FALSE)
  if (anyDuplicated(basename(files))) stop("Bundle input basenames must be unique", call. = FALSE)
  execution_profile <- Sys.getenv("AST_ALT_EXECUTION_PROFILE", unset = "build_validation")
  formal_lineage_required <- !identical(execution_profile, "build_validation") ||
    nzchar(Sys.getenv("AST_ALT_STAGE_CAPSULE", unset = ""))
  if (is.null(scientific_config_sha256)) {
    if (formal_lineage_required) stop("Explicit scientific config identity is required", call. = FALSE)
    scientific_config_sha256 <- sha256_text("BUILD_VALIDATION")
  }
  if (!.bundle_sha256_string(scientific_config_sha256)) stop("Scientific config SHA256 must be 64hex", call. = FALSE)
  if (!.bundle_scalar_string(scientific_config_revision) || !nzchar(trimws(scientific_config_revision))) {
    stop("Scientific config revision is required", call. = FALSE)
  }
  if (is.null(lineage)) {
    if (formal_lineage_required) stop("Explicit bundle lineage is required", call. = FALSE)
    lineage <- .default_bundle_lineage()
  }
  lineage <- .validate_bundle_lineage(lineage)
  if (formal_lineage_required) {
    synthetic <- .default_bundle_lineage()
    sha_fields <- setdiff(.bundle_lineage_fields(), "consumed_epoch_set")
    if (any(vapply(sha_fields, function(field) {
      identical(lineage[[field]], synthetic[[field]])
    }, logical(1)))) stop("Synthetic-only lineage is forbidden for formal publication", call. = FALSE)
  }
  if (is.null(consumer_stages)) consumer_stages <- .registered_bundle_consumers(stage)
  if (!.bundle_scalar_string(consumer_stages) || !nzchar(consumer_stages) ||
      identical(consumer_stages, "NEXT_STAGE")) {
    stop("Bundle consumer stages must be registry-derived", call. = FALSE)
  }
  branch <- if (classification == "PUBLIC_AGGREGATE") "public" else "restricted"
  if (!cache_root_name %in% c("approved_cache", "candidate_cache")) stop("Invalid cache root", call. = FALSE)
  base <- file.path(root, cache_root_name, branch)
  staging <- file.path(base, ".staging", stage)
  final <- file.path(base, stage)
  if (dir.exists(staging)) unlink(staging, recursive = TRUE)
  dir.create(staging, recursive = TRUE, showWarnings = FALSE)
  # 保存 bundle 输入到 staging 缓存。
  copied <- file.copy(files, staging, overwrite = FALSE, copy.mode = TRUE, copy.date = FALSE)
  if (!all(copied)) stop("Failed to copy bundle inputs", call. = FALSE)
  staged_files <- file.path(staging, basename(files))
  dimensions <- lapply(staged_files, bundle_tabular_dimensions)
  created_at <- .bundle_utc_now_rfc3339()
  manifest <- data.frame(
    protocol_version = "v4.3-r00",
    scientific_config_sha256 = scientific_config_sha256,
    scientific_config_revision = scientific_config_revision,
    bundle_schema_version = bundle_schema_version,
    consumed_epoch_set = lineage$consumed_epoch_set,
    stage_request_semantic_sha256 = lineage$stage_request_semantic_sha256,
    source_epoch = lineage$source_epoch,
    science_epoch = lineage$science_epoch,
    execution_epoch = lineage$execution_epoch,
    runtime_epoch = lineage$runtime_epoch,
    publication_epoch = lineage$publication_epoch,
    source_handoff_sha256 = lineage$source_handoff_sha256,
    stage_contract_sha256 = lineage$stage_contract_sha256,
    input_identity_sha256 = lineage$input_identity_sha256,
    upstream_artifact_sha256 = lineage$upstream_artifact_sha256,
    exact_consumer_set_sha256 = lineage$exact_consumer_set_sha256,
    reachable_authority_slice_sha256 = lineage$reachable_authority_slice_sha256,
    stage_capsule_sha256 = lineage$stage_capsule_sha256,
    pre_stage_sentinel_sha256 = lineage$pre_stage_sentinel_sha256,
    pre_seal_sentinel_sha256 = lineage$pre_seal_sentinel_sha256,
    producer_stage = stage,
    consumer_stages = consumer_stages,
    data_classification = classification,
    file_name = basename(files),
    relative_path = basename(files),
    sha256 = vapply(staged_files, file_sha256, character(1)),
    size_bytes = as.numeric(file.info(staged_files)$size),
    row_count = vapply(dimensions, `[[`, numeric(1), "row_count"),
    column_count = vapply(dimensions, `[[`, numeric(1), "column_count"),
    created_at = created_at,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  # 写入 bundle 清单，供下游校验 Schema、路径和哈希。
  utils::write.csv(manifest, file.path(staging, "bundle_manifest.csv"), row.names = FALSE, na = "")
  sums <- paste(manifest$sha256, manifest$file_name, sep = "  ")
  writeLines(sums, file.path(staging, "SHA256SUMS.txt"), useBytes = TRUE)
  lock <- list(
    stage = stage,
    stage_status = stage_status,
    approval_basis = approval_basis,
    human_review_required = isTRUE(human_review_required),
    scientific_config_sha256 = scientific_config_sha256,
    scientific_config_revision = scientific_config_revision,
    consumed_epoch_set = lineage$consumed_epoch_set,
    stage_request_semantic_sha256 = lineage$stage_request_semantic_sha256,
    source_epoch = lineage$source_epoch,
    science_epoch = lineage$science_epoch,
    execution_epoch = lineage$execution_epoch,
    runtime_epoch = lineage$runtime_epoch,
    publication_epoch = lineage$publication_epoch,
    source_handoff_sha256 = lineage$source_handoff_sha256,
    stage_contract_sha256 = lineage$stage_contract_sha256,
    input_identity_sha256 = lineage$input_identity_sha256,
    upstream_artifact_sha256 = lineage$upstream_artifact_sha256,
    exact_consumer_set_sha256 = lineage$exact_consumer_set_sha256,
    reachable_authority_slice_sha256 = lineage$reachable_authority_slice_sha256,
    stage_capsule_sha256 = lineage$stage_capsule_sha256,
    pre_stage_sentinel_sha256 = lineage$pre_stage_sentinel_sha256,
    pre_seal_sentinel_sha256 = lineage$pre_seal_sentinel_sha256,
    bundle_sha256 = canonical_bundle_identity(manifest),
    bundle_manifest_sha256 = file_sha256(file.path(staging, "bundle_manifest.csv")),
    bundle_identity_algorithm = "sha256-canonical-manifest-v1",
    bundle_schema_version = bundle_schema_version,
    data_classification = classification,
    created_at = created_at
  )
  .validate_stage_lock_object(lock)
  # 加载 JSON 包并写入机器可验证的阶段锁。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  jsonlite::write_json(lock, file.path(staging, "stage_lock.json"), auto_unbox = TRUE, pretty = TRUE)
  writeLines("complete", file.path(staging, "BUNDLE_COMPLETE"), useBytes = TRUE)
  validate_bundle_complete(staging, expected_stage = stage, expected_classification = classification)
  if (dir.exists(final) && !replace_existing) {
    validate_bundle_complete(final, expected_stage = stage, expected_classification = classification)
    existing_lock <- read_stage_lock(final)
    if (identical(existing_lock$bundle_sha256, lock$bundle_sha256) &&
        identical(.lock_semantic_identity(existing_lock), .lock_semantic_identity(lock))) {
      unlink(staging, recursive = TRUE)
      return(invisible(final))
    }
    stop("A different completed bundle already exists for stage ", stage, call. = FALSE)
  }
  if (dir.exists(final)) unlink(final, recursive = TRUE)
  # 原子发布已经通过校验的 bundle 缓存。
  if (!file.rename(staging, final)) stop("Atomic bundle publication failed", call. = FALSE)
  invisible(final)
}

promote_candidate_bundle <- function(stage, classification, root = ".", decision_path = "") {
  classifications <- c("PUBLIC_AGGREGATE", "RESTRICTED_AGGREGATE", "PATIENT_LEVEL_RESTRICTED")
  if (!classification %in% classifications) stop("Invalid data classification", call. = FALSE)
  branch <- if (classification == "PUBLIC_AGGREGATE") "public" else "restricted"
  candidate <- file.path(root, "candidate_cache", branch, stage)
  approved <- file.path(root, "approved_cache", branch, stage)

  if (dir.exists(approved)) {
    validate_bundle_complete(approved, expected_stage = stage, expected_classification = classification)
    approved_lock <- read_stage_lock(approved)
    decision <- .validate_decision_for_promotion(
      decision_path, stage, approved_lock$approved_candidate_lock_sha256
    )
    if (!identical(file_sha256(decision_path), approved_lock$approval_decision_sha256) ||
        !identical(decision$approved_by, approved_lock$approved_by) ||
        !identical(decision$approved_at, approved_lock$approved_at)) {
      stop("Existing approved bundle is bound to a different decision", call. = FALSE)
    }
    return(approved)
  }

  validate_bundle_complete(candidate, expected_stage = stage, expected_classification = classification)
  candidate_lock_path <- file.path(candidate, "stage_lock.json")
  candidate_manifest_path <- file.path(candidate, "bundle_manifest.csv")
  source_candidate_lock_sha256 <- file_sha256(candidate_lock_path)
  # 加载 JSON 包并读取候选阶段锁。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  candidate_lock <- jsonlite::read_json(candidate_lock_path, simplifyVector = TRUE)
  if (!identical(candidate_lock$approval_basis, "PENDING_HUMAN_REVIEW")) {
    stop("Only a pending-review candidate can be promoted", call. = FALSE)
  }

  authority_lock_sha256 <- source_candidate_lock_sha256
  public_approved_lock <- NULL
  if (!identical(classification, "PUBLIC_AGGREGATE")) {
    approved_public <- file.path(root, "approved_cache", "public", stage)
    validate_bundle_complete(approved_public, expected_stage = stage, expected_classification = "PUBLIC_AGGREGATE")
    public_approved_lock <- read_stage_lock(approved_public)
    authority_lock_sha256 <- public_approved_lock$approved_candidate_lock_sha256
  }
  decision <- .validate_decision_for_promotion(decision_path, stage, authority_lock_sha256)
  decision_sha256 <- file_sha256(decision_path)

  candidate_manifest <- utils::read.csv(
    candidate_manifest_path, stringsAsFactors = FALSE, check.names = FALSE
  )
  revised_sha256 <- candidate_lock$scientific_config_sha256
  revised_revision <- candidate_lock$scientific_config_revision
  candidate_config_file <- file.path(candidate, "ph_nuisance_registry_candidate.csv")
  if (identical(classification, "PUBLIC_AGGREGATE") && identical(stage, "A03") &&
      file.exists(candidate_config_file)) {
    candidate_config <- utils::read.csv(
      candidate_config_file, stringsAsFactors = FALSE, check.names = FALSE
    )
    if (identical(Sys.getenv("AST_ALT_EXECUTION_PROFILE", unset = "build_validation"), "production") &&
        nrow(candidate_config) > 0L) {
      stop("SCIENCE_EPOCH_REVISION_REQUIRED", call. = FALSE)
    }
    revised_sha256 <- sha256_text(c(candidate_lock$scientific_config_sha256, file_sha256(candidate_config_file)))
    revised_revision <- paste0(candidate_lock$scientific_config_revision, "_A03_APPROVED")
  }
  if (!is.null(public_approved_lock)) {
    revised_sha256 <- public_approved_lock$scientific_config_sha256
    revised_revision <- public_approved_lock$scientific_config_revision
  }

  staging <- file.path(dirname(approved), ".promotion_staging", stage)
  if (dir.exists(staging)) unlink(staging, recursive = TRUE)
  dir.create(staging, recursive = TRUE, showWarnings = FALSE)
  artifact_sources <- file.path(candidate, candidate_manifest$relative_path)
  artifact_destinations <- file.path(staging, candidate_manifest$relative_path)
  # 通过同文件系统硬链接保存候选 artifact；不支持时退回复制。
  linked <- file.link(artifact_sources, artifact_destinations)
  if (any(!linked)) {
    copied <- file.copy(
      artifact_sources[!linked], artifact_destinations[!linked],
      overwrite = FALSE, copy.mode = TRUE, copy.date = FALSE
    )
    if (!all(copied)) stop("Candidate artifact promotion copy failed", call. = FALSE)
  }
  file.copy(file.path(candidate, c("SHA256SUMS.txt", "BUNDLE_COMPLETE")), staging, overwrite = FALSE)
  file.copy(candidate_lock_path, file.path(staging, "candidate_stage_lock.json"), overwrite = FALSE)
  file.copy(candidate_manifest_path, file.path(staging, "candidate_bundle_manifest.csv"), overwrite = FALSE)
  file.copy(decision_path, file.path(staging, "approval_decision.json"), overwrite = FALSE)

  approved_manifest <- candidate_manifest
  approved_manifest$protocol_version <- unique(candidate_manifest$protocol_version)
  approved_manifest$scientific_config_sha256 <- revised_sha256
  approved_manifest$scientific_config_revision <- revised_revision
  approved_manifest$created_at <- .bundle_utc_now_rfc3339()
  # 写入晋级后的新清单；原候选清单保持字节级不变。
  utils::write.csv(approved_manifest, file.path(staging, "bundle_manifest.csv"), row.names = FALSE, na = "")
  approved_lock <- list(
    stage = stage,
    stage_status = "PASS_HUMAN_APPROVED",
    approval_basis = "HUMAN_APPROVAL",
    human_review_required = FALSE,
    scientific_config_sha256 = revised_sha256,
    scientific_config_revision = revised_revision,
    consumed_epoch_set = candidate_lock$consumed_epoch_set,
    stage_request_semantic_sha256 = candidate_lock$stage_request_semantic_sha256,
    source_epoch = candidate_lock$source_epoch,
    science_epoch = candidate_lock$science_epoch,
    execution_epoch = candidate_lock$execution_epoch,
    runtime_epoch = candidate_lock$runtime_epoch,
    publication_epoch = candidate_lock$publication_epoch,
    source_handoff_sha256 = candidate_lock$source_handoff_sha256,
    stage_contract_sha256 = candidate_lock$stage_contract_sha256,
    input_identity_sha256 = candidate_lock$input_identity_sha256,
    upstream_artifact_sha256 = candidate_lock$upstream_artifact_sha256,
    exact_consumer_set_sha256 = candidate_lock$exact_consumer_set_sha256,
    reachable_authority_slice_sha256 = candidate_lock$reachable_authority_slice_sha256,
    stage_capsule_sha256 = candidate_lock$stage_capsule_sha256,
    pre_stage_sentinel_sha256 = candidate_lock$pre_stage_sentinel_sha256,
    pre_seal_sentinel_sha256 = candidate_lock$pre_seal_sentinel_sha256,
    bundle_sha256 = canonical_bundle_identity(approved_manifest),
    bundle_manifest_sha256 = file_sha256(file.path(staging, "bundle_manifest.csv")),
    bundle_identity_algorithm = "sha256-canonical-manifest-v1",
    bundle_schema_version = candidate_lock$bundle_schema_version,
    data_classification = classification,
    created_at = .bundle_utc_now_rfc3339(),
    approved_candidate_lock_sha256 = authority_lock_sha256,
    source_candidate_lock_sha256 = source_candidate_lock_sha256,
    approval_decision_sha256 = decision_sha256,
    approved_by = decision$approved_by,
    approved_at = decision$approved_at,
    review_notes = decision$review_notes
  )
  .validate_stage_lock_object(approved_lock)
  # 写入新的人工批准锁，不修改候选阶段锁。
  jsonlite::write_json(
    approved_lock, file.path(staging, "stage_lock.json"),
    auto_unbox = TRUE, pretty = TRUE
  )
  validate_bundle_complete(staging, expected_stage = stage, expected_classification = classification)
  dir.create(dirname(approved), recursive = TRUE, showWarnings = FALSE)
  # 原子发布晋级 bundle；候选 bundle 保持只读证据。
  if (!file.rename(staging, approved)) {
    if (dir.exists(approved)) {
      validate_bundle_complete(approved, expected_stage = stage, expected_classification = classification)
      return(approved)
    }
    stop("Candidate bundle promotion failed", call. = FALSE)
  }
  approved
}

validate_bundle_complete <- function(path, expected_stage = NULL, expected_classification = NULL) {
  if (!dir.exists(path)) stop("Bundle directory is missing", call. = FALSE)
  required <- c("bundle_manifest.csv", "SHA256SUMS.txt", "stage_lock.json", "BUNDLE_COMPLETE")
  missing <- required[!file.exists(file.path(path, required))]
  if (length(missing)) stop("Incomplete bundle: ", paste(missing, collapse = ", "), call. = FALSE)
  required_paths <- file.path(path, required)
  if (any(file.info(required_paths)$isdir) || any(nzchar(Sys.readlink(required_paths)))) {
    stop("Bundle control files must be regular non-symlink files", call. = FALSE)
  }
  marker <- readLines(file.path(path, "BUNDLE_COMPLETE"), warn = FALSE, encoding = "UTF-8")
  if (!identical(marker, "complete")) stop("BUNDLE_COMPLETE marker is invalid", call. = FALSE)
  manifest <- utils::read.csv(
    file.path(path, "bundle_manifest.csv"),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  .validate_manifest_structure(manifest, path)
  expected_sums <- paste(manifest$sha256, manifest$file_name, sep = "  ")
  observed_sums <- readLines(file.path(path, "SHA256SUMS.txt"), warn = FALSE, encoding = "UTF-8")
  if (!identical(observed_sums, expected_sums)) stop("SHA256SUMS does not exactly match bundle manifest", call. = FALSE)

  # 加载 JSON 包并验证阶段锁、Schema 和跨文件身份。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  lock <- jsonlite::read_json(file.path(path, "stage_lock.json"), simplifyVector = TRUE)
  .validate_stage_lock_object(lock)
  .validate_lock_manifest_alignment(lock, manifest, file.path(path, "bundle_manifest.csv"))
  if (!is.null(expected_stage) && !identical(lock$stage, expected_stage)) stop("Bundle stage mismatch", call. = FALSE)
  if (!is.null(expected_classification) &&
      !identical(lock$data_classification, expected_classification)) {
    stop("Bundle classification mismatch", call. = FALSE)
  }

  provenance <- c("candidate_stage_lock.json", "candidate_bundle_manifest.csv", "approval_decision.json")
  actual <- list.files(path, recursive = TRUE, all.files = TRUE, no.. = TRUE, include.dirs = TRUE)
  expected <- c(required, manifest$relative_path)
  if (identical(lock$approval_basis, "HUMAN_APPROVAL")) {
    expected <- c(expected, provenance)
  }
  if (!setequal(actual, expected) || length(actual) != length(expected)) {
    stop("Bundle file inventory contains missing or unregistered paths", call. = FALSE)
  }

  if (identical(lock$approval_basis, "HUMAN_APPROVAL")) {
    candidate_lock_path <- file.path(path, "candidate_stage_lock.json")
    candidate_manifest_path <- file.path(path, "candidate_bundle_manifest.csv")
    decision_path <- file.path(path, "approval_decision.json")
    candidate_lock <- jsonlite::read_json(candidate_lock_path, simplifyVector = TRUE)
    candidate_manifest <- utils::read.csv(
      candidate_manifest_path, stringsAsFactors = FALSE, check.names = FALSE
    )
    .validate_stage_lock_object(candidate_lock)
    .validate_manifest_structure(candidate_manifest, path)
    .validate_lock_manifest_alignment(candidate_lock, candidate_manifest, candidate_manifest_path)
    if (!identical(file_sha256(candidate_lock_path), lock$source_candidate_lock_sha256)) {
      stop("Preserved candidate lock SHA256 mismatch", call. = FALSE)
    }
    decision <- .validate_decision_for_promotion(
      decision_path, lock$stage, lock$approved_candidate_lock_sha256
    )
    if (!identical(file_sha256(decision_path), lock$approval_decision_sha256) ||
        !identical(decision$approved_by, lock$approved_by) ||
        !identical(decision$approved_at, lock$approved_at) ||
        !identical(decision$review_notes, lock$review_notes)) {
      stop("Approval decision provenance mismatch", call. = FALSE)
    }
  }
  invisible(TRUE)
}

read_stage_lock <- function(path) {
  validate_bundle_complete(path)
  # 加载 JSON 包并读取已完成 bundle 的阶段锁。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  jsonlite::read_json(file.path(path, "stage_lock.json"), simplifyVector = TRUE)
}

read_bundle_file <- function(path, file_name) {
  validate_bundle_complete(path)
  manifest <- utils::read.csv(
    file.path(path, "bundle_manifest.csv"),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  if (!file_name %in% manifest$file_name) stop("Bundle file is not registered: ", file_name, call. = FALSE)
  relative_path <- manifest$relative_path[match(file_name, manifest$file_name)]
  if (length(relative_path) != 1L || !identical(relative_path, basename(relative_path))) {
    stop("Registered bundle file path is unsafe", call. = FALSE)
  }
  file.path(path, relative_path)
}
