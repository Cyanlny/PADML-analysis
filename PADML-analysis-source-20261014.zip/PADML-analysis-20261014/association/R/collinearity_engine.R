# VIF/GVIF 与设计矩阵诊断引擎：设计诊断和拟合后诊断使用独立缓存身份。

collinearity_numeric_contract <- function() {
  list(
    exact_alias_qr_tolerance = 1e-12,
    relative_invertibility_tolerance = 1e-10,
    ill_conditioned_warning_threshold = 1e8,
    persistent_fraction = 0.50,
    archive_threshold_mb = 100,
    numeric_implementation_version = "VIF_GVIF_FM_SOLVER_V1"
  )
}

# 加载摘要包并生成稳定对象哈希；正式导出只保留哈希，不保留患者级矩阵。
collinearity_sha256 <- function(object) {
  if (!requireNamespace("digest", quietly = TRUE)) stop("digest is required", call. = FALSE)
  digest::digest(object, algo = "sha256", serialize = TRUE)
}

symmetrize_matrix <- function(matrix_value) {
  (matrix_value + t(matrix_value)) / 2
}

matrix_asymmetry <- function(matrix_value) {
  if (!is.matrix(matrix_value) || nrow(matrix_value) != ncol(matrix_value) || !length(matrix_value)) return(Inf)
  max(abs(matrix_value - t(matrix_value)), na.rm = TRUE)
}

stable_eigen_contract <- function(matrix_value, tolerance = 1e-10) {
  if (!is.matrix(matrix_value) || nrow(matrix_value) != ncol(matrix_value) || !length(matrix_value)) {
    return(list(status = "NOT_ESTIMABLE", reason = "matrix_not_square", values = numeric(), minimum = NA_real_, maximum = NA_real_, condition = Inf, relative_minimum = NA_real_))
  }
  if (any(!is.finite(matrix_value))) {
    return(list(status = "NOT_ESTIMABLE", reason = "matrix_nonfinite", values = numeric(), minimum = NA_real_, maximum = NA_real_, condition = Inf, relative_minimum = NA_real_))
  }
  values <- tryCatch(
    eigen(symmetrize_matrix(matrix_value), symmetric = TRUE, only.values = TRUE)$values,
    error = function(e) numeric()
  )
  if (!length(values) || any(!is.finite(values))) {
    return(list(status = "NOT_ESTIMABLE", reason = "eigen_failure", values = values, minimum = NA_real_, maximum = NA_real_, condition = Inf, relative_minimum = NA_real_))
  }
  maximum <- max(values)
  minimum <- min(values)
  relative <- if (maximum > 0) minimum / maximum else -Inf
  status <- if (minimum <= 0 || relative <= tolerance) "NUMERIC_RANK_DEFICIENCY" else "PASS"
  list(
    status = status,
    reason = if (status == "PASS") "" else "minimum_eigenvalue_below_invertibility_threshold",
    values = values,
    minimum = minimum,
    maximum = maximum,
    condition = if (minimum > 0) maximum / minimum else Inf,
    relative_minimum = relative
  )
}

# 逐列求解 R x=e_j，仅提取逆矩阵对角元，不显式构造 inverse(R)。
solve_inverse_diagonal_stable <- function(correlation_matrix, tolerance = 1e-10) {
  original_asymmetry <- matrix_asymmetry(correlation_matrix)
  if (!is.finite(original_asymmetry) || original_asymmetry > tolerance) {
    return(list(
      status = "NOT_ESTIMABLE", reason = "correlation_matrix_asymmetry", diagonal = numeric(),
      solver_path = "none", cholesky_status = "NOT_RUN", eigen_fallback_used = FALSE,
      minimum = NA_real_, maximum = NA_real_, condition = Inf
    ))
  }
  correlation_matrix <- symmetrize_matrix(correlation_matrix)
  contract <- stable_eigen_contract(correlation_matrix, tolerance)
  if (contract$status != "PASS") {
    return(c(contract, list(diagonal = numeric(), solver_path = "none", cholesky_status = "NOT_RUN", eigen_fallback_used = FALSE)))
  }
  dimension_n <- nrow(correlation_matrix)
  chol_factor <- tryCatch(chol(correlation_matrix), error = function(e) NULL)
  if (!is.null(chol_factor)) {
    diagonal <- vapply(seq_len(dimension_n), function(index) {
      unit <- rep(0, dimension_n)
      unit[[index]] <- 1
      solution <- backsolve(chol_factor, forwardsolve(t(chol_factor), unit))
      solution[[index]]
    }, numeric(1))
    return(c(contract, list(
      diagonal = diagonal, solver_path = "cholesky_linear_solve",
      cholesky_status = "PASS", eigen_fallback_used = FALSE
    )))
  }
  decomposition <- eigen(correlation_matrix, symmetric = TRUE)
  diagonal <- vapply(seq_len(dimension_n), function(index) {
    unit <- rep(0, dimension_n)
    unit[[index]] <- 1
    projected <- crossprod(decomposition$vectors, unit)
    solution <- decomposition$vectors %*% (projected / decomposition$values)
    solution[[index]]
  }, numeric(1))
  c(contract, list(
    diagonal = diagonal, solver_path = "symmetric_eigen_linear_solve",
    cholesky_status = "FAILED_ROUNDING", eigen_fallback_used = TRUE
  ))
}

# 使用正定矩阵的 log-determinant，避免普通 determinant 的上溢和下溢。
stable_logdet_spd <- function(matrix_value, tolerance = 1e-10) {
  if (!length(matrix_value)) return(list(status = "PASS", logdet = 0, solver_path = "empty_block"))
  asymmetry <- matrix_asymmetry(matrix_value)
  if (!is.finite(asymmetry) || asymmetry > tolerance) {
    return(list(status = "NOT_ESTIMABLE", logdet = NA_real_, solver_path = "asymmetry"))
  }
  matrix_value <- symmetrize_matrix(matrix_value)
  contract <- stable_eigen_contract(matrix_value, tolerance)
  if (contract$status != "PASS") {
    return(list(status = "NOT_ESTIMABLE", logdet = NA_real_, solver_path = contract$status))
  }
  chol_factor <- tryCatch(chol(matrix_value), error = function(e) NULL)
  if (!is.null(chol_factor)) {
    return(list(status = "PASS", logdet = 2 * sum(log(diag(chol_factor))), solver_path = "cholesky_logdet"))
  }
  list(status = "PASS", logdet = sum(log(contract$values)), solver_path = "eigen_logdet")
}

term_classification <- function(parent_term, expected_df) {
  if (parent_term %in% c("log2_AST_ALT", "AST_ALT_Tertile", "Rutherford_cat")) return("PROTECTED_CORE")
  if (grepl(":", parent_term, fixed = TRUE)) return("INTERACTION_TERM")
  if (grepl("rcs|spline|ns\\(", parent_term, ignore.case = TRUE)) return("SPLINE_PARENT")
  if (expected_df > 1L) "MULTIDF_PARENT" else "MAIN_EFFECT_PARENT"
}

protected_parent <- function(parent_term) {
  parent_term %in% c("log2_AST_ALT", "AST_ALT_Tertile", "Rutherford_cat")
}

fit_parent_map <- function(fit) {
  mapping <- coefficient_parent_map(fit)
  mapping <- mapping[!is.na(mapping$coefficient) & nzchar(mapping$coefficient), , drop = FALSE]
  mapping$column_index <- match(mapping$coefficient, colnames(fit$x))
  mapping
}

factor_parent_status <- function(fit, parent_term) {
  model_data <- fit$model
  if (is.null(model_data) || !parent_term %in% names(model_data) || !is.factor(model_data[[parent_term]])) {
    return(list(is_factor = FALSE, expected_levels = character(), observed_levels = character()))
  }
  value <- model_data[[parent_term]]
  list(
    is_factor = TRUE,
    expected_levels = levels(value),
    observed_levels = unique(as.character(value[!is.na(value)]))
  )
}

build_design_request_from_fit <- function(fit, context_row, formula_text) {
  contract <- collinearity_numeric_contract()
  x <- fit$x
  mapping <- fit_parent_map(fit)
  parent_terms <- unique(mapping$parent_term)
  parent_rows <- lapply(parent_terms, function(parent) {
    coefficients <- mapping$coefficient[mapping$parent_term == parent]
    indices <- match(coefficients, colnames(x))
    variance <- vapply(indices, function(index) if (is.na(index)) NA_real_ else stats::var(x[, index]), numeric(1))
    factor_status <- factor_parent_status(fit, parent)
    zero <- !is.finite(variance) | variance == 0
    structural_zero <- zero & factor_status$is_factor
    data.frame(
      parent_term = parent,
      expected_parent_df = length(coefficients),
      realized_parent_df = sum(!zero),
      absent_training_level_count = if (factor_status$is_factor) max(0L, length(factor_status$expected_levels) - length(factor_status$observed_levels)) else 0L,
      structural_zero_column_count = sum(structural_zero),
      nonstructural_zero_column_count = sum(zero & !structural_zero),
      level_absence_reason = if (any(structural_zero)) "legal_factor_level_absent_in_current_imputation" else "",
      protected = protected_parent(parent),
      term_class = term_classification(parent, length(coefficients)),
      stringsAsFactors = FALSE
    )
  })
  parent_df <- if (length(parent_rows)) do.call(rbind, parent_rows) else data.frame()
  design_matrix_semantic_hash <- collinearity_sha256(list(values = unclass(x), dimensions = dim(x), columns = colnames(x)))
  realized_column_order_hash <- collinearity_sha256(colnames(x))
  parent_term_map_hash <- collinearity_sha256(mapping[c("coefficient", "parent_term", "column_index")])
  diagnostic_contract_hash <- collinearity_sha256(contract)
  implementation_hash <- collinearity_sha256(contract$numeric_implementation_version)
  diagnostic_object_id <- collinearity_sha256(c(
    design_matrix_semantic_hash, realized_column_order_hash, parent_term_map_hash,
    diagnostic_contract_hash, implementation_hash
  ))
  list(
    diagnostic_object_id = diagnostic_object_id,
    cache_key = diagnostic_object_id,
    context = context_row,
    formula_text = formula_text,
    x = x,
    mapping = mapping,
    parent_df = parent_df,
    design_matrix_semantic_hash = design_matrix_semantic_hash,
    realized_column_order_hash = realized_column_order_hash,
    parent_term_map_hash = parent_term_map_hash,
    diagnostic_contract_hash = diagnostic_contract_hash,
    implementation_hash = implementation_hash
  )
}

scale_design_for_svd <- function(x) {
  output <- x
  for (index in seq_len(ncol(output))) {
    values <- output[, index]
    if (length(unique(values)) > 2L) output[, index] <- as.numeric(scale(values))
  }
  output
}

diagnose_design_request <- function(request) {
  contract <- collinearity_numeric_contract()
  x <- request$x
  variance <- apply(x, 2, stats::var)
  zero_columns <- names(variance)[!is.finite(variance) | variance == 0]
  structural_parents <- if (nrow(request$parent_df)) {
    request$parent_df$parent_term[request$parent_df$structural_zero_column_count > 0L]
  } else character()
  structural_columns <- request$mapping$coefficient[
    request$mapping$parent_term %in% structural_parents & request$mapping$coefficient %in% zero_columns
  ]
  nonstructural_zero <- setdiff(zero_columns, structural_columns)
  estimable_columns <- setdiff(colnames(x), zero_columns)
  estimable <- x[, estimable_columns, drop = FALSE]
  rank_value <- 0L
  alias_columns <- character()
  singular_values <- numeric()
  condition <- Inf
  smallest <- 0
  if (!ncol(estimable)) {
    design_status <- "NUMERIC_RANK_DEFICIENCY"
  } else {
    scaled <- scale_design_for_svd(estimable)
    qr_result <- qr(scaled, tol = contract$exact_alias_qr_tolerance)
    rank_value <- qr_result$rank
    if (rank_value < ncol(scaled)) {
      alias_columns <- colnames(scaled)[qr_result$pivot[seq.int(rank_value + 1L, ncol(scaled))]]
    }
    nonaliased <- setdiff(colnames(scaled), alias_columns)
    svd_matrix <- scaled[, nonaliased, drop = FALSE]
    singular_values <- if (ncol(svd_matrix)) svd(svd_matrix, nu = 0, nv = 0)$d else numeric()
    condition <- if (length(singular_values) && min(singular_values) > 0) max(singular_values) / min(singular_values) else Inf
    smallest <- if (length(singular_values)) min(singular_values) else 0
    relative <- if (length(singular_values) && max(singular_values) > 0) min(singular_values) / max(singular_values) else 0
    design_status <- if (length(alias_columns)) {
      "EXACT_ALIAS"
    } else if (relative <= contract$relative_invertibility_tolerance) {
      "NUMERIC_RANK_DEFICIENCY"
    } else if (condition > contract$ill_conditioned_warning_threshold) {
      "ILL_CONDITIONED_FULL_RANK"
    } else {
      "STABLE_FULL_RANK"
    }
  }
  design_summary <- data.frame(
    diagnostic_object_id = request$diagnostic_object_id,
    design_matrix_semantic_hash = request$design_matrix_semantic_hash,
    realized_column_order_hash = request$realized_column_order_hash,
    parent_term_map_hash = request$parent_term_map_hash,
    full_matrix_column_n = ncol(x),
    full_matrix_rank = rank_value,
    structural_zero_column_count = length(structural_columns),
    nonstructural_zero_column_count = length(nonstructural_zero),
    exact_alias_column_count = length(alias_columns),
    exact_alias_columns = paste(alias_columns, collapse = "|"),
    design_condition_number_2 = condition,
    smallest_scaled_singular_value = smallest,
    design_status = design_status,
    diagnostic_estimate_status = if (design_status %in% c("EXACT_ALIAS", "NUMERIC_RANK_DEFICIENCY")) "DESIGN_NOT_ESTIMABLE" else "ESTIMABLE",
    status_scope = "DESIGN",
    dependency_role = "DESIGN_DIAGNOSTIC",
    stringsAsFactors = FALSE
  )
  parent <- request$parent_df
  if (nrow(parent)) {
    parent$diagnostic_object_id <- request$diagnostic_object_id
    parent$parent_estimability_status <- ifelse(
      parent$realized_parent_df == 0L, "PARENT_NOT_ESTIMABLE",
      ifelse(parent$realized_parent_df < parent$expected_parent_df, "PARENT_PARTIALLY_NONESTIMABLE", "PARENT_ESTIMABLE")
    )
    parent$status_scope <- "FOLD_IMPUTATION_TERM"
    parent$dependency_role <- "PARENT_TERM_DIAGNOSTIC"
  }
  list(design_summary = design_summary, parent_summary = parent)
}

normalized_fit_identity <- function(fit, formula_text) {
  coefficients <- stats::coef(fit)
  covariance <- stats::vcov(fit)
  list(
    fit_object_hash = collinearity_sha256(list(
      formula_text = formula_text, coefficients = coefficients, covariance = covariance,
      n = fit$n, nevent = fit$nevent, loglik = fit$loglik
    )),
    covariance_hash = collinearity_sha256(covariance),
    event_time_identity_hash = collinearity_sha256(unclass(fit$y))
  )
}

build_fit_diagnostic_request_from_fit <- function(fit, context_row, formula_text) {
  contract <- collinearity_numeric_contract()
  identity <- normalized_fit_identity(fit, formula_text)
  mapping <- fit_parent_map(fit)
  parent_term_map_hash <- collinearity_sha256(mapping[c("coefficient", "parent_term", "column_index")])
  diagnostic_contract_hash <- collinearity_sha256(contract)
  key <- collinearity_sha256(c(
    identity$fit_object_hash, identity$covariance_hash, context_row$endpoint,
    identity$event_time_identity_hash, parent_term_map_hash,
    diagnostic_contract_hash, contract$numeric_implementation_version
  ))
  list(
    diagnostic_object_id = key,
    cache_key = key,
    context = context_row,
    formula_text = formula_text,
    fit = fit,
    mapping = mapping,
    fit_object_hash = identity$fit_object_hash,
    covariance_hash = identity$covariance_hash,
    event_time_identity_hash = identity$event_time_identity_hash,
    parent_term_map_hash = parent_term_map_hash,
    diagnostic_contract_hash = diagnostic_contract_hash,
    numeric_implementation_version = contract$numeric_implementation_version
  )
}

required_exposure_coefficients <- function(exposure_form) {
  if (exposure_form == "log2_AST_ALT") "log2_AST_ALT" else c("AST_ALT_TertileT2", "AST_ALT_TertileT3")
}

covariance_contract <- function(covariance, tolerance = 1e-10) {
  if (!is.matrix(covariance) || nrow(covariance) != ncol(covariance) || !nrow(covariance) || any(!is.finite(covariance))) {
    return(list(status = "INVALID", condition = Inf, minimum = NA_real_, maximum = NA_real_))
  }
  contract <- stable_eigen_contract(covariance, tolerance)
  list(
    status = if (contract$status == "PASS") "VALID" else contract$status,
    condition = contract$condition,
    minimum = contract$minimum,
    maximum = contract$maximum
  )
}

empty_fit_term_result <- function(parents, request, reason_code, model_status, covariance_status) {
  expected_df <- vapply(parents, function(parent) sum(request$mapping$parent_term == parent), integer(1))
  data.frame(
    diagnostic_object_id = request$diagnostic_object_id,
    parent_term = parents,
    df = expected_df,
    fit_realized_parent_df = 0L,
    vif = NA_real_, gvif = NA_real_, gvif_adjusted = NA_real_, comparison_value = NA_real_,
    diagnostic_estimate_status = if (model_status == "MODEL_ESTIMABLE") "MODEL_ESTIMABLE_DIAGNOSTIC_NOT_ESTIMABLE" else "MODEL_NOT_ESTIMABLE",
    parent_estimability_status_fit = "PARENT_ESTIMABILITY_UNKNOWN",
    not_estimable_reason_code = reason_code,
    status_scope = "FOLD_IMPUTATION_TERM",
    dependency_role = "FIT_DEPENDENT_DIAGNOSTIC",
    solver_path = "none", cholesky_status = "NOT_RUN", eigen_fallback_used = FALSE,
    minimum_eigenvalue = covariance_status$minimum,
    maximum_eigenvalue = covariance_status$maximum,
    coefficient_correlation_condition_number_2 = NA_real_,
    stringsAsFactors = FALSE
  )
}

diagnose_fit_request <- function(request) {
  contract <- collinearity_numeric_contract()
  fit <- request$fit
  context <- request$context
  coefficients <- stats::coef(fit)
  covariance <- stats::vcov(fit)
  required <- required_exposure_coefficients(context$exposure_form)
  required_available <- all(required %in% names(coefficients)) && all(is.finite(coefficients[required]))
  required_covariance <- if (required_available) covariance[required, required, drop = FALSE] else matrix(NA_real_, 0, 0)
  required_covariance_status <- covariance_contract(required_covariance, contract$relative_invertibility_tolerance)
  full_covariance_status <- covariance_contract(covariance, contract$relative_invertibility_tolerance)
  model_status <- if (required_available && required_covariance_status$status == "VALID") "MODEL_ESTIMABLE" else "MODEL_NOT_ESTIMABLE"
  finite_diagonal <- if (is.matrix(covariance) && nrow(covariance)) is.finite(diag(covariance)) & diag(covariance) > 0 else logical()
  valid_coefficients <- intersect(names(coefficients)[is.finite(coefficients)], rownames(covariance)[finite_diagonal])
  valid_covariance <- covariance[valid_coefficients, valid_coefficients, drop = FALSE]
  available_signature <- paste(valid_coefficients, collapse = "|")
  required_signature <- paste(required, collapse = "|")
  fit_summary <- data.frame(
    diagnostic_object_id = request$diagnostic_object_id,
    fit_object_hash = request$fit_object_hash,
    covariance_hash = request$covariance_hash,
    event_time_identity_hash = request$event_time_identity_hash,
    required_parameter_names = required_signature,
    available_parameter_names = available_signature,
    coefficient_name_signature = collinearity_sha256(names(coefficients)),
    required_parameter_availability = required_available,
    required_covariance_status = required_covariance_status$status,
    full_covariance_status = full_covariance_status$status,
    covariance_condition_number_2 = full_covariance_status$condition,
    model_estimate_status = model_status,
    stringsAsFactors = FALSE
  )
  parents <- unique(request$mapping$parent_term)
  if (length(parents) < 2L) {
    return(list(
      fit_summary = fit_summary,
      term_results = empty_fit_term_result(parents, request, "NE_SINGLE_PREDICTOR_VIF_NOT_DEFINED", model_status, full_covariance_status)
    ))
  }
  valid_covariance_status <- covariance_contract(valid_covariance, contract$relative_invertibility_tolerance)
  if (length(valid_coefficients) < 2L || valid_covariance_status$status != "VALID") {
    return(list(
      fit_summary = fit_summary,
      term_results = empty_fit_term_result(parents, request, "NE_VIF_MODEL_MATRIX_INVALID", model_status, valid_covariance_status)
    ))
  }
  standard_deviation <- sqrt(diag(valid_covariance))
  correlation <- symmetrize_matrix(valid_covariance / outer(standard_deviation, standard_deviation))
  solver <- solve_inverse_diagonal_stable(correlation, contract$relative_invertibility_tolerance)
  if (!identical(solver$status, "PASS")) {
    result <- empty_fit_term_result(parents, request, "NE_VIF_MODEL_MATRIX_INVALID", model_status, solver)
    result$solver_path <- solver$solver_path
    result$cholesky_status <- solver$cholesky_status
    result$eigen_fallback_used <- solver$eigen_fallback_used
    result$minimum_eigenvalue <- solver$minimum
    result$maximum_eigenvalue <- solver$maximum
    result$coefficient_correlation_condition_number_2 <- solver$condition
    return(list(fit_summary = fit_summary, term_results = result))
  }
  valid_mapping <- request$mapping[request$mapping$coefficient %in% valid_coefficients, , drop = FALSE]
  full_logdet <- stable_logdet_spd(correlation, contract$relative_invertibility_tolerance)
  term_rows <- lapply(parents, function(parent) {
    term_coefficients <- valid_mapping$coefficient[valid_mapping$parent_term == parent]
    expected_df <- sum(request$mapping$parent_term == parent)
    realized_df <- length(term_coefficients)
    parent_status <- if (realized_df == 0L) {
      "PARENT_NOT_ESTIMABLE"
    } else if (realized_df < expected_df) {
      "PARENT_PARTIALLY_NONESTIMABLE"
    } else {
      "PARENT_ESTIMABLE"
    }
    if (!realized_df) {
      return(data.frame(
        parent_term = parent, df = expected_df, fit_realized_parent_df = realized_df,
        vif = NA_real_, gvif = NA_real_, gvif_adjusted = NA_real_, comparison_value = NA_real_,
        diagnostic_estimate_status = "MODEL_ESTIMABLE_DIAGNOSTIC_NOT_ESTIMABLE",
        parent_estimability_status_fit = parent_status,
        not_estimable_reason_code = "NE_ZERO_VARIANCE_TERM", stringsAsFactors = FALSE
      ))
    }
    index <- match(term_coefficients, valid_coefficients)
    complement <- setdiff(seq_along(valid_coefficients), index)
    if (!length(complement)) {
      return(data.frame(
        parent_term = parent, df = expected_df, fit_realized_parent_df = realized_df,
        vif = NA_real_, gvif = NA_real_, gvif_adjusted = NA_real_, comparison_value = NA_real_,
        diagnostic_estimate_status = "MODEL_ESTIMABLE_DIAGNOSTIC_NOT_ESTIMABLE",
        parent_estimability_status_fit = parent_status,
        not_estimable_reason_code = "NE_SINGLE_PREDICTOR_VIF_NOT_DEFINED", stringsAsFactors = FALSE
      ))
    }
    block_logdet <- stable_logdet_spd(correlation[index, index, drop = FALSE], contract$relative_invertibility_tolerance)
    complement_logdet <- stable_logdet_spd(correlation[complement, complement, drop = FALSE], contract$relative_invertibility_tolerance)
    if (any(c(full_logdet$status, block_logdet$status, complement_logdet$status) != "PASS")) {
      return(data.frame(
        parent_term = parent, df = expected_df, fit_realized_parent_df = realized_df,
        vif = NA_real_, gvif = NA_real_, gvif_adjusted = NA_real_, comparison_value = NA_real_,
        diagnostic_estimate_status = "MODEL_ESTIMABLE_DIAGNOSTIC_NOT_ESTIMABLE",
        parent_estimability_status_fit = parent_status,
        not_estimable_reason_code = "NE_GVIF_TERM_MAPPING_FAILED", stringsAsFactors = FALSE
      ))
    }
    log_gvif <- block_logdet$logdet + complement_logdet$logdet - full_logdet$logdet
    gvif <- exp(log_gvif)
    adjusted <- exp(log_gvif / (2 * realized_df))
    vif <- if (realized_df == 1L) solver$diagonal[index] else NA_real_
    data.frame(
      parent_term = parent, df = expected_df, fit_realized_parent_df = realized_df,
      vif = vif, gvif = gvif,
      gvif_adjusted = if (realized_df > 1L) adjusted else NA_real_,
      comparison_value = if (realized_df == 1L) vif else adjusted,
      diagnostic_estimate_status = "ESTIMABLE",
      parent_estimability_status_fit = parent_status,
      not_estimable_reason_code = "", stringsAsFactors = FALSE
    )
  })
  term_results <- do.call(rbind, term_rows)
  term_results$diagnostic_object_id <- request$diagnostic_object_id
  term_results$status_scope <- "FOLD_IMPUTATION_TERM"
  term_results$dependency_role <- "FIT_DEPENDENT_DIAGNOSTIC"
  term_results$solver_path <- solver$solver_path
  term_results$cholesky_status <- solver$cholesky_status
  term_results$eigen_fallback_used <- solver$eigen_fallback_used
  term_results$minimum_eigenvalue <- solver$minimum
  term_results$maximum_eigenvalue <- solver$maximum
  term_results$coefficient_correlation_condition_number_2 <- solver$condition
  list(fit_summary = fit_summary, term_results = term_results)
}

build_unique_request_registry <- function(requests, request_type) {
  if (!length(requests)) return(list(map = data.frame(), unique_requests = list()))
  keys <- vapply(requests, function(request) request$cache_key, character(1))
  unique_keys <- unique(keys)
  unique_requests <- lapply(unique_keys, function(key) requests[[match(key, keys)]])
  names(unique_requests) <- unique_keys
  map <- do.call(rbind, lapply(seq_along(requests), function(index) {
    context <- requests[[index]]$context
    data.frame(
      request_type = request_type,
      fit_id = context$fit_id,
      endpoint = context$endpoint,
      imputation = context$imputation,
      model_id = context$model_id,
      exposure_form = context$exposure_form,
      model_signature_sha256 = context$model_signature_sha256,
      diagnostic_object_id = keys[[index]],
      computed_once = !duplicated(keys)[[index]],
      reference_count = sum(keys == keys[[index]]),
      reused_across_context = sum(keys == keys[[index]]) > 1L,
      stringsAsFactors = FALSE
    )
  }))
  list(map = map, unique_requests = unique_requests)
}

fit_bundles_to_requests <- function(fit_bundles) {
  design_requests <- list()
  fit_requests <- list()
  index <- 1L
  for (bundle in fit_bundles) {
    for (model_id in names(bundle$fits)) {
      fit <- bundle$fits[[model_id]]
      if (is.null(fit)) next
      fit_id <- paste(bundle$endpoint, bundle$imputation, bundle$exposure_form, model_id, sep = "__")
      formula_text <- bundle$formula_texts[[model_id]]
      context <- data.frame(
        fit_id = fit_id, endpoint = bundle$endpoint, imputation = bundle$imputation,
        model_id = model_id, exposure_form = bundle$exposure_form,
        model_signature_sha256 = fixed_collection_model_signature(
          list(endpoint_row = bundle$endpoint_row, exposure_form = bundle$exposure_form, formula_text = formula_text),
          bundle$project_root
        ),
        stringsAsFactors = FALSE
      )
      design_requests[[index]] <- build_design_request_from_fit(fit, context, formula_text)
      fit_requests[[index]] <- build_fit_diagnostic_request_from_fit(fit, context, formula_text)
      index <- index + 1L
    }
  }
  list(
    design = build_unique_request_registry(design_requests, "DESIGN_ONLY"),
    fit = build_unique_request_registry(fit_requests, "FIT_DEPENDENT")
  )
}

bind_diagnostic_results <- function(results, element) {
  frames <- lapply(results, function(result) result[[element]])
  frames <- Filter(function(frame) !is.null(frame) && nrow(frame), frames)
  if (!length(frames)) data.frame() else do.call(rbind, frames)
}

# 将唯一对象诊断结果展开回完整模型上下文，防止缓存命中造成结果漏行。
expand_diagnostic_results <- function(results, registry_map, element) {
  object_rows <- bind_diagnostic_results(results, element)
  if (!nrow(object_rows) || !nrow(registry_map)) return(data.frame())
  merge(registry_map, object_rows, by = "diagnostic_object_id", all.x = TRUE, sort = FALSE)
}

merge_collinearity_results <- function(design_results, fit_results, design_map, fit_map) {
  design_summary <- expand_diagnostic_results(design_results, design_map, "design_summary")
  parent_summary <- expand_diagnostic_results(design_results, design_map, "parent_summary")
  fit_summary <- expand_diagnostic_results(fit_results, fit_map, "fit_summary")
  term_results <- expand_diagnostic_results(fit_results, fit_map, "term_results")
  context_key <- c("fit_id", "endpoint", "imputation", "model_id", "exposure_form", "model_signature_sha256")
  term_key <- c(context_key, "parent_term")
  long <- merge(
    term_results, parent_summary,
    by = term_key, all = TRUE, sort = FALSE,
    suffixes = c("_fit", "_design")
  )
  long <- merge(long, design_summary, by = context_key, all.x = TRUE, sort = FALSE, suffixes = c("", "_design"))
  long <- merge(long, fit_summary, by = context_key, all.x = TRUE, sort = FALSE, suffixes = c("", "_fit_summary"))
  if (nrow(long)) {
    if ("parent_estimability_status" %in% names(long)) {
      long$parent_estimability_status <- ifelse(
        is.na(long$parent_estimability_status), long$parent_estimability_status_fit,
        long$parent_estimability_status
      )
    } else {
      long$parent_estimability_status <- long$parent_estimability_status_fit
    }
    long$threshold_type <- "HEURISTIC_DIAGNOSTIC"
    long$selection_effect <- "NONE"
    long$protected <- ifelse(is.na(long$protected), protected_parent(long$parent_term), long$protected)
    long$term_class <- ifelse(is.na(long$term_class), mapply(term_classification, long$parent_term, long$df), long$term_class)
    long$scientific_result_status <- ifelse(
      long$model_estimate_status == "MODEL_ESTIMABLE",
      "SCIENTIFIC_RESULT_AVAILABLE", "SCIENTIFIC_RESULT_NOT_ESTIMABLE"
    )
    term_diagnostic_column <- if ("diagnostic_estimate_status_fit" %in% names(long)) {
      "diagnostic_estimate_status_fit"
    } else {
      "diagnostic_estimate_status"
    }
    long$diagnostic_result_status <- long[[term_diagnostic_column]]
  }
  list(long = long, design_summary = design_summary, fit_summary = fit_summary)
}

add_parameter_consistency <- function(merged) {
  long <- merged$long
  fit_summary <- merged$fit_summary
  if (!nrow(fit_summary)) {
    merged$parameter_consistency <- data.frame()
    return(merged)
  }
  groups <- split(fit_summary, interaction(fit_summary$endpoint, fit_summary$model_id, fit_summary$exposure_form, drop = TRUE, lex.order = TRUE))
  rows <- lapply(groups, function(data) {
    full_consistency <- length(unique(data$coefficient_name_signature)) == 1L
    required_consistency <- all(data$required_parameter_availability) &&
      length(unique(data$required_parameter_names)) == 1L &&
      all(data$required_covariance_status == "VALID")
    data.frame(
      endpoint = data$endpoint[[1L]], model_id = data$model_id[[1L]], exposure_form = data$exposure_form[[1L]],
      valid_imputation_n = sum(data$model_estimate_status == "MODEL_ESTIMABLE"),
      coefficient_dimension_consistency = full_consistency,
      required_parameter_availability = all(data$required_parameter_availability),
      d1_parameter_set_consistency = required_consistency,
      stage_gate_status = if (required_consistency) "PASS" else "BLOCKING_WARNING",
      stringsAsFactors = FALSE
    )
  })
  consistency <- do.call(rbind, rows)
  if (nrow(long)) {
    long <- merge(
      long,
      consistency[c("endpoint", "model_id", "exposure_form", "coefficient_dimension_consistency", "required_parameter_availability", "d1_parameter_set_consistency", "stage_gate_status")],
      by = c("endpoint", "model_id", "exposure_form"), all.x = TRUE, sort = FALSE
    )
  }
  merged$long <- long
  merged$parameter_consistency <- consistency
  merged
}

safe_quantile <- function(value, probability) {
  value <- value[is.finite(value)]
  if (!length(value)) NA_real_ else as.numeric(stats::quantile(value, probability, names = FALSE, type = 7))
}

summarize_multicollinearity <- function(long) {
  if (!nrow(long)) return(data.frame())
  groups <- split(long, interaction(long$endpoint, long$model_id, long$exposure_form, long$parent_term, drop = TRUE, lex.order = TRUE))
  rows <- lapply(groups, function(data) {
    value <- data$comparison_value[is.finite(data$comparison_value)]
    comparison_metric <- if (any(data$df > 1L, na.rm = TRUE)) "Adjusted GVIF = GVIF^(1/(2×Df))" else "VIF"
    finite_index <- which(is.finite(data$comparison_value))
    worst_index <- if (length(finite_index)) finite_index[[which.max(data$comparison_value[finite_index])]] else NA_integer_
    data.frame(
      endpoint = data$endpoint[[1L]], model_id = data$model_id[[1L]], exposure_form = data$exposure_form[[1L]],
      parent_term = data$parent_term[[1L]], term_class = data$term_class[[1L]], comparison_metric = comparison_metric,
      valid_imputation_n = length(value),
      median_comparison_value = if (length(value)) stats::median(value) else NA_real_,
      p90_comparison_value = safe_quantile(value, 0.90),
      maximum_comparison_value = if (length(value)) max(value) else NA_real_,
      proportion_ge_2_5 = if (length(value)) mean(value >= 2.5) else NA_real_,
      proportion_ge_5 = if (length(value)) mean(value >= 5) else NA_real_,
      proportion_ge_10 = if (length(value)) mean(value >= 10) else NA_real_,
      persistent_collinearity = if (length(value)) mean(value >= 5) >= collinearity_numeric_contract()$persistent_fraction else FALSE,
      worst_imputation = if (!is.na(worst_index)) data$imputation[[worst_index]] else NA_integer_,
      protected = any(data$protected, na.rm = TRUE),
      threshold_type = "HEURISTIC_DIAGNOSTIC",
      selection_effect = "NONE",
      action = "DIAGNOSTIC_ONLY_NO_SELECTION",
      diagnostic_result_status = if (length(value)) "ESTIMABLE" else "NOT_ESTIMABLE",
      human_review_required = any(data$design_status %in% c("EXACT_ALIAS", "NUMERIC_RANK_DEFICIENCY", "ILL_CONDITIONED_FULL_RANK"), na.rm = TRUE),
      stringsAsFactors = FALSE
    )
  })
  output <- do.call(rbind, rows)
  rownames(output) <- NULL
  output
}

build_collinearity_exception_publication <- function(long) {
  if (!nrow(long)) return(long)
  keep <- (!is.na(long$comparison_value) & long$comparison_value >= 2.5) |
    long$diagnostic_result_status != "ESTIMABLE" |
    long$design_status %in% c("EXACT_ALIAS", "NUMERIC_RANK_DEFICIENCY", "ILL_CONDITIONED_FULL_RANK")
  long[keep, , drop = FALSE]
}

build_vif_failure_summary <- function(long) {
  if (!nrow(long)) return(data.frame())
  failed <- long[long$diagnostic_result_status != "ESTIMABLE" | long$stage_gate_status == "BLOCKING_WARNING", , drop = FALSE]
  if (!nrow(failed)) return(data.frame(
    reason_code = character(), representative_model = character(), representative_imputation = integer(),
    representative_term = character(), singular_value_summary = character(), evidence_path = character(), log_tail = character()
  ))
  groups <- split(failed, ifelse(nzchar(failed$not_estimable_reason_code), failed$not_estimable_reason_code, failed$design_status))
  do.call(rbind, lapply(groups, function(data) data.frame(
    reason_code = if (nzchar(data$not_estimable_reason_code[[1L]])) data$not_estimable_reason_code[[1L]] else data$design_status[[1L]],
    representative_model = data$model_id[[1L]], representative_imputation = data$imputation[[1L]],
    representative_term = data$parent_term[[1L]],
    singular_value_summary = paste0("smallest=", signif(data$smallest_scaled_singular_value[[1L]], 6)),
    evidence_path = "collinearity_per_imputation.csv.gz", log_tail = "",
    stringsAsFactors = FALSE
  )))
}

safe_maximum <- function(value) {
  value <- value[is.finite(value)]
  if (length(value)) max(value) else NA_real_
}

build_vif_summary_receipt <- function(summary, design_map, fit_map, long, fit_count) {
  expected <- 200L
  completed <- length(unique(long$fit_id))
  not_estimable_designs <- length(unique(long$fit_id[long$diagnostic_result_status != "ESTIMABLE"]))
  data.frame(
    expected_designs = expected,
    completed_designs = completed,
    vif_expected_design_count = expected,
    vif_completed_design_count = completed,
    vif_not_estimable_design_count = not_estimable_designs,
    vif_missing_design_count = expected - completed,
    unique_design_hashes = length(unique(design_map$diagnostic_object_id)),
    unique_fit_diagnostic_hashes = length(unique(fit_map$diagnostic_object_id)),
    design_cache_hits = sum(!design_map$computed_once),
    fit_cache_hits = sum(!fit_map$computed_once),
    not_estimable_count = sum(long$diagnostic_result_status != "ESTIMABLE", na.rm = TRUE),
    max_adjusted_vif = if (nrow(summary)) safe_maximum(summary$maximum_comparison_value) else NA_real_,
    n_gt5 = if (nrow(summary)) sum(summary$maximum_comparison_value >= 5, na.rm = TRUE) else 0L,
    n_gt10 = if (nrow(summary)) sum(summary$maximum_comparison_value >= 10, na.rm = TRUE) else 0L,
    rank_deficiency_count = sum(long$design_status %in% c("EXACT_ALIAS", "NUMERIC_RANK_DEFICIENCY"), na.rm = TRUE),
    observed_fixed_cox_fit_count = fit_count,
    expected_fixed_cox_fit_count = expected,
    ph_triggered_additional_fit_count = 0L,
    vif_triggered_additional_fit_count = 0L,
    design_diagnostic_triggered_fit_count = 0L,
    refit_count = max(0L, fit_count - expected),
    selection_effect = "NONE",
    predictor_deletion_count = 0L,
    predictor_recode_count = 0L,
    reference_level_change_count = 0L,
    formula_change_count = 0L,
    stringsAsFactors = FALSE
  )
}

diagnose_design_request_target <- function(request, profile = "production") {
  diagnose_design_request(request)
}

diagnose_fit_request_target <- function(request) {
  diagnose_fit_request(request)
}

# 合成恢复测试仅在诊断写出前注入失败，确保40个拟合分支及诊断缓存均可复用。
a03_diagnostic_write_guard <- function(collinearity, profile = "production") {
  inject <- identical(Sys.getenv("AST_ALT_INJECT_A03_DIAGNOSTIC_FAILURE", "0"), "1")
  selected_row_exists <- any(
    collinearity$long$imputation == 7L &
      collinearity$long$exposure_form == "AST_ALT_Tertile" &
      collinearity$long$model_id == "M4"
  )
  if (identical(profile, "build_validation") && inject && selected_row_exists) {
    stop("SYNTHETIC_RECOVERY_INJECTION_IMP07_TERTILE_M4_DIAGNOSTIC_WRITE", call. = FALSE)
  }
  TRUE
}

flatten_diagnostic_target_results <- function(value) {
  if (is.list(value) && any(c("design_summary", "fit_summary") %in% names(value))) return(list(value))
  if (!is.list(value)) return(list())
  unlist(lapply(value, flatten_diagnostic_target_results), recursive = FALSE)
}

# 集中生成A03共线性canonical层、状态表、缓存血缘和审核摘要。
assemble_a03_collinearity <- function(request_registry, design_results, fit_results, fixed_stage) {
  design_results <- flatten_diagnostic_target_results(design_results)
  fit_results <- flatten_diagnostic_target_results(fit_results)
  merged <- merge_collinearity_results(
    design_results, fit_results,
    request_registry$design$map, request_registry$fit$map
  )
  merged <- add_parameter_consistency(merged)
  long <- merged$long
  summary <- summarize_multicollinearity(long)
  exception <- build_collinearity_exception_publication(long)
  failure <- build_vif_failure_summary(long)
  receipt <- build_vif_summary_receipt(
    summary, request_registry$design$map, request_registry$fit$map,
    long, fixed_stage$observed_fixed_cox_fit_count
  )
  model_fit_status <- merge(
    fixed_stage$diagnostics,
    merged$parameter_consistency,
    by = c("endpoint", "model_id", "exposure_form"), all.x = TRUE, sort = FALSE
  )
  design_link <- request_registry$design$map[c("fit_id", "model_signature_sha256", "diagnostic_object_id")]
  names(design_link)[[3L]] <- "design_diagnostic_object_id"
  fit_link <- request_registry$fit$map[c("fit_id", "diagnostic_object_id")]
  names(fit_link)[[2L]] <- "fit_diagnostic_object_id"
  linkage <- merge(design_link, fit_link, by = "fit_id", all = TRUE, sort = FALSE)
  linkage$fixed_result_file <- "fixed_cox_results.csv"
  linkage$ph_result_file <- "ph_per_imputation_term_results.csv"
  linkage$collinearity_result_file <- "collinearity_per_imputation.csv.gz"
  linkage$design_matrix_qc_file <- "design_matrix_qc.csv"
  cache_audit <- rbind(
    transform(request_registry$design$map, cache_layer = "DESIGN_ONLY"),
    transform(request_registry$fit$map, cache_layer = "FIT_DEPENDENT")
  )
  list(
    long = long,
    summary = summary,
    s10 = summary,
    exception_publication = exception,
    failure_summary = failure,
    receipt = receipt,
    design_qc = merged$design_summary,
    parameter_consistency = merged$parameter_consistency,
    model_fit_status = model_fit_status,
    diagnostic_linkage = linkage,
    design_request_registry = request_registry$design$map,
    fit_request_registry = request_registry$fit$map,
    cache_audit = cache_audit
  )
}
