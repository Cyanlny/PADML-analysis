# 模型项映射：冻结公式项、系数顺序和父变量映射。

split_registry_terms <- function(text) {
  if (is.na(text) || !nzchar(text)) character() else strsplit(text, "|", fixed = TRUE)[[1L]]
}

read_model_spec <- function(model_id, root = ".") {
  registry <- utils::read.csv(file.path(root, "config", "model_registry.csv"), stringsAsFactors = FALSE, check.names = FALSE)
  row <- registry[registry$model_id == model_id, , drop = FALSE]
  if (nrow(row) != 1L) stop("Unknown model_id: ", model_id, call. = FALSE)
  row
}

build_cox_formula_text <- function(model_id, endpoint_row, exposure_form, root = ".", covariates_override = NULL) {
  model <- read_model_spec(model_id, root)
  covariates <- if (is.null(covariates_override)) split_registry_terms(model$covariates[[1L]]) else covariates_override
  exposure <- switch(
    exposure_form,
    log2_AST_ALT = "log2_AST_ALT",
    AST_ALT_Tertile = "AST_ALT_Tertile",
    stop("Unsupported exposure form: ", exposure_form, call. = FALSE)
  )
  rhs <- c(exposure, covariates)
  sprintf(
    "survival::Surv(%s, %s) ~ %s",
    endpoint_row$time_variable[[1L]], endpoint_row$event_variable[[1L]], paste(rhs, collapse = " + ")
  )
}

coefficient_parent_map <- function(fit) {
  if (is.null(fit$assign)) {
    return(data.frame(coefficient = names(stats::coef(fit)), parent_term = names(stats::coef(fit)), stringsAsFactors = FALSE))
  }
  rows <- lapply(names(fit$assign), function(term) {
    indices <- fit$assign[[term]]
    data.frame(coefficient = names(stats::coef(fit))[indices], parent_term = term, stringsAsFactors = FALSE)
  })
  do.call(rbind, rows)
}

validate_coefficient_order <- function(fits) {
  valid <- Filter(Negate(is.null), fits)
  if (!length(valid)) stop("No valid model fits", call. = FALSE)
  reference <- names(stats::coef(valid[[1L]]))
  same <- vapply(valid, function(fit) identical(names(stats::coef(fit)), reference), logical(1))
  data.frame(valid_fit_n = length(valid), coefficient_n = length(reference), identical_order = all(same), status = ifelse(all(same), "PASS", "FAIL"))
}
