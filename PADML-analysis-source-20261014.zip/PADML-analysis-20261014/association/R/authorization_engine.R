# v4.3 最小权限授权合同：H1 仅允许指定 source/request 的 U02-U05 formal MICE handoff。

.formal_authorization_stop <- function(code, detail = "") {
  message <- if (nzchar(detail)) paste(code, detail, sep = ": ") else code
  stop(message, call. = FALSE)
}

.formal_authorization_is_sha256 <- function(value) {
  is.character(value) && length(value) == 1L && !is.na(value) &&
    grepl("^[0-9a-f]{64}$", value)
}

.formal_authorization_is_utc_second <- function(value) {
  if (!is.character(value) || length(value) != 1L || is.na(value) ||
      !grepl("^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$", value)) {
    return(FALSE)
  }
  parsed <- as.POSIXct(value, format = "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  !is.na(parsed) && identical(format(parsed, "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"), value)
}

.formal_authorization_fields <- function(include_receipt = FALSE) {
  fields <- c(
    "schema_version", "authorization_type", "decision_id", "status", "authorization",
    "scope", "request_sha256", "source_id", "source_sha256", "source_epoch",
    "iteration_scope", "approved_execution_profile", "authority_class", "approved_at"
  )
  if (isTRUE(include_receipt)) c(fields, "receipt_sha256") else fields
}

.formal_authorization_require_control <- function(project_root = ".") {
  if (!exists("canonical_json", mode = "function") ||
      !exists(".control_sha256_text", mode = "function")) {
    path <- file.path(project_root, "R", "control_kernel.R")
    if (!file.exists(path)) .formal_authorization_stop("FORMAL_MICE_AUTHORIZATION_CONTROL_MISSING")
    source(path)
  }
  invisible(TRUE)
}

finalize_formal_mice_authorization_v43 <- function(payload, project_root = ".") {
  .formal_authorization_require_control(project_root)
  if (!is.list(payload) || is.null(names(payload))) {
    .formal_authorization_stop("FORMAL_MICE_AUTHORIZATION_SCHEMA_INVALID")
  }
  payload$receipt_sha256 <- NULL
  fields <- .formal_authorization_fields(FALSE)
  if (!identical(sort(names(payload)), sort(fields))) {
    .formal_authorization_stop("FORMAL_MICE_AUTHORIZATION_SCHEMA_INVALID")
  }
  payload <- payload[fields]
  if (
      !identical(payload$schema_version, "1.0.0") ||
      !identical(payload$authorization_type, "FORMAL_MICE_HANDOFF") ||
      !grepl("^[A-Za-z0-9][A-Za-z0-9._-]{2,127}$", payload$decision_id) ||
      !identical(payload$status, "APPROVED") ||
      !identical(payload$authorization, "RUN_FORMAL_MICE_HANDOFF") ||
      !identical(payload$scope, "U02_U05") ||
      !.formal_authorization_is_sha256(payload$request_sha256) ||
      !identical(payload$source_id, "SRC_A_XLSX_V43") ||
      !.formal_authorization_is_sha256(payload$source_sha256) ||
      !.formal_authorization_is_sha256(payload$source_epoch) ||
      !identical(payload$iteration_scope, "30|40|50|100|200") ||
      !identical(payload$approved_execution_profile, "production") ||
      !identical(payload$authority_class, "USER_SELECTION") ||
      !.formal_authorization_is_utc_second(payload$approved_at)) {
    .formal_authorization_stop("FORMAL_MICE_AUTHORIZATION_SCHEMA_INVALID")
  }
  payload$receipt_sha256 <- .control_sha256_text(canonical_json(payload))
  payload
}

validate_formal_mice_authorization_v43 <- function(receipt, request = NULL, source_receipt = NULL) {
  fields <- .formal_authorization_fields(TRUE)
  if (!is.list(receipt) || !identical(sort(names(receipt)), sort(fields)) ||
      !.formal_authorization_is_sha256(receipt$receipt_sha256)) {
    .formal_authorization_stop("FORMAL_MICE_AUTHORIZATION_SCHEMA_INVALID")
  }
  receipt <- receipt[fields]
  expected_receipt_sha256 <- receipt$receipt_sha256
  payload <- receipt[.formal_authorization_fields(FALSE)]
  finalized <- finalize_formal_mice_authorization_v43(payload)
  if (!identical(finalized$receipt_sha256, expected_receipt_sha256)) {
    .formal_authorization_stop("FORMAL_MICE_AUTHORIZATION_IDENTITY_MISMATCH")
  }
  if (!is.null(source_receipt)) {
    source_fields <- c("source_id", "source_sha256", "source_epoch")
    if (!is.list(source_receipt) || any(!source_fields %in% names(source_receipt)) ||
        !all(vapply(source_fields, function(field) {
          identical(receipt[[field]], source_receipt[[field]])
        }, logical(1)))) {
      .formal_authorization_stop("FORMAL_MICE_AUTHORIZATION_SOURCE_MISMATCH")
    }
  }
  if (!is.null(request)) {
    request_fields <- c("request_sha256", "source_id", "source_sha256", "source_epoch")
    if (!is.list(request) || any(!request_fields %in% names(request)) ||
        !all(vapply(request_fields, function(field) {
          identical(receipt[[field]], request[[field]])
        }, logical(1)))) {
      .formal_authorization_stop("FORMAL_MICE_AUTHORIZATION_REQUEST_MISMATCH")
    }
  }
  TRUE
}

load_formal_mice_authorization_v43 <- function(
    path, expected_file_sha256, request = NULL, source_receipt = NULL) {
  if (!is.character(path) || length(path) != 1L || !file.exists(path) ||
      isTRUE(file.info(path)$isdir) || nzchar(Sys.readlink(path)) ||
      !.formal_authorization_is_sha256(expected_file_sha256)) {
    .formal_authorization_stop("FORMAL_MICE_AUTHORIZATION_FILE_INVALID")
  }
  # 中文备注：加载摘要包以绑定 H1 授权文件的精确字节身份。
  if (!requireNamespace("digest", quietly = TRUE)) {
    .formal_authorization_stop("FORMAL_MICE_AUTHORIZATION_DEPENDENCY_MISSING", "digest")
  }
  observed_sha256 <- digest::digest(file = path, algo = "sha256", serialize = FALSE)
  if (!identical(observed_sha256, expected_file_sha256)) {
    .formal_authorization_stop("FORMAL_MICE_AUTHORIZATION_FILE_SHA_MISMATCH")
  }
  # 中文备注：加载 JSON 包并验证 H1 语义 receipt 与 source/request 的双重绑定。
  if (!requireNamespace("jsonlite", quietly = TRUE)) {
    .formal_authorization_stop("FORMAL_MICE_AUTHORIZATION_DEPENDENCY_MISSING", "jsonlite")
  }
  receipt <- jsonlite::read_json(path, simplifyVector = TRUE)
  validate_formal_mice_authorization_v43(receipt, request, source_receipt)
  receipt
}
