# 阶段合同清单：只纳入显式依赖与 contract index 声明的活动 owner。

.contract_index_owner_files <- function(stage, project_root) {
  index_path <- file.path(project_root, "config", "contract_index.csv")
  if (!file.exists(index_path)) stop("CONTRACT_INDEX_MISSING", call. = FALSE)
  index <- utils::read.csv(index_path, stringsAsFactors = FALSE, check.names = FALSE, na.strings = "")
  required <- c(
    "contract_id", "owner_relative_path", "status", "producer_stage", "consumer_stages"
  )
  if (!all(required %in% names(index)) || anyDuplicated(index$contract_id)) {
    stop("CONTRACT_INDEX_SCHEMA_INVALID", call. = FALSE)
  }
  consumes <- vapply(index$consumer_stages, function(value) {
    stage %in% strsplit(ifelse(is.na(value), "", value), "|", fixed = TRUE)[[1L]]
  }, logical(1))
  produces <- index$producer_stage == stage
  produces[is.na(produces)] <- FALSE
  relative <- unique(index$owner_relative_path[index$status == "ACTIVE" & (consumes | produces)])
  relative <- relative[!is.na(relative) & nzchar(relative)]
  c(index_path, file.path(project_root, relative))
}

.stage_full_contract_files <- function(stage, project_root = ".") {
  allowed_stages <- c("P00", paste0("A0", 1:7))
  if (!stage %in% allowed_stages) stop("Unknown stage contract: ", stage, call. = FALSE)
  project_root <- normalizePath(project_root, mustWork = TRUE)
  common_r <- c(
    "stage_contract_manifest.R", "stage_context.R", "stage_execution.R",
    "stage_gate.R", "bundle_manager.R", "review_pack.R", "runner_control.R",
    "control_kernel.R", "epoch_guard.R", "authority_engine.R", "profile_guard.R"
  )
  stage_r <- switch(stage,
    P00 = c(
      "data_handoff_engine.R", "source_input_adapter.R", "profile_guard.R",
      "exposure_freeze_engine.R", "cox_engine.R", "model_term_map.R"
    ),
    A01 = c("data_handoff_engine.R", "source_input_adapter.R", "patient_identity_guard.R", "exposure_freeze_engine.R", "descriptive_engine.R"),
    A02 = c("imputation_qc_engine.R", "mi_qc_engine_v43.R", "mi_recipe_engine.R"),
    A03 = c("cox_engine.R", "ph_engine.R", "schoenfeld_diagnostic_engine.R", "model_term_map.R", "pooling_engine.R", "canonical_results.R", "model_signature.R"),
    A04 = c("cox_engine.R", "tve_engine.R", "rcs_engine.R", "cutoff_engine.R", "d1_adapter.R", "model_term_map.R", "pooling_engine.R", "canonical_results.R", "model_signature.R"),
    A05 = c("cox_engine.R", "tve_engine.R", "subgroup_engine.R", "observability.R", "d1_adapter.R", "model_term_map.R", "pooling_engine.R", "canonical_results.R", "model_signature.R"),
    A06 = c("cox_engine.R", "tve_engine.R", "rcs_engine.R", "sensitivity_engine.R", "schoenfeld_diagnostic_engine.R", "cutoff_engine.R", "observability.R", "model_term_map.R", "pooling_engine.R", "canonical_results.R", "model_signature.R"),
    A07 = c("publication_renderer.R", "release_manager.R", "export_manager.R", "canonical_results.R")
  )
  common_config <- c(
    "task_registry.csv", "warning_registry.csv", "qc_gate_registry.csv",
    "execution_profile_registry.csv", "contract_index.csv",
    "stage_execution_registry.csv", "stage_artifact_registry.csv",
    "identity_slice_registry.csv"
  )
  stage_config <- switch(stage,
    P00 = c(
      "runtime_budget.yml", "runtime_profile_registry.csv", "data_source_registry.csv",
      "endpoint_registry.csv", "exposure_registry.csv", "model_registry.csv", "estimand_registry.csv",
      "timepoint_registry.csv", "subgroup_registry.csv", "sensitivity_registry.csv",
      "sensitivity_parameter_registry.csv", "multiparameter_pooling_registry.csv",
      "cox_engine_registry.csv", "ph_rule_registry.csv", "collinearity_registry.csv",
      "collinearity_decision_matrix.csv", "table1_method_registry.csv", "output_registry.csv",
      "output_recipe_registry.csv", "table_registry.csv", "figure_registry.csv",
      "canonical_file_registry.csv", "canonical_abi_registry.csv", "canonical_value_applicability_registry.csv",
      "diagnostic_extension_registry.csv", "cutoff_registry.csv",
      "scientific_question_output_map.csv",
      "source_dataset_registry.csv", "source_column_mapping_registry.csv",
      "source_preprocessing_registry.csv", "source_passive_formula_registry.csv"
    ),
    A01 = c("data_source_registry.csv", "endpoint_registry.csv", "exposure_registry.csv", "table1_method_registry.csv", "timepoint_registry.csv"),
    A02 = c("data_source_registry.csv"),
    A03 = c("endpoint_registry.csv", "model_registry.csv", "cox_engine_registry.csv", "ph_rule_registry.csv", "diagnostic_extension_registry.csv", "canonical_abi_registry.csv", "multiparameter_pooling_registry.csv", "not_estimable_reason_registry.csv"),
    A04 = c("endpoint_registry.csv", "model_registry.csv", "exposure_registry.csv", "timepoint_registry.csv", "cutoff_registry.csv", "canonical_abi_registry.csv", "multiparameter_pooling_registry.csv", "estimand_registry.csv"),
    A05 = c("endpoint_registry.csv", "model_registry.csv", "exposure_registry.csv", "timepoint_registry.csv", "multiparameter_pooling_registry.csv", "subgroup_registry.csv"),
    A06 = c("endpoint_registry.csv", "model_registry.csv", "exposure_registry.csv", "timepoint_registry.csv", "diagnostic_extension_registry.csv", "cutoff_registry.csv", "canonical_abi_registry.csv", "multiparameter_pooling_registry.csv", "sensitivity_registry.csv", "sensitivity_parameter_registry.csv"),
    A07 = c("output_registry.csv", "output_recipe_registry.csv", "table_registry.csv", "figure_registry.csv", "canonical_file_registry.csv", "canonical_abi_registry.csv", "canonical_value_applicability_registry.csv", "diagnostic_extension_registry.csv", "cutoff_registry.csv", "scientific_question_output_map.csv", "estimand_registry.csv")
  )
  reference_files <- if (stage %in% c("P00", "A01")) {
    file.path(project_root, "reference", c("upstream_handoff_pointer.csv", "approved_upstream_handoff.csv"))
  } else character()
  files <- c(
    file.path(project_root, "R", unique(c(common_r, stage_r))),
    file.path(project_root, "config", unique(c(common_config, stage_config))),
    file.path(project_root, "schemas", c(
      "stage_lock_schema.json", "bundle_manifest_schema.csv", "review_decision_schema.json",
      "stateless_capsule_manifest.schema.json", "stateless_stage_request.schema.json",
      "stateless_stage_result.schema.json"
    )),
    file.path(project_root, "_targets", paste0(stage, "_targets.R")),
    file.path(project_root, "renv.lock"),
    reference_files,
    .contract_index_owner_files(stage, project_root)
  )
  if (identical(stage, "A07")) {
    files <- c(files, list.files(file.path(project_root, "report"), recursive = TRUE, full.names = TRUE))
  }
  files <- unique(files)
  missing <- files[!file.exists(files) | file.info(files)$isdir]
  if (length(missing)) {
    stop("STAGE_CONTRACT_FILE_MISSING: ", paste(basename(missing), collapse = "|"), call. = FALSE)
  }
  sort(normalizePath(files, mustWork = TRUE))
}

stage_full_contract_files <- function(stage, project_root = ".") {
  .stage_full_contract_files(stage, project_root)
}

.stage_consumed_semantic_domains <- function(stage) {
  publication <- stage %in% c("P00", "A07")
  source <- stage %in% c("P00", "A01", "A02", "A07")
  unique(c(
    if (source) c("SOURCE_IDENTITY", "SOURCE_PREPROCESSING") else character(),
    c("MI_RECIPE", "SCIENTIFIC_MODEL", "SENSITIVITY"),
    "CONTROL_PLANE", "REMOTE_RUNTIME",
    if (publication) "PUBLICATION" else character()
  ))
}

stage_contract_files <- function(stage, project_root = ".") {
  project_root <- normalizePath(project_root, mustWork = TRUE)
  files <- .stage_full_contract_files(stage, project_root)
  control_only <- file.path(project_root, "R", c(
    "authority_engine.R", "bundle_manager.R", "control_kernel.R", "epoch_guard.R",
    "review_pack.R", "runner_control.R", "stage_context.R",
    "stage_contract_manifest.R", "stage_gate.R"
  ))
  control_schemas <- file.path(project_root, "schemas", c(
    "stage_lock_schema.json", "bundle_manifest_schema.csv", "review_decision_schema.json"
  ))
  index <- utils::read.csv(
    file.path(project_root, "config", "contract_index.csv"),
    stringsAsFactors = FALSE, check.names = FALSE, na.strings = character()
  )
  consumed_domains <- .stage_consumed_semantic_domains(stage)
  active_owners <- index[
    index$status == "ACTIVE" & nzchar(index$owner_relative_path),
    c("owner_relative_path", "semantic_domain"),
    drop = FALSE
  ]
  owner_domains <- split(active_owners$semantic_domain, active_owners$owner_relative_path)
  excluded_owner_relative <- names(owner_domains)[vapply(owner_domains, function(domains) {
    !any(domains %in% consumed_domains)
  }, logical(1))]
  excluded_owner_paths <- file.path(
    project_root,
    excluded_owner_relative
  )
  excluded <- unique(c(
    control_only, control_schemas,
    file.path(project_root, "config", "contract_index.csv"),
    excluded_owner_paths
  ))
  sort(setdiff(files, normalizePath(excluded[file.exists(excluded)], mustWork = TRUE)))
}

# 将相对路径与内容 hash 写入阶段 context，使依赖精确失效且 basename 碰撞不可隐藏。
context_with_contract <- function(context, files) {
  # 加载摘要包以计算稳定的阶段合同内容 hash。
  if (!requireNamespace("digest", quietly = TRUE)) stop("digest is required", call. = FALSE)
  root <- normalizePath(context$project_root, mustWork = TRUE)
  paths <- normalizePath(files, mustWork = TRUE)
  prefix <- paste0(root, .Platform$file.sep)
  if (any(!startsWith(paths, prefix))) stop("STAGE_CONTRACT_PATH_OUTSIDE_PROJECT", call. = FALSE)
  relative <- substring(paths, nchar(prefix) + 1L)
  relative <- gsub("\\\\", "/", relative)
  if (anyDuplicated(relative)) stop("STAGE_CONTRACT_RELATIVE_PATH_DUPLICATE", call. = FALSE)
  order_index <- order(relative)
  relative <- relative[order_index]
  paths <- paths[order_index]
  hashes <- vapply(paths, function(path) digest::digest(file = path, algo = "sha256", serialize = FALSE), character(1))
  execution_contract_sha256 <- digest::digest(
    paste(relative, hashes, sep = "\t", collapse = "\n"),
    algo = "sha256", serialize = FALSE
  )
  context$stage_execution_contract_sha256 <- execution_contract_sha256
  context$stage_execution_contract_file_n <- length(paths)
  if (!is.character(context$stage_contract_sha256) || length(context$stage_contract_sha256) != 1L ||
      !grepl("^[0-9a-f]{64}$", context$stage_contract_sha256)) {
    context$stage_contract_sha256 <- execution_contract_sha256
    context$stage_contract_file_n <- length(paths)
  }
  context
}
