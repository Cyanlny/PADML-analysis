# RCS basis 模块：所有插补必须使用相同knots和软件实现。
build_frozen_rcs_basis <- function(x_log2, frozen_knots) {
  # 加载 Hmisc 包以构造冻结的限制性立方样条基函数。
  if (!requireNamespace("Hmisc", quietly = TRUE)) stop("Hmisc is required", call. = FALSE)
  if (length(frozen_knots) != 4L || any(diff(frozen_knots) <= 0)) stop("Four increasing knots are required", call. = FALSE)
  Hmisc::rcspline.eval(x_log2, knots = frozen_knots, inclx = TRUE, norm = 2)
}

frozen_rcs_spec <- function(x_log2) {
  knots <- as.numeric(stats::quantile(x_log2, probs = c(0.05, 0.35, 0.65, 0.95), type = 7, names = FALSE, na.rm = TRUE))
  reference <- stats::median(x_log2, na.rm = TRUE)
  grid <- seq(min(x_log2, na.rm = TRUE), max(x_log2, na.rm = TRUE), length.out = 200)
  list(knots = knots, reference = reference, grid = grid, quantile_type = 7L)
}

validate_rcs_grid <- function(grid, observed_range) {
  status <- if (min(grid) < observed_range[[1L]] || max(grid) > observed_range[[2L]]) "FAIL" else "PASS"
  data.frame(grid_n = length(grid), grid_min = min(grid), grid_max = max(grid), observed_min = observed_range[[1L]], observed_max = observed_range[[2L]], status = status)
}

prepare_rcs_data <- function(data, frozen_knots) {
  data <- normalize_cox_factor_levels(data)
  basis <- build_frozen_rcs_basis(data$log2_AST_ALT, frozen_knots)
  colnames(basis) <- c("rcs_linear", paste0("rcs_nonlinear", seq_len(ncol(basis) - 1L)))
  cbind(data, as.data.frame(basis, check.names = FALSE))
}

.validate_frozen_rcs_spec <- function(rcs_spec) {
  valid <- is.list(rcs_spec) &&
    identical(names(rcs_spec), c("knots", "reference", "grid", "quantile_type")) &&
    is.numeric(rcs_spec$knots) && length(rcs_spec$knots) == 4L &&
    all(is.finite(rcs_spec$knots)) && all(diff(rcs_spec$knots) > 0) &&
    is.numeric(rcs_spec$reference) && length(rcs_spec$reference) == 1L &&
    is.finite(rcs_spec$reference) &&
    is.numeric(rcs_spec$grid) && length(rcs_spec$grid) == 200L &&
    all(is.finite(rcs_spec$grid)) && all(diff(rcs_spec$grid) > 0) &&
    min(rcs_spec$grid) <= min(rcs_spec$knots) && max(rcs_spec$grid) >= max(rcs_spec$knots) &&
    rcs_spec$reference >= min(rcs_spec$grid) && rcs_spec$reference <= max(rcs_spec$grid) &&
    identical(rcs_spec$quantile_type, 7L)
  if (!isTRUE(valid)) stop("A04_RCS_SPEC_IDENTITY_MISMATCH", call. = FALSE)
  invisible(rcs_spec)
}

make_rcs_collection_spec <- function(
    completed, endpoint_row, exposure_scale, root = ".", rcs_spec = NULL) {
  if (!is.list(completed) || length(completed) != 20L) {
    stop("A04_RCS_BRANCH_CONTRACT_INVALID", call. = FALSE)
  }
  if (is.null(rcs_spec)) {
    rcs_spec <- list(
      knots = as.numeric(stats::quantile(completed[[1L]]$log2_AST_ALT, probs = c(0.05, 0.35, 0.65, 0.95), type = 7, names = FALSE)),
      reference = exposure_scale$reference_median[[1L]],
      grid = seq(min(completed[[1L]]$log2_AST_ALT), max(completed[[1L]]$log2_AST_ALT), length.out = 200),
      quantile_type = 7L
    )
  }
  .validate_frozen_rcs_spec(rcs_spec)
  covariates <- split_registry_terms(read_model_spec("M5", root)$covariates[[1L]])
  basis_names <- c("rcs_linear", paste0("rcs_nonlinear", seq_len(length(rcs_spec$knots) - 2L)))
  full_text <- sprintf(
    "survival::Surv(%s, %s) ~ %s",
    endpoint_row$time_variable[[1L]], endpoint_row$event_variable[[1L]], paste(c(basis_names, covariates), collapse = " + ")
  )
  linear_text <- sprintf(
    "survival::Surv(%s, %s) ~ %s",
    endpoint_row$time_variable[[1L]], endpoint_row$event_variable[[1L]], paste(c("rcs_linear", covariates), collapse = " + ")
  )
  null_text <- sprintf(
    "survival::Surv(%s, %s) ~ %s",
    endpoint_row$time_variable[[1L]], endpoint_row$event_variable[[1L]], paste(covariates, collapse = " + ")
  )
  formulas <- lapply(c(full = full_text, linear = linear_text, null = null_text), stats::as.formula)
  list(
    rcs_spec = rcs_spec,
    formulas = c(full = full_text, linear = linear_text, null = null_text),
    basis_names = basis_names, endpoint_row = endpoint_row
  )
}

make_rcs_branch_specs <- function(
    completed, endpoint_row, exposure_scale, root = ".", rcs_spec = NULL) {
  collection <- make_rcs_collection_spec(
    completed, endpoint_row, exposure_scale, root, rcs_spec = rcs_spec
  )
  specs <- list()
  index <- 1L
  for (formula_id in c("full", "linear", "null")) {
    for (imputation_id in seq_along(completed)) {
      specs[[index]] <- list(
        formula_id = formula_id,
        formula_text = unname(collection$formulas[[formula_id]]),
        imputation_id = as.integer(imputation_id),
        rcs_spec = collection$rcs_spec,
        basis_names = collection$basis_names,
        endpoint_row = collection$endpoint_row
      )
      index <- index + 1L
    }
  }
  keys <- vapply(specs, function(spec) paste(spec$formula_id, spec$imputation_id, sep = "__"), character(1))
  if (length(specs) != 60L || anyDuplicated(keys)) stop("A04_RCS_BRANCH_CONTRACT_INVALID", call. = FALSE)
  specs
}

fit_rcs_branch <- function(completed, branch_spec) {
  required <- c("formula_id", "formula_text", "imputation_id", "rcs_spec", "basis_names", "endpoint_row")
  if (!is.list(branch_spec) || !identical(names(branch_spec), required) ||
      !branch_spec$formula_id %in% c("full", "linear", "null") ||
      length(completed) != 20L || !branch_spec$imputation_id %in% seq_along(completed)) {
    stop("A04_RCS_BRANCH_CONTRACT_INVALID", call. = FALSE)
  }
  data <- prepare_rcs_data(completed[[branch_spec$imputation_id]], branch_spec$rcs_spec$knots)
  failure <- ""
  fit <- tryCatch({
    if (!requireNamespace("survival", quietly = TRUE)) stop("survival is required")
    survival::coxph(
      stats::as.formula(branch_spec$formula_text), data = data, ties = "efron",
      na.action = stats::na.fail, x = FALSE, y = FALSE, model = FALSE
    )
  }, error = function(error) {
    failure <<- conditionMessage(error)
    NULL
  })
  list(spec = branch_spec, fit = fit, failure = failure)
}

assemble_rcs_branch_collections <- function(branches) {
  if (!is.list(branches) || length(branches) != 60L) {
    stop("A04_RCS_BRANCH_CARDINALITY_INVALID", call. = FALSE)
  }
  branches <- unname(branches)
  keys <- vapply(branches, function(branch) {
    if (!is.list(branch) || !all(c("spec", "fit", "failure") %in% names(branch))) {
      stop("A04_RCS_BRANCH_CONTRACT_INVALID", call. = FALSE)
    }
    paste(branch$spec$formula_id, branch$spec$imputation_id, sep = "__")
  }, character(1))
  expected <- as.vector(outer(c("full", "linear", "null"), seq_len(20L), paste, sep = "__"))
  if (anyDuplicated(keys) || !identical(sort(keys), sort(expected))) {
    stop("A04_RCS_BRANCH_SET_INVALID", call. = FALSE)
  }
  first <- branches[[1L]]$spec
  stable_shared <- c("rcs_spec", "basis_names", "endpoint_row")
  if (!all(vapply(branches, function(branch) {
    identical(branch$spec[stable_shared], first[stable_shared])
  }, logical(1)))) {
    stop("A04_RCS_BRANCH_SCIENTIFIC_IDENTITY_MISMATCH", call. = FALSE)
  }
  fits <- setNames(vector("list", 3L), c("full", "linear", "null"))
  failures <- list()
  for (formula_id in names(fits)) {
    group <- branches[vapply(branches, function(branch) identical(branch$spec$formula_id, formula_id), logical(1))]
    group <- group[order(vapply(group, function(branch) branch$spec$imputation_id, integer(1)))]
    stable_fields <- setdiff(names(group[[1L]]$spec), "imputation_id")
    if (!identical(
        vapply(group, function(branch) branch$spec$imputation_id, integer(1)),
        seq_len(20L)
      ) || !all(vapply(group, function(branch) {
        identical(branch$spec[stable_fields], group[[1L]]$spec[stable_fields])
      }, logical(1)))) {
      stop("A04_RCS_BRANCH_SCIENTIFIC_IDENTITY_MISMATCH", call. = FALSE)
    }
    fits[[formula_id]] <- lapply(group, `[[`, "fit")
    for (branch in group) if (nzchar(branch$failure)) {
      failures[[paste(formula_id, branch$spec$imputation_id, sep = "__")]] <- branch$failure
    }
  }
  list(
    fits = fits, failures = failures,
    formulas = setNames(vapply(c("full", "linear", "null"), function(id) {
      branch <- branches[[which(vapply(branches, function(item) identical(item$spec$formula_id, id), logical(1)))[[1L]]]]
      branch$spec$formula_text
    }, character(1)), c("full", "linear", "null")),
    basis_names = first$basis_names, endpoint_row = first$endpoint_row
  )
}

fit_rcs_collections <- function(completed, endpoint_row, rcs_spec, root = ".") {
  exposure_scale <- data.frame(reference_median = rcs_spec$reference)
  specs <- make_rcs_branch_specs(
    completed, endpoint_row, exposure_scale, root, rcs_spec = rcs_spec
  )
  branches <- lapply(specs, function(spec) fit_rcs_branch(completed, spec))
  assemble_rcs_branch_collections(branches)
}

pool_rcs_grid <- function(collections, rcs_spec, root = ".") {
  source(file.path(root, "R", "pooling_engine.R"))
  grid_basis <- build_frozen_rcs_basis(rcs_spec$grid, rcs_spec$knots)
  reference_basis <- build_frozen_rcs_basis(rcs_spec$reference, rcs_spec$knots)
  colnames(grid_basis) <- collections$basis_names
  colnames(reference_basis) <- collections$basis_names
  beta_list <- lapply(collections$fits$full, function(fit) if (is.null(fit)) setNames(rep(NA_real_, length(collections$basis_names)), collections$basis_names) else stats::coef(fit))
  covariance_list <- lapply(collections$fits$full, function(fit) if (is.null(fit)) matrix(NA_real_, length(collections$basis_names), length(collections$basis_names), dimnames = list(collections$basis_names, collections$basis_names)) else stats::vcov(fit))
  rows <- lapply(seq_along(rcs_spec$grid), function(i) {
    contrast <- grid_basis[i, ] - reference_basis[1L, ]
    names(contrast) <- collections$basis_names
    pooled <- tryCatch(pool_linear_contrast_rubin(beta_list, covariance_list, contrast), error = function(e) NULL)
    data.frame(
      endpoint = collections$endpoint_row$event_variable[[1L]], model_id = "M5", x_log2 = rcs_spec$grid[[i]],
      x_ast_alt = 2^rcs_spec$grid[[i]], reference_log2 = rcs_spec$reference,
      beta = if (is.null(pooled)) NA_real_ else pooled$pooled_estimate[[1L]],
      se = if (is.null(pooled)) NA_real_ else pooled$se[[1L]],
      hr = if (is.null(pooled)) NA_real_ else exp(pooled$pooled_estimate[[1L]]),
      lower_95_ci = if (is.null(pooled)) NA_real_ else exp(pooled$lower[[1L]]),
      upper_95_ci = if (is.null(pooled)) NA_real_ else exp(pooled$upper[[1L]]),
      valid_imputation_n = if (is.null(pooled)) 0L else pooled$valid_imputation_n[[1L]],
      estimate_status = ifelse(is.null(pooled), "NOT_ESTIMABLE", "ESTIMABLE"),
      stringsAsFactors = FALSE
    )
  })
  do.call(rbind, rows)
}

combine_rcs_branches <- function(completed, branches, exposure_scale, root = ".") {
  if (!is.list(branches) || length(branches) != 60L) {
    stop("A04_RCS_BRANCH_CARDINALITY_INVALID", call. = FALSE)
  }
  collection_spec <- make_rcs_collection_spec(
    completed, branches[[1L]]$spec$endpoint_row, exposure_scale, root
  )
  if (!identical(branches[[1L]]$spec$rcs_spec, collection_spec$rcs_spec)) {
    stop("A04_RCS_SPEC_IDENTITY_MISMATCH", call. = FALSE)
  }
  spec <- collection_spec$rcs_spec
  collections <- assemble_rcs_branch_collections(branches)
  if (!identical(collections$formulas, collection_spec$formulas) ||
      !identical(collections$basis_names, collection_spec$basis_names) ||
      !identical(collections$endpoint_row, collection_spec$endpoint_row)) {
    stop("A04_RCS_BRANCH_SCIENTIFIC_IDENTITY_MISMATCH", call. = FALSE)
  }
  curve <- pool_rcs_grid(collections, spec, root)
  rcs_fit_n <- unique(vapply(
    collections$fits$full,
    function(fit) if (is.null(fit)) NA_integer_ else as.integer(fit$n),
    integer(1)
  ))
  rcs_fit_events <- unique(vapply(
    collections$fits$full,
    function(fit) if (is.null(fit)) NA_integer_ else as.integer(fit$nevent),
    integer(1)
  ))
  rcs_fit_n <- rcs_fit_n[is.finite(rcs_fit_n)]
  rcs_fit_events <- rcs_fit_events[is.finite(rcs_fit_events)]
  if (length(rcs_fit_n) != 1L || length(rcs_fit_events) != 1L) {
    stop("RCS_SOURCE_SAMPLE_EVENT_IDENTITY_MISMATCH", call. = FALSE)
  }
  curve$analysis_n <- rcs_fit_n[[1L]]
  curve$event_n <- rcs_fit_events[[1L]]
  # 从同一 RCS fit 与同一 basis 计算解析导数候选，不增加任何 Cox 拟合。
  cutoff <- derive_rcs_turning_point(
    collections$fits$full, spec, collections$basis_names,
    minimum_root_imputations = 16L, maximum_iqr_fraction = 0.10
  )
  source(file.path(root, "R", "d1_adapter.R"))
  overall <- tryCatch(run_locked_d1(collections$fits$full, collections$fits$null, "rcs_overall", root), error = function(e) data.frame(analysis_type = "rcs_overall", statistic = NA_real_, numerator_df = NA_real_, denominator_df = NA_real_, p_value = NA_real_, riv = NA_real_, valid_imputation_n = sum(!vapply(collections$fits$full, is.null, logical(1))), pooling_method = "mice_D1_locked", failure = conditionMessage(e)))
  nonlinearity <- tryCatch(run_locked_d1(collections$fits$full, collections$fits$linear, "rcs_nonlinearity", root), error = function(e) data.frame(analysis_type = "rcs_nonlinearity", statistic = NA_real_, numerator_df = NA_real_, denominator_df = NA_real_, p_value = NA_real_, riv = NA_real_, valid_imputation_n = sum(!vapply(collections$fits$full, is.null, logical(1))), pooling_method = "mice_D1_locked", failure = conditionMessage(e)))
  reference_row <- curve[which.min(abs(curve$x_log2 - spec$reference)), , drop = FALSE]
  qc <- data.frame(
    qc_item = c("knots_increasing", "grid_n_200", "no_extrapolation", "reference_hr_near_1"),
    observed = c(all(diff(spec$knots) > 0), nrow(curve) == 200L, min(spec$grid) >= min(completed[[1L]]$log2_AST_ALT) && max(spec$grid) <= max(completed[[1L]]$log2_AST_ALT), abs(reference_row$hr - 1)),
    status = c(ifelse(all(diff(spec$knots) > 0), "PASS", "FAIL"), ifelse(nrow(curve) == 200L, "PASS", "FAIL"), "PASS", ifelse(abs(reference_row$hr - 1) <= 0.05, "PASS", "FAIL")),
    stringsAsFactors = FALSE
  )
  # 中文备注：D1 与曲线 pooling 完成后压缩模型对象，后续阶段只消费 canonical 数值结果。
  compact_collections <- collections
  compact_collections$fits <- lapply(collections$fits, function(group) lapply(group, compact_cox_fit))
  list(
    spec = spec, collections = compact_collections, curve = curve,
    tests = rbind(overall, nonlinearity), qc = qc, cutoff = cutoff
  )
}

run_rcs_stage <- function(completed, endpoint_row, exposure_scale, root = ".") {
  specs <- make_rcs_branch_specs(completed, endpoint_row, exposure_scale, root)
  branches <- lapply(specs, function(spec) fit_rcs_branch(completed, spec))
  combine_rcs_branches(completed, branches, exposure_scale, root)
}
