# v4.3 formal MICE 执行器：只消费已验证 runtime spec，并通过 exactly-once admission 发布 checkpoint。

.formal_mi_stop <- function(code, detail = "") {
  message <- if (nzchar(detail)) paste(code, detail, sep = ": ") else code
  stop(message, call. = FALSE)
}

.formal_mi_require_functions <- function(project_root = ".") {
  files <- c(
    control_kernel.R = "canonical_json",
    authorization_engine.R = "validate_formal_mice_authorization_v43",
    source_input_adapter.R = "validate_source_candidate_receipt",
    mi_recipe_engine.R = "validate_mi_runtime_spec_v43",
    mi_transaction_engine.R = "finalize_mi_transaction_request_v43"
  )
  for (file in names(files)) {
    if (!exists(files[[file]], mode = "function")) {
      path <- file.path(project_root, "R", file)
      if (!file.exists(path)) .formal_mi_stop("FORMAL_MICE_ENGINE_DEPENDENCY_MISSING", file)
      source(path)
    }
  }
  invisible(TRUE)
}

.formal_mi_relative_hash_projection <- function(project_root, relative_paths) {
  relative_paths <- sort(unique(relative_paths))
  if (any(grepl("^/|^[A-Za-z]:[/\\\\]|(^|/)\\.\\.(/|$)", relative_paths, perl = TRUE))) {
    .formal_mi_stop("FORMAL_MICE_IDENTITY_PATH_INVALID")
  }
  full <- file.path(project_root, relative_paths)
  if (any(!file.exists(full)) || any(file.info(full)$isdir %in% TRUE)) {
    .formal_mi_stop("FORMAL_MICE_IDENTITY_FILE_MISSING")
  }
  hashes <- vapply(full, .mi_tx_sha256_file, character(1))
  paste(relative_paths, hashes, sep = "\t", collapse = "\n")
}

compute_mi_recipe_identity_v43 <- function(project_root = ".") {
  .formal_mi_require_functions(project_root)
  mapping <- read_source_column_mapping_registry(project_root)
  tracked <- load_compiled_mi_recipe_v43(project_root, mapping$target_name)
  projection_files <- c(
    "config/source_mi_recipe_registry.csv",
    "config/source_mi_method_registry.csv",
    "config/source_mi_predictor_edges.csv",
    "config/source_mi_block_registry.csv"
  )
  owner_files <- c(
    "protocol/amendments/MAIN_V43_R00_CONFLICT_SAFE_DRIFT_SAFE_EXACT_CLOSURE_FINAL.json",
    "config/source_column_mapping_registry.csv"
  )
  projection <- .formal_mi_relative_hash_projection(project_root, projection_files)
  owner_projection <- .formal_mi_relative_hash_projection(project_root, owner_files)
  list(
    recipe_epoch = .control_sha256_text(paste(owner_projection, projection, sep = "\n")),
    recipe_projection_sha256 = .control_sha256_text(projection),
    predictor_policy_sha256 = tracked$owner$predictor$policy_subset_sha256,
    candidate_projection_sha256 = .mi_projection_identity_v43(tracked$projection),
    candidate_edge_n = as.integer(nrow(tracked$projection$predictor_edges))
  )
}

compute_mi_runtime_identity_v43 <- function(project_root = ".") {
  .formal_mi_require_functions(project_root)
  admission_identity <- Sys.getenv("AST_ALT_VERIFIED_RUNTIME_IDENTITY_SHA256", unset = "")
  if (!grepl("^[0-9a-f]{64}$", admission_identity)) {
    .formal_mi_stop("FORMAL_MICE_RUNTIME_ADMISSION_IDENTITY_REQUIRED")
  }
  compatibility_patch_lock <- "remote/r-source-compatibility-patch-lock.csv"
  compatibility_patch_controller <- "remote/apply_r_source_compatibility_patches.R"
  if (!file.exists(file.path(project_root, compatibility_patch_lock))) {
    .formal_mi_stop("FORMAL_MICE_RUNTIME_PATCH_LOCK_MISSING")
  }
  if (!file.exists(file.path(project_root, compatibility_patch_controller))) {
    .formal_mi_stop("FORMAL_MICE_RUNTIME_PATCH_CONTROLLER_MISSING")
  }
  # 中文备注：加载严格补丁合同读取器，先验证 lock、source lock、patch documents 与 effective identity。
  source(file.path(project_root, compatibility_patch_controller), local = environment())
  validated_patch_lock <- tryCatch(
    .r_source_patch_read_lock(project_root),
    error = function(condition) {
      .formal_mi_stop("FORMAL_MICE_RUNTIME_PATCH_LOCK_INVALID", conditionMessage(condition))
    }
  )
  if (!identical(
      attr(validated_patch_lock, "sha256"),
      .mi_tx_sha256_file(file.path(project_root, compatibility_patch_lock))
    )) {
    .formal_mi_stop("FORMAL_MICE_RUNTIME_PATCH_LOCK_INVALID", "validated_sha256")
  }
  candidate_files <- c(
    "renv.lock", "config/runtime_profile_registry.csv", "config/runtime_budget.yml",
    "remote/bootstrap_env.sh", "remote/restore_project.R", "remote/conda-linux-64-spec.txt",
    compatibility_patch_controller, compatibility_patch_lock,
    "R/formal_mice_engine.R", "R/mi_recipe_engine.R", "R/mi_transaction_engine.R"
  )
  runtime_files <- candidate_files[file.exists(file.path(project_root, candidate_files))]
  file_projection <- .formal_mi_relative_hash_projection(project_root, runtime_files)
  profile <- .mi_read_csv(file.path(project_root, "config", "runtime_profile_registry.csv"))
  profile <- profile[profile$runtime_profile_id == "AUTODL_UBUNTU2204_V43", , drop = FALSE]
  if (nrow(profile) != 1L || !identical(profile$platform[[1L]], "linux-64") ||
      !identical(profile$r_version[[1L]], "4.6.0")) {
    .formal_mi_stop("FORMAL_MICE_RUNTIME_PROFILE_INVALID")
  }
  # 中文备注：读取 lock 绑定 AutoDL accepted V3 的 mice 版本，不在本机加载或执行 MICE。
  if (!requireNamespace("jsonlite", quietly = TRUE)) {
    .formal_mi_stop("FORMAL_MICE_DEPENDENCY_MISSING", "jsonlite")
  }
  lock <- jsonlite::read_json(file.path(project_root, "renv.lock"), simplifyVector = TRUE)
  mice_version <- as.character(lock$Packages$mice$Version)
  if (!identical(mice_version, "3.19.0")) .formal_mi_stop("FORMAL_MICE_RUNTIME_PROFILE_INVALID")
  identity <- list(
    runtime_profile_id = profile$runtime_profile_id[[1L]],
    runtime_admission_identity_sha256 = admission_identity,
    r_version = profile$r_version[[1L]],
    mice_version = mice_version,
    rng_kind = "L'Ecuyer-CMRG|Inversion|Rejection",
    chain_count = 20L,
    worker_pool_capacity = 24L,
    chain_stream_policy = "NEXT_RNG_STREAM_FROM_MASTER_SEED",
    chain_merge_order = "CHAIN_ID_ASCENDING",
    platform = profile$platform[[1L]],
    runtime_file_projection_sha256 = .control_sha256_text(file_projection)
  )
  runtime_epoch <- .control_sha256_text(canonical_json(identity))
  list(
    runtime_epoch = runtime_epoch,
    runtime_identity_sha256 = .control_sha256_text(canonical_json(c(identity, list(runtime_epoch = runtime_epoch)))),
    runtime_admission_identity_sha256 = admission_identity
  )
}

.formal_mi_canonical_input_identity_v43 <- function(source_receipt) {
  # 中文备注：以已审计 source receipt 的规范身份代表确定性 canonical 输入，不读取患者值。
  source_candidate_receipt_identity_v43(source_receipt)
}

build_mi_transaction_request_proposal_v43 <- function(source_receipt, project_root = ".") {
  .formal_mi_require_functions(project_root)
  validate_source_candidate_receipt_current_owner_v43(source_receipt, project_root)
  mapping <- read_source_column_mapping_registry(project_root)
  owner <- read_mi_contract_v43(project_root)
  projection <- compile_mi_projection_v43(project_root, owner, mapping)
  recipe_identity <- compute_mi_recipe_identity_v43(project_root)
  runtime_identity <- compute_mi_runtime_identity_v43(project_root)
  finalize_mi_transaction_request_v43(list(
    schema_version = "1.0.0",
    transaction_type = "FORMAL_MICE_V43",
    source_id = source_receipt$source_id,
    source_epoch = source_receipt$source_epoch,
    source_sha256 = source_receipt$source_sha256,
    patient_order_sha256 = source_receipt$patient_order_sha256,
    canonical_schema_sha256 = source_receipt$canonical_schema_sha256,
    canonical_input_sha256 = .formal_mi_canonical_input_identity_v43(source_receipt),
    recipe_id = owner$source$mi_recipe_id[[1L]],
    recipe_epoch = recipe_identity$recipe_epoch,
    recipe_projection_sha256 = recipe_identity$recipe_projection_sha256,
    predictor_policy_sha256 = recipe_identity$predictor_policy_sha256,
    candidate_projection_sha256 = recipe_identity$candidate_projection_sha256,
    candidate_edge_n = recipe_identity$candidate_edge_n,
    runtime_epoch = runtime_identity$runtime_epoch,
    runtime_identity_sha256 = runtime_identity$runtime_identity_sha256,
    runtime_admission_identity_sha256 = runtime_identity$runtime_admission_identity_sha256,
    m = as.integer(owner$recipe$m),
    seed = as.integer(owner$recipe$seed),
    maxit_initial = as.integer(owner$recipe$maxit_initial),
    continuation_maxit = paste(as.integer(owner$recipe$continuation_maxit), collapse = "|"),
    scientific_generation_id = "MAIN_24_WORKER_SCIENTIFIC_GENERATION_APPROVED",
    rng_kind = owner$recipe$rng_kind,
    chain_count = as.integer(owner$recipe$chain_count),
    worker_pool_capacity = as.integer(owner$recipe$worker_pool_capacity),
    chain_stream_policy = owner$recipe$chain_stream_policy,
    chain_merge_order = owner$recipe$chain_merge_order
  ))
}

build_mi_transaction_request_v43 <- function(
    source_receipt, runtime, projection, owner, mapping, project_root = ".") {
  .formal_mi_require_functions(project_root)
  validate_source_candidate_receipt_current_owner_v43(source_receipt, project_root)
  validate_mi_runtime_spec_v43(runtime, projection, owner, mapping)
  tracked <- load_compiled_mi_recipe_v43(project_root, mapping$target_name)
  if (!identical(tracked$projection, projection)) .formal_mi_stop("FORMAL_MICE_PROJECTION_IDENTITY_MISMATCH")
  canonical <- runtime$data[mapping$target_name]
  patient_order_sha <- .source_sha256_text(as.character(canonical$Patient_ID))
  schema_sha <- .source_sha256_text(paste(
    names(canonical),
    vapply(canonical, function(value) paste(class(value), collapse = "|"), character(1)),
    sep = "\t"
  ))
  if (!identical(nrow(canonical), as.integer(source_receipt$eligible_row_n)) ||
      !identical(patient_order_sha, source_receipt$patient_order_sha256) ||
      !identical(schema_sha, source_receipt$canonical_schema_sha256) ||
      !identical(owner$source$source_id[[1L]], source_receipt$source_id) ||
      !identical(owner$source$expected_sha256[[1L]], source_receipt$source_sha256)) {
    .formal_mi_stop("FORMAL_MICE_SOURCE_IDENTITY_MISMATCH")
  }
  proposal <- build_mi_transaction_request_proposal_v43(source_receipt, project_root)
  if (!identical(proposal$patient_order_sha256, patient_order_sha) ||
      !identical(proposal$canonical_schema_sha256, schema_sha)) {
    .formal_mi_stop("FORMAL_MICE_REQUEST_PROPOSAL_SOURCE_MISMATCH")
  }
  proposal
}

assert_formal_mice_authorized_v43 <- function(execution_profile, authorization, request) {
  if (!identical(execution_profile, "production")) .formal_mi_stop("FORMAL_MICE_PROFILE_FORBIDDEN")
  if (!is.list(authorization)) .formal_mi_stop("FORMAL_MICE_AUTHORIZATION_RECEIPT_REQUIRED")
  validate_formal_mice_authorization_v43(authorization, request = request)
  TRUE
}

formal_mice_continuation_delta_v43 <- function(current_iteration, desired_iteration) {
  current_iteration <- as.integer(current_iteration)
  desired_iteration <- as.integer(desired_iteration)
  valid <- (current_iteration == 30L && desired_iteration == 40L) ||
    (current_iteration == 40L && desired_iteration == 50L) ||
    (current_iteration == 50L && desired_iteration == 100L) ||
    (current_iteration == 100L && desired_iteration == 200L)
  if (!isTRUE(valid)) .formal_mi_stop("MI_CONTINUATION_SEQUENCE_INVALID")
  desired_iteration - current_iteration
}

.resolve_formal_mice_authorized_request_v43 <- function(
    transaction_root, authorization, current_request, source_receipt = NULL) {
  validate_mi_transaction_request_v43(current_request)
  validate_formal_mice_authorization_v43(
    authorization, source_receipt = source_receipt
  )
  transaction_root <- .mi_tx_assert_root(transaction_root)
  transaction_path <- file.path(transaction_root, authorization$request_sha256)
  request <- if (dir.exists(transaction_path)) {
    if (nzchar(Sys.readlink(transaction_path))) {
      .formal_mi_stop("FORMAL_MICE_AUTHORIZED_REQUEST_INVALID")
    }
    request_path <- file.path(transaction_path, "REQUEST.json")
    if (!file.exists(request_path) || isTRUE(file.info(request_path)$isdir) ||
        nzchar(Sys.readlink(request_path))) {
      .formal_mi_stop("FORMAL_MICE_AUTHORIZED_REQUEST_INVALID")
    }
    observed <- .mi_tx_read_json(request_path)
    validate_mi_transaction_request_v43(observed)
    observed <- observed[c(.mi_tx_request_payload_fields(), "request_sha256")]
    .mi_tx_validate_request_directory(transaction_path, observed)
    observed
  } else {
    current_request
  }
  validate_formal_mice_authorization_v43(
    authorization, request = request, source_receipt = source_receipt
  )
  list(
    request = request,
    current_request = current_request,
    transaction_root = transaction_root,
    transaction_path = file.path(transaction_root, request$request_sha256)
  )
}

.validate_formal_mice_repair_delta_v43 <- function(
    historical_request, current_request, project_root = ".") {
  validate_mi_transaction_request_v43(historical_request)
  validate_mi_transaction_request_v43(current_request)
  changed <- names(historical_request)[vapply(names(historical_request), function(field) {
    !identical(historical_request[[field]], current_request[[field]])
  }, logical(1))]
  if (!identical(
      sort(changed),
      sort(c(
        "runtime_epoch", "runtime_identity_sha256",
        "runtime_admission_identity_sha256", "request_sha256"
      ))
  )) .formal_mi_stop("FORMAL_MICE_REPAIR_BRIDGE_INVALID")
  current_runtime <- compute_mi_runtime_identity_v43(project_root)
  if (!identical(current_request$runtime_epoch, current_runtime$runtime_epoch) ||
      !identical(current_request$runtime_identity_sha256, current_runtime$runtime_identity_sha256) ||
      !identical(
        current_request$runtime_admission_identity_sha256,
        current_runtime$runtime_admission_identity_sha256
      )) {
    .formal_mi_stop("FORMAL_MICE_REPAIR_BRIDGE_INVALID")
  }
  invisible(TRUE)
}

validate_formal_mice_repair_bridge_v43 <- function(
    historical_request, current_request, transaction_path, project_root = ".") {
  .validate_formal_mice_repair_delta_v43(
    historical_request, current_request, project_root
  )
  state <- inspect_mi_transaction_v43(transaction_path, historical_request)
  if (identical(state$status, "FAILED_TYPED") || !length(state$failure_recoveries)) {
    .formal_mi_stop("FORMAL_MICE_REPAIR_BRIDGE_INVALID")
  }
  latest <- tail(state$failure_recoveries, 1L)[[1L]]
  if (!identical(
      latest$recovery$repair_owner_identity_sha256,
      .mi_tx_repair_owner_identity_v43(project_root)
  )) .formal_mi_stop("FORMAL_MICE_REPAIR_BRIDGE_INVALID")
  invisible(state)
}

.assert_formal_request_matches_runtime_v43 <- function(
    request, runtime, projection, owner, mapping, transaction_path, project_root) {
  validate_mi_transaction_request_v43(request)
  recipe_identity <- compute_mi_recipe_identity_v43(project_root)
  runtime_identity <- compute_mi_runtime_identity_v43(project_root)
  canonical <- runtime$data[mapping$target_name]
  patient_order_sha <- .source_sha256_text(as.character(canonical$Patient_ID))
  schema_sha <- .source_sha256_text(paste(
    names(canonical),
    vapply(canonical, function(value) paste(class(value), collapse = "|"), character(1)),
    sep = "\t"
  ))
  stable_matches <- c(
    identical(request$patient_order_sha256, patient_order_sha),
    identical(request$canonical_schema_sha256, schema_sha),
    .mi_tx_is_sha256(request$canonical_input_sha256),
    identical(request$recipe_epoch, recipe_identity$recipe_epoch),
    identical(request$recipe_projection_sha256, recipe_identity$recipe_projection_sha256),
    identical(request$predictor_policy_sha256, recipe_identity$predictor_policy_sha256),
    identical(request$candidate_projection_sha256, recipe_identity$candidate_projection_sha256),
    identical(as.integer(request$candidate_edge_n), as.integer(recipe_identity$candidate_edge_n)),
    identical(request$recipe_id, owner$source$mi_recipe_id[[1L]]),
    identical(request$scientific_generation_id, "MAIN_24_WORKER_SCIENTIFIC_GENERATION_APPROVED"),
    identical(request$rng_kind, owner$recipe$rng_kind),
    identical(as.integer(request$chain_count), as.integer(owner$recipe$chain_count)),
    identical(as.integer(request$worker_pool_capacity), as.integer(owner$recipe$worker_pool_capacity)),
    identical(request$chain_stream_policy, owner$recipe$chain_stream_policy),
    identical(request$chain_merge_order, owner$recipe$chain_merge_order)
  )
  if (!all(stable_matches)) .formal_mi_stop("FORMAL_MICE_REQUEST_RUNTIME_IDENTITY_MISMATCH")
  runtime_matches <-
    identical(request$runtime_epoch, runtime_identity$runtime_epoch) &&
    identical(request$runtime_identity_sha256, runtime_identity$runtime_identity_sha256) &&
    identical(
      request$runtime_admission_identity_sha256,
      runtime_identity$runtime_admission_identity_sha256
    )
  if (!runtime_matches) {
    current_request <- request[.mi_tx_request_payload_fields()]
    current_request$runtime_epoch <- runtime_identity$runtime_epoch
    current_request$runtime_identity_sha256 <- runtime_identity$runtime_identity_sha256
    current_request$runtime_admission_identity_sha256 <-
      runtime_identity$runtime_admission_identity_sha256
    current_request <- finalize_mi_transaction_request_v43(current_request)
    validate_formal_mice_repair_bridge_v43(
      request, current_request, transaction_path, project_root
    )
  }
  invisible(TRUE)
}

.formal_mi_seed_identity_v43 <- function(seed) {
  if (!is.integer(seed) || length(seed) != 7L || anyNA(seed)) {
    .formal_mi_stop("MI_FORMAL_CHAIN_SEED_INVALID")
  }
  .control_sha256_text(paste(seed, collapse = "|"))
}

.formal_mi_initial_streams_v43 <- function(master_seed, chain_count) {
  master_seed <- as.integer(master_seed)
  chain_count <- as.integer(chain_count)
  if (!identical(master_seed, 123L) || !identical(chain_count, 20L)) {
    .formal_mi_stop("MI_FORMAL_CHAIN_POLICY_INVALID")
  }
  prior_kind <- RNGkind()
  had_seed <- exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
  prior_seed <- if (had_seed) get(".Random.seed", envir = .GlobalEnv, inherits = FALSE) else NULL
  on.exit({
    do.call(RNGkind, as.list(prior_kind))
    if (had_seed) {
      assign(".Random.seed", prior_seed, envir = .GlobalEnv)
    } else if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)) {
      rm(".Random.seed", envir = .GlobalEnv)
    }
  }, add = TRUE)
  RNGkind("L'Ecuyer-CMRG", "Inversion", "Rejection")
  set.seed(master_seed)
  streams <- vector("list", chain_count)
  streams[[1L]] <- get(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
  if (chain_count > 1L) {
    for (chain_id in 2:chain_count) {
      streams[[chain_id]] <- parallel::nextRNGStream(streams[[chain_id - 1L]])
    }
  }
  if (anyDuplicated(vapply(streams, .formal_mi_seed_identity_v43, character(1)))) {
    .formal_mi_stop("MI_FORMAL_CHAIN_STREAM_DUPLICATED")
  }
  streams
}

.formal_mi_chain_state_v43 <- function(results, owner, iteration) {
  chain_count <- as.integer(owner$recipe$chain_count)
  streams <- .formal_mi_initial_streams_v43(owner$recipe$seed, chain_count)
  chain_ids <- vapply(results, function(result) as.integer(result$chain_id), integer(1))
  if (!identical(chain_ids, seq_len(chain_count))) {
    .formal_mi_stop("MI_FORMAL_CHAIN_ORDER_INVALID")
  }
  last_seeds <- lapply(results, function(result) result$last_seed)
  last_seed_sha256 <- vapply(last_seeds, .formal_mi_seed_identity_v43, character(1))
  list(
    schema_version = "1.0.0",
    scientific_generation_id = "MAIN_24_WORKER_SCIENTIFIC_GENERATION_APPROVED",
    rng_kind = owner$recipe$rng_kind,
    master_seed = as.integer(owner$recipe$seed),
    chain_count = chain_count,
    worker_pool_capacity = as.integer(owner$recipe$worker_pool_capacity),
    chain_stream_policy = owner$recipe$chain_stream_policy,
    chain_merge_order = owner$recipe$chain_merge_order,
    chain_id = chain_ids,
    initial_stream_sha256 = vapply(streams, .formal_mi_seed_identity_v43, character(1)),
    last_seed = last_seeds,
    last_seed_sha256 = last_seed_sha256,
    iteration = as.integer(iteration)
  )
}

.formal_mi_validate_chain_state_v43 <- function(mids_object, owner, expected_iteration) {
  state <- attr(mids_object, "formal_chain_state_v43", exact = TRUE)
  required <- c(
    "schema_version", "scientific_generation_id", "rng_kind", "master_seed",
    "chain_count", "worker_pool_capacity", "chain_stream_policy", "chain_merge_order",
    "chain_id", "initial_stream_sha256", "last_seed", "last_seed_sha256", "iteration"
  )
  chain_count <- as.integer(owner$recipe$chain_count)
  streams <- .formal_mi_initial_streams_v43(owner$recipe$seed, chain_count)
  valid <- is.list(state) && identical(names(state), required) &&
    identical(state$schema_version, "1.0.0") &&
    identical(state$scientific_generation_id, "MAIN_24_WORKER_SCIENTIFIC_GENERATION_APPROVED") &&
    identical(state$rng_kind, owner$recipe$rng_kind) &&
    identical(as.integer(state$master_seed), as.integer(owner$recipe$seed)) &&
    identical(as.integer(state$chain_count), chain_count) &&
    identical(as.integer(state$worker_pool_capacity), as.integer(owner$recipe$worker_pool_capacity)) &&
    identical(state$chain_stream_policy, owner$recipe$chain_stream_policy) &&
    identical(state$chain_merge_order, owner$recipe$chain_merge_order) &&
    identical(as.integer(state$chain_id), seq_len(chain_count)) &&
    identical(as.integer(state$iteration), as.integer(expected_iteration)) &&
    identical(
      as.character(state$initial_stream_sha256),
      vapply(streams, .formal_mi_seed_identity_v43, character(1))
    ) && is.list(state$last_seed) && length(state$last_seed) == chain_count &&
    identical(
      as.character(state$last_seed_sha256),
      vapply(state$last_seed, .formal_mi_seed_identity_v43, character(1))
    ) && identical(mids_object$lastSeedValue, state$last_seed[[chain_count]])
  if (!isTRUE(valid)) .formal_mi_stop("MI_FORMAL_CHAIN_STATE_INVALID")
  invisible(state)
}

validate_formal_working_mids_v43 <- function(
    mids_object, runtime, projection, owner, mapping, expected_iteration) {
  validate_mi_runtime_spec_v43(runtime, projection, owner, mapping)
  if (!inherits(mids_object, "mids")) .formal_mi_stop("MI_FORMAL_MIDS_CLASS_INVALID")
  if (!identical(as.integer(mids_object$m), as.integer(owner$recipe$m))) {
    .formal_mi_stop("MI_FORMAL_MIDS_M_INVALID")
  }
  expected_iteration <- as.integer(expected_iteration)
  if (!expected_iteration %in% .mi_tx_iteration_plan_v43() ||
      !identical(as.integer(mids_object$iteration), expected_iteration)) {
    .formal_mi_stop("MI_FORMAL_MIDS_ITERATION_INVALID")
  }
  if (!identical(mids_object$data, runtime$data)) .formal_mi_stop("MI_FORMAL_MIDS_DATA_IDENTITY_MISMATCH")
  if (!identical(mids_object$method, runtime$method) ||
      !identical(mids_object$predictorMatrix, runtime$predictor_matrix) ||
      !identical(mids_object$blocks, runtime$blocks) ||
      !identical(mids_object$where, runtime$where) ||
      !identical(mids_object$blots, runtime$blots) ||
      !identical(mids_object$visitSequence, runtime$visit_sequence)) {
    .formal_mi_stop("MI_FORMAL_MIDS_RECIPE_IDENTITY_MISMATCH")
  }
  if (!identical(as.integer(mids_object$seed), as.integer(owner$recipe$seed)) ||
      !is.integer(mids_object$lastSeedValue) || !length(mids_object$lastSeedValue)) {
    .formal_mi_stop("MI_FORMAL_MIDS_RNG_IDENTITY_INVALID")
  }
  .formal_mi_validate_chain_state_v43(mids_object, owner, expected_iteration)
  expected_chain_names <- if (expected_iteration == as.integer(owner$recipe$maxit_initial)) {
    projection$working_names
  } else {
    projection$target_names
  }
  expected_chain_dim <- c(length(expected_chain_names), expected_iteration, as.integer(owner$recipe$m))
  if (!identical(dim(mids_object$chainMean), expected_chain_dim) ||
      !identical(dim(mids_object$chainVar), expected_chain_dim) ||
      !identical(dimnames(mids_object$chainMean)[[1L]], expected_chain_names) ||
      !identical(dimnames(mids_object$chainVar)[[1L]], expected_chain_names)) {
    .formal_mi_stop("MI_FORMAL_MIDS_CHAIN_IDENTITY_INVALID")
  }
  for (target in projection$target_names) {
    imputed <- mids_object$imp[[target]]
    if (!is.data.frame(imputed) || nrow(imputed) != sum(runtime$where[, target]) ||
        ncol(imputed) != as.integer(owner$recipe$m) ||
        any(!is.finite(as.matrix(imputed)))) {
      .formal_mi_stop("MI_FORMAL_MIDS_IMPUTATION_INVALID", target)
    }
  }
  logged_event_n <- if (is.null(mids_object$loggedEvents)) 0L else nrow(mids_object$loggedEvents)
  list(valid = TRUE, logged_event_n = as.integer(logged_event_n))
}

.formal_mi_parallel_map_v43 <- function(tasks, worker, pool_capacity) {
  pool_capacity <- as.integer(pool_capacity)
  if (!identical(Sys.getenv("AST_ALT_STATELESS_COMPUTE_NODE", unset = ""), "TRUE") ||
      !identical(suppressWarnings(as.integer(Sys.getenv("AST_ALT_WORKERS", unset = ""))), 24L) ||
      !identical(pool_capacity, 24L)) {
    .formal_mi_stop("FORMAL_MICE_REMOTE_POOL_REQUIRED")
  }
  cluster <- parallel::makePSOCKcluster(
    pool_capacity, homogeneous = TRUE,
    outfile = if (file.exists("/dev/null")) "/dev/null" else ""
  )
  on.exit(parallel::stopCluster(cluster), add = TRUE)
  if (!identical(length(cluster), pool_capacity)) .formal_mi_stop("FORMAL_MICE_POOL_CAPACITY_INVALID")
  parallel::parLapply(cluster, tasks, worker)
}

.formal_mi_initial_chain_worker_v43 <- function(task) {
  do.call(RNGkind, as.list(task$rng_kind))
  assign(".Random.seed", task$stream, envir = .GlobalEnv)
  object <- mice::mice(
    data = task$runtime$data, m = 1L, method = task$runtime$method,
    predictorMatrix = task$runtime$predictor_matrix, where = task$runtime$where,
    blocks = task$runtime$blocks, visitSequence = task$runtime$visit_sequence,
    blots = task$runtime$blots, maxit = task$maxit, printFlag = task$print_flag,
    seed = NA, remove.constant = task$remove_constant,
    remove.collinear = task$remove_collinear
  )
  object$seed <- task$master_seed
  list(chain_id = task$chain_id, object = object, last_seed = object$lastSeedValue)
}

.formal_mi_canonicalize_imp_v43 <- function(object) {
  data_names <- if (is.data.frame(object$data)) names(object$data) else character()
  target_names <- names(object$blocks)
  imp_names <- names(object$imp)
  m <- as.integer(object$m)
  valid <-
    inherits(object, "mids") && length(data_names) > 0L && !anyDuplicated(data_names) &&
    is.list(object$blocks) && length(target_names) > 0L && !anyDuplicated(target_names) &&
    identical(unname(unlist(object$blocks, use.names = FALSE)), target_names) &&
    !length(setdiff(target_names, data_names)) &&
    is.list(object$imp) && !is.null(imp_names) && !anyDuplicated(imp_names) &&
    (identical(imp_names, data_names) || setequal(imp_names, target_names)) &&
    is.matrix(object$where) && identical(colnames(object$where), data_names) &&
    length(m) == 1L && !is.na(m) && is.finite(m) && m > 0L
  if (!isTRUE(valid)) .formal_mi_stop("MI_FORMAL_IMPUTATION_CONTAINER_INVALID")
  if (identical(imp_names, data_names) && any(vapply(
    setdiff(data_names, target_names), function(name) !is.null(object$imp[[name]]), logical(1)
  ))) {
    .formal_mi_stop("MI_FORMAL_IMPUTATION_CONTAINER_INVALID")
  }
  target_valid <- vapply(target_names, function(target) {
    value <- object$imp[[target]]
    is.data.frame(value) && nrow(value) == sum(object$where[, target]) &&
      ncol(value) == m && identical(names(value), as.character(seq_len(m)))
  }, logical(1))
  if (!all(target_valid)) .formal_mi_stop("MI_FORMAL_IMPUTATION_CONTAINER_INVALID")
  canonical <- stats::setNames(vector("list", length(data_names)), data_names)
  canonical[target_names] <- object$imp[target_names]
  object$imp <- canonical
  object
}

.formal_mi_canonicalize_bound_imp_v43 <- function(object, left, right) {
  data_names <- if (is.data.frame(object$data)) names(object$data) else character()
  target_names <- names(object$blocks)
  imp_names <- names(object$imp)
  merged_m <- as.integer(left$m) + as.integer(right$m)
  valid <-
    inherits(object, "mids") && length(data_names) > 0L && !anyDuplicated(data_names) &&
    is.list(object$blocks) && length(target_names) > 0L && !anyDuplicated(target_names) &&
    identical(unname(unlist(object$blocks, use.names = FALSE)), target_names) &&
    is.list(object$imp) && !is.null(imp_names) && !anyDuplicated(imp_names) &&
    (identical(imp_names, data_names) || setequal(imp_names, target_names)) &&
    length(merged_m) == 1L && !is.na(merged_m) && merged_m > 0L &&
    identical(as.integer(object$m), merged_m)
  if (!isTRUE(valid)) .formal_mi_stop("MI_FORMAL_IMPUTATION_CONTAINER_INVALID")
  for (target in target_names) {
    value <- object$imp[[target]]
    left_value <- left$imp[[target]]
    right_value <- right$imp[[target]]
    raw_names <- c(names(left_value), names(right_value))
    canonical_names <- as.character(seq_len(merged_m))
    if (!is.data.frame(value) || !is.data.frame(left_value) || !is.data.frame(right_value) ||
        nrow(value) != nrow(left_value) || nrow(value) != nrow(right_value) ||
        ncol(value) != merged_m ||
        !(identical(names(value), raw_names) || identical(names(value), canonical_names))) {
      .formal_mi_stop("MI_FORMAL_IMPUTATION_CONTAINER_INVALID")
    }
    expected <- cbind(left_value, right_value)
    names(expected) <- canonical_names
    normalized <- value
    names(normalized) <- canonical_names
    if (!identical(normalized, expected)) {
      .formal_mi_stop("MI_FORMAL_IMPUTATION_CONTAINER_INVALID")
    }
    names(value) <- canonical_names
    object$imp[[target]] <- value
  }
  .formal_mi_canonicalize_imp_v43(object)
}

.formal_mi_bind_chain_results_v43 <- function(results, owner, iteration, binder = NULL) {
  chain_count <- as.integer(owner$recipe$chain_count)
  order <- order(vapply(results, function(result) as.integer(result$chain_id), integer(1)))
  results <- results[order]
  if (!identical(vapply(results, function(result) as.integer(result$chain_id), integer(1)), seq_len(chain_count))) {
    .formal_mi_stop("MI_FORMAL_CHAIN_ORDER_INVALID")
  }
  if (is.null(binder)) {
    if (!requireNamespace("mice", quietly = TRUE)) {
      .formal_mi_stop("FORMAL_MICE_DEPENDENCY_MISSING", "mice")
    }
    binder <- mice::ibind
  }
  objects <- lapply(results, function(result) .formal_mi_canonicalize_imp_v43(result$object))
  merged <- Reduce(function(left, right) {
    # mice::ibind drops NULL list slots for non-imputed columns; restore the
    # documented full-data positional container after every deterministic pair.
    .formal_mi_canonicalize_bound_imp_v43(binder(left, right), left, right)
  }, objects)
  merged$m <- chain_count
  merged$seed <- as.integer(owner$recipe$seed)
  merged$lastSeedValue <- results[[chain_count]]$last_seed
  logged <- lapply(results, function(result) result$object$loggedEvents)
  nonempty <- which(vapply(logged, function(value) is.data.frame(value) && nrow(value) > 0L, logical(1)))
  malformed <- vapply(logged, function(value) {
    !is.null(value) && (!is.data.frame(value) || (nrow(value) > 0L && !"im" %in% names(value)))
  }, logical(1))
  if (any(malformed) || (length(nonempty) > 1L &&
      !all(vapply(logged[nonempty], function(value) {
        identical(names(value), names(logged[[nonempty[[1L]]]]))
      }, logical(1))))) {
    .formal_mi_stop("MI_FORMAL_CHAIN_LOGGED_EVENT_INVALID")
  }
  if (length(nonempty)) {
    rows <- lapply(nonempty, function(chain_id) {
      value <- logged[[chain_id]]
      value$im <- as.integer(chain_id)
      value
    })
    merged$loggedEvents <- do.call(rbind, rows)
    rownames(merged$loggedEvents) <- NULL
  } else {
    merged$loggedEvents <- NULL
  }
  expected_chain_names <- paste("Chain", seq_len(chain_count))
  if (length(dim(merged$chainMean)) == 3L) dimnames(merged$chainMean)[[3L]] <- expected_chain_names
  if (length(dim(merged$chainVar)) == 3L) dimnames(merged$chainVar)[[3L]] <- expected_chain_names
  attr(merged, "formal_chain_state_v43") <- .formal_mi_chain_state_v43(results, owner, iteration)
  merged
}

.formal_mi_initial_call <- function(
    runtime, owner, print_flag, mapper = .formal_mi_parallel_map_v43, binder = NULL) {
  if (!requireNamespace("mice", quietly = TRUE)) .formal_mi_stop("FORMAL_MICE_DEPENDENCY_MISSING", "mice")
  chain_count <- as.integer(owner$recipe$chain_count)
  streams <- .formal_mi_initial_streams_v43(owner$recipe$seed, chain_count)
  tasks <- lapply(seq_len(chain_count), function(chain_id) list(
    chain_id = chain_id, stream = streams[[chain_id]], rng_kind = runtime$rng_kind,
    runtime = runtime, maxit = as.integer(owner$recipe$maxit_initial),
    print_flag = isTRUE(print_flag), master_seed = as.integer(owner$recipe$seed),
    remove_constant = isTRUE(owner$recipe$remove_constant),
    remove_collinear = isTRUE(owner$recipe$remove_collinear)
  ))
  results <- mapper(
    tasks, .formal_mi_initial_chain_worker_v43,
    as.integer(owner$recipe$worker_pool_capacity)
  )
  .formal_mi_bind_chain_results_v43(
    results, owner, as.integer(owner$recipe$maxit_initial), binder
  )
}

.formal_mi_prepare_continuation_chain_v43 <- function(previous, target_names) {
  data_names <- if (is.data.frame(previous$data)) names(previous$data) else character()
  chain_mean <- previous$chainMean
  chain_var <- previous$chainVar
  mean_names <- if (length(dim(chain_mean)) == 3L) dimnames(chain_mean)[[1L]] else NULL
  var_names <- if (length(dim(chain_var)) == 3L) dimnames(chain_var)[[1L]] else NULL
  block_ids <- names(previous$blocks)
  block_names <- unique(unlist(previous$blocks, use.names = FALSE))
  valid <-
    length(data_names) > 0L && !anyDuplicated(data_names) &&
    is.character(target_names) && length(target_names) > 0L && !anyDuplicated(target_names) &&
    identical(block_ids, target_names) && identical(block_names, target_names) &&
    identical(as.character(previous$visitSequence), target_names) &&
    !length(setdiff(target_names, data_names)) &&
    identical(dim(chain_mean), dim(chain_var)) &&
    identical(dimnames(chain_mean), dimnames(chain_var)) &&
    identical(mean_names, var_names) && !anyDuplicated(mean_names) &&
    (identical(mean_names, data_names) || identical(mean_names, target_names))
  if (!isTRUE(valid)) .formal_mi_stop("MI_FORMAL_MIDS_CHAIN_IDENTITY_INVALID")

  expand_chain <- function(chain) {
    if (identical(dimnames(chain)[[1L]], data_names)) return(chain)
    expanded <- array(
      NA_real_,
      dim = c(length(data_names), dim(chain)[[2L]], dim(chain)[[3L]]),
      dimnames = list(data_names, dimnames(chain)[[2L]], dimnames(chain)[[3L]])
    )
    expanded[target_names, , ] <- chain[target_names, , , drop = FALSE]
    expanded
  }
  previous$chainMean <- expand_chain(chain_mean)
  previous$chainVar <- expand_chain(chain_var)
  previous$blocks <- stats::setNames(as.list(data_names), data_names)
  previous
}

.formal_mi_extract_chain_v43 <- function(previous, chain_id) {
  state <- attr(previous, "formal_chain_state_v43", exact = TRUE)
  chain_id <- as.integer(chain_id)
  if (!is.list(state) || !chain_id %in% state$chain_id ||
      !identical(as.integer(state$chain_id), seq_len(as.integer(state$chain_count)))) {
    .formal_mi_stop("MI_FORMAL_CHAIN_STATE_INVALID")
  }
  chain <- .formal_mi_canonicalize_imp_v43(previous)
  target_names <- names(chain$blocks)
  attr(chain, "formal_chain_state_v43") <- NULL
  chain$m <- 1L
  # Continuation uses name-addressed target imputations. Keep the persisted
  # full-data positional container out of mice.mids while preserving target order.
  chain$imp <- lapply(chain$imp[target_names], function(imputed) {
    if (!is.data.frame(imputed) || ncol(imputed) < chain_id) {
      .formal_mi_stop("MI_FORMAL_CHAIN_IMPUTATION_INVALID")
    }
    value <- imputed[, chain_id, drop = FALSE]
    names(value) <- "1"
    value
  })
  chain$chainMean <- chain$chainMean[, , chain_id, drop = FALSE]
  chain$chainVar <- chain$chainVar[, , chain_id, drop = FALSE]
  dimnames(chain$chainMean)[[3L]] <- "Chain 1"
  dimnames(chain$chainVar)[[3L]] <- "Chain 1"
  if (is.data.frame(chain$loggedEvents) && "im" %in% names(chain$loggedEvents)) {
    chain$loggedEvents <- chain$loggedEvents[chain$loggedEvents$im == chain_id, , drop = FALSE]
    chain$loggedEvents$im <- 1L
  }
  chain$lastSeedValue <- state$last_seed[[chain_id]]
  chain
}

.formal_mi_continuation_chain_worker_v43 <- function(task) {
  do.call(RNGkind, as.list(task$rng_kind))
  assign(".Random.seed", task$last_seed, envir = .GlobalEnv)
  object <- mice::mice.mids(
    task$previous, maxit = task$delta, printFlag = task$print_flag
  )
  object$seed <- task$master_seed
  list(chain_id = task$chain_id, object = object, last_seed = object$lastSeedValue)
}

.formal_mi_restore_continuation_recipe_v43 <- function(
    continued, recipe, data_names, target_names, retain_full_chain = FALSE) {
  aligned <-
    identical(names(continued$data), data_names) &&
    identical(dim(continued$chainMean), dim(continued$chainVar)) &&
    identical(dimnames(continued$chainMean), dimnames(continued$chainVar)) &&
    identical(dimnames(continued$chainMean)[[1L]], data_names)
  if (!isTRUE(aligned)) .formal_mi_stop("MI_FORMAL_MIDS_CHAIN_IDENTITY_INVALID")
  if (!isTRUE(retain_full_chain)) {
    continued$chainMean <- continued$chainMean[target_names, , , drop = FALSE]
    continued$chainVar <- continued$chainVar[target_names, , , drop = FALSE]
  }
  for (field in names(recipe)) continued[[field]] <- recipe[[field]]
  continued
}

.formal_mi_continuation_call <- function(
    previous, target_names, delta, print_flag, owner,
    mapper = .formal_mi_parallel_map_v43, binder = NULL) {
  if (!requireNamespace("mice", quietly = TRUE)) .formal_mi_stop("FORMAL_MICE_DEPENDENCY_MISSING", "mice")
  recipe_fields <- c(
    "blocks", "method", "predictorMatrix", "where", "blots", "formulas",
    "calltype", "post", "ignore", "seed", "visitSequence"
  )
  recipe <- previous[recipe_fields]
  data_names <- names(previous$data)
  state <- .formal_mi_validate_chain_state_v43(previous, owner, previous$iteration)
  tasks <- lapply(state$chain_id, function(chain_id) {
    chain <- .formal_mi_extract_chain_v43(previous, chain_id)
    list(
      chain_id = chain_id,
      previous = .formal_mi_prepare_continuation_chain_v43(chain, target_names),
      last_seed = state$last_seed[[chain_id]],
      rng_kind = strsplit(owner$recipe$rng_kind, "|", fixed = TRUE)[[1L]],
      delta = as.integer(delta), print_flag = isTRUE(print_flag),
      master_seed = as.integer(owner$recipe$seed)
    )
  })
  results <- mapper(
    tasks, .formal_mi_continuation_chain_worker_v43,
    as.integer(owner$recipe$worker_pool_capacity)
  )
  results <- lapply(results, function(result) {
    result$object <- .formal_mi_restore_continuation_recipe_v43(
      result$object, recipe, data_names, target_names, retain_full_chain = TRUE
    )
    result
  })
  merged <- .formal_mi_bind_chain_results_v43(
    results, owner, as.integer(previous$iteration) + as.integer(delta), binder
  )
  merged$chainMean <- merged$chainMean[target_names, , , drop = FALSE]
  merged$chainVar <- merged$chainVar[target_names, , , drop = FALSE]
  merged
}

execute_formal_mice_step_v43 <- function(
    admission, runtime, projection, owner, mapping,
    execution_profile, authorization, authorization_file_sha256,
    print_flag = TRUE, project_root = ".") {
  if (!is.list(admission) || !is.list(admission$request) ||
      !admission$action %in% c("START_INITIAL", "START_CONTINUATION") ||
      !dir.exists(admission$lease_path)) {
    .formal_mi_stop("FORMAL_MICE_ADMISSION_INVALID")
  }
  outcome <- tryCatch({
    assert_formal_mice_authorized_v43(execution_profile, authorization, admission$request)
    validate_mi_transaction_authorization_v43(
      admission$transaction_path, admission$request, authorization,
      authorization_file_sha256, project_root
    )
    validate_mi_runtime_spec_v43(runtime, projection, owner, mapping)
    .assert_formal_request_matches_runtime_v43(
      admission$request, runtime, projection, owner, mapping,
      admission$transaction_path, project_root
    )
    preflight_mi_design_v43(runtime, projection, owner, mapping)
    desired <- as.integer(admission$desired_iteration)
    if (identical(admission$action, "START_INITIAL")) {
      if (desired != as.integer(owner$recipe$maxit_initial)) .formal_mi_stop("MI_CONTINUATION_SEQUENCE_INVALID")
      object <- .formal_mi_initial_call(runtime, owner, print_flag)
    } else {
      previous_path <- file.path(admission$checkpoint$checkpoint_path, "mids_checkpoint.rds")
      if (!file.exists(previous_path) ||
          !identical(.mi_tx_sha256_file(previous_path), admission$checkpoint$object_sha256)) {
        .formal_mi_stop("MI_CHECKPOINT_INTEGRITY_FAILED")
      }
      # 中文备注：读取受限 formal MICE checkpoint 以恢复同一链。
      previous <- readRDS(previous_path)
      current <- as.integer(admission$checkpoint$iteration)
      validate_formal_working_mids_v43(previous, runtime, projection, owner, mapping, current)
      delta <- formal_mice_continuation_delta_v43(current, desired)
      object <- .formal_mi_continuation_call(
        previous, projection$target_names, delta, print_flag, owner
      )
    }
    validation <- validate_formal_working_mids_v43(object, runtime, projection, owner, mapping, desired)
    checkpoint <- .publish_mi_checkpoint_v43(
      admission, object = object, iteration = desired,
      predictor_matrix_sha256 = runtime$predictor_matrix_sha256,
      predictor_edge_n = runtime$predictor_edge_n, object_class = "mids"
    )
    list(validation = validation, checkpoint = checkpoint, desired = desired)
  }, error = function(error) {
    failure <- publish_mi_failure_terminal_v43(
      admission, "MICE_STEP_ERROR", conditionMessage(error)
    )
    .formal_mi_stop("FORMAL_MICE_EXECUTION_FAILED", failure$failure_signature)
  })
  list(
    status = if (outcome$validation$logged_event_n == 0L) "CHECKPOINTED" else "CHECKPOINTED_BLOCKING_LOGGED_EVENT",
    iteration = outcome$desired,
    continuation_count = outcome$checkpoint$continuation_count,
    logged_event_n = outcome$validation$logged_event_n,
    checkpoint_path = outcome$checkpoint$checkpoint_path,
    checkpoint_sha256 = outcome$checkpoint$checkpoint_sha256,
    object_sha256 = outcome$checkpoint$object_sha256
  )
}

run_formal_mice_transaction_step_v43 <- function(
    transaction_root, source_receipt, runtime, projection, owner, mapping,
    desired_iteration, execution_profile, authorization, authorization_file_sha256,
    request = NULL, print_flag = TRUE,
    project_root = ".") {
  current_request <- build_mi_transaction_request_v43(
    source_receipt, runtime, projection, owner, mapping, project_root
  )
  if (is.null(request)) request <- current_request
  validate_mi_transaction_request_v43(request)
  transaction_path <- file.path(.mi_tx_assert_root(transaction_root), request$request_sha256)
  if (!identical(request, current_request)) {
    validate_formal_mice_repair_bridge_v43(
      request, current_request, transaction_path, project_root
    )
  }
  assert_formal_mice_authorized_v43(execution_profile, authorization, request)
  admission <- admit_mi_transaction_v43(
    transaction_root, request, desired_iteration, authorization,
    authorization_file_sha256, project_root
  )
  if (!admission$action %in% c("START_INITIAL", "START_CONTINUATION")) {
    return(list(
      status = admission$action,
      request_sha256 = request$request_sha256,
      desired_iteration = as.integer(desired_iteration),
      transaction_path = admission$transaction_path
    ))
  }
  execute_formal_mice_step_v43(
    admission = admission,
    runtime = runtime,
    projection = projection,
    owner = owner,
    mapping = mapping,
    execution_profile = execution_profile,
    authorization = authorization,
    authorization_file_sha256 = authorization_file_sha256,
    print_flag = print_flag,
    project_root = project_root
  )
}
