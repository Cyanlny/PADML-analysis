# 阶段门禁：将 QC、warning、人工决定和 runner 续行规则转为机器状态。

.utc_now_rfc3339 <- function() {
  format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
}

.is_scalar_string <- function(value) {
  is.character(value) && length(value) == 1L && !is.na(value)
}

.is_sha256 <- function(value) {
  .is_scalar_string(value) && grepl("^[0-9a-f]{64}$", value)
}

.is_rfc3339 <- function(value) {
  if (!.is_scalar_string(value)) return(FALSE)
  pattern <- "^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(\\.[0-9]+)?(Z|[+-][0-9]{2}:[0-9]{2})$"
  if (!grepl(pattern, value, perl = TRUE)) return(FALSE)
  if (!grepl("Z$", value)) {
    offset <- substr(value, nchar(value) - 5L, nchar(value))
    if (as.integer(substr(offset, 2L, 3L)) > 23L || as.integer(substr(offset, 5L, 6L)) > 59L) return(FALSE)
  }
  normalized <- if (grepl("Z$", value)) {
    sub("Z$", "+0000", value)
  } else {
    sub("([+-][0-9]{2}):([0-9]{2})$", "\\1\\2", value, perl = TRUE)
  }
  parsed <- suppressWarnings(strptime(normalized, format = "%Y-%m-%dT%H:%M:%OS%z", tz = "UTC"))
  length(parsed) == 1L && !is.na(parsed)
}

.control_schema_path <- function(file_name) {
  project_root <- Sys.getenv("AST_ALT_PROJECT_ROOT", unset = "")
  candidates <- unique(c(
    if (nzchar(project_root)) file.path(project_root, "schemas", file_name) else character(),
    file.path(getwd(), "schemas", file_name)
  ))
  existing <- candidates[file.exists(candidates)]
  if (!length(existing)) stop("Control-plane schema is missing: ", file_name, call. = FALSE)
  normalizePath(existing[[1L]], mustWork = TRUE)
}

.validate_flat_json_object <- function(object, schema) {
  errors <- character()
  if (!is.list(object) || is.data.frame(object) || is.null(names(object)) || any(!nzchar(names(object)))) {
    return(list(valid = FALSE, errors = "top_level_object_required"))
  }
  if (anyDuplicated(names(object))) errors <- c(errors, "duplicate_property")
  required <- as.character(schema$required)
  allowed <- names(schema$properties)
  missing <- setdiff(required, names(object))
  unknown <- setdiff(names(object), allowed)
  if (length(missing)) errors <- c(errors, paste0("missing:", paste(missing, collapse = ",")))
  if (isFALSE(schema$additionalProperties) && length(unknown)) {
    errors <- c(errors, paste0("unknown:", paste(unknown, collapse = ",")))
  }
  for (name in intersect(names(object), allowed)) {
    value <- object[[name]]
    rule <- schema$properties[[name]]
    type <- if (is.null(rule$type)) "" else as.character(rule$type)
    if (identical(type, "string") && !.is_scalar_string(value)) {
      errors <- c(errors, paste0(name, ":type"))
      next
    }
    if (identical(type, "boolean") && !(is.logical(value) && length(value) == 1L && !is.na(value))) {
      errors <- c(errors, paste0(name, ":type"))
      next
    }
    if (!is.null(rule$enum) && !(length(value) == 1L && !is.na(value) && value %in% as.character(rule$enum))) {
      errors <- c(errors, paste0(name, ":enum"))
    }
    if (!is.null(rule$const) && !identical(value, rule$const)) errors <- c(errors, paste0(name, ":const"))
    if (!is.null(rule$minLength) && .is_scalar_string(value) && nchar(trimws(value), type = "chars") < as.integer(rule$minLength)) {
      errors <- c(errors, paste0(name, ":minLength"))
    }
    if (!is.null(rule$pattern) && .is_scalar_string(value) && !grepl(rule$pattern, value, perl = TRUE)) {
      errors <- c(errors, paste0(name, ":pattern"))
    }
    if (!is.null(rule$format) && identical(rule$format, "date-time") && !.is_rfc3339(value)) {
      errors <- c(errors, paste0(name, ":date-time"))
    }
  }
  list(valid = !length(errors), errors = unique(errors))
}

sha256_text <- function(text) {
  # 加载摘要包并计算规范文本的 SHA-256。
  if (!requireNamespace("digest", quietly = TRUE)) stop("digest is required", call. = FALSE)
  digest::digest(enc2utf8(paste(text, collapse = "\n")), algo = "sha256", serialize = FALSE)
}

allowed_stage_statuses <- function() {
  c(
    "PASS_AUTO_CONTINUE",
    "PASS_WITH_NONBLOCKING_WARNINGS",
    "PASS_HUMAN_APPROVED",
    "WARNING_WAITING_FOR_HUMAN_REVIEW",
    "SCIENTIFIC_CONFIG_CANDIDATE_WAITING_FOR_HUMAN_REVIEW",
    "RESOURCE_GATE_WAITING_FOR_HUMAN_REVIEW",
    "FAIL_WAITING_FOR_HUMAN_REVIEW",
    "STOP_PROJECT"
  )
}

determine_stage_status <- function(stage, qc_results, warnings = data.frame(), scientific_config_candidate = FALSE) {
  if (!.is_scalar_string(stage)) stop("Stage must be a scalar string", call. = FALSE)
  if (!is.data.frame(qc_results) || !all(c("status", "severity") %in% names(qc_results))) {
    stop("QC results require status and severity", call. = FALSE)
  }
  qc_status <- as.character(qc_results$status)
  qc_severity <- as.character(qc_results$severity)
  warning_class <- if (is.data.frame(warnings) && "class" %in% names(warnings)) as.character(warnings$class) else character()
  warning_code <- if (is.data.frame(warnings) && "warning_code" %in% names(warnings)) as.character(warnings$warning_code) else character()
  qc_id <- if ("qc_id" %in% names(qc_results)) as.character(qc_results$qc_id) else rep("", nrow(qc_results))
  qc_check <- if ("check" %in% names(qc_results)) as.character(qc_results$check) else rep("", nrow(qc_results))
  nonpass <- qc_status %in% c("FAIL", "WARNING", "STOP_PROJECT")

  stop_requested <- any(qc_status == "STOP_PROJECT" | qc_severity == "STOP_PROJECT") ||
    any(warning_class == "STOP_PROJECT" | warning_code == "W_STOP_PROJECT")
  hard_fail <- any(qc_status == "FAIL" & qc_severity == "HARD_STOP") ||
    any(warning_class == "FAIL" | warning_class == "HARD_STOP")
  resource <- any(nonpass & (qc_id %in% c("P00_RESOURCE", "QC002") | qc_check == "runtime_budget")) ||
    any(warning_code == "W_RESOURCE_GATE" | warning_class == "RESOURCE_GATE")
  blocking <- any(nonpass & qc_severity == "BLOCKING_WARNING") || any(warning_class == "BLOCKING_WARNING")
  nonblocking <- any(qc_status == "WARNING" & qc_severity == "NONBLOCKING_WARNING") ||
    any(warning_class == "NONBLOCKING_WARNING")

  if (stop_requested) return("STOP_PROJECT")
  if (hard_fail) return("FAIL_WAITING_FOR_HUMAN_REVIEW")
  if (resource) return("RESOURCE_GATE_WAITING_FOR_HUMAN_REVIEW")
  if (isTRUE(scientific_config_candidate)) return("SCIENTIFIC_CONFIG_CANDIDATE_WAITING_FOR_HUMAN_REVIEW")
  if (blocking) return("WARNING_WAITING_FOR_HUMAN_REVIEW")
  if (nonblocking) return("PASS_WITH_NONBLOCKING_WARNINGS")
  "PASS_AUTO_CONTINUE"
}

write_stage_result <- function(
    stage, status, public_bundle = "", restricted_bundle = "", review_package = "",
    candidate = FALSE, root = ".", failure_envelope = "", failure_signature_sha256 = "") {
  if (!status %in% allowed_stage_statuses()) stop("Invalid stage status", call. = FALSE)
  dir.create(file.path(root, "runtime"), recursive = TRUE, showWarnings = FALSE)
  # 加载 JSON 包并写入 runner 唯一读取的阶段结果。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  result <- list(
    stage = stage,
    stage_status = status,
    public_bundle = public_bundle,
    restricted_bundle = restricted_bundle,
    review_package = review_package,
    candidate = isTRUE(candidate),
    failure_envelope = failure_envelope,
    failure_signature_sha256 = failure_signature_sha256,
    created_at = .utc_now_rfc3339()
  )
  path <- file.path(root, "runtime", paste0("stage_result_", stage, ".json"))
  jsonlite::write_json(result, path, auto_unbox = TRUE, pretty = TRUE)
  path
}

validate_human_decision <- function(path, expected_stage, expected_lock_sha256) {
  invalid <- function(reason, checks = logical(), decision = NULL) {
    list(valid = FALSE, reason = reason, checks = checks, decision = decision)
  }
  if (!file.exists(path)) return(invalid("decision_file_missing"))
  # 加载 JSON 包并读取人工审批文件和严格字段 Schema。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  parsed <- tryCatch(
    list(
      decision = jsonlite::read_json(path, simplifyVector = TRUE),
      schema = jsonlite::read_json(.control_schema_path("review_decision_schema.json"), simplifyVector = TRUE)
    ),
    error = identity
  )
  if (inherits(parsed, "error")) return(invalid("decision_json_or_schema_invalid"))
  schema_check <- .validate_flat_json_object(parsed$decision, parsed$schema)
  checks <- c(
    schema = isTRUE(schema_check$valid),
    expected_stage = .is_scalar_string(expected_stage),
    expected_lock = .is_sha256(expected_lock_sha256),
    stage = .is_scalar_string(parsed$decision$stage) && identical(parsed$decision$stage, expected_stage),
    lock = .is_sha256(parsed$decision$approved_stage_lock_sha256) &&
      identical(parsed$decision$approved_stage_lock_sha256, expected_lock_sha256)
  )
  valid <- length(checks) == 5L && all(checks)
  list(
    valid = valid,
    reason = if (valid) "valid" else paste(c(schema_check$errors, names(checks)[!checks]), collapse = ";"),
    checks = checks,
    decision = parsed$decision
  )
}

resolve_stage_continuation <- function(
    stage_result, execution_mode = "continuous", decision_path = "", stage_lock_sha256 = "") {
  status <- stage_result$stage_status
  if (!status %in% allowed_stage_statuses()) stop("Unknown stage status", call. = FALSE)
  if (identical(status, "STOP_PROJECT")) {
    return(list(continue = FALSE, exit_code = 31L, reason = "stop_project_terminal"))
  }
  if (identical(status, "FAIL_WAITING_FOR_HUMAN_REVIEW")) {
    return(list(continue = FALSE, exit_code = 30L, reason = "fail_terminal_repair_required"))
  }
  if (identical(status, "RESOURCE_GATE_WAITING_FOR_HUMAN_REVIEW")) {
    return(list(continue = FALSE, exit_code = 32L, reason = "resource_recheck_required"))
  }
  if (identical(status, "PASS_HUMAN_APPROVED")) {
    return(list(continue = TRUE, exit_code = 0L, reason = "recorded_human_approval"))
  }

  pass <- status %in% c("PASS_AUTO_CONTINUE", "PASS_WITH_NONBLOCKING_WARNINGS")
  if (pass && identical(execution_mode, "continuous")) {
    return(list(continue = TRUE, exit_code = 0L, reason = "gate_pass"))
  }
  decision <- validate_human_decision(decision_path, stage_result$stage, stage_lock_sha256)
  if (!isTRUE(decision$valid)) {
    reason <- if (pass) "stagewise_review_pause" else "human_review_required"
    return(list(continue = FALSE, exit_code = if (pass) 20L else 21L, reason = reason))
  }
  if (identical(decision$decision$decision, "APPROVE_NEXT_STAGE")) {
    reason <- if (pass) "stagewise_human_approval" else "human_approval"
    return(list(continue = TRUE, exit_code = 0L, reason = reason))
  }
  list(continue = FALSE, exit_code = 22L, reason = decision$decision$decision)
}

canonicalize_failure_message <- function(message) {
  value <- enc2utf8(paste(message, collapse = " "))
  value <- gsub("\\\\", "/", value)
  value <- gsub(
    "[0-9]{4}-[0-9]{2}-[0-9]{2}[T ][0-9]{2}:[0-9]{2}:[0-9]{2}(\\.[0-9]+)?(Z|[+-][0-9]{2}:[0-9]{2})?",
    "<TIMESTAMP>", value, perl = TRUE
  )
  value <- gsub("([A-Za-z]:)?/[^[:space:]]+", "<PATH>", value, perl = TRUE)
  value <- gsub("\\b[0-9a-fA-F]{12,}\\b", "<HEX>", value, perl = TRUE)
  value <- gsub("\\bline[[:space:]]+[0-9]+\\b", "line <N>", value, ignore.case = TRUE, perl = TRUE)
  trimws(gsub("[[:space:]]+", " ", value))
}

canonical_failure_signature <- function(
    stage, condition, target = "", failure_code = "UNHANDLED_STAGE_ERROR") {
  condition_class <- if (inherits(condition, "condition")) class(condition)[[1L]] else class(condition)[[1L]]
  message <- if (inherits(condition, "condition")) conditionMessage(condition) else as.character(condition)
  canonical <- c(
    paste0("stage=", stage),
    paste0("target=", target),
    paste0("failure_code=", failure_code),
    paste0("condition_class=", condition_class),
    paste0("message=", canonicalize_failure_message(message))
  )
  sha256_text(canonical)
}

.canonical_json <- function(object) {
  # 加载 JSON 包并生成 repair ledger 的规范单行表示。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  as.character(jsonlite::toJSON(
    object, auto_unbox = TRUE, null = "null", na = "null", digits = NA,
    POSIXt = "ISO8601", pretty = FALSE
  ))
}

.read_repair_ledger <- function(path) {
  if (!file.exists(path)) return(list())
  lines <- readLines(path, warn = FALSE, encoding = "UTF-8")
  if (any(!nzchar(lines))) stop("Repair ledger contains an empty event", call. = FALSE)
  # 加载 JSON 包并校验 append-only ledger 哈希链。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  events <- lapply(lines, function(line) jsonlite::fromJSON(line, simplifyVector = TRUE))
  previous <- paste(rep("0", 64L), collapse = "")
  for (index in seq_along(events)) {
    event <- events[[index]]
    if (!identical(as.integer(event$event_index), as.integer(index))) stop("Repair ledger event index mismatch", call. = FALSE)
    if (!identical(event$previous_event_sha256, previous)) stop("Repair ledger hash chain mismatch", call. = FALSE)
    supplied <- event$event_sha256
    event$event_sha256 <- NULL
    observed <- sha256_text(.canonical_json(event))
    if (!identical(supplied, observed)) stop("Repair ledger event hash mismatch", call. = FALSE)
    previous <- supplied
  }
  events
}

update_repair_state <- function(
    stage, failure_signature, root = ".", revision = Sys.getenv("AST_ALT_EXECUTION_REVISION_SHA256", ""),
    stop_on_exceeded = TRUE) {
  if (!.is_scalar_string(stage)) stop("Repair stage must be a scalar string", call. = FALSE)
  if (!.is_sha256(failure_signature)) stop("Failure signature must be 64hex", call. = FALSE)
  if (!.is_sha256(revision)) stop("Execution revision must be 64hex", call. = FALSE)
  dir.create(file.path(root, "runtime"), recursive = TRUE, showWarnings = FALSE)
  path <- file.path(root, "runtime", paste0("repair_ledger_", stage, ".jsonl"))
  events <- .read_repair_ledger(path)
  matching <- Filter(
    function(event) {
      identical(event$stage, stage) &&
        identical(event$failure_signature_sha256, failure_signature) &&
        isTRUE(event$accepted_revision)
    },
    events
  )
  accepted_revisions <- unique(vapply(matching, `[[`, character(1), "execution_revision_sha256"))
  already_seen <- revision %in% accepted_revisions
  repair_round <- if (already_seen) match(revision, accepted_revisions) - 1L else length(accepted_revisions)
  accepted <- already_seen || repair_round <= 2L
  event_type <- if (already_seen) {
    "RETRY_SAME_REVISION"
  } else if (!accepted) {
    "REPAIR_LIMIT_EXCEEDED"
  } else if (repair_round == 0L) {
    "INITIAL_FAILURE"
  } else {
    "TECHNICAL_REPAIR_REVISION"
  }
  previous_sha <- if (length(events)) events[[length(events)]]$event_sha256 else paste(rep("0", 64L), collapse = "")
  event <- list(
    ledger_schema_version = "REPAIR_LEDGER_R04_V1",
    event_index = as.integer(length(events) + 1L),
    stage = stage,
    failure_signature_sha256 = failure_signature,
    execution_revision_sha256 = revision,
    event_type = event_type,
    repair_round = as.integer(repair_round),
    accepted_revision = isTRUE(accepted),
    occurred_at = .utc_now_rfc3339(),
    previous_event_sha256 = previous_sha
  )
  event$event_sha256 <- sha256_text(.canonical_json(event))
  # 追加写入 repair ledger；历史事件不覆盖、不重排。
  connection <- file(path, open = "at", encoding = "UTF-8")
  on.exit(close(connection), add = TRUE)
  writeLines(.canonical_json(event), connection, sep = "\n", useBytes = TRUE)
  Sys.chmod(path, mode = "0600", use_umask = FALSE)
  state <- list(
    stage = stage,
    failure_signature_sha256 = failure_signature,
    execution_revision_sha256 = revision,
    event_type = event_type,
    repair_round = as.integer(repair_round),
    allowed = isTRUE(accepted),
    ledger_event_index = event$event_index,
    ledger_event_sha256 = event$event_sha256,
    ledger_path = path
  )
  if (!accepted && isTRUE(stop_on_exceeded)) {
    stop("Repair limit exceeded for identical failure signature", call. = FALSE)
  }
  state
}
