# 执行配置守卫：阻止 profile 越权和真实数据误读。
parse_strict_pipeline_args <- function(
    args = commandArgs(trailingOnly = TRUE),
    env_handoff = Sys.getenv("AST_ALT_HANDOFF_ZIP", "")) {
  stop_cli <- function(code, detail = "") {
    message <- if (nzchar(detail)) paste(code, detail, sep = ": ") else code
    stop(message, call. = FALSE)
  }

  raw_source <- grepl("^--source-xlsx(?:=|$)", args, perl = TRUE)
  if (any(raw_source)) stop_cli("RAW_SOURCE_FORBIDDEN_IN_ANALYSIS_RUNNER")

  value_flags <- c(
    "--execution-profile" = "profile",
    "--execution-mode" = "execution_mode",
    "--handoff-zip" = "handoff_zip",
    "--run-id" = "run_id",
    "--run-root" = "run_root"
  )
  boolean_flags <- c("--dry-run")
  values <- list(
    profile = "build_validation",
    execution_mode = "continuous",
    handoff_zip = "",
    run_id = "",
    run_root = "",
    dry_run = FALSE
  )
  seen <- character()
  index <- 1L
  while (index <= length(args)) {
    token <- args[[index]]
    if (token %in% boolean_flags) {
      if (token %in% seen) stop_cli("CLI_ARGUMENT_DUPLICATE", token)
      seen <- c(seen, token)
      values$dry_run <- TRUE
      index <- index + 1L
      next
    }
    if (!token %in% names(value_flags)) stop_cli("CLI_ARGUMENT_UNKNOWN", token)
    if (token %in% seen) stop_cli("CLI_ARGUMENT_DUPLICATE", token)
    if (index == length(args) || startsWith(args[[index + 1L]], "--")) {
      stop_cli("CLI_ARGUMENT_VALUE_MISSING", token)
    }
    seen <- c(seen, token)
    values[[unname(value_flags[[token]])]] <- args[[index + 1L]]
    index <- index + 2L
  }

  if (!values$profile %in% c("build_validation", "production", "release_only")) {
    stop_cli("EXECUTION_PROFILE_INVALID", values$profile)
  }
  if (!values$execution_mode %in% c("continuous", "stagewise")) {
    stop_cli("EXECUTION_MODE_INVALID", values$execution_mode)
  }

  explicit_handoff <- "--handoff-zip" %in% seen
  env_handoff <- trimws(ifelse(is.na(env_handoff), "", env_handoff))
  if (identical(values$profile, "production")) {
    if (explicit_handoff && nzchar(env_handoff) && !identical(values$handoff_zip, env_handoff)) {
      stop_cli("HANDOFF_PATH_AMBIGUOUS")
    }
    if (!explicit_handoff) values$handoff_zip <- env_handoff
    if (!nzchar(values$handoff_zip)) stop_cli("HANDOFF_PATH_REQUIRED_FOR_PRODUCTION")
  } else {
    if (explicit_handoff) stop_cli("HANDOFF_FORBIDDEN_FOR_PROFILE", values$profile)
    # 非 production profile 必须清空继承环境，避免误触真实 handoff。
    values$handoff_zip <- ""
  }
  values
}

read_execution_profiles <- function(root = ".") {
  utils::read.csv(file.path(root, "config", "execution_profile_registry.csv"), stringsAsFactors = FALSE)
}

assert_execution_profile <- function(profile, action, root = ".") {
  profiles <- read_execution_profiles(root)
  row <- profiles[profiles$profile == profile, , drop = FALSE]
  if (nrow(row) != 1L) stop("Unknown execution profile: ", profile, call. = FALSE)
  allowed <- switch(
    action,
    read_patient_data = isTRUE(row$patient_data_allowed),
    fit_scientific_model = row$scientific_model_allowed %in% c("TRUE", "SYNTHETIC_ONLY"),
    generate_release = isTRUE(row$formal_release_allowed),
    stop("Unknown profile action: ", action, call. = FALSE)
  )
  if (!allowed) stop("Execution profile forbids action: ", profile, " / ", action, call. = FALSE)
  invisible(row)
}

assert_build_fixture_path <- function(path, root = ".") {
  allowed_root <- normalizePath(file.path(root, "tests", "fixtures"), mustWork = FALSE)
  candidate <- normalizePath(path, mustWork = FALSE)
  if (!startsWith(candidate, paste0(allowed_root, .Platform$file.sep))) {
    stop("build_validation may only read tests/fixtures", call. = FALSE)
  }
  invisible(TRUE)
}
