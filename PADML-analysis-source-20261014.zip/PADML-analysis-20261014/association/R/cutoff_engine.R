# 探索性 cutoff 引擎：RCS 解析导数、IPCW ROC/Youden 与描述性 KM 共用同一冻结队列。

.cutoff_stop <- function(code) stop(code, call. = FALSE)

rcs_basis_derivative <- function(x, knots, order = 1L) {
  x <- as.numeric(x)
  knots <- as.numeric(knots)
  if (length(knots) != 4L || any(!is.finite(knots)) || any(diff(knots) <= 0) || !order %in% c(1L, 2L)) {
    .cutoff_stop("RCS_DERIVATIVE_CONTRACT_INVALID")
  }
  knot_first <- knots[[1L]]
  knot_last <- knots[[4L]]
  knot_penultimate <- knots[[3L]]
  scale <- (knot_last - knot_first)^(2 / 3)
  derivative_power <- if (order == 1L) 2L else 1L
  multiplier <- if (order == 1L) 3 / scale else 6 / scale^2
  positive <- function(value, knot) pmax((value - knot) / scale, 0)^derivative_power
  nonlinear <- vapply(seq_len(length(knots) - 2L), function(index) {
    multiplier * positive(x, knots[[index]]) +
      ((knot_penultimate - knots[[index]]) * multiplier * positive(x, knot_last) -
        (knot_last - knots[[index]]) * multiplier * positive(x, knot_penultimate)) /
      (knot_last - knot_penultimate)
  }, numeric(length(x)))
  if (is.null(dim(nonlinear))) nonlinear <- matrix(nonlinear, ncol = length(knots) - 2L)
  result <- cbind(if (order == 1L) rep(1, length(x)) else rep(0, length(x)), nonlinear)
  colnames(result) <- c("rcs_linear", paste0("rcs_nonlinear", seq_len(length(knots) - 2L)))
  result
}

classify_turning_points <- function(x, derivative, support, tolerance = 1e-10) {
  x <- as.numeric(x)
  derivative <- as.numeric(derivative)
  support <- as.numeric(support)
  if (length(x) != length(derivative) || length(x) < 3L || length(support) != 2L ||
      any(diff(x) <= 0) || support[[1L]] >= support[[2L]]) {
    .cutoff_stop("TURNING_POINT_INPUT_INVALID")
  }
  sign_value <- sign(derivative)
  sign_value[abs(derivative) <= tolerance] <- 0
  crossing <- list()
  index_out <- 1L
  for (index in seq_len(length(x) - 1L)) {
    left <- sign_value[[index]]
    right <- sign_value[[index + 1L]]
    if (left < 0 && right > 0) {
      root <- x[[index]] - derivative[[index]] * (x[[index + 1L]] - x[[index]]) /
        (derivative[[index + 1L]] - derivative[[index]])
      crossing[[index_out]] <- root
      index_out <- index_out + 1L
    } else if (left < 0 && right == 0) {
      next_nonzero <- which(sign_value[(index + 2L):length(sign_value)] != 0)
      if (length(next_nonzero) && sign_value[[index + 1L + next_nonzero[[1L]]]] > 0) {
        crossing[[index_out]] <- x[[index + 1L]]
        index_out <- index_out + 1L
      }
    } else if (left == 0 && right > 0 && index > 1L && sign_value[[index - 1L]] < 0) {
      crossing[[index_out]] <- x[[index]]
      index_out <- index_out + 1L
    }
  }
  roots <- sort(unique(round(as.numeric(unlist(crossing)), 12L)))
  if (sign_value[[1L]] == 0L && any(sign_value[-1L] > 0L)) roots <- sort(unique(c(roots, support[[1L]])))
  if (sign_value[[length(sign_value)]] == 0L && any(sign_value[-length(sign_value)] < 0L)) {
    roots <- sort(unique(c(roots, support[[2L]])))
  }
  internal <- roots[roots > support[[1L]] + tolerance & roots < support[[2L]] - tolerance]
  boundary <- setdiff(roots, internal)
  if (length(boundary)) {
    status <- "BOUNDARY_TURNING_POINT_REJECTED"
    cutoff <- NA_real_
  } else if (!length(internal)) {
    status <- "NO_INTERNAL_NEGATIVE_TO_POSITIVE_TURNING_POINT"
    cutoff <- NA_real_
  } else if (length(internal) > 1L) {
    status <- "AMBIGUOUS_MULTIPLE_TURNING_POINTS"
    cutoff <- NA_real_
  } else {
    status <- "UNIQUE_INTERNAL_NEGATIVE_TO_POSITIVE"
    cutoff <- internal[[1L]]
  }
  list(status = status, cutoff = cutoff, roots = roots, internal_roots = internal)
}

.analytic_roots <- function(beta, knots, support, grid_n = 4001L) {
  evaluate <- function(value) as.numeric(rcs_basis_derivative(value, knots, 1L) %*% beta)
  grid <- seq(support[[1L]], support[[2L]], length.out = grid_n)
  values <- vapply(grid, evaluate, numeric(1))
  classified <- classify_turning_points(grid, values, support)
  if (identical(classified$status, "UNIQUE_INTERNAL_NEGATIVE_TO_POSITIVE")) {
    index <- max(which(grid <= classified$cutoff))
    left <- grid[[max(1L, index)]]
    right <- grid[[min(length(grid), index + 1L)]]
    refined <- tryCatch(stats::uniroot(evaluate, c(left, right), tol = 1e-12)$root, error = function(condition) classified$cutoff)
    classified$cutoff <- refined
    classified$internal_roots <- refined
    classified$roots <- refined
  }
  classified
}

derive_rcs_turning_point <- function(fits, rcs_spec, basis_names, minimum_root_imputations = 16L, maximum_iqr_fraction = 0.10) {
  support <- range(rcs_spec$knots[c(1L, length(rcs_spec$knots))])
  width <- diff(support)
  fit_rows <- lapply(seq_along(fits), function(imputation) {
    fit <- fits[[imputation]]
    coefficients <- if (is.null(fit)) numeric() else stats::coef(fit)
    if (!all(basis_names %in% names(coefficients)) || any(!is.finite(coefficients[basis_names]))) {
      return(data.frame(imputation = imputation, cutoff_log2 = NA_real_, status = "FIT_NOT_ESTIMABLE", stringsAsFactors = FALSE))
    }
    candidate <- .analytic_roots(coefficients[basis_names], rcs_spec$knots, support)
    data.frame(imputation = imputation, cutoff_log2 = candidate$cutoff, status = candidate$status, stringsAsFactors = FALSE)
  })
  per_imputation <- do.call(rbind, fit_rows)
  valid <- per_imputation$cutoff_log2[per_imputation$status == "UNIQUE_INTERNAL_NEGATIVE_TO_POSITIVE" & is.finite(per_imputation$cutoff_log2)]
  beta_matrix <- do.call(rbind, lapply(fits, function(fit) {
    coefficients <- if (is.null(fit)) numeric() else stats::coef(fit)
    if (!all(basis_names %in% names(coefficients))) rep(NA_real_, length(basis_names)) else coefficients[basis_names]
  }))
  pooled_beta <- if (nrow(beta_matrix) && all(colSums(is.finite(beta_matrix)) >= minimum_root_imputations)) {
    colMeans(beta_matrix, na.rm = TRUE)
  } else rep(NA_real_, length(basis_names))
  pooled <- if (all(is.finite(pooled_beta))) .analytic_roots(pooled_beta, rcs_spec$knots, support) else list(status = "POOLED_DERIVATIVE_NOT_ESTIMABLE", cutoff = NA_real_)
  cutoff_iqr <- if (length(valid)) stats::IQR(valid, type = 7) else NA_real_
  stable <- length(valid) >= minimum_root_imputations &&
    identical(pooled$status, "UNIQUE_INTERNAL_NEGATIVE_TO_POSITIVE") &&
    is.finite(cutoff_iqr) && cutoff_iqr <= maximum_iqr_fraction * width
  status <- if (stable) "RCS_CANDIDATE_STABLE_WITHIN_IMPUTATIONS" else if (!identical(pooled$status, "UNIQUE_INTERNAL_NEGATIVE_TO_POSITIVE")) {
    pooled$status
  } else if (length(valid) < minimum_root_imputations) {
    "RCS_CUTOFF_INSUFFICIENT_IMPUTATION_SUPPORT"
  } else "RCS_CUTOFF_IMPUTATION_IQR_TOO_WIDE"
  candidate <- data.frame(
    cutoff_source = "RCS_ANALYTIC_DERIVATIVE", cutoff_log2 = if (stable) pooled$cutoff else NA_real_,
    cutoff_ast_alt = if (stable) 2^pooled$cutoff else NA_real_, support_lower_log2 = support[[1L]],
    support_upper_log2 = support[[2L]], support_width_log2 = width,
    valid_imputation_n = length(valid), cutoff_imputation_median_log2 = if (length(valid)) stats::median(valid) else NA_real_,
    cutoff_imputation_iqr_log2 = cutoff_iqr, status = status, selection_effect = "NONE",
    stringsAsFactors = FALSE
  )
  derivative_grid <- if (all(is.finite(pooled_beta))) {
    grid <- seq(support[[1L]], support[[2L]], length.out = 200L)
    data.frame(
      x_log2 = grid, x_ast_alt = 2^grid,
      pooled_log_hr_derivative = as.numeric(rcs_basis_derivative(grid, rcs_spec$knots, 1L) %*% pooled_beta),
      cutoff_log2 = candidate$cutoff_log2, status = candidate$status,
      stringsAsFactors = FALSE
    )
  } else data.frame()
  list(candidate = candidate, per_imputation = per_imputation, derivative_grid = derivative_grid, pooled_beta = pooled_beta)
}

validate_rcs_variant_stability <- function(candidate, variant_candidates, maximum_difference_fraction = 0.10) {
  required <- c("MI_FULL", "COMPLETE_CASE", "P1_P99_RESTRICTED")
  if (!is.data.frame(variant_candidates) || !all(c("analysis_variant", "cutoff_log2", "status") %in% names(variant_candidates)) ||
      !all(required %in% variant_candidates$analysis_variant)) .cutoff_stop("RCS_VARIANT_STABILITY_INPUT_INVALID")
  rows <- variant_candidates[match(required, variant_candidates$analysis_variant), , drop = FALSE]
  width <- candidate$support_width_log2[[1L]]
  reference <- candidate$cutoff_log2[[1L]]
  differences <- abs(rows$cutoff_log2 - reference)
  stable <- identical(candidate$status[[1L]], "RCS_CANDIDATE_STABLE_WITHIN_IMPUTATIONS") &&
    all(rows$status == "RCS_CANDIDATE_STABLE_WITHIN_IMPUTATIONS") &&
    all(is.finite(differences)) && max(differences) <= maximum_difference_fraction * width
  transform(candidate, status = ifelse(stable, "STABLE_RCS_CUTOFF", "RCS_CUTOFF_VARIANT_INSTABILITY"),
            maximum_variant_difference_log2 = if (all(is.finite(differences))) max(differences) else NA_real_)
}

censoring_km <- function(time, event) {
  order_index <- order(time, event, method = "radix")
  time <- as.numeric(time[order_index])
  event <- as.integer(event[order_index])
  unique_time <- sort(unique(time))
  survival <- 1
  rows <- vector("list", length(unique_time))
  for (index in seq_along(unique_time)) {
    current <- unique_time[[index]]
    at_risk <- sum(time >= current)
    censored <- sum(time == current & event == 0L)
    before <- survival
    if (at_risk > 0L) survival <- survival * (1 - censored / at_risk)
    rows[[index]] <- data.frame(time = current, at_risk = at_risk, censored = censored, g_before = before, g_after = survival)
  }
  do.call(rbind, rows)
}

.km_g_before <- function(km, value) {
  indices <- which(km$time < value)
  if (length(indices)) km$g_after[[max(indices)]] else 1
}

.km_g_at <- function(km, value) {
  indices <- which(km$time <= value)
  if (length(indices)) km$g_after[[max(indices)]] else 1
}

.weighted_auc <- function(case_marker, case_weight, control_marker, control_weight) {
  control <- stats::aggregate(control_weight, list(marker = control_marker), sum)
  control <- control[order(control$marker), , drop = FALSE]
  cumulative <- cumsum(control$x)
  contribution <- vapply(case_marker, function(marker) {
    less_index <- which(control$marker < marker)
    equal_index <- which(control$marker == marker)
    less <- if (length(less_index)) cumulative[[max(less_index)]] else 0
    equal <- if (length(equal_index)) control$x[[equal_index[[1L]]]] else 0
    less + 0.5 * equal
  }, numeric(1))
  sum(case_weight * contribution) / (sum(case_weight) * sum(control_weight))
}

ipcw_point_estimate <- function(time, event, marker, time_month) {
  if (length(time) != length(event) || length(time) != length(marker) || length(time) < 2L ||
      any(!is.finite(time) | time < 0) || any(!event %in% c(0L, 1L)) ||
      any(!is.finite(marker))) {
    .cutoff_stop("IPCW_FROZEN_COHORT_INVALID")
  }
  time <- as.numeric(time)
  event <- as.integer(event)
  marker <- as.numeric(marker)
  if (!is.finite(time_month) || time_month <= 0) .cutoff_stop("IPCW_INPUT_INVALID")
  cases <- event == 1L & time <= time_month
  controls <- time > time_month
  if (!any(cases) || !any(controls)) .cutoff_stop("IPCW_EMPTY_CASE_OR_CONTROL")
  km <- censoring_km(time, event)
  g_time <- .km_g_at(km, time_month)
  case_g <- vapply(time[cases], function(value) .km_g_before(km, value), numeric(1))
  if (!is.finite(g_time) || g_time <= 0 || any(!is.finite(case_g) | case_g <= 0)) .cutoff_stop("IPCW_ZERO_CENSOR_SURVIVAL")
  case_weight <- 1 / case_g
  control_weight <- rep(1 / g_time, sum(controls))
  case_marker <- marker[cases]
  control_marker <- marker[controls]
  unique_marker <- sort(unique(marker))
  if (length(unique_marker) < 2L) .cutoff_stop("IPCW_MARKER_CONSTANT")
  cutoffs <- (unique_marker[-length(unique_marker)] + unique_marker[-1L]) / 2
  threshold <- lapply(cutoffs, function(cutoff) {
    sensitivity <- sum(case_weight[case_marker > cutoff]) / sum(case_weight)
    specificity <- sum(control_weight[control_marker <= cutoff]) / sum(control_weight)
    data.frame(
      cutoff = cutoff, sensitivity = sensitivity, specificity = specificity,
      fpr = 1 - specificity, youden_j = sensitivity + specificity - 1,
      balance = min(sensitivity, specificity), stringsAsFactors = FALSE
    )
  })
  threshold <- do.call(rbind, threshold)
  frozen_median <- stats::median(marker)
  ordering <- order(-threshold$youden_j, -threshold$balance, abs(threshold$cutoff - frozen_median), threshold$cutoff, method = "radix")
  best <- threshold[ordering[[1L]], , drop = FALSE]
  auc <- .weighted_auc(case_marker, case_weight, control_marker, control_weight)
  roc_points <- rbind(
    data.frame(cutoff = Inf, sensitivity = 0, specificity = 1, fpr = 0, youden_j = 0, balance = 0),
    threshold[order(threshold$fpr, threshold$sensitivity), , drop = FALSE],
    data.frame(cutoff = -Inf, sensitivity = 1, specificity = 0, fpr = 1, youden_j = 0, balance = 0)
  )
  public_fpr <- seq(0, 1, length.out = 101L)
  public_tpr <- vapply(public_fpr, function(value) {
    eligible <- roc_points$sensitivity[abs(roc_points$fpr - value) < 1e-12]
    if (length(eligible)) max(eligible) else stats::approx(roc_points$fpr, roc_points$sensitivity, xout = value, ties = max, rule = 2)$y
  }, numeric(1))
  list(
    summary = data.frame(
      time_month = time_month, auc = auc, cutoff = best$cutoff, sensitivity = best$sensitivity,
      specificity = best$specificity, youden_j = best$youden_j, case_n = sum(cases), control_n = sum(controls),
      g_time = g_time, maximum_weight = max(c(case_weight, control_weight)), frozen_marker_median = frozen_median,
      stringsAsFactors = FALSE
    ),
    restricted_thresholds = threshold,
    public_roc = data.frame(time_month = time_month, fpr = public_fpr, tpr = public_tpr, stringsAsFactors = FALSE)
  )
}

make_ipcw_rng_streams <- function(times = c(6, 12, 24, 36), seed = 42103L) {
  old_kind <- RNGkind()
  had_seed <- exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
  if (had_seed) old_seed <- get(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
  on.exit({
    do.call(RNGkind, as.list(old_kind))
    if (had_seed) assign(".Random.seed", old_seed, envir = .GlobalEnv) else if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)) rm(".Random.seed", envir = .GlobalEnv)
  }, add = TRUE)
  RNGkind("L'Ecuyer-CMRG")
  set.seed(seed)
  streams <- vector("list", length(times))
  streams[[1L]] <- .Random.seed
  if (length(times) > 1L) for (index in 2:length(times)) streams[[index]] <- parallel::nextRNGStream(streams[[index - 1L]])
  names(streams) <- as.character(times)
  streams
}

run_ipcw_timepoint <- function(time, event, marker, time_month, bootstrap_n = 1000L, rng_stream = NULL) {
  point <- ipcw_point_estimate(time, event, marker, time_month)
  if (is.null(rng_stream)) rng_stream <- make_ipcw_rng_streams(time_month, 42103L)[[1L]]
  assign(".Random.seed", rng_stream, envir = .GlobalEnv)
  # 以患者为单位顺序 bootstrap；外层时间点可并行，函数内部禁止 nested parallel。
  bootstrap <- lapply(seq_len(bootstrap_n), function(iteration) {
    index <- sample.int(length(time), length(time), replace = TRUE)
    tryCatch({
      estimate <- ipcw_point_estimate(time[index], event[index], marker[index], time_month)$summary
      data.frame(iteration = iteration, auc = estimate$auc, cutoff = estimate$cutoff)
    }, error = function(condition) data.frame(iteration = iteration, auc = NA_real_, cutoff = NA_real_))
  })
  bootstrap <- do.call(rbind, bootstrap)
  valid <- is.finite(bootstrap$auc) & is.finite(bootstrap$cutoff)
  quantile_value <- function(values, probability) if (length(values)) as.numeric(stats::quantile(values, probability, type = 7, names = FALSE)) else NA_real_
  auc_values <- bootstrap$auc[valid]
  cutoff_values <- bootstrap$cutoff[valid]
  summary <- transform(
    point$summary,
    auc_lower_95_ci = quantile_value(auc_values, 0.025), auc_upper_95_ci = quantile_value(auc_values, 0.975),
    cutoff_bootstrap_median = if (length(cutoff_values)) stats::median(cutoff_values) else NA_real_,
    cutoff_bootstrap_iqr = if (length(cutoff_values)) stats::IQR(cutoff_values, type = 7) else NA_real_,
    cutoff_bootstrap_lower_95_ci = quantile_value(cutoff_values, 0.025),
    cutoff_bootstrap_upper_95_ci = quantile_value(cutoff_values, 0.975),
    valid_bootstrap_n = sum(valid), bootstrap_n = bootstrap_n
  )
  list(summary = summary, public_roc = point$public_roc, restricted_thresholds = point$restricted_thresholds, restricted_bootstrap = bootstrap)
}

ipcw_validity_gate <- function(summary, time, event, marker, minimum_at_risk_n = 100L, minimum_at_risk_fraction = 0.10,
                               minimum_cumulative_events = 20L, minimum_valid_bootstrap_n = 950L) {
  cutoff <- summary$cutoff[[1L]]
  group_high <- marker > cutoff
  p5_p95 <- stats::quantile(marker, c(0.05, 0.95), type = 7, na.rm = TRUE, names = FALSE)
  at_risk <- sum(time >= summary$time_month[[1L]])
  cumulative_events <- sum(event == 1L & time <= summary$time_month[[1L]])
  checks <- c(
    g_positive = is.finite(summary$g_time[[1L]]) && summary$g_time[[1L]] > 0,
    bootstrap = summary$valid_bootstrap_n[[1L]] >= minimum_valid_bootstrap_n,
    cutoff_support = is.finite(cutoff) && cutoff >= p5_p95[[1L]] && cutoff <= p5_p95[[2L]],
    low_fraction = mean(!group_high) >= 0.10,
    high_fraction = mean(group_high) >= 0.10,
    low_events = sum(event == 1L & !group_high) >= 10L,
    high_events = sum(event == 1L & group_high) >= 10L,
    at_risk = at_risk >= minimum_at_risk_n && at_risk / length(time) >= minimum_at_risk_fraction,
    cumulative_events = cumulative_events >= minimum_cumulative_events
  )
  warning_class <- if (!checks[["g_positive"]] || !all(checks)) {
    "FAIL"
  } else if (summary$g_time[[1L]] < 0.10) {
    "BLOCKING_WARNING"
  } else {
    "INFO"
  }
  data.frame(
    time_month = summary$time_month[[1L]], check_id = names(checks), passed = unname(checks),
    warning_class = warning_class,
    status = ifelse(all(checks) && warning_class == "INFO", "VALID_YOUDEN_CUTOFF", "NOT_ESTIMABLE"),
    stringsAsFactors = FALSE
  )
}

.not_estimable_cutoff_km <- function(cutoff_source, cutoff, reason_code) {
  list(
    status = data.frame(
      cutoff_source = cutoff_source, cutoff = cutoff, status = "NOT_ESTIMABLE",
      reason_code = reason_code, stringsAsFactors = FALSE
    ),
    curve = data.frame(
      time_month = NA_real_, survival = NA_real_, lower_95_ci = NA_real_,
      upper_95_ci = NA_real_, n_risk = NA_integer_, n_event = NA_integer_,
      group = "NOT_ESTIMABLE", cutoff = cutoff, cutoff_source = cutoff_source,
      analysis_n = NA_integer_, event_n = NA_integer_,
      estimate_status = "NOT_ESTIMABLE", not_estimable_reason_code = reason_code,
      selection_effect = "DESCRIPTIVE_POST_SELECTION", stringsAsFactors = FALSE
    ),
    risk_table = data.frame(
      time_month = NA_real_, n_risk = NA_integer_, group = "NOT_ESTIMABLE",
      cutoff = cutoff, cutoff_source = cutoff_source,
      estimate_status = "NOT_ESTIMABLE", not_estimable_reason_code = reason_code,
      stringsAsFactors = FALSE
    ),
    statistics = data.frame(
      cutoff_source = cutoff_source, cutoff = cutoff, low_n = NA_integer_, high_n = NA_integer_,
      low_events = NA_integer_, high_events = NA_integer_, logrank_chisq = NA_real_,
      logrank_df = NA_integer_, p_value = NA_real_, annotation_p = NA_real_,
      annotation_p_type = "DESCRIPTIVE_POST_SELECTION", significance_symbol = "",
      estimate_status = "NOT_ESTIMABLE", not_estimable_reason_code = reason_code,
      stringsAsFactors = FALSE
    )
  )
}

run_cutoff_km <- function(time, event, marker, cutoff, cutoff_source, risk_times = c(0, 6, 12, 24, 36)) {
  valid <- length(cutoff) == 1L && is.finite(cutoff) && length(time) == length(event) && length(time) == length(marker)
  if (!valid) {
    return(.not_estimable_cutoff_km(cutoff_source, NA_real_, "INVALID_CUTOFF"))
  }
  if (any(!is.finite(time) | time < 0) || any(!event %in% c(0L, 1L)) ||
      any(!is.finite(marker))) {
    return(.not_estimable_cutoff_km(cutoff_source, cutoff, "INVALID_COHORT"))
  }
  group <- factor(ifelse(marker <= cutoff, "AST_ALT <= cutoff", "AST_ALT > cutoff"),
                  levels = c("AST_ALT <= cutoff", "AST_ALT > cutoff"))
  if (anyNA(group) || sum(table(group)) != length(group) || any(table(group) == 0L)) {
    return(.not_estimable_cutoff_km(cutoff_source, cutoff, "EMPTY_OR_INCOMPLETE_PARTITION"))
  }
  data <- data.frame(time = time, event = event, group = group)
  # 加载 survival 包并从冻结 cutoff 队列计算描述性 KM、log-rank 与固定风险表。
  if (!requireNamespace("survival", quietly = TRUE)) .cutoff_stop("KM_SURVIVAL_MISSING")
  fit <- survival::survfit(survival::Surv(time, event) ~ group, data = data, conf.type = "log")
  curve <- data.frame(
    time_month = fit$time, survival = fit$surv, lower_95_ci = fit$lower, upper_95_ci = fit$upper,
    n_risk = fit$n.risk, n_event = fit$n.event,
    group = sub("^group=", "", rep(names(fit$strata), fit$strata)),
    cutoff = cutoff, cutoff_source = cutoff_source,
    analysis_n = length(time), event_n = sum(event == 1L),
    estimate_status = "ESTIMABLE", not_estimable_reason_code = "",
    selection_effect = "DESCRIPTIVE_POST_SELECTION", stringsAsFactors = FALSE
  )
  risk <- summary(fit, times = risk_times, extend = TRUE)
  risk_table <- data.frame(
    time_month = risk$time, n_risk = risk$n.risk,
    group = sub("^group=", "", as.character(risk$strata)),
    cutoff = cutoff, cutoff_source = cutoff_source,
    estimate_status = "ESTIMABLE", not_estimable_reason_code = "", stringsAsFactors = FALSE
  )
  logrank <- survival::survdiff(survival::Surv(time, event) ~ group, data = data)
  p_value <- stats::pchisq(logrank$chisq, df = length(logrank$n) - 1L, lower.tail = FALSE)
  statistics <- data.frame(
    cutoff_source = cutoff_source, cutoff = cutoff, low_n = sum(group == levels(group)[[1L]]),
    high_n = sum(group == levels(group)[[2L]]), low_events = sum(event == 1L & group == levels(group)[[1L]]),
    high_events = sum(event == 1L & group == levels(group)[[2L]]), logrank_chisq = unname(logrank$chisq),
    logrank_df = length(logrank$n) - 1L, p_value = p_value, annotation_p = p_value,
    annotation_p_type = "DESCRIPTIVE_POST_SELECTION", significance_symbol = "",
    estimate_status = "ESTIMABLE", not_estimable_reason_code = "",
    stringsAsFactors = FALSE
  )
  list(
    status = data.frame(cutoff_source = cutoff_source, cutoff = cutoff, status = "ESTIMABLE", reason_code = "", stringsAsFactors = FALSE),
    curve = curve, risk_table = risk_table, statistics = statistics
  )
}
