# D1 生产适配层：验证模型列表、参数顺序与 mice 返回结构。

as_locked_mira <- function(fits, minimum_valid_imputations = 20L) {
  valid <- Filter(Negate(is.null), fits)
  if (length(valid) < minimum_valid_imputations) stop("Insufficient valid imputations for D1", call. = FALSE)
  coefficient_names <- lapply(valid, function(fit) names(stats::coef(fit)))
  if (!all(vapply(coefficient_names, identical, logical(1), coefficient_names[[1L]]))) {
    stop("D1 coefficient order differs across imputations", call. = FALSE)
  }
  # 加载 mice 包并将冻结模型列表转换为 mira，不重新拟合模型。
  if (!requireNamespace("mice", quietly = TRUE)) stop("mice is required", call. = FALSE)
  mice::as.mira(valid)
}

run_locked_d1 <- function(full_fits, reduced_fits, analysis_type, root = ".", dfcom = NULL) {
  registry <- utils::read.csv(file.path(root, "config", "multiparameter_pooling_registry.csv"), stringsAsFactors = FALSE, check.names = FALSE)
  rule <- registry[registry$analysis_type == analysis_type, , drop = FALSE]
  if (nrow(rule) != 1L) stop("No unique D1 registry rule for ", analysis_type, call. = FALSE)
  minimum <- as.integer(rule$minimum_valid_imputations[[1L]])
  full <- as_locked_mira(full_fits, minimum)
  reduced <- as_locked_mira(reduced_fits, minimum)
  source(file.path(root, "R", "pooling_engine.R"))
  result <- pool_joint_wald_d1(full, reduced, dfcom = dfcom)
  matrix <- result$result
  data.frame(
    analysis_type = analysis_type,
    statistic = unname(matrix[1L, "F.value"]),
    numerator_df = unname(matrix[1L, "df1"]),
    denominator_df = unname(matrix[1L, "df2"]),
    p_value = unname(matrix[1L, "P(>F)"]),
    riv = unname(matrix[1L, "RIV"]),
    valid_imputation_n = length(full$analyses),
    pooling_method = "mice_D1_locked",
    stringsAsFactors = FALSE
  )
}
