# 暴露冻结引擎：仅由 .imp=0 原始 AST/ALT 建立权威主暴露。

assign_frozen_tertile <- function(x, cut1, cut2) {
  factor(
    ifelse(x <= cut1, "T1", ifelse(x <= cut2, "T2", "T3")),
    levels = c("T1", "T2", "T3"), ordered = FALSE
  )
}

.analysis_binary_event_names <- c("All_Cause_Death", "MACE", "CV_CBV_Death")

.normalize_frozen_binary_event_01 <- function(value, event_name) {
  valid <- is.factor(value) && !is.ordered(value) && length(value) > 0L &&
    identical(levels(value), c("0", "1")) && !anyNA(value) &&
    all(as.character(value) %in% c("0", "1"))
  if (!valid) {
    stop(paste0("FROZEN_ANALYSIS_EVENT_ENCODING_INVALID:", event_name), call. = FALSE)
  }
  output <- match(as.character(value), c("0", "1")) - 1L
  names(output) <- names(value)
  output
}

.normalize_frozen_analysis_events <- function(data) {
  if (!is.data.frame(data) || anyDuplicated(names(data))) {
    stop("FROZEN_ANALYSIS_EVENT_ENCODING_INVALID:data", call. = FALSE)
  }
  missing <- setdiff(.analysis_binary_event_names, names(data))
  if (length(missing)) {
    stop(paste0("FROZEN_ANALYSIS_EVENT_ENCODING_INVALID:", missing[[1L]]), call. = FALSE)
  }
  for (event_name in .analysis_binary_event_names) {
    data[[event_name]] <- .normalize_frozen_binary_event_01(data[[event_name]], event_name)
  }
  data
}

.assert_analysis_binary_event_integer <- function(value, event_name) {
  if (!is.integer(value) || anyNA(value) || any(!value %in% c(0L, 1L))) {
    stop(paste0("ANALYSIS_BINARY_EVENT_NOT_NORMALIZED:", event_name), call. = FALSE)
  }
  value
}

freeze_exposure_identity <- function(sources, tolerance = 1e-8) {
  source_data <- sources$imp0
  completed <- sources$completed
  source(file.path("R", "patient_identity_guard.R"))
  identity_qc <- validate_patient_identity(source_data, completed)

  ast <- suppressWarnings(as.numeric(source_data$AST))
  alt <- suppressWarnings(as.numeric(source_data$ALT))
  eligible <- is.finite(ast) & ast > 0 & is.finite(alt) & alt > 0
  if (!any(eligible)) stop("No exposure-eligible patients", call. = FALSE)
  ratio <- ast[eligible] / alt[eligible]
  if (any(!is.finite(ratio)) || any(ratio <= 0)) stop("Invalid original AST/ALT ratio", call. = FALSE)
  cutoffs <- as.numeric(stats::quantile(ratio, probs = c(1 / 3, 2 / 3), type = 7, names = FALSE))
  if (any(diff(cutoffs) <= 0)) stop("AST/ALT tertile cutoffs are not strictly increasing", call. = FALSE)
  tertile <- assign_frozen_tertile(ratio, cutoffs[[1L]], cutoffs[[2L]])
  log2_ratio <- log2(ratio)

  private <- data.frame(
    Patient_ID = as.character(source_data$Patient_ID[eligible]),
    Patient_ID_hash = hash_patient_identifier(source_data$Patient_ID[eligible]),
    AST_original = ast[eligible],
    ALT_original = alt[eligible],
    AST_ALT_original = ratio,
    log2_AST_ALT = log2_ratio,
    AST_ALT_Tertile = tertile,
    exposure_eligible = TRUE,
    stringsAsFactors = FALSE
  )

  frozen_completed <- lapply(seq_along(completed), function(i) {
    data <- completed[[i]]
    idx <- match(private$Patient_ID, as.character(data$Patient_ID))
    if (anyNA(idx) || anyDuplicated(idx)) stop("Frozen exposure join is not one-to-one", call. = FALSE)
    data <- data[idx, , drop = FALSE]
    data$AST <- private$AST_original
    data$ALT <- private$ALT_original
    data$AST_ALT <- private$AST_ALT_original
    data$log2_AST_ALT <- private$log2_AST_ALT
    data$AST_ALT_Tertile <- private$AST_ALT_Tertile
    .normalize_frozen_analysis_events(data)
  })

  passive_difference <- unlist(lapply(frozen_completed, function(data) abs(data$AST_ALT - data$AST / data$ALT)), use.names = FALSE)
  tertile_mismatch_n <- sum(vapply(frozen_completed, function(data) {
    sum(as.character(data$AST_ALT_Tertile) != as.character(private$AST_ALT_Tertile))
  }, integer(1)))
  if (any(!is.finite(passive_difference)) || max(passive_difference) > tolerance) stop("Frozen exposure identity failed", call. = FALSE)
  if (tertile_mismatch_n != 0L) stop("Tertile identity differs across imputations", call. = FALSE)

  scale <- data.frame(
    source_population = "MAIN_EXPOSURE_ELIGIBLE",
    source_imp = 0,
    n = nrow(private),
    cutoff_T1_T2 = cutoffs[[1L]],
    cutoff_T2_T3 = cutoffs[[2L]],
    log2_mean = mean(log2_ratio),
    log2_sd = stats::sd(log2_ratio),
    log2_q1 = as.numeric(stats::quantile(log2_ratio, 0.25, type = 7)),
    log2_q3 = as.numeric(stats::quantile(log2_ratio, 0.75, type = 7)),
    log2_iqr = stats::IQR(log2_ratio, type = 7),
    reference_median = stats::median(log2_ratio),
    stringsAsFactors = FALSE
  )
  summary <- data.frame(
    metric = c("source_n", "eligible_n", "excluded_n", "nonpositive_AST_n", "nonpositive_ALT_n", "nonfinite_exposure_n", "max_identity_difference", "tertile_mismatch_n"),
    value = c(
      nrow(source_data), nrow(private), nrow(source_data) - nrow(private),
      sum(is.finite(ast) & ast <= 0, na.rm = TRUE), sum(is.finite(alt) & alt <= 0, na.rm = TRUE),
      sum(!is.finite(ast) | !is.finite(alt)), max(passive_difference), tertile_mismatch_n
    ),
    status = c("INFO", "PASS", "INFO", "INFO", "INFO", "INFO", ifelse(max(passive_difference) <= tolerance, "PASS", "FAIL"), ifelse(tertile_mismatch_n == 0L, "PASS", "FAIL")),
    stringsAsFactors = FALSE
  )
  imp0_eligible <- source_data[match(private$Patient_ID, as.character(source_data$Patient_ID)), , drop = FALSE]
  imp0_eligible$AST <- private$AST_original
  imp0_eligible$ALT <- private$ALT_original
  imp0_eligible$AST_ALT <- private$AST_ALT_original
  imp0_eligible$log2_AST_ALT <- private$log2_AST_ALT
  imp0_eligible$AST_ALT_Tertile <- private$AST_ALT_Tertile
  imp0_eligible <- .normalize_frozen_analysis_events(imp0_eligible)
  list(
    private_identity = private,
    imp0_eligible = imp0_eligible,
    completed = frozen_completed,
    identity_qc = identity_qc,
    exposure_summary = summary,
    exposure_scale = scale
  )
}
