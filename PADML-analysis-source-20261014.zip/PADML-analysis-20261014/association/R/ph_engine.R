# PH 与设计矩阵引擎：逐插补保存父变量和系数层级诊断。

normalize_ph_rule_term <- function(term) {
  if (term %in% c("log2_AST_ALT", "AST_ALT_Tertile")) "AST_ALT" else term
}

extract_ph_from_collection <- function(collection, root = ".") {
  term_rows <- list()
  dummy_rows <- list()
  index_term <- 1L
  index_dummy <- 1L
  model_signature <- fixed_collection_model_signature(collection, root)
  formula_hash <- collinearity_sha256(collection$formula_text)
  factor_reference_hash <- collinearity_sha256(c("AST_ALT_Tertile=T1"))
  for (i in seq_along(collection$fits)) {
    fit <- collection$fits[[i]]
    if (is.null(fit)) next
    fit_identity <- normalized_fit_identity(fit, collection$formula_text)
    fit_id <- paste(collection$endpoint_row$event_variable[[1L]], i, collection$exposure_form, collection$model_id, sep = "__")
    term_result <- tryCatch({
      # 加载 survival 包并执行父变量层级 PH 诊断。
      if (!requireNamespace("survival", quietly = TRUE)) stop("survival is required")
      survival::cox.zph(fit, transform = "km", terms = TRUE, singledf = FALSE)
    }, error = function(e) NULL)
    coefficient_result <- tryCatch(survival::cox.zph(fit, transform = "km", terms = FALSE), error = function(e) NULL)
    if (!is.null(term_result)) {
      table <- as.data.frame(term_result$table)
      table$parent_term <- rownames(table)
      table$imputation <- i
      table$model_id <- collection$model_id
      table$exposure_form <- collection$exposure_form
      table$endpoint <- collection$endpoint_row$event_variable[[1L]]
      table$fit_id <- fit_id
      table$model_signature_sha256 <- model_signature
      table$fit_object_hash <- fit_identity$fit_object_hash
      table$formula_hash <- formula_hash
      table$factor_reference_hash <- factor_reference_hash
      names(table)[names(table) == "p"] <- "p_value"
      term_rows[[index_term]] <- table
      index_term <- index_term + 1L
    }
    if (!is.null(coefficient_result)) {
      mapping <- coefficient_parent_map(fit)
      y <- coefficient_result$y
      transformed_time <- coefficient_result$x
      coefficients <- colnames(y)
      rho <- vapply(seq_along(coefficients), function(j) suppressWarnings(stats::cor(transformed_time, y[, j], use = "complete.obs")), numeric(1))
      p <- coefficient_result$table[coefficients, "p"]
      dummy_rows[[index_dummy]] <- data.frame(
        imputation = i, model_id = collection$model_id, exposure_form = collection$exposure_form,
        endpoint = collection$endpoint_row$event_variable[[1L]],
        fit_id = fit_id, model_signature_sha256 = model_signature,
        fit_object_hash = fit_identity$fit_object_hash, formula_hash = formula_hash,
        factor_reference_hash = factor_reference_hash,
        coefficient = coefficients, parent_term = mapping$parent_term[match(coefficients, mapping$coefficient)], rho = rho, p_value = p,
        stringsAsFactors = FALSE
      )
      index_dummy <- index_dummy + 1L
    }
  }
  list(
    term = if (length(term_rows)) do.call(rbind, term_rows) else data.frame(),
    dummy = if (length(dummy_rows)) do.call(rbind, dummy_rows) else data.frame()
  )
}

summarize_ph_dummy_directions <- function(dummy_results) {
  if (!nrow(dummy_results)) return(data.frame())
  groups <- split(
    dummy_results,
    interaction(
      dummy_results$model_id,
      dummy_results$exposure_form,
      dummy_results$parent_term,
      dummy_results$coefficient,
      drop = TRUE,
      lex.order = TRUE
    )
  )
  rows <- lapply(groups, function(data) {
    rho <- data$rho[is.finite(data$rho)]
    p_value <- data$p_value[is.finite(data$p_value)]
    positive_fraction <- if (length(rho)) mean(rho > 0) else NA_real_
    negative_fraction <- if (length(rho)) mean(rho < 0) else NA_real_
    direction_consistency <- if (length(rho)) max(positive_fraction, negative_fraction) else NA_real_
    dominant_direction <- if (!length(rho)) {
      NA_character_
    } else if (positive_fraction > negative_fraction) {
      "positive"
    } else if (negative_fraction > positive_fraction) {
      "negative"
    } else {
      "mixed"
    }
    data.frame(
      model_id = data$model_id[[1L]],
      exposure_form = data$exposure_form[[1L]],
      parent_term = data$parent_term[[1L]],
      coefficient = data$coefficient[[1L]],
      valid_imputation_n = length(rho),
      p_lt_0_05_n = sum(p_value < 0.05),
      median_rho = if (length(rho)) stats::median(rho) else NA_real_,
      median_abs_rho = if (length(rho)) stats::median(abs(rho)) else NA_real_,
      positive_fraction = positive_fraction,
      negative_fraction = negative_fraction,
      dominant_direction = dominant_direction,
      direction_consistency = direction_consistency,
      stringsAsFactors = FALSE
    )
  })
  result <- do.call(rbind, rows)
  rownames(result) <- NULL
  result
}

summarize_ph_parent_rules <- function(term_results, dummy_results, root = ".") {
  if (!nrow(term_results)) return(data.frame())
  rules <- utils::read.csv(file.path(root, "config", "ph_rule_registry.csv"), stringsAsFactors = FALSE, check.names = FALSE)
  terms <- setdiff(unique(term_results$parent_term), "GLOBAL")
  rows <- lapply(terms, function(term) {
    subset <- term_results[term_results$parent_term == term, , drop = FALSE]
    dummy <- dummy_results[dummy_results$parent_term == term, , drop = FALSE]
    valid_n <- sum(is.finite(subset$p_value))
    p_count <- sum(subset$p_value < 0.05, na.rm = TRUE)
    if (nrow(dummy)) {
      by_dummy <- split(dummy, dummy$coefficient)
      consistency <- vapply(by_dummy, function(x) {
        signs <- sign(x$rho[is.finite(x$rho) & x$rho != 0])
        if (!length(signs)) return(0)
        max(mean(signs > 0), mean(signs < 0))
      }, numeric(1))
      median_abs_rho <- max(vapply(by_dummy, function(x) stats::median(abs(x$rho), na.rm = TRUE), numeric(1)), na.rm = TRUE)
      direction_consistency <- max(consistency, na.rm = TRUE)
      consistent_dummy_n <- sum(consistency >= 0.80)
    } else {
      median_abs_rho <- NA_real_
      direction_consistency <- NA_real_
      consistent_dummy_n <- 0L
    }
    rule_term <- normalize_ph_rule_term(term)
    known <- rules[rules$term == rule_term, , drop = FALSE]
    generic <- rules[rules$term == "OTHER_COVARIATE", , drop = FALSE]
    rule <- if (nrow(known) == 1L) known else generic
    triggered <- valid_n >= rule$minimum_valid_imputations[[1L]] &&
      p_count >= rule$minimum_p_lt_0_05_count[[1L]] &&
      is.finite(direction_consistency) && direction_consistency >= rule$minimum_direction_consistency[[1L]] &&
      is.finite(median_abs_rho) && median_abs_rho >= rule$median_abs_rho_threshold[[1L]] &&
      (rule$term_type[[1L]] != "multilevel" || consistent_dummy_n >= rule$dummy_minimum_count[[1L]])
    data.frame(
      parent_term = term, rule_term = rule_term, valid_imputation_n = valid_n, p_lt_0_05_n = p_count,
      direction_consistency = direction_consistency, median_abs_rho = median_abs_rho,
      consistent_dummy_n = consistent_dummy_n, triggered = triggered,
      action_if_triggered = rule$action_if_triggered[[1L]], human_review_required = rule$human_review_required[[1L]],
      stringsAsFactors = FALSE
    )
  })
  do.call(rbind, rows)
}

run_formal_ph_stage <- function(fixed_stage, root = ".") {
  term <- list()
  dummy <- list()
  index <- 1L
  for (key in names(fixed_stage$collections)) {
    collection <- fixed_stage$collections[[key]]
    extracted <- extract_ph_from_collection(collection, root)
    term[[index]] <- extracted$term
    dummy[[index]] <- extracted$dummy
    index <- index + 1L
  }
  term_data <- do.call(rbind, term)
  dummy_data <- do.call(rbind, dummy)
  primary_term <- term_data[term_data$model_id == "M5" & term_data$exposure_form == "log2_AST_ALT", , drop = FALSE]
  primary_dummy <- dummy_data[dummy_data$model_id == "M5" & dummy_data$exposure_form == "log2_AST_ALT", , drop = FALSE]
  list(
    per_imputation_term = term_data,
    parent_joint = term_data[term_data$parent_term != "GLOBAL", , drop = FALSE],
    per_imputation_dummy = dummy_data,
    dummy_direction_summary = summarize_ph_dummy_directions(dummy_data),
    trigger_summary = summarize_ph_parent_rules(primary_term, primary_dummy, root)
  )
}

registered_schoenfeld_series <- function(diagnostic_ids, root = ".") {
  registry <- utils::read.csv(
    file.path(root, "config", "diagnostic_extension_registry.csv"),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  selected <- registry[registry$diagnostic_id %in% diagnostic_ids, , drop = FALSE]
  expected_ids <- sort(unique(diagnostic_ids), method = "radix")
  observed_ids <- sort(unique(selected$diagnostic_id), method = "radix")
  if (!nrow(selected) || !identical(expected_ids, observed_ids)) {
    stop("SCHOENFELD_DIAGNOSTIC_REGISTRY_CLOSURE_INVALID", call. = FALSE)
  }
  data.frame(
    diagnostic_id = selected$diagnostic_id,
    series_id = selected$series_id,
    mode = selected$mode,
    term_pattern = selected$term_pattern,
    legend_label = gsub("_", " ", selected$series_id, fixed = TRUE),
    stringsAsFactors = FALSE
  )
}

run_a03_schoenfeld_extensions <- function(fixed_stage, root = ".") {
  collection <- fixed_stage$collections[["M5__log2_AST_ALT"]]
  if (is.null(collection) || length(collection$fits) != 20L) {
    stop("A03_SCHOENFELD_SOURCE_FIT_BUNDLE_INVALID", call. = FALSE)
  }
  run_schoenfeld_diagnostic(
    collection$fits,
    registered_schoenfeld_series(c("SF21", "SF22"), root),
    spline_df = 4L, grid_n = 120L, minimum_valid_imputations = 16L
  )
}

run_component_schoenfeld_extensions <- function(full_component_fits, root = ".") {
  if (!is.list(full_component_fits) || length(full_component_fits) != 20L) {
    stop("A06_COMPONENT_SCHOENFELD_SOURCE_FIT_BUNDLE_INVALID", call. = FALSE)
  }
  run_schoenfeld_diagnostic(
    full_component_fits,
    registered_schoenfeld_series(c("SF19", "SF20"), root),
    spline_df = 4L, grid_n = 120L, minimum_valid_imputations = 16L
  )
}
