# 人工审核包模块：生成阶段审核包和累计单一审核 ZIP，禁止患者级内容。

empty_review_table <- function(columns) {
  output <- as.data.frame(setNames(replicate(length(columns), character(), simplify = FALSE), columns), stringsAsFactors = FALSE)
  output[0, , drop = FALSE]
}

bind_review_frames <- function(...) {
  frames <- Filter(function(data) !is.null(data) && nrow(as.data.frame(data)) > 0L, list(...))
  if (!length(frames)) return(data.frame())
  frames <- lapply(frames, function(data) as.data.frame(data, stringsAsFactors = FALSE))
  columns <- Reduce(union, lapply(frames, names))
  frames <- lapply(frames, function(data) {
    for (column in setdiff(columns, names(data))) data[[column]] <- NA_character_
    data[columns]
  })
  do.call(rbind, frames)
}

qc_alerts_for_review <- function(qc_results, stage) {
  if (is.null(qc_results) || !nrow(qc_results) || !all(c("status", "qc_id", "check") %in% names(qc_results))) return(data.frame())
  alerts <- qc_results[qc_results$status != "PASS", , drop = FALSE]
  if (!nrow(alerts)) return(data.frame())
  severity <- if ("severity" %in% names(alerts)) alerts$severity else alerts$status
  data.frame(
    warning_code = alerts$qc_id,
    stage = stage,
    class = severity,
    message_cn = paste0(alerts$check, "：observed=", alerts$observed, "；expected=", alerts$expected),
    required_action = ifelse(
      severity %in% c("HARD_STOP", "BLOCKING_WARNING"),
      "必须完成规则性人工审核后方可继续",
      "记录于人工审核包；非阻断时可按stage gate继续"
    ),
    source = "qc_gate",
    stringsAsFactors = FALSE
  )
}

sanitize_review_frame <- function(data, name = "review_data") {
  if (is.null(data)) return(data.frame())
  data <- as.data.frame(data, stringsAsFactors = FALSE)
  if (ncol(data) == 0L) data <- data.frame(record_status = character(), notes = character(), stringsAsFactors = FALSE)
  forbidden_columns <- grepl(
    "(?i)^(patient[_ -]?id|patient_identifier|raw_patient_id)$",
    names(data),
    perl = TRUE
  )
  hit <- names(data)[forbidden_columns]
  if (length(hit)) stop("Patient identifier column is forbidden in review package: ", name, call. = FALSE)
  for (column in names(data)) {
    if (is.character(data[[column]])) {
      values <- data[[column]]
      absolute_pattern <- "(^|[[:space:]\"'(=,:])/(Users|Volumes|home|root|mnt|private|tmp|var|opt|srv)/|[A-Za-z]:\\\\"
      forbidden_token <- "(?i)(^|[^A-Za-z0-9])(patient[_ -]?id)([^A-Za-z0-9]|$)|restricted_cache"
      if (any(grepl(absolute_pattern, values, perl = TRUE), na.rm = TRUE)) {
        stop("Absolute path is forbidden in review package: ", name, call. = FALSE)
      }
      if (any(grepl(forbidden_token, values, perl = TRUE), na.rm = TRUE)) {
        stop("Restricted token is forbidden in review package: ", name, call. = FALSE)
      }
    }
  }
  data
}

write_review_csv <- function(data, path, name = basename(path)) {
  data <- sanitize_review_frame(data, name)
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  # 输出人工审核 CSV，保留机器可读字段。
  utils::write.csv(data, path, row.names = FALSE, na = "")
  path
}

write_review_one_page <- function(stage, status, output_path, warnings = character(), missing_outputs = character(), decision_path = "") {
  html <- c(
    "<!doctype html><html><head><meta charset='utf-8'><title>Stage Review</title>",
    "<style>body{font-family:Arial,sans-serif;max-width:980px;margin:32px auto;line-height:1.55}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ddd;padding:8px}.status{font-weight:700}</style></head><body>",
    sprintf("<h1>%s 阶段人工审核摘要</h1>", stage),
    sprintf("<p class='status'><strong>状态：</strong>%s</p>", status),
    sprintf("<p><strong>阻断/非阻断提示：</strong>%s</p>", ifelse(length(warnings), paste(warnings, collapse = "; "), "无")),
    sprintf("<p><strong>缺失输出：</strong>%s</p>", ifelse(length(missing_outputs), paste(missing_outputs, collapse = "; "), "无")),
    sprintf("<p><strong>决策文件：</strong>%s</p>", ifelse(nzchar(decision_path), decision_path, "本阶段无需人工放行或模板位于审核包内")),
    "<h2>建议审核顺序</h2><ol><li>阶段摘要</li><li>验收标准</li><li>QC门禁</li><li>警告与错误</li><li>关键汇总结果</li><li>预期与实际输出</li><li>偏差与配置变化</li><li>填写决策文件</li></ol>",
    "<p>本审核包仅含汇总信息，不包含患者级数据。</p></body></html>"
  )
  dir.create(dirname(output_path), recursive = TRUE, showWarnings = FALSE)
  writeLines(html, output_path, useBytes = TRUE)
  invisible(output_path)
}

package_versions_table <- function() {
  packages <- c("R", "survival", "mice", "Hmisc", "targets", "tarchetypes", "ggplot2", "digest", "jsonlite")
  data.frame(
    package = packages,
    version = vapply(packages, function(package) {
      if (package == "R") return(as.character(getRversion()))
      if (!requireNamespace(package, quietly = TRUE)) return("NOT_INSTALLED")
      as.character(utils::packageVersion(package))
    }, character(1)),
    stringsAsFactors = FALSE
  )
}

build_stage_review_pack <- function(
    stage, status, qc_results, warnings = data.frame(), key_results = data.frame(),
    output_manifest = data.frame(), expected_outputs = data.frame(), config_diff = data.frame(),
    deviations = data.frame(), cache_audit = data.frame(), stage_lock_path = "",
    review_sections = list(), root = ".", run_id = "current") {
  pack_dir <- file.path(root, "human_review", "stages", stage)
  if (dir.exists(pack_dir)) unlink(pack_dir, recursive = TRUE)
  dir.create(file.path(pack_dir, "decision"), recursive = TRUE, showWarnings = FALSE)
  readme <- c(
    paste0("# ", stage, " 人工审核包"), "",
    paste0("- 阶段状态：`", status, "`"),
    "- 本目录仅包含汇总结果、QC、输出清单和决策模板。",
    "- 不包含患者级记录、患者标识、绝对路径或受限模型对象。",
    "- 请先打开 `REVIEW_ONE_PAGE_SUMMARY.html`，再依次检查编号 CSV。"
  )
  writeLines(readme, file.path(pack_dir, "00_README_CN.md"), useBytes = TRUE)
  warnings <- bind_review_frames(warnings, qc_alerts_for_review(qc_results, stage))
  stage_summary <- data.frame(stage = stage, stage_status = status, run_id = run_id, review_required = status %in% c("WARNING_WAITING_FOR_HUMAN_REVIEW", "SCIENTIFIC_CONFIG_CANDIDATE_WAITING_FOR_HUMAN_REVIEW", "RESOURCE_GATE_WAITING_FOR_HUMAN_REVIEW", "FAIL_WAITING_FOR_HUMAN_REVIEW"), stringsAsFactors = FALSE)
  write_review_csv(stage_summary, file.path(pack_dir, "01_stage_summary.csv"))
  write_review_csv(qc_results, file.path(pack_dir, "02_acceptance_criteria_results.csv"))
  write_review_csv(qc_results, file.path(pack_dir, "03_qc_gate_results.csv"))
  write_review_csv(warnings, file.path(pack_dir, "04_warnings_errors.csv"))
  write_review_csv(key_results, file.path(pack_dir, "05_key_results_aggregate.csv"))
  write_review_csv(output_manifest, file.path(pack_dir, "06_output_manifest.csv"))
  write_review_csv(expected_outputs, file.path(pack_dir, "07_expected_vs_actual_outputs.csv"))
  write_review_csv(config_diff, file.path(pack_dir, "08_scientific_config_diff.csv"))
  write_review_csv(deviations, file.path(pack_dir, "09_protocol_deviation_log.csv"))
  write_review_csv(cache_audit, file.path(pack_dir, "10_cache_reuse_audit.csv"))
  write_review_csv(package_versions_table(), file.path(pack_dir, "11_package_versions.csv"))
  capture.output(utils::sessionInfo(), file = file.path(pack_dir, "12_session_info.txt"))
  if (length(review_sections)) {
    for (section_name in names(review_sections)) {
      section <- review_sections[[section_name]]
      section_dir <- file.path(pack_dir, section_name)
      dir.create(section_dir, recursive = TRUE, showWarnings = FALSE)
      for (file_name in names(section)) {
        write_review_csv(section[[file_name]], file.path(section_dir, file_name), paste(stage, section_name, file_name, sep = "/"))
      }
    }
  }
  lock_sha <- if (nzchar(stage_lock_path) && file.exists(stage_lock_path)) file_sha256(stage_lock_path) else ""
  decision <- list(
    stage = stage, decision = "", approved_by = "", approved_at = "", review_notes = "",
    approved_stage_lock_sha256 = lock_sha
  )
  # 加载 JSON 包并写入不可被空模板误认为批准的人工决策文件。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  jsonlite::write_json(decision, file.path(pack_dir, "decision", paste0("REVIEW_DECISION_", stage, ".json")), auto_unbox = TRUE, pretty = TRUE)
  warning_text <- if (nrow(warnings) && "warning_code" %in% names(warnings)) warnings$warning_code else character()
  missing <- if (nrow(expected_outputs) && all(c("actual_exists", "file_name") %in% names(expected_outputs))) expected_outputs$file_name[!expected_outputs$actual_exists] else character()
  write_review_one_page(stage, status, file.path(pack_dir, "REVIEW_ONE_PAGE_SUMMARY.html"), warning_text, missing, file.path("decision", paste0("REVIEW_DECISION_", stage, ".json")))
  pack_dir
}

collect_review_csv <- function(stage_dirs, file_name) {
  paths <- file.path(stage_dirs, file_name)
  paths <- paths[file.exists(paths)]
  if (!length(paths)) return(data.frame())
  frames <- lapply(paths, function(path) utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE))
  columns <- Reduce(union, lapply(frames, names))
  frames <- lapply(frames, function(data) {
    missing <- setdiff(columns, names(data))
    for (column in missing) data[[column]] <- rep(NA, nrow(data))
    data[columns]
  })
  do.call(rbind, frames)
}

privacy_scan_empty_result <- function() {
  data.frame(
    file = character(),
    entry_type = character(),
    allowed_type = logical(),
    hidden_entry = logical(),
    patient_identifier_token = logical(),
    restricted_token = logical(),
    absolute_path = logical(),
    ssh_identity = logical(),
    forbidden_path = logical(),
    binary_unapproved = logical(),
    nested_archive = logical(),
    status = character(),
    reason_codes = character(),
    stringsAsFactors = FALSE
  )
}

privacy_path_components <- function(path) {
  components <- unlist(strsplit(gsub("\\\\", "/", path), "/", fixed = TRUE), use.names = FALSE)
  components[nzchar(components)]
}

privacy_path_flags <- function(relative_path) {
  components <- privacy_path_components(relative_path)
  hidden <- any(startsWith(components, "."))
  forbidden <- any(tolower(components) %in% c(
    "restricted_cache", "patient_level", "raw", "_targets", "objects"
  ))
  traversal <- any(components == "..") ||
    grepl("^/", relative_path) ||
    grepl("^[A-Za-z]:[/\\\\]", relative_path)
  list(hidden = hidden, forbidden = forbidden || traversal)
}

privacy_text_flags <- function(text) {
  patient_pattern <- "(?i)(^|[^A-Za-z0-9])patient[_ -]?id([^A-Za-z0-9]|$)"
  restricted_pattern <- "(?i)restricted_cache|PATIENT_LEVEL_RESTRICTED|(^|[/\\\\])patient_level([/\\\\]|$)|_targets[/\\\\]objects"
  absolute_pattern <- "(^|[[:space:]\"'(=,:])/(Users|Volumes|home|root|mnt|private|tmp|var|opt|srv)/|[A-Za-z]:\\\\"
  ssh_pattern <- "(?i)(ssh[[:space:]]+-[^\\n]*[[:space:]])?[A-Za-z0-9._-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
  list(
    patient_identifier_token = grepl(patient_pattern, text, perl = TRUE),
    restricted_token = grepl(restricted_pattern, text, perl = TRUE),
    absolute_path = grepl(absolute_pattern, text, perl = TRUE),
    ssh_identity = grepl(ssh_pattern, text, perl = TRUE)
  )
}

privacy_publication_binary_signature <- function(relative_path, raw) {
  components <- tolower(privacy_path_components(relative_path))
  extension <- tolower(tools::file_ext(relative_path))
  approved_location <- any(components %in% c("figures", "publication_outputs"))
  if (!approved_location || !extension %in% c("pdf", "png")) return(FALSE)
  if (extension == "pdf") {
    return(length(raw) >= 5L && identical(rawToChar(raw[seq_len(5L)]), "%PDF-"))
  }
  png_signature <- as.raw(c(137L, 80L, 78L, 71L, 13L, 10L, 26L, 10L))
  length(raw) >= length(png_signature) &&
    identical(raw[seq_along(png_signature)], png_signature)
}

privacy_binary_ascii_text <- function(raw) {
  values <- as.integer(raw)
  printable <- values %in% c(9L, 10L, 13L, 32L:126L)
  if (!any(printable)) return("")
  run_id <- cumsum(!printable)
  runs <- split(raw[printable], run_id[printable])
  paste(vapply(runs, rawToChar, character(1)), collapse = "\n")
}

privacy_png_metadata_text <- function(raw) {
  position <- 9L
  pieces <- character()
  while (position + 11L <= length(raw)) {
    chunk_length <- sum(
      as.integer(raw[position + 0:3]) * c(256^3, 256^2, 256, 1)
    )
    type_start <- position + 4L
    chunk_type <- rawToChar(raw[type_start + 0:3])
    data_start <- position + 8L
    data_end <- data_start + chunk_length - 1L
    crc_end <- position + 11L + chunk_length
    if (!is.finite(chunk_length) || chunk_length < 0L || crc_end > length(raw)) {
      return(privacy_binary_ascii_text(raw))
    }
    chunk_data <- if (chunk_length > 0L) raw[data_start:data_end] else raw()
    if (chunk_type %in% c("tEXt", "zTXt", "iTXt")) {
      pieces <- c(pieces, privacy_binary_ascii_text(chunk_data))
    }
    if (identical(chunk_type, "IEND")) {
      if (crc_end < length(raw)) {
        pieces <- c(pieces, privacy_binary_ascii_text(raw[(crc_end + 1L):length(raw)]))
      }
      return(paste(pieces, collapse = "\n"))
    }
    position <- crc_end + 1L
  }
  privacy_binary_ascii_text(raw)
}

privacy_publication_binary_text <- function(relative_path, raw) {
  if (identical(tolower(tools::file_ext(relative_path)), "png")) {
    privacy_png_metadata_text(raw)
  } else {
    privacy_binary_ascii_text(raw)
  }
}

privacy_reason_codes <- function(row) {
  mapping <- c(
    allowed_type = "TYPE_NOT_ALLOWLISTED",
    hidden_entry = "HIDDEN_ENTRY",
    patient_identifier_token = "PATIENT_IDENTIFIER_TOKEN",
    restricted_token = "RESTRICTED_TOKEN",
    absolute_path = "ABSOLUTE_LOCAL_PATH",
    ssh_identity = "USER_OR_HOST_IDENTITY",
    forbidden_path = "FORBIDDEN_PATH",
    binary_unapproved = "BINARY_NOT_ALLOWLISTED",
    nested_archive = "NESTED_ARCHIVE"
  )
  flags <- vapply(names(mapping), function(name) {
    value <- isTRUE(row[[name]])
    if (name == "allowed_type") !value else value
  }, logical(1))
  paste(unname(mapping[flags]), collapse = "|")
}

scan_review_directory_privacy <- function(path, display_prefix = "") {
  root <- normalizePath(path, mustWork = TRUE)
  entries <- list.files(
    root,
    recursive = TRUE,
    full.names = TRUE,
    all.files = TRUE,
    no.. = TRUE,
    include.dirs = TRUE
  )
  if (!length(entries)) return(privacy_scan_empty_result())
  prefix <- paste0(root, .Platform$file.sep)
  rows <- lapply(entries, function(entry) {
    normalized <- normalizePath(entry, mustWork = FALSE)
    escaped <- !identical(normalized, root) && !startsWith(normalized, prefix)
    relative <- if (escaped) basename(entry) else substring(normalized, nchar(prefix) + 1L)
    display <- if (nzchar(display_prefix)) paste0(display_prefix, relative) else relative
    info <- file.info(entry)
    is_directory <- isTRUE(info$isdir[[1L]])
    is_symlink <- nzchar(Sys.readlink(entry))
    path_flags <- privacy_path_flags(relative)
    extension <- tolower(tools::file_ext(relative))
    text_extensions <- c("csv", "md", "txt", "html", "json", "svg", "qmd", "sha256", "css", "js")
    archive_extensions <- c("zip", "tar", "gz", "tgz", "bz2", "xz", "7z")
    object_extensions <- c("rds", "rdata", "rda", "rhistory", "qs", "feather", "parquet")
    raw <- if (!is_directory) {
      size <- as.numeric(info$size[[1L]])
      readBin(entry, what = "raw", n = size)
    } else raw()
    approved_publication_binary <- !is_directory && !is_symlink &&
      privacy_publication_binary_signature(relative, raw)
    allowed_type <- is_directory ||
      (!is_symlink && extension %in% text_extensions) || approved_publication_binary
    binary_unapproved <- !is_directory && !approved_publication_binary && (
      is_symlink || !extension %in% text_extensions || extension %in% object_extensions
    )
    nested_archive <- !is_directory && extension %in% archive_extensions
    text_flags <- list(
      patient_identifier_token = FALSE,
      restricted_token = FALSE,
      absolute_path = FALSE,
      ssh_identity = FALSE
    )
    if (!is_directory && allowed_type && !approved_publication_binary) {
      if (any(raw == as.raw(0L))) {
        allowed_type <- FALSE
        binary_unapproved <- TRUE
      } else {
        text <- tryCatch(rawToChar(raw), error = function(condition) "")
        if (!nzchar(text) && length(raw)) {
          allowed_type <- FALSE
          binary_unapproved <- TRUE
        } else {
          # HTML、QMD 和代码块均扫描完整原文，禁止先删除可疑区域。
          text_flags <- privacy_text_flags(text)
        }
      }
    } else if (approved_publication_binary) {
      text_flags <- privacy_text_flags(
        privacy_publication_binary_text(relative, raw)
      )
    }
    row <- data.frame(
      file = display,
      entry_type = if (is_directory) "DIRECTORY" else if (is_symlink) "SYMLINK" else "FILE",
      allowed_type = allowed_type,
      hidden_entry = path_flags$hidden,
      patient_identifier_token = text_flags$patient_identifier_token,
      restricted_token = text_flags$restricted_token,
      absolute_path = text_flags$absolute_path,
      ssh_identity = text_flags$ssh_identity,
      forbidden_path = path_flags$forbidden || escaped,
      binary_unapproved = binary_unapproved,
      nested_archive = nested_archive,
      stringsAsFactors = FALSE
    )
    fail <- !row$allowed_type || row$hidden_entry || row$patient_identifier_token ||
      row$restricted_token || row$absolute_path || row$ssh_identity ||
      row$forbidden_path || row$binary_unapproved || row$nested_archive
    row$status <- ifelse(fail, "FAIL", "PASS")
    row$reason_codes <- privacy_reason_codes(row)
    row
  })
  do.call(rbind, rows)
}

scan_review_zip_privacy <- function(path) {
  listing <- tryCatch(
    utils::unzip(path, list = TRUE),
    error = function(condition) stop("Review ZIP cannot be listed: ", conditionMessage(condition), call. = FALSE)
  )
  if (!nrow(listing)) stop("Review ZIP is empty", call. = FALSE)
  names_in_zip <- listing$Name
  if (anyDuplicated(names_in_zip)) stop("REVIEW_ZIP_DUPLICATE_MEMBER", call. = FALSE)
  unsafe_name <- vapply(names_in_zip, function(name) {
    flags <- privacy_path_flags(name)
    flags$hidden || flags$forbidden
  }, logical(1))
  nested <- grepl("\\.(zip|tar|tgz|gz|bz2|xz|7z)$", names_in_zip, ignore.case = TRUE)
  if (any(unsafe_name | nested)) {
    rows <- lapply(seq_along(names_in_zip), function(i) {
      flags <- privacy_path_flags(names_in_zip[[i]])
      row <- data.frame(
        file = paste0("zip::", names_in_zip[[i]]),
        entry_type = "ZIP_MEMBER",
        allowed_type = !(unsafe_name[[i]] || nested[[i]]),
        hidden_entry = flags$hidden,
        patient_identifier_token = FALSE,
        restricted_token = FALSE,
        absolute_path = FALSE,
        ssh_identity = FALSE,
        forbidden_path = flags$forbidden,
        binary_unapproved = FALSE,
        nested_archive = nested[[i]],
        stringsAsFactors = FALSE
      )
      row$status <- ifelse(row$allowed_type, "PASS", "FAIL")
      row$reason_codes <- privacy_reason_codes(row)
      row
    })
    return(do.call(rbind, rows))
  }
  extraction <- tempfile("review-zip-scan-")
  dir.create(extraction, recursive = TRUE, showWarnings = FALSE)
  on.exit(unlink(extraction, recursive = TRUE), add = TRUE)
  # 解压前已验证所有成员名，随后逐成员执行与目录完全相同的严格扫描。
  utils::unzip(path, exdir = extraction)
  scan_review_directory_privacy(extraction, display_prefix = "zip::")
}

scan_review_package_privacy <- function(path) {
  if (!file.exists(path) && !dir.exists(path)) stop("Privacy scan target does not exist", call. = FALSE)
  if (dir.exists(path)) return(scan_review_directory_privacy(path))
  if (tolower(tools::file_ext(path)) != "zip") {
    stop("Privacy scan file target must be a ZIP archive", call. = FALSE)
  }
  scan_review_zip_privacy(path)
}

build_stage_review_archive <- function(stage_pack, stage, root = ".") {
  root <- normalizePath(root, mustWork = TRUE)
  stage_pack <- normalizePath(stage_pack, mustWork = TRUE)
  expected_pack <- normalizePath(
    file.path(root, "human_review", "stages", stage), mustWork = TRUE
  )
  if (!identical(stage_pack, expected_pack)) stop("Stage review pack path mismatch", call. = FALSE)
  privacy <- scan_review_package_privacy(stage_pack)
  if (nrow(privacy) && any(privacy$status != "PASS")) {
    stop("Stage review pack privacy scan failed", call. = FALSE)
  }
  archive_dir <- file.path(root, "human_review", "stage_archives", stage)
  dir.create(archive_dir, recursive = TRUE, showWarnings = FALSE)
  staging <- tempfile(pattern = paste0(".", stage, "."), tmpdir = archive_dir, fileext = ".zip")
  on.exit(if (file.exists(staging)) unlink(staging), add = TRUE)
  old <- getwd()
  on.exit(setwd(old), add = TRUE)
  setwd(dirname(stage_pack))
  # 压缩不可变阶段审核包，作为 StageArtifactEnvelope 的稳定输入证据。
  utils::zip(zipfile = staging, files = basename(stage_pack), flags = "-r9Xq")
  if (!file.exists(staging)) stop("Stage review archive was not created", call. = FALSE)
  archive_privacy <- scan_review_package_privacy(staging)
  if (nrow(archive_privacy) && any(archive_privacy$status != "PASS")) {
    stop("Stage review archive privacy scan failed", call. = FALSE)
  }
  sha <- file_sha256(staging)
  final <- file.path(archive_dir, paste0(sha, ".zip"))
  existing <- list.files(archive_dir, pattern = "^[0-9a-f]{64}[.]zip$", full.names = TRUE)
  if (file.exists(final)) {
    if (!identical(file_sha256(final), sha)) stop("Stage review archive hash collision", call. = FALSE)
    unlink(staging)
  } else if (length(existing)) {
    stop("Stage review archive result conflict", call. = FALSE)
  } else if (!file.rename(staging, final)) {
    stop("Stage review archive atomic publication failed", call. = FALSE)
  }
  final
}

build_consolidated_review_package <- function(root = ".", current_stage, run_id = "current") {
  root <- normalizePath(root, mustWork = TRUE)
  stage_root <- file.path(root, "human_review", "stages")
  stage_order <- c("P00", "A01", "A02", "A03", "A04", "A05", "A06", "A07")
  native_stage_dirs <- if (dir.exists(stage_root)) {
    list.dirs(stage_root, recursive = FALSE, full.names = TRUE)
  } else character()
  mainctl_stage_dirs <- file.path(root, "human_review", stage_order)
  mainctl_stage_dirs <- mainctl_stage_dirs[dir.exists(mainctl_stage_dirs)]
  # 优先使用本地 A07 原生审核目录，并兼容前序 mainctl 单阶段审核目录。
  stage_dirs <- unname(vapply(stage_order, function(stage) {
    native <- native_stage_dirs[basename(native_stage_dirs) == stage]
    local <- mainctl_stage_dirs[basename(mainctl_stage_dirs) == stage]
    if (length(native)) native[[1L]] else if (length(local)) local[[1L]] else ""
  }, character(1)))
  stage_dirs <- stage_dirs[nzchar(stage_dirs)]
  package_name <- paste0("AST_ALT_HUMAN_REVIEW_", run_id)
  package_dir <- file.path(root, "human_review", "consolidated", package_name)
  if (dir.exists(package_dir)) unlink(package_dir, recursive = TRUE)
  dir.create(file.path(package_dir, "stage_packs"), recursive = TRUE, showWarnings = FALSE)
  for (directory in stage_dirs) file.copy(directory, file.path(package_dir, "stage_packs"), recursive = TRUE)
  mappings <- c(
    "01_stage_summary.csv" = "01_STAGE_STATUS_MATRIX.csv",
    "02_acceptance_criteria_results.csv" = "02_ACCEPTANCE_CRITERIA_RESULTS.csv",
    "03_qc_gate_results.csv" = "03_ALL_QC_GATES.csv",
    "04_warnings_errors.csv" = "04_WARNINGS_AND_ERRORS.csv",
    "05_key_results_aggregate.csv" = "05_KEY_RESULTS_FOR_REVIEW.csv",
    "06_output_manifest.csv" = "06_OUTPUT_MANIFEST.csv",
    "07_expected_vs_actual_outputs.csv" = "07_EXPECTED_VS_ACTUAL_OUTPUTS.csv",
    "08_scientific_config_diff.csv" = "08_SCIENTIFIC_CONFIG_DIFF.csv",
    "09_protocol_deviation_log.csv" = "09_PROTOCOL_DEVIATION_LOG.csv",
    "10_cache_reuse_audit.csv" = "10_CACHE_REUSE_AUDIT.csv"
  )
  for (source_name in names(mappings)) {
    write_review_csv(collect_review_csv(stage_dirs, source_name), file.path(package_dir, mappings[[source_name]]))
  }
  write_review_csv(package_versions_table(), file.path(package_dir, "11_PACKAGE_VERSIONS.csv"))
  capture.output(utils::sessionInfo(), file = file.path(package_dir, "12_SESSION_INFO.txt"))
  release_dir <- file.path(root, "release")
  if (identical(current_stage, "A07") && dir.exists(release_dir)) {
    publication_dir <- file.path(package_dir, "publication_outputs")
    dir.create(publication_dir, recursive = TRUE, showWarnings = FALSE)
    release_items <- list.files(release_dir, all.files = TRUE, no.. = TRUE, full.names = TRUE)
    # 复制已经通过 A07 隐私门禁的聚合发布物，供一次性人工审核。
    file.copy(release_items, publication_dir, recursive = TRUE, copy.mode = FALSE, copy.date = FALSE)
    publication_manifest <- file.path(release_dir, "manifest", "publication_output_manifest.csv")
    if (file.exists(publication_manifest)) {
      write_review_csv(
        utils::read.csv(publication_manifest, stringsAsFactors = FALSE, check.names = FALSE),
        file.path(package_dir, "14_PUBLICATION_OUTPUT_MANIFEST.csv")
      )
    }
    source_receipts <- file.path(
      release_dir, "audit", "publication_source_integrity_receipts.csv"
    )
    if (!file.exists(source_receipts)) {
      stop("A07 publication source integrity receipts are missing", call. = FALSE)
    }
    write_review_csv(
      utils::read.csv(source_receipts, stringsAsFactors = FALSE, check.names = FALSE),
      file.path(package_dir, "15_PUBLICATION_SOURCE_INTEGRITY_RECEIPTS.csv")
    )
  }
  start <- c(
    "<!doctype html><html><head><meta charset='utf-8'><title>AST/ALT 人工审核总包</title>",
    "<style>body{font-family:Arial,sans-serif;max-width:1000px;margin:32px auto;line-height:1.6}li{margin:6px 0}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ddd;padding:7px;text-align:left}.notice{padding:12px;border-left:5px solid #b45309;background:#fff7ed}.pass{color:#166534;font-weight:700}.warning{color:#b45309;font-weight:700}</style></head><body>",
    paste0("<h1>AST/ALT Cox 分析人工审核总包</h1><p><strong>当前阶段：</strong>", current_stage, "</p>"),
    if (grepl("^build_validation", run_id)) "<div class='notice'><strong>重要：</strong>本包来自纯合成数据 build validation，只能审核执行完整性，不能作为真实研究结果解释。</div>" else "",
    "<p>本包集中汇总截至当前阶段的所有审核材料。请先检查阶段状态，再依次检查 QC、警告、关键结果和输出完整性。</p>",
    "<h2>集中审核入口</h2>",
    "<ol><li><a href='01_STAGE_STATUS_MATRIX.csv'>阶段状态矩阵</a></li><li><a href='02_ACCEPTANCE_CRITERIA_RESULTS.csv'>验收标准</a></li><li><a href='03_ALL_QC_GATES.csv'>全部QC门禁</a></li><li><a href='04_WARNINGS_AND_ERRORS.csv'>警告与错误</a></li><li><a href='05_KEY_RESULTS_FOR_REVIEW.csv'>关键汇总结果</a></li><li><a href='07_EXPECTED_VS_ACTUAL_OUTPUTS.csv'>预期与实际输出</a></li><li><a href='13_PRIVACY_AND_PATH_QC.csv'>隐私与路径检查</a></li><li><a href='publication_outputs/AST_ALT_Cox_Executive_Review.html'>执行摘要HTML</a></li><li><a href='publication_outputs/AST_ALT_Cox_Full_Report.html'>完整QMD渲染报告</a></li><li>stage_packs/ 中对应阶段的决策模板</li></ol>",
    "<h2>阶段状态</h2>",
    if (file.exists(file.path(package_dir, "01_STAGE_STATUS_MATRIX.csv"))) {
      stage_matrix <- utils::read.csv(file.path(package_dir, "01_STAGE_STATUS_MATRIX.csv"), stringsAsFactors = FALSE, check.names = FALSE)
      rows <- apply(stage_matrix, 1L, function(row) {
        css <- if (grepl("^PASS", row[["stage_status"]])) if (grepl("WARNING", row[["stage_status"]])) "warning" else "pass" else "warning"
        paste0("<tr><td>", row[["stage"]], "</td><td class='", css, "'>", row[["stage_status"]], "</td><td>", row[["review_required"]], "</td></tr>")
      })
      paste0("<table><thead><tr><th>Stage</th><th>Status</th><th>Human review required</th></tr></thead><tbody>", paste(rows, collapse = ""), "</tbody></table>")
    } else "<p>阶段状态矩阵尚未生成。</p>",
    "<p>若某阶段为阻断状态，必须在对应 <code>stage_packs/&lt;STAGE&gt;/decision/</code> 中填写并签署决策文件；空模板不构成批准。</p>",
    "<p>本包不含患者级数据、患者标识或受限模型对象。</p></body></html>"
  )
  writeLines(start, file.path(package_dir, "00_START_HERE_CN.html"), useBytes = TRUE)
  privacy <- scan_review_package_privacy(package_dir)
  write_review_csv(privacy, file.path(package_dir, "13_PRIVACY_AND_PATH_QC.csv"))
  if (nrow(privacy) && any(privacy$status != "PASS")) stop("Consolidated review package privacy scan failed", call. = FALSE)
  zip_path <- paste0(package_dir, ".zip")
  if (file.exists(zip_path)) unlink(zip_path)
  old <- getwd()
  on.exit(setwd(old), add = TRUE)
  setwd(dirname(package_dir))
  # 压缩累计人工审核目录，供用户一次性下载和审核。
  utils::zip(zipfile = basename(zip_path), files = basename(package_dir), flags = "-r9Xq")
  if (!file.exists(zip_path)) stop("Consolidated review ZIP was not created", call. = FALSE)
  final_privacy <- scan_review_package_privacy(zip_path)
  if (nrow(final_privacy) && any(final_privacy$status != "PASS")) {
    unlink(zip_path)
    stop("Consolidated review ZIP privacy scan failed", call. = FALSE)
  }
  writeLines(file.path("human_review", "consolidated", basename(zip_path)), file.path(root, "human_review", "LATEST_HUMAN_REVIEW_PACKAGE.txt"), useBytes = TRUE)
  zip_path
}
