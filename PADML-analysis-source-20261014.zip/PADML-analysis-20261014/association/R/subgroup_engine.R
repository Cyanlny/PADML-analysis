# 亚组引擎：只运行 registry 冻结亚组，并将组内估计与交互检验分开保存。

derive_subgroup_factor <- function(data, variable) {
  if (variable == "Age") return(factor(ifelse(data$Age < 70, "<70", ">=70"), levels = c("<70", ">=70")))
  if (variable == "BMI") return(factor(ifelse(data$BMI < 24, "<24", ">=24"), levels = c("<24", ">=24")))
  factor(as.character(data[[variable]]), levels = unique(as.character(data[[variable]])))
}

subgroup_covariates <- function(variable, root = ".") {
  covariates <- split_registry_terms(read_model_spec("M5", root)$covariates[[1L]])
  setdiff(covariates, variable)
}

fit_subgroup_interaction_models <- function(completed, endpoint_row, variable, root = ".") {
  covariates <- subgroup_covariates(variable, root)
  fixed_full <- fixed_reduced <- tve_full <- tve_reduced <- vector("list", length(completed))
  failure <- character(length(completed))
  for (i in seq_along(completed)) {
    data <- prepare_tve_analysis_data(completed[[i]])
    data$subgroup_analysis <- derive_subgroup_factor(data, variable)
    if (nlevels(data$subgroup_analysis) < 2L) {
      failure[[i]] <- "subgroup has fewer than two levels"
      next
    }
    matrix <- stats::model.matrix(~ subgroup_analysis, data = data)[, -1L, drop = FALSE]
    dummy_names <- paste0("SGD", seq_len(ncol(matrix)))
    colnames(matrix) <- dummy_names
    data <- cbind(data, matrix)
    interaction_names <- paste0("SGI", seq_along(dummy_names))
    for (j in seq_along(dummy_names)) data[[interaction_names[[j]]]] <- data$log2_AST_ALT * data[[dummy_names[[j]]]]
    base_terms <- c("log2_AST_ALT", dummy_names, covariates)
    fixed_reduced_formula <- stats::as.formula(sprintf(
      "survival::Surv(%s, %s) ~ %s", endpoint_row$time_variable[[1L]], endpoint_row$event_variable[[1L]], paste(base_terms, collapse = " + ")
    ))
    fixed_full_formula <- stats::update.formula(fixed_reduced_formula, paste(". ~ . +", paste(interaction_names, collapse = " + ")))
    tve_reduced_formula <- stats::as.formula(sprintf(
      "survival::Surv(%s, %s) ~ %s", endpoint_row$time_variable[[1L]], endpoint_row$event_variable[[1L]],
      paste(c(base_terms, interaction_names, "tt(log2_AST_ALT)"), collapse = " + ")
    ))
    tve_full_formula <- stats::update.formula(tve_reduced_formula, paste(". ~ . +", paste(paste0("tt(", interaction_names, ")"), collapse = " + ")))
    tt_function <- function(x, t, ...) x * g12(t)
    fit_one <- function(formula, use_tt = FALSE) {
      # 加载 survival 包并拟合预注册亚组交互模型。
      if (!requireNamespace("survival", quietly = TRUE)) stop("survival is required")
      if (use_tt) survival::coxph(formula, data = data, ties = "efron", na.action = stats::na.fail, tt = tt_function, x = FALSE, y = FALSE, model = FALSE)
      else survival::coxph(formula, data = data, ties = "efron", na.action = stats::na.fail, x = FALSE, y = FALSE, model = FALSE)
    }
    fixed_reduced[[i]] <- tryCatch(fit_one(fixed_reduced_formula), error = function(e) NULL)
    fixed_full[[i]] <- tryCatch(fit_one(fixed_full_formula), error = function(e) NULL)
    tve_reduced[[i]] <- tryCatch(fit_one(tve_reduced_formula, TRUE), error = function(e) NULL)
    tve_full[[i]] <- tryCatch(fit_one(tve_full_formula, TRUE), error = function(e) NULL)
  }
  list(fixed_full = fixed_full, fixed_reduced = fixed_reduced, tve_full = tve_full, tve_reduced = tve_reduced, failure = failure)
}

read_subgroup_registry <- function(root = ".") {
  registry <- utils::read.csv(
    file.path(root, "config", "subgroup_registry.csv"),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  required <- c(
    "subgroup_id", "variable", "coding", "reference", "cutoff_source",
    "interaction_required", "overlap_action", "minimum_events_per_level", "required"
  )
  if (!identical(names(registry), required) || !nrow(registry) ||
      anyDuplicated(registry$subgroup_id) || any(!grepl("^SG[0-9]{2}$", registry$subgroup_id))) {
    stop("A05_SUBGROUP_REGISTRY_INVALID", call. = FALSE)
  }
  registry
}

make_subgroup_branch_specs <- function(root = ".") {
  registry <- read_subgroup_registry(root)
  lapply(seq_len(nrow(registry)), function(index) registry[index, , drop = FALSE])
}

.subgroup_result_sha256 <- function(value) {
  if (!exists("stage_branch_result_sha256", mode = "function")) {
    stop("A05_OBSERVABILITY_FUNCTION_MISSING", call. = FALSE)
  }
  stage_branch_result_sha256(value)
}

subgroup_branch_envelope <- function(
    subgroup_id, variable, estimates = data.frame(), interaction = data.frame(),
    information = data.frame(), branch_status = "PASS", branch_error = data.frame()) {
  envelope <- list(
    envelope_schema_version = "A05_SUBGROUP_BRANCH_ENVELOPE_V43_V1",
    subgroup_id = subgroup_id,
    variable = variable,
    branch_status = branch_status,
    estimates = estimates,
    interaction = interaction,
    information = information,
    branch_error = branch_error
  )
  envelope$result_identity_sha256 <- .subgroup_result_sha256(envelope)
  envelope
}

validate_subgroup_branch_envelope <- function(envelope) {
  required <- c(
    "envelope_schema_version", "subgroup_id", "variable", "branch_status",
    "estimates", "interaction", "information", "branch_error",
    "result_identity_sha256"
  )
  if (!is.list(envelope) || !identical(sort(names(envelope)), sort(required)) ||
      !identical(envelope$envelope_schema_version, "A05_SUBGROUP_BRANCH_ENVELOPE_V43_V1") ||
      !is.character(envelope$subgroup_id) || length(envelope$subgroup_id) != 1L ||
      !grepl("^SG[0-9]{2}$", envelope$subgroup_id) ||
      !is.character(envelope$variable) || length(envelope$variable) != 1L ||
      !envelope$branch_status %in% c("PASS", "FAILED_TYPED") ||
      any(!vapply(envelope[c("estimates", "interaction", "information", "branch_error")], is.data.frame, logical(1))) ||
      !is.character(envelope$result_identity_sha256) ||
      !grepl("^[0-9a-f]{64}$", envelope$result_identity_sha256)) {
    stop("A05_SUBGROUP_BRANCH_ENVELOPE_INVALID", call. = FALSE)
  }
  payload <- envelope
  supplied <- payload$result_identity_sha256
  payload$result_identity_sha256 <- NULL
  if (!identical(supplied, .subgroup_result_sha256(payload))) {
    stop("A05_SUBGROUP_BRANCH_IDENTITY_MISMATCH", call. = FALSE)
  }
  if (identical(envelope$branch_status, "FAILED_TYPED") != (nrow(envelope$branch_error) == 1L)) {
    stop("A05_SUBGROUP_BRANCH_ERROR_CARDINALITY_INVALID", call. = FALSE)
  }
  invisible(TRUE)
}

.run_subgroup_branch_impl <- function(
    rule, completed, endpoint_row, exposure_scale, root = ".") {
  subgroup_id <- rule$subgroup_id[[1L]]
  variable <- rule$variable[[1L]]
  if (!variable %in% names(completed[[1L]])) {
    interaction <- data.frame(
      subgroup_id = subgroup_id, variable = variable,
      p_interaction_overall = NA_real_, p_interaction_time = NA_real_,
      adjusted_p_overall = NA_real_, adjusted_p_time = NA_real_,
      estimate_status = "NOT_ESTIMABLE", reason = "NE_MISSING_REQUIRED_VARIABLE",
      stringsAsFactors = FALSE
    )
    return(subgroup_branch_envelope(subgroup_id, variable, interaction = interaction))
  }
  estimates <- list()
  information <- list()
  estimate_index <- info_index <- 1L
  subgroup_levels <- levels(derive_subgroup_factor(completed[[1L]], variable))
  covariates <- subgroup_covariates(variable, root)
  for (level in subgroup_levels) {
    subset_completed <- lapply(completed, function(data) {
      group <- derive_subgroup_factor(data, variable)
      data[group == level, , drop = FALSE]
    })
    endpoint <- endpoint_row$event_variable[[1L]]
    time <- endpoint_row$time_variable[[1L]]
    n <- nrow(subset_completed[[1L]])
    events <- sum(subset_completed[[1L]][[endpoint]] == 1L)
    information[[info_index]] <- data.frame(
      subgroup_id = subgroup_id, variable = variable, level = level, n = n,
      events = events,
      information_flag = ifelse(
        events < rule$minimum_events_per_level[[1L]], "LOW_INFORMATION", "ADEQUATE"
      ),
      stringsAsFactors = FALSE
    )
    info_index <- info_index + 1L
    if (events == 0L || n < 5L) next
    riskset <- data.frame(
      endpoint = endpoint,
      time_month = c(6, 12, 24, 36),
      at_risk_n = vapply(
        c(6, 12, 24, 36),
        function(value) sum(subset_completed[[1L]][[time]] >= value),
        integer(1)
      )
    )
    collection <- fit_tve_collection(
      subset_completed, "M5", endpoint_row, "log2_AST_ALT", root,
      covariates_override = covariates,
      include_rutherford_tve = "Rutherford_cat" %in% covariates
    )
    pooled <- pool_tve_collection(collection, exposure_scale, riskset, root)$canonical
    pooled <- pooled[pooled$contrast == "per_1_SD", , drop = FALSE]
    if (nrow(pooled)) {
      pooled$subgroup_id <- subgroup_id
      pooled$subgroup_variable <- variable
      pooled$subgroup_level <- level
      pooled$subgroup_n <- n
      pooled$subgroup_events <- events
      pooled$model_covariates_used <- paste(covariates, collapse = "|")
      estimates[[estimate_index]] <- pooled
      estimate_index <- estimate_index + 1L
    }
  }
  models <- fit_subgroup_interaction_models(completed, endpoint_row, variable, root)
  source(file.path(root, "R", "d1_adapter.R"))
  overall <- tryCatch(
    run_locked_d1(models$fixed_full, models$fixed_reduced, "subgroup_interaction", root),
    error = function(condition) NULL
  )
  time <- tryCatch(
    run_locked_d1(models$tve_full, models$tve_reduced, "time_interaction", root),
    error = function(condition) NULL
  )
  interaction <- data.frame(
    subgroup_id = subgroup_id, variable = variable,
    p_interaction_overall = if (is.null(overall)) NA_real_ else overall$p_value[[1L]],
    p_interaction_time = if (is.null(time)) NA_real_ else time$p_value[[1L]],
    adjusted_p_overall = NA_real_, adjusted_p_time = NA_real_,
    estimate_status = ifelse(is.null(overall) || is.null(time), "NOT_ESTIMABLE", "ESTIMABLE"),
    reason = ifelse(is.null(overall) || is.null(time), "NE_MODEL_NONCONVERGENCE", ""),
    stringsAsFactors = FALSE
  )
  subgroup_branch_envelope(
    subgroup_id, variable,
    estimates = if (length(estimates)) do.call(rbind, estimates) else data.frame(),
    interaction = interaction,
    information = if (length(information)) do.call(rbind, information) else data.frame()
  )
}

run_subgroup_branch <- function(
    spec, completed, endpoint_row, exposure_scale, root = ".") {
  if (!is.data.frame(spec) || nrow(spec) != 1L ||
      !all(c("subgroup_id", "variable") %in% names(spec))) {
    stop("A05_SUBGROUP_BRANCH_SPEC_INVALID", call. = FALSE)
  }
  subgroup_id <- spec$subgroup_id[[1L]]
  variable <- spec$variable[[1L]]
  envelope <- tryCatch(
    .run_subgroup_branch_impl(spec, completed, endpoint_row, exposure_scale, root),
    error = function(condition) {
      message <- if (exists("canonicalize_failure_message", mode = "function")) {
        canonicalize_failure_message(conditionMessage(condition))
      } else {
        gsub("(/[A-Za-z0-9._-]+)+", "<PATH>", conditionMessage(condition), perl = TRUE)
      }
      branch_error <- data.frame(
        subgroup_id = subgroup_id,
        error_class = class(condition)[[1L]],
        reason_code = "SUBGROUP_BRANCH_EXECUTION_FAILED",
        canonical_message = message,
        stringsAsFactors = FALSE
      )
      subgroup_branch_envelope(
        subgroup_id, variable, branch_status = "FAILED_TYPED",
        branch_error = branch_error
      )
    }
  )
  validate_subgroup_branch_envelope(envelope)
  envelope
}

.bind_subgroup_frames <- function(branches, field) {
  frames <- lapply(branches, `[[`, field)
  frames <- Filter(function(value) is.data.frame(value) && nrow(value), frames)
  if (length(frames)) do.call(rbind, frames) else data.frame()
}

combine_subgroup_branches <- function(branches, root = ".") {
  branches <- unlist(lapply(branches, function(branch) {
    if (is.list(branch) && !is.null(branch$subgroup_id)) list(branch) else branch
  }), recursive = FALSE)
  if (!length(branches)) stop("A05_SUBGROUP_BRANCHES_MISSING", call. = FALSE)
  invisible(lapply(branches, validate_subgroup_branch_envelope))
  registry <- read_subgroup_registry(root)
  observed_ids <- unname(vapply(branches, `[[`, character(1), "subgroup_id"))
  if (anyDuplicated(observed_ids) ||
      !identical(sort(observed_ids, method = "radix"), sort(registry$subgroup_id, method = "radix"))) {
    stop("A05_SUBGROUP_BRANCH_REGISTRY_CLOSURE_FAILED", call. = FALSE)
  }
  branches <- branches[match(registry$subgroup_id, observed_ids)]
  interaction_data <- .bind_subgroup_frames(branches, "interaction")
  if (!nrow(interaction_data)) {
    interaction_data <- data.frame(
      subgroup_id = character(), variable = character(),
      p_interaction_overall = numeric(), p_interaction_time = numeric(),
      adjusted_p_overall = numeric(), adjusted_p_time = numeric(),
      estimate_status = character(), reason = character(), stringsAsFactors = FALSE
    )
  }
  valid_overall <- is.finite(interaction_data$p_interaction_overall)
  valid_time <- is.finite(interaction_data$p_interaction_time)
  interaction_data$adjusted_p_overall[valid_overall] <- stats::p.adjust(
    interaction_data$p_interaction_overall[valid_overall], method = "BH"
  )
  interaction_data$adjusted_p_time[valid_time] <- stats::p.adjust(
    interaction_data$p_interaction_time[valid_time], method = "BH"
  )
  branch_coverage <- data.frame(
    subgroup_id = registry$subgroup_id,
    variable = registry$variable,
    branch_status = vapply(branches, `[[`, character(1), "branch_status"),
    result_identity_sha256 = vapply(branches, `[[`, character(1), "result_identity_sha256"),
    stringsAsFactors = FALSE
  )
  list(
    estimates = .bind_subgroup_frames(branches, "estimates"),
    interactions = interaction_data,
    information = .bind_subgroup_frames(branches, "information"),
    branch_coverage = branch_coverage,
    branch_errors = .bind_subgroup_frames(branches, "branch_error")
  )
}

record_subgroup_branch_progress <- function(branch, context) {
  validate_subgroup_branch_envelope(branch)
  write_stage_branch_progress_receipt(
    run_id = context$run_id,
    stage = "A05",
    target = "A05_subgroup_branch",
    branch_type = "subgroup_id",
    branch_id = branch$subgroup_id,
    stage_request_sha256 = context$stage_request_semantic_sha256,
    result_sha256 = branch$result_identity_sha256,
    root = context$run_root
  )$path
}

run_subgroup_stage <- function(completed, endpoint_row, exposure_scale, root = ".") {
  specs <- make_subgroup_branch_specs(root)
  branches <- lapply(
    specs, run_subgroup_branch,
    completed = completed, endpoint_row = endpoint_row,
    exposure_scale = exposure_scale, root = root
  )
  combine_subgroup_branches(branches, root)
}
