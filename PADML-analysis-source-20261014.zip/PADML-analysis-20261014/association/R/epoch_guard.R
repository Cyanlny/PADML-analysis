# v4.3 epoch 与漂移守卫：仅对实际消费的身份做精确失效。

.epoch_stop <- function(code, detail = "") {
  message <- if (nzchar(detail)) paste(code, detail, sep = ": ") else code
  stop(message, call. = FALSE)
}

.epoch_sha256_text <- function(text) {
  # 加载摘要包并计算 epoch SHA-256。
  if (!requireNamespace("digest", quietly = TRUE)) .epoch_stop("EPOCH_DEPENDENCY_MISSING", "digest")
  digest::digest(enc2utf8(paste(text, collapse = "\n")), algo = "sha256", serialize = FALSE)
}

.epoch_file_sha256 <- function(path) {
  # 加载摘要包并计算消费文件 SHA-256。
  if (!requireNamespace("digest", quietly = TRUE)) .epoch_stop("EPOCH_DEPENDENCY_MISSING", "digest")
  digest::digest(file = path, algo = "sha256", serialize = FALSE)
}

canonical_relative_file_digest <- function(project_root, relative_paths) {
  relative_paths <- sort(unique(relative_paths))
  if (any(grepl("^/|^[A-Za-z]:[/\\\\]|(^|/)\\.\\.(/|$)", relative_paths, perl = TRUE))) .epoch_stop("EPOCH_PATH_NOT_RELATIVE")
  full <- file.path(project_root, relative_paths)
  if (any(!file.exists(full)) || any(file.info(full)$isdir %in% TRUE)) .epoch_stop("EPOCH_INPUT_FILE_MISSING")
  hashes <- vapply(full, .epoch_file_sha256, character(1))
  .epoch_sha256_text(paste(relative_paths, hashes, sep = "\t", collapse = "\n"))
}

.epoch_existing_files <- function(project_root, paths) {
  paths[file.exists(file.path(project_root, paths)) & !file.info(file.path(project_root, paths))$isdir]
}

compute_source_epoch <- function(
    project_root, source_patient_order_sha256, handoff_sha256 = "") {
  source_files <- c(
    "config/source_dataset_registry.csv", "config/source_column_mapping_registry.csv",
    "config/source_preprocessing_registry.csv", "config/source_passive_formula_registry.csv"
  )
  if (!grepl("^[0-9a-f]{64}$", source_patient_order_sha256) ||
      (nzchar(handoff_sha256) && !grepl("^[0-9a-f]{64}$", handoff_sha256))) {
    .epoch_stop("EPOCH_SOURCE_COMPONENT_INVALID")
  }
  source_projection <- canonical_relative_file_digest(
    project_root, .epoch_existing_files(project_root, source_files)
  )
  .epoch_sha256_text(c(source_projection, source_patient_order_sha256, handoff_sha256))
}

compute_project_epochs <- function(
    project_root, contract_index, source_patient_order_sha256 = "", handoff_sha256 = "",
    authoritative_source_epoch = "") {
  digests <- authority_digests(contract_index, project_root)
  if (nzchar(authoritative_source_epoch)) {
    if (!grepl("^[0-9a-f]{64}$", authoritative_source_epoch)) {
      .epoch_stop("EPOCH_AUTHORITATIVE_SOURCE_INVALID")
    }
    source_epoch <- authoritative_source_epoch
  } else {
    source_epoch <- compute_source_epoch(
      project_root, source_patient_order_sha256, handoff_sha256
    )
  }

  science_epoch <- digests$scientific_value_digest
  execution_files <- c(
    list.files(file.path(project_root, "R"), pattern = "[.]R$", full.names = FALSE),
    file.path("_targets", list.files(file.path(project_root, "_targets"), pattern = "[.]R$", full.names = FALSE)),
    "config/task_registry.csv", "config/contract_index.csv"
  )
  execution_files[!startsWith(execution_files, "_targets/") & grepl("[.]R$", execution_files)] <- file.path("R", execution_files[!startsWith(execution_files, "_targets/") & grepl("[.]R$", execution_files)])
  execution_epoch <- .epoch_sha256_text(paste(canonical_relative_file_digest(project_root, sort(unique(execution_files))), digests$execution_plan_digest, sep = "\n"))

  # 运行期只消费锁、profile 与已接纳 admission 身份；旧 remote 文件扫描不再参与计算 epoch。
  runtime_files <- .epoch_existing_files(project_root, c(
    "renv.lock", "config/runtime_profile_registry.csv", "config/runtime_budget.yml"
  ))
  remote_runtime_identity <- Sys.getenv(
    "AST_ALT_VERIFIED_RUNTIME_IDENTITY_SHA256", unset = ""
  )
  if (nzchar(remote_runtime_identity) &&
      !grepl("^[0-9a-f]{64}$", remote_runtime_identity)) {
    .epoch_stop("REMOTE_RUNTIME_IDENTITY_INVALID")
  }
  runtime_epoch <- .epoch_sha256_text(c(
    canonical_relative_file_digest(project_root, runtime_files),
    digests$runtime_plan_digest,
    paste0("REMOTE_RUNTIME_IDENTITY=", remote_runtime_identity)
  ))

  publication_files <- c(
    "config/output_registry.csv", "config/output_recipe_registry.csv", "config/table_registry.csv",
    "config/figure_registry.csv", "R/publication_renderer.R", "R/release_manager.R", "R/review_pack.R"
  )
  report_files <- file.path("report", list.files(file.path(project_root, "report"), recursive = TRUE, full.names = FALSE))
  publication_epoch <- .epoch_sha256_text(paste(
    canonical_relative_file_digest(project_root, c(.epoch_existing_files(project_root, publication_files), report_files)),
    digests$deliverable_registry_digest,
    sep = "\n"
  ))
  list(
    source_epoch = source_epoch,
    science_epoch = science_epoch,
    execution_epoch = execution_epoch,
    runtime_epoch = runtime_epoch,
    publication_epoch = publication_epoch
  )
}

.epoch_git_output <- function(project_root, args, allow_failure = FALSE) {
  git <- Sys.which("git")
  if (!nzchar(git)) .epoch_stop("GIT_EXECUTABLE_MISSING")
  previous <- getwd()
  on.exit(setwd(previous), add = TRUE)
  setwd(project_root)
  output <- suppressWarnings(system2(git, args = args, stdout = TRUE, stderr = TRUE))
  status <- attr(output, "status")
  if (is.null(status)) status <- 0L
  if (!identical(as.integer(status), 0L) && !isTRUE(allow_failure)) {
    .epoch_stop("GIT_IDENTITY_READ_FAILED", paste(output, collapse = " "))
  }
  list(status = as.integer(status), output = enc2utf8(output))
}

git_worktree_identity <- function(project_root = ".") {
  project_root <- normalizePath(project_root, mustWork = TRUE)
  stateless_compute <- Sys.getenv("AST_ALT_STATELESS_COMPUTE_NODE", unset = "")
  stateless_commit <- Sys.getenv("AST_ALT_STATELESS_SOURCE_GIT_COMMIT", unset = "")
  stateless_tree <- Sys.getenv("AST_ALT_STATELESS_SOURCE_GIT_TREE", unset = "")
  stateless_content <- Sys.getenv("AST_ALT_STATELESS_CODE_CONTENT_TREE_SHA256", unset = "")
  stateless_values <- c(stateless_commit, stateless_tree, stateless_content)
  if (identical(stateless_compute, "TRUE") || any(nzchar(stateless_values))) {
    if (!identical(stateless_compute, "TRUE") ||
        !grepl("^[0-9a-f]{40}$", stateless_commit) ||
        !grepl("^[0-9a-f]{40}$", stateless_tree) ||
        !grepl("^[0-9a-f]{64}$", stateless_content)) {
      .epoch_stop("STATELESS_CODE_IDENTITY_INVALID")
    }
    return(list(
      git_commit = stateless_commit,
      git_tree = stateless_tree,
      allowed_patch_sha256 = .epoch_sha256_text(c("STATELESS_CODE_CAPSULE", stateless_content)),
      changed_paths = character()
    ))
  }
  packaged_root <- Sys.getenv("AST_ALT_VERIFIED_CODE_BUNDLE_ROOT", unset = "")
  if (nzchar(packaged_root)) {
    packaged_root <- normalizePath(packaged_root, mustWork = TRUE)
    payload_root <- normalizePath(file.path(packaged_root, "payload"), mustWork = TRUE)
    if (!identical(project_root, payload_root)) .epoch_stop("REMOTE_CODE_PROJECT_ROOT_MISMATCH")
    contract_path <- file.path(project_root, "remote", "remote_contract.R")
    if (!exists("verify_remote_bundle_directory", mode = "function")) source(contract_path)
    verified <- verify_remote_bundle_directory(packaged_root, "CODE_BUNDLE")
    expected_identity <- Sys.getenv("AST_ALT_VERIFIED_CODE_IDENTITY_SHA256", unset = "")
    expected_manifest <- Sys.getenv("AST_ALT_VERIFIED_CODE_MANIFEST_SHA256", unset = "")
    expected_tree <- Sys.getenv("AST_ALT_VERIFIED_CODE_CONTENT_TREE_SHA256", unset = "")
    if (!grepl("^[0-9a-f]{64}$", expected_identity) ||
        !grepl("^[0-9a-f]{64}$", expected_manifest) ||
        !grepl("^[0-9a-f]{64}$", expected_tree) ||
        !identical(verified$identity_sha256, expected_identity) ||
        !identical(verified$manifest_sha256, expected_manifest) ||
        !identical(verified$content_tree_sha256, expected_tree)) {
      .epoch_stop("REMOTE_CODE_BUNDLE_IDENTITY_MISMATCH")
    }
    return(list(
      git_commit = verified$origin_git_commit,
      git_tree = verified$origin_git_tree,
      allowed_patch_sha256 = .epoch_sha256_text(c(
        "REMOTE_VERIFIED_CODE_BUNDLE", verified$identity_sha256,
        verified$manifest_sha256, verified$content_tree_sha256
      )),
      changed_paths = character()
    ))
  }
  inside <- .epoch_git_output(project_root, c("rev-parse", "--is-inside-work-tree"))$output
  if (!identical(inside, "true")) .epoch_stop("GIT_WORKTREE_REQUIRED")
  commit <- .epoch_git_output(project_root, c("rev-parse", "HEAD"))$output
  tree <- .epoch_git_output(project_root, c("rev-parse", "HEAD^{tree}"))$output
  if (length(commit) != 1L || !grepl("^[0-9a-f]{40}$", commit) ||
      length(tree) != 1L || !grepl("^[0-9a-f]{40}$", tree)) {
    .epoch_stop("GIT_IDENTITY_INVALID")
  }
  status <- .epoch_git_output(
    project_root, c("status", "--porcelain=v1", "--untracked-files=all")
  )$output
  patch <- .epoch_git_output(
    project_root, c("diff", "--binary", "--no-ext-diff", "HEAD", "--")
  )$output
  untracked <- .epoch_git_output(
    project_root, c("ls-files", "--others", "--exclude-standard")
  )$output
  untracked <- sort(unique(untracked[nzchar(untracked)]))
  unsafe <- startsWith(untracked, "/") |
    grepl("^[A-Za-z]:", untracked, perl = TRUE) |
    grepl("(^|/)\\.\\.(/|$)", untracked, perl = TRUE)
  if (any(unsafe)) .epoch_stop("GIT_UNTRACKED_PATH_UNSAFE")
  untracked_hashes <- if (length(untracked)) {
    paths <- file.path(project_root, untracked)
    if (any(!file.exists(paths)) || any(file.info(paths)$isdir %in% TRUE)) {
      .epoch_stop("GIT_UNTRACKED_IDENTITY_UNSTABLE")
    }
    paste(untracked, vapply(paths, .epoch_file_sha256, character(1)), sep = "=")
  } else character()
  patch_sha256 <- .epoch_sha256_text(c(
    if (length(status)) paste0("STATUS\t", status) else "STATUS\tCLEAN",
    if (length(patch)) paste0("PATCH\t", patch) else "PATCH\tEMPTY",
    if (length(untracked_hashes)) paste0("UNTRACKED\t", untracked_hashes) else "UNTRACKED\tNONE"
  ))
  list(
    git_commit = unname(commit),
    git_tree = unname(tree),
    allowed_patch_sha256 = patch_sha256,
    changed_paths = status
  )
}

.stage_relative_paths <- function(project_root, paths) {
  root <- normalizePath(project_root, mustWork = TRUE)
  normalized <- normalizePath(paths, mustWork = TRUE)
  prefix <- paste0(root, .Platform$file.sep)
  if (any(!startsWith(normalized, prefix))) .epoch_stop("STAGE_CONTRACT_PATH_OUTSIDE_PROJECT")
  gsub("\\\\", "/", substring(normalized, nchar(prefix) + 1L))
}

stage_contract_identity <- function(stage, project_root = ".", execution_slice = FALSE) {
  if (!exists("stage_contract_files", mode = "function") ||
      !exists("stage_full_contract_files", mode = "function")) {
    source(file.path(project_root, "R", "stage_contract_manifest.R"))
  }
  files <- if (isTRUE(execution_slice)) {
    stage_contract_files(stage, project_root)
  } else {
    stage_full_contract_files(stage, project_root)
  }
  relative <- .stage_relative_paths(project_root, files)
  order_index <- order(relative)
  relative <- relative[order_index]
  files <- files[order_index]
  list(
    sha256 = .epoch_sha256_text(paste(
      relative, vapply(files, .epoch_file_sha256, character(1)), sep = "\t", collapse = "\n"
    )),
    file_n = length(files),
    relative_paths = relative
  )
}

.stage_direct_input_stages <- function(stage) {
  switch(
    stage,
    P00 = character(),
    A01 = "P00",
    A02 = "A01",
    A03 = "A02",
    A04 = "A03",
    A05 = "A04",
    A06 = "A05",
    A07 = paste0("A0", 1:6),
    .epoch_stop("STAGE_DIRECT_INPUT_UNKNOWN", stage)
  )
}

.stage_artifact_envelope_path <- function(stage, run_root) {
  directory <- file.path(run_root, "control", "artifacts", stage)
  files <- if (dir.exists(directory)) {
    list.files(directory, pattern = "^[0-9a-f]{64}[.]json$", full.names = TRUE)
  } else character()
  if (length(files) != 1L) .epoch_stop("UPSTREAM_ARTIFACT_ENVELOPE_CARDINALITY", stage)
  files[[1L]]
}

.stage_resolve_run_relative <- function(
    run_root, relative_path, expected_relative = "", expected_kind = c("file", "directory")) {
  expected_kind <- match.arg(expected_kind)
  if (!is.character(relative_path) || length(relative_path) != 1L || is.na(relative_path) ||
      !nzchar(relative_path) || grepl(intToUtf8(92L), relative_path, fixed = TRUE) ||
      grepl("^/|^[A-Za-z]:|(^|/)[.][.]?(/|$)|//", relative_path, perl = TRUE)) {
    .epoch_stop("UPSTREAM_ARTIFACT_RELATIVE_PATH_INVALID", relative_path)
  }
  if (nzchar(expected_relative) && !identical(relative_path, expected_relative)) {
    .epoch_stop("UPSTREAM_ARTIFACT_RELATIVE_PATH_MISMATCH", relative_path)
  }
  root <- normalizePath(run_root, mustWork = TRUE)
  path <- file.path(root, relative_path)
  if (!file.exists(path)) .epoch_stop("UPSTREAM_ARTIFACT_PATH_MISSING", relative_path)
  is_directory <- isTRUE(file.info(path)$isdir)
  if (!identical(is_directory, identical(expected_kind, "directory"))) {
    .epoch_stop("UPSTREAM_ARTIFACT_PATH_KIND_MISMATCH", relative_path)
  }
  if (nzchar(Sys.readlink(path))) .epoch_stop("UPSTREAM_ARTIFACT_SYMLINK_FORBIDDEN", relative_path)
  normalized <- normalizePath(path, mustWork = TRUE)
  prefix <- paste0(root, .Platform$file.sep)
  if (!startsWith(normalized, prefix)) .epoch_stop("UPSTREAM_ARTIFACT_PATH_OUTSIDE_RUN", relative_path)
  normalized
}

read_stage_artifact_envelope <- function(stage, run_root, verify_bundles = TRUE) {
  path <- .stage_artifact_envelope_path(stage, run_root)
  observed_sha <- .epoch_file_sha256(path)
  if (!identical(basename(path), paste0(observed_sha, ".json"))) {
    .epoch_stop("UPSTREAM_ARTIFACT_ENVELOPE_HASH_MISMATCH", stage)
  }
  # 加载 JSON 包并验证不可变 StageArtifactEnvelope。
  if (!requireNamespace("jsonlite", quietly = TRUE)) .epoch_stop("EPOCH_DEPENDENCY_MISSING", "jsonlite")
  envelope <- jsonlite::read_json(path, simplifyVector = TRUE)
  required <- c(
    "schema_version", "stage", "status", "verifier_status",
    "stage_request_semantic_sha256", "stage_capsule_sha256",
    "public_bundle_relative_path", "public_lock_sha256", "public_bundle_sha256",
    "restricted_bundle_relative_path", "restricted_lock_sha256", "restricted_bundle_sha256",
    "review_package_relative_path", "review_package_sha256",
    "artifact_semantic_sha256", "created_at"
  )
  if (!is.list(envelope) || !identical(sort(names(envelope)), sort(required)) ||
      !identical(envelope$schema_version, "1.0.0") ||
      !identical(envelope$stage, stage) || !identical(envelope$status, "SEALED") ||
      !identical(envelope$verifier_status, "PASS") ||
      !is.character(envelope$created_at) || length(envelope$created_at) != 1L ||
      !nzchar(envelope$created_at)) {
    .epoch_stop("UPSTREAM_ARTIFACT_ENVELOPE_SCHEMA_INVALID", stage)
  }
  sha_fields <- c(
    "stage_request_semantic_sha256", "stage_capsule_sha256", "public_lock_sha256",
    "public_bundle_sha256", "review_package_sha256", "artifact_semantic_sha256"
  )
  if (any(!vapply(envelope[sha_fields], function(value) {
    is.character(value) && length(value) == 1L && grepl("^[0-9a-f]{64}$", value)
  }, logical(1)))) .epoch_stop("UPSTREAM_ARTIFACT_ENVELOPE_IDENTITY_INVALID", stage)
  optional_sha <- c("restricted_lock_sha256", "restricted_bundle_sha256")
  if (any(!vapply(envelope[optional_sha], function(value) {
    is.character(value) && length(value) == 1L && (!nzchar(value) || grepl("^[0-9a-f]{64}$", value))
  }, logical(1)))) .epoch_stop("UPSTREAM_ARTIFACT_ENVELOPE_IDENTITY_INVALID", stage)
  restricted_present <- is.character(envelope$restricted_bundle_relative_path) &&
    length(envelope$restricted_bundle_relative_path) == 1L &&
    nzchar(envelope$restricted_bundle_relative_path)
  if (!identical(restricted_present, nzchar(envelope$restricted_lock_sha256)) ||
      !identical(restricted_present, nzchar(envelope$restricted_bundle_sha256))) {
    .epoch_stop("UPSTREAM_RESTRICTED_ARTIFACT_CARDINALITY_INVALID", stage)
  }
  public <- .stage_resolve_run_relative(
    run_root, envelope$public_bundle_relative_path,
    file.path("approved_cache", "public", stage), "directory"
  )
  restricted <- if (restricted_present) {
    .stage_resolve_run_relative(
      run_root, envelope$restricted_bundle_relative_path,
      file.path("approved_cache", "restricted", stage), "directory"
    )
  } else ""
  if (!is.character(envelope$review_package_relative_path) ||
      !grepl("^human_review/.+[.]zip$", envelope$review_package_relative_path, perl = TRUE)) {
    .epoch_stop("UPSTREAM_REVIEW_PACKAGE_PATH_INVALID", stage)
  }
  review <- .stage_resolve_run_relative(
    run_root, envelope$review_package_relative_path, expected_kind = "file"
  )
  if (!identical(.epoch_file_sha256(review), envelope$review_package_sha256)) {
    .epoch_stop("UPSTREAM_REVIEW_PACKAGE_IDENTITY_MISMATCH", stage)
  }
  if (isTRUE(verify_bundles)) {
    if (!exists("validate_bundle_complete", mode = "function")) {
      source(file.path(Sys.getenv("AST_ALT_PROJECT_ROOT", unset = "."), "R", "bundle_manager.R"))
    }
    validate_bundle_complete(public, expected_stage = stage, expected_classification = "PUBLIC_AGGREGATE")
    public_lock <- read_stage_lock(public)
    if (!identical(.epoch_file_sha256(file.path(public, "stage_lock.json")), envelope$public_lock_sha256) ||
        !identical(public_lock$bundle_sha256, envelope$public_bundle_sha256) ||
        !identical(public_lock$stage_request_semantic_sha256, envelope$stage_request_semantic_sha256) ||
        !identical(public_lock$stage_capsule_sha256, envelope$stage_capsule_sha256)) {
      .epoch_stop("UPSTREAM_PUBLIC_LOCK_IDENTITY_MISMATCH", stage)
    }
    if (restricted_present) {
      validate_bundle_complete(restricted, expected_stage = stage)
      restricted_lock <- read_stage_lock(restricted)
      if (!identical(.epoch_file_sha256(file.path(restricted, "stage_lock.json")), envelope$restricted_lock_sha256) ||
          !identical(restricted_lock$bundle_sha256, envelope$restricted_bundle_sha256) ||
          !identical(restricted_lock$stage_request_semantic_sha256, envelope$stage_request_semantic_sha256) ||
          !identical(restricted_lock$stage_capsule_sha256, envelope$stage_capsule_sha256)) {
        .epoch_stop("UPSTREAM_RESTRICTED_LOCK_IDENTITY_MISMATCH", stage)
      }
    }
  }
  expected_semantic <- .epoch_sha256_text(c(
    paste0("stage=", stage),
    paste0("request=", envelope$stage_request_semantic_sha256),
    paste0("public=", envelope$public_bundle_sha256),
    paste0("restricted=", envelope$restricted_bundle_sha256)
  ))
  if (!identical(expected_semantic, envelope$artifact_semantic_sha256)) {
    .epoch_stop("UPSTREAM_ARTIFACT_SEMANTIC_IDENTITY_MISMATCH", stage)
  }
  list(
    path = path, sha256 = observed_sha, envelope = envelope,
    public_bundle = public, restricted_bundle = restricted, review_package = review
  )
}

stage_upstream_artifact_identity <- function(stage, run_root, project_root = ".") {
  stages <- .stage_direct_input_stages(stage)
  if (!length(stages)) {
    root <- .epoch_sha256_text(c("ROOT_STAGE_INPUT", stage))
    return(list(exact_sha256 = root, semantic_sha256 = root, stages = character()))
  }
  direct_public_bundles <- identical(
    Sys.getenv("AST_ALT_STATELESS_COMPUTE_NODE", unset = ""), "TRUE"
  ) || identical(Sys.getenv("AST_ALT_EXECUTION_PROFILE", unset = ""), "release_only")
  if (direct_public_bundles) {
    if (!exists("validate_bundle_complete", mode = "function") ||
        !exists("read_stage_lock", mode = "function")) {
      .epoch_stop("STATELESS_UPSTREAM_VALIDATOR_MISSING")
    }
    locks <- lapply(stages, function(input_stage) {
      bundle <- file.path(run_root, "approved_cache", "public", input_stage)
      validate_bundle_complete(
        bundle, expected_stage = input_stage, expected_classification = "PUBLIC_AGGREGATE"
      )
      lock <- read_stage_lock(bundle)
      if (!lock$approval_basis %in% c("AUTO_GATE_PASS", "HUMAN_APPROVAL") ||
          isTRUE(lock$human_review_required)) {
        .epoch_stop("STATELESS_UPSTREAM_NOT_LOCALLY_APPROVED", input_stage)
      }
      list(lock = lock, lock_sha = .epoch_file_sha256(file.path(bundle, "stage_lock.json")))
    })
    exact <- vapply(locks, `[[`, character(1), "lock_sha")
    semantic <- vapply(locks, function(item) item$lock$bundle_sha256, character(1))
    return(list(
      exact_sha256 = .epoch_sha256_text(paste(stages, exact, sep = "=")),
      semantic_sha256 = .epoch_sha256_text(paste(stages, semantic, sep = "=")),
      stages = stages
    ))
  }
  envelopes <- lapply(stages, read_stage_artifact_envelope, run_root = run_root)
  exact <- vapply(envelopes, `[[`, character(1), "sha256")
  semantic <- vapply(envelopes, function(item) item$envelope$artifact_semantic_sha256, character(1))
  list(
    exact_sha256 = .epoch_sha256_text(paste(stages, exact, sep = "=")),
    semantic_sha256 = .epoch_sha256_text(paste(stages, semantic, sep = "=")),
    stages = stages
  )
}

stage_source_handoff_identity <- function(profile, project_root, handoff_sha256 = "") {
  if (identical(profile, "production")) {
    path <- trimws(Sys.getenv("AST_ALT_HANDOFF_ZIP", unset = ""))
    if (!nzchar(path) || !file.exists(path) || isTRUE(file.info(path)$isdir)) {
      .epoch_stop("DRIFT_HANDOFF_INPUT_MISSING")
    }
    observed <- .epoch_file_sha256(path)
    if (!grepl("^[0-9a-f]{64}$", handoff_sha256) || !identical(observed, handoff_sha256)) {
      .epoch_stop("DRIFT_HANDOFF_IDENTITY_MISMATCH")
    }
    return(observed)
  }
  if (identical(profile, "build_validation")) {
    fixture <- file.path(project_root, "tests", "fixtures", "synthetic_mi_fixture.rds")
    if (!file.exists(fixture)) .epoch_stop("SYNTHETIC_SOURCE_FIXTURE_MISSING")
    return(.epoch_file_sha256(fixture))
  }
  if (grepl("^[0-9a-f]{64}$", handoff_sha256)) return(handoff_sha256)
  .epoch_sha256_text("RELEASE_ONLY_APPROVED_LAYER2_INPUT")
}

compute_stage_drift_components <- function(
    stage, project_root, run_root, profile, epochs, handoff_sha256 = "") {
  required_epochs <- c("source", "science", "execution", "runtime", "publication")
  if (!is.list(epochs) || !identical(sort(names(epochs)), sort(required_epochs)) ||
      any(!vapply(epochs, function(value) grepl("^[0-9a-f]{64}$", value), logical(1)))) {
    .epoch_stop("STAGE_EPOCH_CONTEXT_INVALID")
  }
  index <- read_contract_index(project_root)
  reachable <- authority_digests(index, project_root, stage = stage)
  contract <- stage_contract_identity(stage, project_root)
  execution_contract <- stage_contract_identity(stage, project_root, execution_slice = TRUE)
  git <- git_worktree_identity(project_root)
  upstream <- stage_upstream_artifact_identity(stage, run_root, project_root)
  source_handoff <- stage_source_handoff_identity(profile, project_root, handoff_sha256)
  authority_scientific <- .epoch_sha256_text(c(
    epochs$science, reachable$scientific_value_digest,
    reachable$reachable_authority_slice_digest
  ))
  execution_runtime <- .epoch_sha256_text(c(
    epochs$execution, epochs$runtime, contract$sha256
  ))
  publication_consumer <- .epoch_sha256_text(c(
    epochs$publication, reachable$deliverable_registry_digest,
    reachable$exact_consumer_set_digest
  ))
  list(
    sentinel = make_drift_sentinel(
      git_tree = git$git_tree,
      allowed_patch_sha256 = git$allowed_patch_sha256,
      source_handoff_sha256 = source_handoff,
      authority_scientific_sha256 = authority_scientific,
      execution_runtime_sha256 = execution_runtime,
      upstream_artifact_sha256 = upstream$exact_sha256,
      publication_consumer_sha256 = publication_consumer
    ),
    git = git,
    contract = contract,
    execution_contract = execution_contract,
    upstream_artifact_sha256 = upstream$exact_sha256,
    upstream_artifact_semantic_sha256 = upstream$semantic_sha256,
    source_handoff_sha256 = source_handoff,
    reachable = reachable,
    input_identity_sha256 = .epoch_sha256_text(c(
      source_handoff, upstream$semantic_sha256
    ))
  )
}

stage_consumed_epoch_set <- function(stage) {
  switch(
    stage,
    P00 = c("source", "science", "execution", "runtime", "publication"),
    A01 = c("source", "science", "execution", "runtime"),
    A02 = c("source", "science", "execution", "runtime"),
    A03 = c("source", "science", "execution", "runtime"),
    A04 = c("source", "science", "execution", "runtime"),
    A05 = c("source", "science", "execution", "runtime"),
    A06 = c("source", "science", "execution", "runtime"),
    A07 = c("source", "science", "execution", "runtime", "publication"),
    .epoch_stop("STAGE_CONSUMED_EPOCH_SET_UNKNOWN", stage)
  )
}

stage_request_semantic_identity <- function(stage, profile, components, epochs) {
  consumed <- stage_consumed_epoch_set(stage)
  projections <- list(
    source = .epoch_sha256_text(c(epochs$source, components$reachable$source_value_digest)),
    science = components$reachable$scientific_value_digest,
    execution = .epoch_sha256_text(c(
      components$execution_contract$sha256, components$reachable$execution_plan_digest
    )),
    runtime = .epoch_sha256_text(c(epochs$runtime, components$reachable$runtime_plan_digest)),
    publication = components$reachable$deliverable_registry_digest
  )
  consumer_projections <- list(
    source = components$reachable$source_consumer_set_digest,
    science = components$reachable$science_consumer_set_digest,
    execution = components$reachable$execution_consumer_set_digest,
    runtime = components$reachable$runtime_consumer_set_digest,
    publication = components$reachable$publication_consumer_set_digest
  )
  if (any(!vapply(projections[consumed], function(value) {
    is.character(value) && length(value) == 1L && grepl("^[0-9a-f]{64}$", value)
  }, logical(1)))) .epoch_stop("STAGE_REQUEST_PROJECTION_INVALID")
  list(
    consumed_epoch_set = paste(consumed, collapse = "|"),
    sha256 = .epoch_sha256_text(c(
      paste0("stage=", stage), paste0("profile=", profile),
      paste0("consumed_epoch_set=", paste(consumed, collapse = "|")),
      paste(names(projections[consumed]), unlist(projections[consumed]), sep = "="),
      paste0("input=", components$input_identity_sha256),
      paste0("execution_contract=", components$execution_contract$sha256),
      paste0("consumed_authority=", .epoch_sha256_text(
        paste(names(projections[consumed]), unlist(projections[consumed]), sep = "=")
      )),
      paste0("consumers=", .epoch_sha256_text(
        paste(names(consumer_projections[consumed]), unlist(consumer_projections[consumed]), sep = "=")
      ))
    ))
  )
}

.write_drift_sentinel_receipt <- function(run_root, sentinel) {
  if (!exists("canonical_json", mode = "function") ||
      !exists(".control_write_atomic", mode = "function")) {
    project_root <- Sys.getenv("AST_ALT_PROJECT_ROOT", unset = ".")
    source(file.path(project_root, "R", "control_kernel.R"))
  }
  text <- canonical_json(sentinel)
  sha <- .epoch_sha256_text(text)
  relative <- file.path("control", "sentinels", paste0(sha, ".json"))
  path <- file.path(run_root, relative)
  if (file.exists(path)) {
    observed <- paste(readLines(path, warn = FALSE), collapse = "\n")
    if (!identical(observed, text)) .epoch_stop("DRIFT_SENTINEL_HASH_COLLISION")
  } else {
    .control_write_atomic(path, text, mode = "0600")
  }
  list(path = path, relative_path = relative, sha256 = sha)
}

record_pre_seal_drift <- function(context) {
  required <- c(
    "stage", "pre_stage_sentinel", "source_epoch", "science_epoch",
    "execution_epoch", "runtime_epoch", "publication_epoch"
  )
  if (!is.list(context) || length(setdiff(required, names(context)))) {
    .epoch_stop("PRE_SEAL_CONTEXT_INVALID")
  }
  epochs <- list(
    source = context$source_epoch,
    science = context$science_epoch,
    execution = context$execution_epoch,
    runtime = context$runtime_epoch,
    publication = context$publication_epoch
  )
  handoff_sha256 <- context$handoff_sha256
  if (identical(context$profile, "release_only")) {
    handoff_sha256 <- Sys.getenv("AST_ALT_FROZEN_SOURCE_HANDOFF_SHA256", unset = "")
    if (!grepl("^[0-9a-f]{64}$", handoff_sha256)) {
      .epoch_stop("RELEASE_ONLY_SOURCE_HANDOFF_IDENTITY_INVALID")
    }
  }
  fresh <- compute_stage_drift_components(
    stage = context$stage,
    project_root = context$project_root,
    run_root = context$run_root,
    profile = context$profile,
    epochs = epochs,
    handoff_sha256 = handoff_sha256
  )
  compare_drift_sentinels(context$pre_stage_sentinel, fresh$sentinel)
  receipt <- .write_drift_sentinel_receipt(context$run_root, fresh$sentinel)
  if (identical(context$profile, "release_only")) {
    return(list(
      sentinel = fresh$sentinel,
      relative_path = receipt$relative_path,
      sha256 = receipt$sha256,
      state_sha256 = ""
    ))
  }
  if (!exists("read_run_state", mode = "function") ||
      !exists("transition_run_state", mode = "function")) {
    source(file.path(context$project_root, "R", "control_kernel.R"))
  }
  state <- read_run_state(context$run_root)
  if (!identical(state$active_stage, context$stage) ||
      !identical(state$active_gate, "EXECUTION_ACTIVE")) {
    .epoch_stop("PRE_SEAL_CONTROL_STATE_INVALID")
  }
  transition <- transition_run_state(
    run_root = context$run_root,
    expected_state_sha256 = state$state_sha256,
    updates = list(
      active_gate = "PRE_SEAL_DRIFT_SENTINEL_PASS",
      primary_next_action = paste0("SEAL_STAGE_", context$stage)
    ),
    event_type = "PRE_SEAL_ADMISSION",
    reason_code = "PRE_SEAL_DRIFT_SENTINEL_PASS",
    relative_path = receipt$relative_path,
    artifact_sha256 = receipt$sha256
  )
  list(
    sentinel = fresh$sentinel,
    relative_path = receipt$relative_path,
    sha256 = receipt$sha256,
    state_sha256 = transition$state$state_sha256
  )
}

assert_pre_seal_drift <- function(context) {
  required <- c(
    "stage", "pre_stage_sentinel", "source_epoch", "science_epoch",
    "execution_epoch", "runtime_epoch", "publication_epoch"
  )
  if (!is.list(context) || length(setdiff(required, names(context)))) {
    .epoch_stop("PRE_SEAL_CONTEXT_INVALID")
  }
  fresh <- compute_stage_drift_components(
    stage = context$stage,
    project_root = context$project_root,
    run_root = context$run_root,
    profile = context$profile,
    epochs = list(
      source = context$source_epoch, science = context$science_epoch,
      execution = context$execution_epoch, runtime = context$runtime_epoch,
      publication = context$publication_epoch
    ),
    handoff_sha256 = context$handoff_sha256
  )
  compare_drift_sentinels(context$pre_stage_sentinel, fresh$sentinel)
  TRUE
}

make_drift_sentinel <- function(
    git_tree, allowed_patch_sha256, source_handoff_sha256,
    authority_scientific_sha256, execution_runtime_sha256,
    upstream_artifact_sha256, publication_consumer_sha256) {
  values <- list(
    git_tree = git_tree,
    allowed_patch_sha256 = allowed_patch_sha256,
    source_handoff_sha256 = source_handoff_sha256,
    authority_scientific_sha256 = authority_scientific_sha256,
    execution_runtime_sha256 = execution_runtime_sha256,
    upstream_artifact_sha256 = upstream_artifact_sha256,
    publication_consumer_sha256 = publication_consumer_sha256
  )
  if (any(!vapply(values, function(value) is.character(value) && length(value) == 1L && !is.na(value) && nzchar(value), logical(1)))) {
    .epoch_stop("DRIFT_SENTINEL_FIELD_INVALID")
  }
  values[sort(names(values))]
}

compare_drift_sentinels <- function(pre_stage, pre_seal) {
  fields <- sort(union(names(pre_stage), names(pre_seal)))
  changed <- fields[!vapply(fields, function(name) {
    name %in% names(pre_stage) && name %in% names(pre_seal) &&
      identical(pre_stage[[name]], pre_seal[[name]])
  }, logical(1))]
  if (length(changed)) {
    .epoch_stop("MID_STAGE_DRIFT_DETECTED", paste(changed, collapse = "|"))
  }
  TRUE
}

assert_worktree_scope <- function(changed_paths, allowed_write_paths) {
  changed_paths <- sort(unique(changed_paths))
  allowed_write_paths <- sort(unique(allowed_write_paths))
  unexpected <- setdiff(changed_paths, allowed_write_paths)
  list(valid = !length(unexpected), unexpected = unexpected)
}

build_stage_context_capsule <- function(
    stage, task_id, contract_index, project_root,
    allowed_read_paths, allowed_write_paths, input_identity,
    expected_cardinality, acceptance_commands, primary_next_action,
    conflict_id = "", blocker_id = "", input_schema = list(), output_schema = list(),
    lineage = list(), pre_stage_sentinel = list()) {
  active <- contract_index[contract_index$status == "ACTIVE", , drop = FALSE]
  reachable <- active[vapply(active$consumer_stages, function(value) stage %in% strsplit(value, "|", fixed = TRUE)[[1L]], logical(1)), , drop = FALSE]
  pointers <- lapply(seq_len(nrow(reachable)), function(index) {
    row <- reachable[index, , drop = FALSE]
    list(
      contract_id = row$contract_id[[1L]],
      semantic_key = row$semantic_key[[1L]],
      relative_path = row$owner_relative_path[[1L]],
      owner_pointer = row$owner_pointer[[1L]],
      sha256 = .epoch_file_sha256(file.path(project_root, row$owner_relative_path[[1L]]))
    )
  })
  capsule <- list(
    schema_version = "1.0.0",
    stage = stage,
    task_id = task_id,
    allowed_read_paths = sort(unique(allowed_read_paths)),
    allowed_write_paths = sort(unique(allowed_write_paths)),
    active_owner_pointers = pointers,
    input_schema = input_schema,
    output_schema = output_schema,
    input_identity = input_identity,
    expected_cardinality = expected_cardinality,
    acceptance_commands = acceptance_commands,
    conflict_id = conflict_id,
    blocker_id = blocker_id,
    primary_next_action = primary_next_action,
    lineage = lineage,
    pre_stage_sentinel = pre_stage_sentinel
  )
  if (nchar(canonical_json(capsule), type = "bytes") > 32768L) .epoch_stop("STAGE_CONTEXT_CAPSULE_TOO_LARGE")
  capsule
}
