# v4.3 U04 MI QC：convergence(all)、完整性、donor、observed-cell 与 passive 重算共用一条路径。

.mi_qc_stop <- function(code, detail = "") {
  message <- if (nzchar(detail)) paste(code, detail, sep = ": ") else code
  stop(message, call. = FALSE)
}

assert_mi_qc_dependency_lock_v43 <- function(project_root = ".") {
  required <- c(
    "mice", "rstan", "purrr", "dplyr", "abind", "BH", "desc",
    "distributional", "inline", "loo", "matrixStats", "pkgbuild",
    "posterior", "QuickJSR", "RcppParallel", "StanHeaders", "tensorA"
  )
  installed <- vapply(required, requireNamespace, logical(1), quietly = TRUE)
  if (!all(installed)) .mi_qc_stop("MI_QC_DEPENDENCY_MISSING", paste(required[!installed], collapse = "|"))
  lock_path <- file.path(project_root, "renv.lock")
  if (!file.exists(lock_path)) .mi_qc_stop("MI_QC_RENV_LOCK_MISSING")
  # 中文备注：加载 JSON 包并验证 convergence(all) 的直接依赖已进入离线 lock。
  if (!requireNamespace("jsonlite", quietly = TRUE)) .mi_qc_stop("MI_QC_DEPENDENCY_MISSING", "jsonlite")
  lock <- jsonlite::read_json(lock_path, simplifyVector = TRUE)
  locked <- names(lock$Packages)
  missing <- setdiff(required, locked)
  if (length(missing)) .mi_qc_stop("MI_QC_DEPENDENCY_NOT_LOCKED", paste(missing, collapse = "|"))
  invisible(TRUE)
}

.mi_qc_require_control_kernel <- function(project_root = ".") {
  if (!exists("canonical_json", mode = "function") ||
      !exists(".control_sha256_text", mode = "function") ||
      !exists(".control_write_atomic", mode = "function")) {
    path <- file.path(project_root, "R", "control_kernel.R")
    if (!file.exists(path)) .mi_qc_stop("MI_QC_CONTROL_KERNEL_MISSING")
    source(path)
  }
  invisible(TRUE)
}

.mi_qc_receipt_fields <- function() {
  c(
    "schema_version", "request_sha256", "source_epoch", "recipe_epoch",
    "predictor_policy_sha256", "candidate_projection_sha256", "candidate_edge_n",
    "predictor_matrix_sha256", "predictor_edge_n", "status",
    "m", "final_iteration", "continuation_count", "convergence_function", "diagnostic",
    "parameters", "psrf_threshold", "required_consecutive_iterations",
    "missing_diagnostic_n", "nonfinite_diagnostic_n", "psrf_exceed_n",
    "lag1_review_n", "standardized_shift_review_n", "logged_event_n", "hard_fail_n",
    "completed_dataset_n", "observed_cell_change_n", "invalid_pmm_donor_n",
    "remaining_missing_n", "nonfinite_completed_n", "passive_policy", "created_at",
    "receipt_sha256"
  )
}

finalize_mi_qc_receipt_v43 <- function(payload, project_root = ".") {
  .mi_qc_require_control_kernel(project_root)
  fields <- .mi_qc_receipt_fields()
  payload_fields <- fields[fields != "receipt_sha256"]
  if (!is.list(payload) || !identical(names(payload), payload_fields)) {
    .mi_qc_stop("MI_QC_RECEIPT_SCHEMA_INVALID")
  }
  receipt <- payload
  receipt$receipt_sha256 <- .control_sha256_text(canonical_json(payload))
  validate_mi_qc_receipt_v43(receipt, project_root)
  receipt
}

validate_mi_qc_receipt_v43 <- function(receipt, project_root = ".") {
  .mi_qc_require_control_kernel(project_root)
  fields <- .mi_qc_receipt_fields()
  if (!is.list(receipt) || !identical(sort(names(receipt)), sort(fields))) {
    .mi_qc_stop("MI_QC_RECEIPT_SCHEMA_INVALID")
  }
  receipt <- receipt[fields]
  sha_fields <- c(
    "request_sha256", "source_epoch", "recipe_epoch", "predictor_policy_sha256",
    "candidate_projection_sha256", "predictor_matrix_sha256", "receipt_sha256"
  )
  edge_counts_are_exact_integers <-
    is.integer(receipt$candidate_edge_n) && length(receipt$candidate_edge_n) == 1L &&
    !is.na(receipt$candidate_edge_n) &&
    is.integer(receipt$predictor_edge_n) && length(receipt$predictor_edge_n) == 1L &&
    !is.na(receipt$predictor_edge_n)
  if (any(!vapply(receipt[sha_fields], function(value) {
    is.character(value) && length(value) == 1L && grepl("^[0-9a-f]{64}$", value)
  }, logical(1))) ||
      !identical(receipt$schema_version, "1.0.0") ||
      !identical(receipt$predictor_policy_sha256, "6fad1a3d5c1291d0e8f7246e62284c876743d169762e1d1adcb0addf4870cb1d") ||
      !edge_counts_are_exact_integers ||
      !identical(receipt$candidate_edge_n, 896L) ||
      receipt$predictor_edge_n < 1L || receipt$predictor_edge_n > 896L ||
      !receipt$status %in% c(
        "PASS", "HUMAN_REVIEW_REQUIRED", "CONTINUE_TO_40", "CONTINUE_TO_50",
        "CONTINUE_TO_100", "CONTINUE_TO_200",
        "PROTOCOL_REVIEW_REQUIRED", "FAIL"
      ) ||
      !identical(as.integer(receipt$m), 20L) ||
      !as.integer(receipt$final_iteration) %in% c(30L, 40L, 50L, 100L, 200L) ||
      !identical(as.integer(receipt$continuation_count), match(as.integer(receipt$final_iteration), c(30L, 40L, 50L, 100L, 200L)) - 1L) ||
      !identical(receipt$convergence_function, "mice::convergence") ||
      !identical(receipt$diagnostic, "all") ||
      !identical(receipt$parameters, "mean|sd") ||
      !identical(as.numeric(receipt$psrf_threshold), 1.1) ||
      !identical(as.integer(receipt$required_consecutive_iterations), 3L) ||
      !identical(as.integer(receipt$completed_dataset_n), 20L) ||
      !identical(receipt$passive_policy, "RECALCULATE_AFTER_EACH_COMPLETED_DATASET") ||
      !grepl("^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$", receipt$created_at)) {
    .mi_qc_stop("MI_QC_RECEIPT_VALUE_INVALID")
  }
  count_fields <- c(
    "missing_diagnostic_n", "nonfinite_diagnostic_n", "psrf_exceed_n",
    "lag1_review_n", "standardized_shift_review_n", "logged_event_n", "hard_fail_n",
    "observed_cell_change_n", "invalid_pmm_donor_n", "remaining_missing_n",
    "nonfinite_completed_n"
  )
  if (any(!vapply(receipt[count_fields], function(value) {
    is.numeric(value) && length(value) == 1L && is.finite(value) && value >= 0 && value == floor(value)
  }, logical(1)))) {
    .mi_qc_stop("MI_QC_RECEIPT_COUNT_INVALID")
  }
  payload <- receipt[names(receipt) != "receipt_sha256"]
  if (!identical(receipt$receipt_sha256, .control_sha256_text(canonical_json(payload)))) {
    .mi_qc_stop("MI_QC_RECEIPT_IDENTITY_MISMATCH")
  }
  invisible(TRUE)
}

compute_mice_convergence_diagnostics_v43 <- function(
    mids_object, target_names, owner, project_root = ".") {
  validate_mi_contract_v43(owner)
  assert_mi_qc_dependency_lock_v43(project_root)
  if (!inherits(mids_object, "mids") || as.integer(mids_object$m) < 2L ||
      as.integer(mids_object$iteration) < as.integer(owner$qc$required_consecutive_iterations)) {
    .mi_qc_stop("MI_QC_MIDS_DIAGNOSTIC_INPUT_INVALID")
  }
  target_names <- as.character(target_names)
  if (!length(target_names) || anyDuplicated(target_names) ||
      length(setdiff(target_names, names(mids_object$data)))) {
    .mi_qc_stop("MI_QC_TARGET_SET_INVALID")
  }
  chain_mean_names <- dimnames(mids_object$chainMean)[[1L]]
  chain_var_names <- dimnames(mids_object$chainVar)[[1L]]
  if (is.null(chain_mean_names) || is.null(chain_var_names) ||
      length(setdiff(target_names, chain_mean_names)) ||
      length(setdiff(target_names, chain_var_names))) {
    .mi_qc_stop("MI_QC_TARGET_CHAIN_DIAGNOSTIC_MISSING")
  }
  diagnostic_mids <- mids_object
  diagnostic_mids$data <- mids_object$data[target_names]
  diagnostic_mids$chainMean <- mids_object$chainMean[target_names, , , drop = FALSE]
  diagnostic_mids$chainVar <- mids_object$chainVar[target_names, , , drop = FALSE]
  final_iteration <- as.integer(mids_object$iteration)
  window_n <- as.integer(owner$qc$required_consecutive_iterations)
  required_iterations <- seq.int(final_iteration - window_n + 1L, final_iteration)
  rows <- lapply(c("mean", "sd"), function(parameter) {
    # 中文备注：调用 mice::convergence(diagnostic="all") 计算指定参数的 PSRF 与 lag-1 指标。
    observed <- suppressWarnings(mice::convergence(
      diagnostic_mids, diagnostic = owner$qc$diagnostic, parameter = parameter
    ))
    required_columns <- c(".it", "vrb", "ac", "psrf")
    if (!is.data.frame(observed) || length(setdiff(required_columns, names(observed)))) {
      .mi_qc_stop("MI_QC_CONVERGENCE_SCHEMA_INVALID", parameter)
    }
    observed <- observed[
      observed$vrb %in% target_names & observed$.it %in% required_iterations,
      required_columns, drop = FALSE
    ]
    expected_keys <- as.vector(outer(
      target_names, required_iterations, function(variable, iteration) paste(variable, iteration, sep = "|")
    ))
    observed_keys <- paste(observed$vrb, observed$.it, sep = "|")
    if (nrow(observed) != length(expected_keys) || anyDuplicated(observed_keys) ||
        !setequal(observed_keys, expected_keys)) {
      .mi_qc_stop("MI_QC_CONVERGENCE_CARDINALITY_INVALID", parameter)
    }
    observed <- observed[order(match(observed$vrb, target_names), observed$.it), , drop = FALSE]
    data.frame(
      variable = observed$vrb,
      parameter = parameter,
      iteration = as.integer(observed$.it),
      psrf = as.numeric(observed$psrf),
      lag1_autocorrelation = as.numeric(observed$ac),
      psrf_threshold = as.numeric(owner$qc$psrf_threshold),
      psrf_status = ifelse(
        is.finite(observed$psrf) & observed$psrf <= as.numeric(owner$qc$psrf_threshold),
        "PASS", "FAIL"
      ),
      lag1_review_flag = ifelse(
        is.finite(observed$ac) & abs(observed$ac) > as.numeric(owner$qc$lag1_review_abs_threshold),
        "MANUAL_REVIEW", "PASS"
      ),
      stringsAsFactors = FALSE
    )
  })
  result <- do.call(rbind, rows)
  rownames(result) <- NULL
  result
}

summarize_mi_convergence_v43 <- function(diagnostics, owner, current_iteration) {
  validate_mi_contract_v43(owner)
  required <- c(
    "variable", "parameter", "iteration", "psrf", "lag1_autocorrelation",
    "psrf_threshold", "psrf_status", "lag1_review_flag"
  )
  if (!is.data.frame(diagnostics) || !identical(names(diagnostics), required) || !nrow(diagnostics)) {
    .mi_qc_stop("MI_QC_DIAGNOSTIC_SCHEMA_INVALID")
  }
  current_iteration <- as.integer(current_iteration)
  expected_iterations <- seq.int(
    current_iteration - as.integer(owner$qc$required_consecutive_iterations) + 1L,
    current_iteration
  )
  groups <- table(paste(diagnostics$variable, diagnostics$parameter, sep = "|"))
  if (any(groups != as.integer(owner$qc$required_consecutive_iterations)) ||
      !identical(sort(unique(diagnostics$iteration)), expected_iterations) ||
      !identical(sort(unique(diagnostics$parameter)), c("mean", "sd"))) {
    .mi_qc_stop("MI_QC_DIAGNOSTIC_WINDOW_INVALID")
  }
  missing_n <- sum(is.na(diagnostics$psrf)) + sum(is.na(diagnostics$lag1_autocorrelation))
  nonfinite_n <- sum(!is.na(diagnostics$psrf) & !is.finite(diagnostics$psrf)) +
    sum(!is.na(diagnostics$lag1_autocorrelation) & !is.finite(diagnostics$lag1_autocorrelation))
  psrf_exceed_n <- sum(
    is.finite(diagnostics$psrf) & diagnostics$psrf > as.numeric(owner$qc$psrf_threshold)
  )
  lag1_review_n <- sum(
    is.finite(diagnostics$lag1_autocorrelation) &
      abs(diagnostics$lag1_autocorrelation) > as.numeric(owner$qc$lag1_review_abs_threshold)
  )
  list(
    target_n = length(unique(diagnostics$variable)),
    parameter_n = length(unique(diagnostics$parameter)),
    required_consecutive_iterations = as.integer(owner$qc$required_consecutive_iterations),
    final_iteration = current_iteration,
    missing_n = as.integer(missing_n),
    nonfinite_n = as.integer(nonfinite_n),
    psrf_exceed_n = as.integer(psrf_exceed_n),
    lag1_review_n = as.integer(lag1_review_n),
    convergence_pass = identical(missing_n, as.integer(owner$qc$missing_diagnostic_n)) &&
      identical(nonfinite_n, as.integer(owner$qc$nonfinite_diagnostic_n)) && psrf_exceed_n == 0L
  )
}

complete_and_recalculate_mids_v43 <- function(
    mids_object, canonical, mapping, formula_registry) {
  if (!inherits(mids_object, "mids") || !is.data.frame(canonical) ||
      !identical(names(canonical), mapping$target_name)) {
    .mi_qc_stop("MI_QC_COMPLETION_INPUT_INVALID")
  }
  completed <- lapply(seq_len(as.integer(mids_object$m)), function(imputation) {
    # 中文备注：从受限 mids 提取一套 completed data；该对象仅在 U04/U05 受限内存中处理。
    data <- mice::complete(mids_object, action = imputation)
    if (length(setdiff(mapping$target_name, names(data)))) .mi_qc_stop("MI_QC_COMPLETED_COLUMNS_MISSING")
    data <- data[mapping$target_name]
    # 中文备注：按锁定公式顺序重算每套 completed data 的全部 passive variables。
    data <- recalculate_source_passive_variables(data, formula_registry)
    data <- data[mapping$target_name]
    validate_canonical_pre_mi(data, mapping)
    data
  })
  completed
}

.mi_qc_changed_count <- function(before, after, observed) {
  if (is.factor(before)) {
    value_changed <- as.character(before[observed]) != as.character(after[observed])
    level_changed <- !identical(levels(before), levels(after)) || !identical(is.ordered(before), is.ordered(after))
  } else if (is.numeric(before)) {
    value_changed <- before[observed] != after[observed]
    level_changed <- FALSE
  } else {
    value_changed <- as.character(before[observed]) != as.character(after[observed])
    level_changed <- FALSE
  }
  value_changed[is.na(value_changed)] <- TRUE
  c(changed_n = sum(value_changed), level_changed = as.integer(level_changed))
}

evaluate_observed_cell_identity_v43 <- function(canonical, completed) {
  if (!is.data.frame(canonical) || !length(completed) ||
      any(!vapply(completed, is.data.frame, logical(1)))) {
    .mi_qc_stop("MI_QC_OBSERVED_IDENTITY_INPUT_INVALID")
  }
  rows <- lapply(names(canonical), function(variable) {
    observed <- !is.na(canonical[[variable]])
    counts <- vapply(completed, function(data) {
      if (!variable %in% names(data) || nrow(data) != nrow(canonical)) return(c(changed_n = Inf, level_changed = 1))
      .mi_qc_changed_count(canonical[[variable]], data[[variable]], observed)
    }, numeric(2))
    changed_n <- sum(counts["changed_n", ])
    level_changed_n <- sum(counts["level_changed", ])
    data.frame(
      variable = variable,
      observed_n = sum(observed),
      completed_n = length(completed),
      changed_n = as.integer(changed_n),
      level_changed_n = as.integer(level_changed_n),
      status = ifelse(changed_n == 0L && level_changed_n == 0L, "PASS", "FAIL"),
      stringsAsFactors = FALSE
    )
  })
  do.call(rbind, rows)
}

evaluate_pmm_donor_membership_v43 <- function(canonical, completed, target_names) {
  rows <- lapply(target_names, function(variable) {
    missing <- is.na(canonical[[variable]])
    donors <- canonical[[variable]][!missing]
    if (!is.numeric(donors) || any(!is.finite(donors)) || !length(donors)) {
      .mi_qc_stop("MI_QC_DONOR_REFERENCE_INVALID", variable)
    }
    imputed <- unlist(lapply(completed, function(data) data[[variable]][missing]), use.names = FALSE)
    invalid <- is.na(imputed) | !is.finite(imputed) | !imputed %in% donors
    data.frame(
      variable = variable,
      donor_n = length(donors),
      imputed_n_total = length(imputed),
      invalid_donor_n = sum(invalid),
      status = ifelse(sum(invalid) == 0L, "PASS", "FAIL"),
      stringsAsFactors = FALSE
    )
  })
  do.call(rbind, rows)
}

evaluate_completed_structure_v43 <- function(canonical, completed, expected_m) {
  expected_m <- as.integer(expected_m)
  if (length(completed) != expected_m) {
    return(data.frame(
      imputation = seq_along(completed), row_n = vapply(completed, nrow, integer(1)),
      column_n = vapply(completed, ncol, integer(1)), same_patient_set = FALSE,
      same_patient_order = FALSE, same_column_order = FALSE, remaining_missing_n = NA_integer_,
      nonfinite_numeric_n = NA_integer_, factor_identity = FALSE, status = "FAIL",
      stringsAsFactors = FALSE
    ))
  }
  reference_ids <- as.character(canonical$Patient_ID)
  factor_names <- names(canonical)[vapply(canonical, is.factor, logical(1))]
  rows <- lapply(seq_along(completed), function(imputation) {
    data <- completed[[imputation]]
    numeric_names <- names(data)[vapply(data, is.numeric, logical(1))]
    factor_identity <- all(vapply(factor_names, function(variable) {
      is.factor(data[[variable]]) && identical(levels(data[[variable]]), levels(canonical[[variable]])) &&
        identical(is.ordered(data[[variable]]), is.ordered(canonical[[variable]]))
    }, logical(1)))
    same_set <- setequal(as.character(data$Patient_ID), reference_ids)
    same_order <- identical(as.character(data$Patient_ID), reference_ids)
    same_columns <- identical(names(data), names(canonical))
    missing_n <- sum(is.na(data))
    nonfinite_n <- sum(vapply(data[numeric_names], function(value) sum(!is.finite(value)), integer(1)))
    pass <- nrow(data) == nrow(canonical) && same_set && same_order && same_columns &&
      missing_n == 0L && nonfinite_n == 0L && factor_identity
    data.frame(
      imputation = imputation, row_n = nrow(data), column_n = ncol(data),
      same_patient_set = same_set, same_patient_order = same_order,
      same_column_order = same_columns, remaining_missing_n = missing_n,
      nonfinite_numeric_n = nonfinite_n, factor_identity = factor_identity,
      status = ifelse(pass, "PASS", "FAIL"), stringsAsFactors = FALSE
    )
  })
  do.call(rbind, rows)
}

evaluate_mi_distribution_v43 <- function(canonical, completed, target_names, owner) {
  threshold <- as.numeric(owner$qc$standardized_mean_shift_review_abs_threshold)
  rows <- lapply(target_names, function(variable) {
    original <- as.numeric(canonical[[variable]])
    missing <- is.na(original)
    observed <- original[!missing]
    imputed <- unlist(lapply(completed, function(data) as.numeric(data[[variable]][missing])), use.names = FALSE)
    observed_sd <- stats::sd(observed)
    shift <- if (is.finite(observed_sd) && observed_sd > 0 && length(imputed)) {
      (mean(imputed) - mean(observed)) / observed_sd
    } else {
      NA_real_
    }
    remaining <- sum(is.na(imputed))
    nonfinite <- sum(!is.na(imputed) & !is.finite(imputed))
    hard_fail <- !is.finite(observed_sd) || observed_sd <= 0 || remaining > 0L || nonfinite > 0L || !is.finite(shift)
    review <- !hard_fail && abs(shift) > threshold
    data.frame(
      variable = variable,
      observed_n = length(observed),
      imputed_n_total = length(imputed),
      observed_mean = mean(observed),
      imputed_mean = mean(imputed),
      observed_sd = observed_sd,
      imputed_sd = stats::sd(imputed),
      standardized_mean_shift = shift,
      remaining_missing_n = remaining,
      nonfinite_n = nonfinite,
      review_flag = ifelse(review, "MANUAL_REVIEW", "PASS"),
      status = ifelse(hard_fail, "FAIL", ifelse(review, "REVIEW", "PASS")),
      stringsAsFactors = FALSE
    )
  })
  do.call(rbind, rows)
}

decide_mi_qc_terminal_v43 <- function(
    hard_fail_n, logged_event_n, convergence_pass,
    lag1_review_n, shift_review_n, current_iteration) {
  if (as.integer(hard_fail_n) > 0L) return("FAIL")
  if (as.integer(logged_event_n) > 0L) return("HUMAN_REVIEW_REQUIRED")
  if (!isTRUE(convergence_pass)) {
    current_iteration <- as.integer(current_iteration)
    if (current_iteration == 30L) return("CONTINUE_TO_40")
    if (current_iteration == 40L) return("CONTINUE_TO_50")
    if (current_iteration == 50L) return("CONTINUE_TO_100")
    if (current_iteration == 100L) return("CONTINUE_TO_200")
    if (current_iteration == 200L) return("PROTOCOL_REVIEW_REQUIRED")
    .mi_qc_stop("MI_QC_ITERATION_INVALID")
  }
  if (as.integer(lag1_review_n) > 0L || as.integer(shift_review_n) > 0L) {
    return("HUMAN_REVIEW_REQUIRED")
  }
  "PASS"
}

.validate_mi_qc_transaction_context_v43 <- function(transaction_path, request) {
  validate_mi_transaction_request_v43(request)
  if (!is.character(transaction_path) || length(transaction_path) != 1L ||
      is.na(transaction_path) || !dir.exists(transaction_path) ||
      nzchar(Sys.readlink(transaction_path))) {
    .mi_qc_stop("MI_QC_TRANSACTION_CONTEXT_INVALID")
  }
  normalized <- normalizePath(transaction_path, mustWork = TRUE)
  portable <- gsub("\\\\", "/", normalized)
  if (!grepl("(^|/)(candidate_cache|restricted_cache)(/|$)", portable) ||
      !identical(basename(normalized), request$request_sha256)) {
    .mi_qc_stop("MI_QC_TRANSACTION_CONTEXT_INVALID")
  }
  normalized
}

evaluate_formal_mi_qc_v43 <- function(
    mids_object, canonical, runtime, projection, owner, mapping,
    formula_registry, request, transaction_path, project_root = ".") {
  transaction_path <- .validate_mi_qc_transaction_context_v43(
    transaction_path, request
  )
  current_iteration <- as.integer(mids_object$iteration)
  mids_validation <- validate_formal_working_mids_v43(
    mids_object, runtime, projection, owner, mapping, current_iteration
  )
  .assert_formal_request_matches_runtime_v43(
    request, runtime, projection, owner, mapping, transaction_path, project_root
  )
  diagnostics <- compute_mice_convergence_diagnostics_v43(
    mids_object, projection$target_names, owner, project_root
  )
  convergence <- summarize_mi_convergence_v43(diagnostics, owner, current_iteration)
  completed <- complete_and_recalculate_mids_v43(
    mids_object, canonical, mapping, formula_registry
  )
  structure <- evaluate_completed_structure_v43(canonical, completed, as.integer(owner$recipe$m))
  observed <- evaluate_observed_cell_identity_v43(canonical, completed)
  donors <- evaluate_pmm_donor_membership_v43(canonical, completed, projection$target_names)
  distribution <- evaluate_mi_distribution_v43(canonical, completed, projection$target_names, owner)
  hard_fail_n <- sum(structure$status != "PASS") + sum(observed$status != "PASS") +
    sum(donors$status != "PASS") + sum(distribution$status == "FAIL")
  shift_review_n <- sum(distribution$review_flag == "MANUAL_REVIEW")
  terminal <- decide_mi_qc_terminal_v43(
    hard_fail_n = hard_fail_n,
    logged_event_n = mids_validation$logged_event_n,
    convergence_pass = convergence$convergence_pass,
    lag1_review_n = convergence$lag1_review_n,
    shift_review_n = shift_review_n,
    current_iteration = current_iteration
  )
  receipt <- finalize_mi_qc_receipt_v43(list(
    schema_version = "1.0.0",
    request_sha256 = request$request_sha256,
    source_epoch = request$source_epoch,
    recipe_epoch = request$recipe_epoch,
    predictor_policy_sha256 = request$predictor_policy_sha256,
    candidate_projection_sha256 = request$candidate_projection_sha256,
    candidate_edge_n = as.integer(request$candidate_edge_n),
    predictor_matrix_sha256 = runtime$predictor_matrix_sha256,
    predictor_edge_n = as.integer(runtime$predictor_edge_n),
    status = terminal,
    m = as.integer(owner$recipe$m),
    final_iteration = current_iteration,
    continuation_count = match(current_iteration, c(30L, 40L, 50L, 100L, 200L)) - 1L,
    convergence_function = "mice::convergence",
    diagnostic = owner$qc$diagnostic,
    parameters = "mean|sd",
    psrf_threshold = as.numeric(owner$qc$psrf_threshold),
    required_consecutive_iterations = as.integer(owner$qc$required_consecutive_iterations),
    missing_diagnostic_n = convergence$missing_n,
    nonfinite_diagnostic_n = convergence$nonfinite_n,
    psrf_exceed_n = convergence$psrf_exceed_n,
    lag1_review_n = convergence$lag1_review_n,
    standardized_shift_review_n = shift_review_n,
    logged_event_n = mids_validation$logged_event_n,
    hard_fail_n = as.integer(hard_fail_n),
    completed_dataset_n = length(completed),
    observed_cell_change_n = sum(observed$changed_n) + sum(observed$level_changed_n),
    invalid_pmm_donor_n = sum(donors$invalid_donor_n),
    remaining_missing_n = sum(structure$remaining_missing_n),
    nonfinite_completed_n = sum(structure$nonfinite_numeric_n),
    passive_policy = "RECALCULATE_AFTER_EACH_COMPLETED_DATASET",
    created_at = format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  ), project_root)
  list(
    status = terminal,
    receipt = receipt,
    convergence_diagnostics = diagnostics,
    convergence_summary = convergence,
    distribution_qc = distribution,
    observed_cell_qc = observed,
    donor_qc = donors,
    structure_qc = structure,
    logged_events = if (is.null(mids_object$loggedEvents)) data.frame() else mids_object$loggedEvents,
    completed = completed
  )
}
