# 出版层渲染器：只读取显式允许的 Layer 2 汇总结果，不拟合或重新合并模型。

publication_recipe_columns <- function(value) {
  if (length(value) != 1L || is.na(value) || !nzchar(trimws(value))) return(character())
  output <- trimws(strsplit(value, "|", fixed = TRUE)[[1L]])
  output[nzchar(output)]
}

publication_key_columns <- function(value) {
  if (length(value) != 1L || is.na(value) || !nzchar(trimws(value))) return(character())
  output <- trimws(strsplit(value, "|", fixed = TRUE)[[1L]])
  output[nzchar(output)]
}

publication_semantic_numeric_columns <- function(columns) {
  pattern <- paste0(
    "(^source_imp$|^missing_(n|rate)$|^smd_|^observed_(n|mean|sd)$|",
    "^imputed_(n_total|mean|sd)$|^standardized_mean_shift$|^wasserstein_approx$|",
    "^(illegal_level|remaining_missing|nonfinite)_n$|^n_(risk|event)$|^survival$|",
    "^subgroup_(n|events)$|^log2_(mean|sd|q1|q3|iqr)$|",
    "^reference_(log2|median)$|^p_lt_0_05_n$|",
    "^median_(rho|abs_rho|comparison_value)$|^(positive|negative)_fraction$|",
    "^direction_consistency$|^consistent_dummy_n$|^total_imputation_n$|",
    "^(p90|maximum)_comparison_value$|^proportion_ge_|^worst_imputation$|",
    "^omitted_imputation$|^remaining_(n|events)$|^effect_time_order$|",
    "^baseline_n$|^at_risk_fraction$|^cumulative_events_by_time$|",
    "^events_in_previous_interval$|^value_numeric$)"
  )
  extension_numeric <- c(
    "time_grid_index", "point_index", "transformed_time", "trend_median",
    "trend_p10", "trend_p90", "ph_trigger_n", "ph_valid_imputation_n",
    "ph_trigger_fraction", "analysis_n", "event_n", "cutoff", "cutoff_log2",
    "cutoff_ast_alt", "support_lower_log2", "support_upper_log2",
    "support_width_log2", "cutoff_imputation_median_log2",
    "cutoff_imputation_iqr_log2", "maximum_variant_difference_log2",
    "cutoff_bootstrap_median", "cutoff_bootstrap_iqr",
    "cutoff_bootstrap_lower_95_ci", "cutoff_bootstrap_upper_95_ci",
    "x_ast_alt", "y_value", "lower_value", "upper_value", "fpr", "tpr",
    "auc", "auc_lower_95_ci", "auc_upper_95_ci", "sensitivity",
    "specificity", "youden_j", "case_n", "control_n", "g_time",
    "maximum_weight", "valid_bootstrap_n", "bootstrap_n", "low_n", "high_n",
    "low_events", "high_events", "logrank_chisq", "logrank_df"
  )
  columns[grepl(pattern, columns, perl = TRUE) | columns %in% extension_numeric]
}

publication_semantic_integer_columns <- function(columns) {
  pattern <- paste0(
    "(^source_imp$|^missing_n$|^observed_n$|^imputed_n_total$|",
    "^(illegal_level|remaining_missing|nonfinite)_n$|^n_(risk|event)$|",
    "^subgroup_(n|events)$|^p_lt_0_05_n$|^consistent_dummy_n$|",
    "^total_imputation_n$|^worst_imputation$|^omitted_imputation$|",
    "^remaining_(n|events)$|^effect_time_order$|^baseline_n$|",
    "^cumulative_events_by_time$|^events_in_previous_interval$)"
  )
  extension_integer <- c(
    "time_grid_index", "point_index", "ph_trigger_n", "ph_valid_imputation_n",
    "analysis_n", "event_n", "case_n", "control_n", "valid_bootstrap_n",
    "bootstrap_n", "low_n", "high_n", "low_events", "high_events", "logrank_df"
  )
  columns[grepl(pattern, columns, perl = TRUE) | columns %in% extension_integer]
}

publication_semantic_logical_columns <- function(columns) {
  columns[columns %in% c(
    "triggered", "human_review_required", "persistent_collinearity", "protected"
  )]
}

canonical_applicability_columns_v43 <- function(value) {
  if (length(value) != 1L || is.na(value) || !nzchar(trimws(value)) ||
      identical(trimws(value), "NONE")) return(character())
  output <- trimws(strsplit(value, "|", fixed = TRUE)[[1L]])
  output[nzchar(output)]
}

.canonical_applicability_sha256_file_v43 <- function(path) {
  # 加载摘要包以计算 STRUCT_NA_1A owner、registry、source 与 receipt 身份。
  if (!requireNamespace("digest", quietly = TRUE)) stop("digest is required", call. = FALSE)
  digest::digest(file = path, algo = "sha256", serialize = FALSE)
}

.canonical_applicability_sha256_text_v43 <- function(text) {
  # 加载摘要包以计算 STRUCT_NA_1A 规范文本身份。
  if (!requireNamespace("digest", quietly = TRUE)) stop("digest is required", call. = FALSE)
  digest::digest(enc2utf8(paste(text, collapse = "\n")), algo = "sha256", serialize = FALSE)
}

.canonical_applicability_canonicalize_v43 <- function(value) {
  if (is.data.frame(value)) {
    return(lapply(seq_len(nrow(value)), function(index) {
      .canonical_applicability_canonicalize_v43(as.list(value[index, , drop = FALSE]))
    }))
  }
  if (is.list(value)) {
    if (!is.null(names(value))) value <- value[order(names(value), method = "radix")]
    return(lapply(value, .canonical_applicability_canonicalize_v43))
  }
  if (!is.null(names(value))) {
    value <- value[order(names(value), method = "radix")]
    return(lapply(as.list(value), .canonical_applicability_canonicalize_v43))
  }
  value
}

.canonical_applicability_json_v43 <- function(value) {
  # 加载 JSON 包以生成 STRUCT_NA_1A 选择与 applicability receipt 的规范序列化。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  as.character(jsonlite::toJSON(
    .canonical_applicability_canonicalize_v43(value),
    auto_unbox = TRUE, null = "null", na = "null", digits = 17, pretty = FALSE
  ))
}

read_canonical_structural_na_selection_v43 <- function(project_root = ".") {
  project_root <- normalizePath(project_root, mustWork = TRUE)
  selection_relative <- file.path(
    "protocol", "decisions", "approved",
    "CANONICAL_STRUCTURAL_NA_V43_001_SELECTION.json"
  )
  selection_path <- file.path(project_root, selection_relative)
  package_relative <- file.path(
    "protocol", "decisions", "pending", "CANONICAL_STRUCTURAL_NA_V43_001.json"
  )
  package_path <- file.path(project_root, package_relative)
  if (!file.exists(selection_path) || !file.exists(package_path)) {
    stop("CANONICAL_STRUCTURAL_NA_SELECTION_OR_PACKAGE_MISSING", call. = FALSE)
  }
  # 加载并精确验证用户选择、DecisionPackage SHA 与禁止数值替换规则。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  selection <- tryCatch(
    jsonlite::read_json(selection_path, simplifyVector = TRUE),
    error = function(error) NULL
  )
  package <- tryCatch(
    jsonlite::read_json(package_path, simplifyVector = FALSE),
    error = function(error) NULL
  )
  expected_names <- c(
    "schema_version", "decision_id", "conflict_id", "decision_package_relative_path",
    "decision_package_sha256", "selected_option_id", "selection_sha256", "status",
    "authority_class", "approved_at", "activation_owner_relative_path",
    "activation_owner_pointer", "selected_rule", "invalidation_frontier",
    "production_authorized"
  )
  expected_rule_names <- c(
    "policy", "profile_owner", "receipt_owner", "selector_cardinality",
    "unknown_or_overlapping_profile", "unlisted_na_or_nonfinite",
    "numeric_replacement"
  )
  option_ids <- if (is.list(package) && is.list(package$options)) {
    vapply(package$options, function(option) option$option_id, character(1))
  } else character()
  rule <- if (is.list(selection)) selection$selected_rule else NULL
  valid <- is.list(selection) &&
    identical(sort(names(selection)), sort(expected_names)) &&
    is.list(rule) && identical(sort(names(rule)), sort(expected_rule_names)) &&
    identical(selection$schema_version, "1.0.0") &&
    identical(selection$decision_id, "CANONICAL_STRUCTURAL_NA_V43_001") &&
    identical(selection$conflict_id,
      "9b8f8aaea8d4665db39825a899fc233ebb9aab0dde5c1ccd70dba9cbf6270647") &&
    identical(selection$decision_package_relative_path,
      gsub("\\\\", "/", package_relative)) &&
    identical(selection$selected_option_id, "STRUCT_NA_1A") &&
    identical(selection$status, "HUMAN_APPROVED") &&
    identical(selection$authority_class, "USER_SELECTION") &&
    identical(selection$activation_owner_relative_path,
      gsub("\\\\", "/", selection_relative)) &&
    identical(selection$activation_owner_pointer, "/selected_rule") &&
    identical(selection$production_authorized, FALSE) &&
    identical(
      selection$selection_sha256,
      .canonical_applicability_sha256_text_v43("STRUCT_NA_1A")
    ) &&
    identical(
      selection$decision_package_sha256,
      .canonical_applicability_sha256_file_v43(package_path)
    ) &&
    identical(package$decision_id, selection$decision_id) &&
    identical(package$conflict_id, selection$conflict_id) &&
    selection$selected_option_id %in% option_ids &&
    identical(rule$policy,
      "EXACT_ONE_PROFILE_PER_CANONICAL_ROW_WITH_TYPED_ALLOWED_NA_COLUMNS") &&
    identical(rule$profile_owner, "config/canonical_value_applicability_registry.csv") &&
    identical(rule$receipt_owner, "canonical_value_applicability_receipt.json") &&
    identical(rule$selector_cardinality, "EXACTLY_ONE") &&
    identical(rule$unknown_or_overlapping_profile, "FAIL") &&
    identical(rule$unlisted_na_or_nonfinite, "FAIL") &&
    identical(rule$numeric_replacement, "FORBIDDEN")
  if (!isTRUE(valid)) stop("CANONICAL_STRUCTURAL_NA_SELECTION_INVALID", call. = FALSE)
  attr(selection, "receipt_file_sha256") <-
    .canonical_applicability_sha256_file_v43(selection_path)
  selection
}

canonical_applicability_selector_ids_v43 <- function() {
  c(
    "ALL_ROWS", "ESTIMABLE_ROWS", "TYPED_NOT_ESTIMABLE_ROWS",
    "TABLE1_NONCATEGORICAL", "TABLE1_CATEGORICAL",
    "KM_POSITIVE_SURVIVAL", "KM_ZERO_SURVIVAL",
    "COLLINEARITY_ESTIMABLE", "COLLINEARITY_NOT_ESTIMABLE",
    "SECONDARY_FIXED_EFFECT", "SECONDARY_TIME_SPECIFIC",
    "SENS_FIXED_MI", "SENS_TVE_MI", "SENS_PIECEWISE", "SENS_FIXED_NON_MI",
    "SENS_MAX_DIFFERENCE", "SENS_RUBIN_INFO", "SENS_LANDMARK", "SENS_JOINT_D1"
  )
}

read_canonical_abi_registry <- function(project_root = ".") {
  path <- file.path(project_root, "config", "canonical_abi_registry.csv")
  required <- c(
    "canonical_schema_id", "source_canonical_file", "producer_stage",
    "required_columns", "primary_key", "data_classification",
    "patient_level_allowed", "forbidden_columns"
  )
  if (!file.exists(path) || file.info(path)$isdir) {
    registry <- setNames(
      data.frame(matrix(nrow = 0L, ncol = length(required))), required
    )
    attr(registry, "registry_sha256") <- "NOT_APPLICABLE"
    return(registry)
  }
  registry <- utils::read.csv(
    path, stringsAsFactors = FALSE, check.names = FALSE, na.strings = character()
  )
  if (!identical(names(registry), required) || !nrow(registry) ||
      anyDuplicated(registry$source_canonical_file) ||
      any(!registry$data_classification %in% c("PUBLIC_AGGREGATE", "RESTRICTED_AGGREGATE")) ||
      any(registry$patient_level_allowed) ||
      any(!nzchar(registry$canonical_schema_id)) ||
      any(!nzchar(registry$required_columns)) || any(!nzchar(registry$primary_key))) {
    stop("CANONICAL_ABI_REGISTRY_INVALID", call. = FALSE)
  }
  attr(registry, "registry_sha256") <- .canonical_applicability_sha256_file_v43(path)
  registry
}

canonical_abi_row <- function(source_file, producer_stage, project_root = ".") {
  registry <- read_canonical_abi_registry(project_root)
  row <- registry[
    registry$source_canonical_file == source_file &
      registry$producer_stage == producer_stage,
    , drop = FALSE
  ]
  if (nrow(row) > 1L) stop("CANONICAL_ABI_CARDINALITY_INVALID: ", source_file, call. = FALSE)
  row
}

validate_canonical_abi_source <- function(data, source_file, producer_stage, project_root = ".") {
  row <- canonical_abi_row(source_file, producer_stage, project_root)
  if (!nrow(row)) return(invisible(FALSE))
  canonical <- utils::read.csv(
    file.path(project_root, "config", "canonical_file_registry.csv"),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  owner <- canonical[canonical$source_canonical_file == source_file, , drop = FALSE]
  required <- publication_recipe_columns(row$required_columns[[1L]])
  key <- publication_key_columns(row$primary_key[[1L]])
  forbidden <- publication_recipe_columns(row$forbidden_columns[[1L]])
  if (!is.data.frame(data) || nrow(owner) != 1L ||
      !identical(owner$producer_stage[[1L]], producer_stage) ||
      !identical(owner$canonical_schema_id[[1L]], row$canonical_schema_id[[1L]]) ||
      length(setdiff(required, names(data))) || length(setdiff(key, names(data))) ||
      any(forbidden %in% names(data)) || anyDuplicated(data[key])) {
    stop("CANONICAL_ABI_SOURCE_INVALID: ", source_file, call. = FALSE)
  }
  invisible(TRUE)
}

audit_canonical_abi_source <- function(data, source_file, producer_stage, project_root = ".") {
  validate_canonical_abi_source(data, source_file, producer_stage, project_root)
  row <- canonical_abi_row(source_file, producer_stage, project_root)
  if (!nrow(row)) return(NULL)
  numeric_columns <- names(data)[vapply(data, is.numeric, logical(1))]
  actual_na <- if (length(numeric_columns)) {
    output <- do.call(cbind, lapply(data[numeric_columns], is.na))
    colnames(output) <- numeric_columns
    output
  } else matrix(FALSE, nrow = nrow(data), ncol = 0L)
  typed <- if (all(c("estimate_status", "not_estimable_reason_code") %in% names(data))) {
    as.character(data$estimate_status) == "NOT_ESTIMABLE" &
      !is.na(data$not_estimable_reason_code) &
      nzchar(trimws(as.character(data$not_estimable_reason_code)))
  } else rep(FALSE, nrow(data))
  typed[is.na(typed)] <- FALSE
  structural <- !typed & if (length(actual_na)) rowSums(actual_na) > 0L else FALSE
  list(
    source_file = source_file, row_count = as.integer(nrow(data)),
    profile_id_by_row = rep(paste0("ABI_", row$canonical_schema_id[[1L]]), nrow(data)),
    row_profile_cardinality = rep(1L, nrow(data)), allowed_na_matrix = actual_na,
    structural_na_row = structural, structural_na_row_n = as.integer(sum(structural)),
    structural_na_cell_n = if (length(actual_na)) as.integer(sum(actual_na[structural, , drop = FALSE])) else 0L,
    typed_not_estimable_row_n = as.integer(sum(typed)), missing_status_row_n = 0L,
    permitted_nonfinite_cell_n = 0L,
    profile_counts = paste0("ABI_", row$canonical_schema_id[[1L]], "=", nrow(data)),
    status = "PASS"
  )
}

publication_canonical_audit <- function(
    data, source_file, producer_stage, project_root, applicability_registry) {
  profiles <- applicability_registry[applicability_registry$source_file == source_file, , drop = FALSE]
  if (nrow(profiles)) {
    return(audit_canonical_value_applicability_v43(
      data, source_file, project_root,
      registry = applicability_registry, validate_registry = FALSE
    ))
  }
  audit <- audit_canonical_abi_source(data, source_file, producer_stage, project_root)
  if (is.null(audit)) stop("CANONICAL_SOURCE_HAS_NO_APPLICABILITY_OR_ABI: ", source_file, call. = FALSE)
  audit
}

.validate_canonical_value_applicability_registry_v43 <- function(
    registry, project_root = ".") {
  required <- c(
    "revision", "profile_id", "source_file", "producer_stage", "selector_id",
    "selector_expression", "na_match_rule", "allowed_numeric_na_columns",
    "minimum_na_count", "allow_missing_estimate_status", "reason_code",
    "reason_description", "selection_code", "active"
  )
  if (!is.data.frame(registry) || !identical(names(registry), required) ||
      nrow(registry) < 1L || anyDuplicated(registry$profile_id) ||
      any(!nzchar(registry$profile_id)) || any(!nzchar(registry$source_file)) ||
      any(!grepl("^[A-Za-z0-9_.-]+[.]csv$", registry$source_file)) ||
      any(!registry$na_match_rule %in% c("EXACT", "SUBSET")) ||
      any(!registry$selector_id %in% canonical_applicability_selector_ids_v43()) ||
      any(!grepl("^NA_[A-Z0-9_]+$", registry$reason_code)) ||
      any(registry$revision != "r01") || any(registry$selection_code != "STRUCT_NA_1A") ||
      any(!registry$active) || any(registry$minimum_na_count < 0L) ||
      anyDuplicated(paste(registry$source_file, registry$selector_id, sep = "\r"))) {
    unknown <- unique(registry$selector_id[
      !registry$selector_id %in% canonical_applicability_selector_ids_v43()
    ])
    if (length(unknown)) {
      stop("CANONICAL_APPLICABILITY_SELECTOR_UNKNOWN: ", paste(unknown, collapse = "|"), call. = FALSE)
    }
    stop("CANONICAL_APPLICABILITY_REGISTRY_INVALID", call. = FALSE)
  }
  parsed <- lapply(registry$allowed_numeric_na_columns, canonical_applicability_columns_v43)
  if (any(vapply(parsed, anyDuplicated, integer(1)) > 0L) ||
      any(vapply(seq_len(nrow(registry)), function(index) {
        registry$na_match_rule[[index]] == "EXACT" &&
          length(parsed[[index]]) != as.integer(registry$minimum_na_count[[index]])
      }, logical(1)))) {
    stop("CANONICAL_APPLICABILITY_REGISTRY_COLUMN_SET_INVALID", call. = FALSE)
  }
  recipes <- utils::read.csv(
    file.path(project_root, "config", "output_recipe_registry.csv"),
    stringsAsFactors = FALSE, check.names = FALSE, na.strings = character()
  )
  expected <- unique(recipes[
    recipes$source_kind == "CANONICAL", c("source_file", "producer_stage"), drop = FALSE
  ])
  expected <- expected[order(expected$source_file, method = "radix"), , drop = FALSE]
  observed <- unique(registry[c("source_file", "producer_stage")])
  abi <- read_canonical_abi_registry(project_root)
  abi_sources <- unique(data.frame(
    source_file = abi$source_canonical_file,
    producer_stage = abi$producer_stage,
    stringsAsFactors = FALSE
  ))
  abi_sources <- abi_sources[abi_sources$source_file %in% expected$source_file, , drop = FALSE]
  if (nrow(merge(observed, abi_sources, by = c("source_file", "producer_stage")))) {
    stop("CANONICAL_APPLICABILITY_ABI_OWNER_OVERLAP", call. = FALSE)
  }
  observed <- unique(rbind(observed, abi_sources))
  observed <- observed[order(observed$source_file, method = "radix"), , drop = FALSE]
  rownames(expected) <- NULL
  rownames(observed) <- NULL
  if (!identical(expected, observed)) {
    stop("CANONICAL_APPLICABILITY_REGISTRY_SOURCE_CLOSURE_INVALID", call. = FALSE)
  }
  invisible(registry)
}

read_canonical_value_applicability_registry_v43 <- function(project_root = ".") {
  selection <- read_canonical_structural_na_selection_v43(project_root)
  path <- file.path(project_root, selection$selected_rule$profile_owner)
  if (!file.exists(path) || file.info(path)$isdir) {
    stop("CANONICAL_APPLICABILITY_REGISTRY_MISSING", call. = FALSE)
  }
  registry <- utils::read.csv(
    path, stringsAsFactors = FALSE, check.names = FALSE, na.strings = character()
  )
  .validate_canonical_value_applicability_registry_v43(registry, project_root)
  attr(registry, "registry_sha256") <- .canonical_applicability_sha256_file_v43(path)
  registry
}

.canonical_applicability_require_columns_v43 <- function(data, columns, selector_id) {
  missing <- setdiff(columns, names(data))
  if (length(missing)) {
    stop(
      "CANONICAL_APPLICABILITY_SELECTOR_COLUMNS_MISSING: ", selector_id, "/",
      paste(missing, collapse = "|"), call. = FALSE
    )
  }
}

.canonical_applicability_selector_v43 <- function(data, selector_id) {
  require_columns <- function(columns) {
    .canonical_applicability_require_columns_v43(data, columns, selector_id)
  }
  character_value <- function(column) {
    require_columns(column)
    as.character(data[[column]])
  }
  numeric_value <- function(column) {
    require_columns(column)
    if (!is.numeric(data[[column]])) {
      stop("CANONICAL_APPLICABILITY_SELECTOR_TYPE_INVALID: ", selector_id, "/", column,
        call. = FALSE)
    }
    data[[column]]
  }
  status <- if ("estimate_status" %in% names(data)) as.character(data$estimate_status) else NULL
  result <- switch(
    selector_id,
    ALL_ROWS = rep(TRUE, nrow(data)),
    ESTIMABLE_ROWS = {
      require_columns("estimate_status")
      status == "ESTIMABLE"
    },
    TYPED_NOT_ESTIMABLE_ROWS = {
      require_columns(c("estimate_status", "not_estimable_reason_code"))
      reason <- as.character(data$not_estimable_reason_code)
      status == "NOT_ESTIMABLE" & !is.na(reason) & nzchar(trimws(reason))
    },
    TABLE1_NONCATEGORICAL = character_value("method") != "Pearson_chisq",
    TABLE1_CATEGORICAL = character_value("method") == "Pearson_chisq",
    KM_POSITIVE_SURVIVAL = {
      survival <- numeric_value("survival")
      is.finite(survival) & survival > 0 & survival <= 1
    },
    KM_ZERO_SURVIVAL = {
      survival <- numeric_value("survival")
      !is.na(survival) & survival == 0
    },
    COLLINEARITY_ESTIMABLE = character_value("diagnostic_result_status") == "ESTIMABLE",
    COLLINEARITY_NOT_ESTIMABLE = {
      valid_n <- numeric_value("valid_imputation_n")
      character_value("diagnostic_result_status") == "NOT_ESTIMABLE" & valid_n == 0
    },
    SECONDARY_FIXED_EFFECT = {
      time <- numeric_value("time_month")
      require_columns("estimate_status")
      status == "ESTIMABLE" & is.na(time)
    },
    SECONDARY_TIME_SPECIFIC = {
      time <- numeric_value("time_month")
      require_columns("estimate_status")
      status == "ESTIMABLE" & is.finite(time)
    },
    SENS_FIXED_MI = {
      analysis <- character_value("analysis_id")
      require_columns("estimate_status")
      status == "ESTIMABLE" & analysis %in% c(
        "REUSED_FIXED_M5", "DERIVED_FROM_REUSED_FIXED_M5",
        "OPTIONAL_TERTILE_DESCRIPTION"
      )
    },
    SENS_TVE_MI = {
      analysis <- character_value("analysis_id")
      require_columns("estimate_status")
      status == "ESTIMABLE" & !is.na(analysis) & grepl("G12_TVE", analysis, fixed = TRUE)
    },
    SENS_PIECEWISE = {
      require_columns(c("estimate_status", "sensitivity_id", "analysis_id"))
      status == "ESTIMABLE" & character_value("sensitivity_id") == "A02" &
        character_value("analysis_id") == "PIECEWISE_TIME_INTERVAL"
    },
    SENS_FIXED_NON_MI = {
      require_columns(c("estimate_status", "sensitivity_id", "analysis_id", "contrast"))
      analysis <- character_value("analysis_id")
      sensitivity <- character_value("sensitivity_id")
      contrast <- character_value("contrast")
      status == "ESTIMABLE" & (
        (!is.na(analysis) & endsWith(analysis, "__FIXED") & sensitivity != "B01") |
          (sensitivity == "B03" & analysis == "JOINT_LOG2_AST_LOG2_ALT" &
            contrast %in% c("ALT_CONDITIONAL_PER_DOUBLING", "AST_CONDITIONAL_PER_DOUBLING"))
      )
    },
    SENS_MAX_DIFFERENCE = {
      require_columns(c("estimate_status", "sensitivity_id", "contrast"))
      status == "ESTIMABLE" & character_value("sensitivity_id") == "A09" &
        character_value("contrast") == "MAX_ABS_LOG_HR_DIFFERENCE_VS_MI_FULL"
    },
    SENS_RUBIN_INFO = {
      require_columns(c("estimate_status", "sensitivity_id", "analysis_id"))
      status == "ESTIMABLE" & character_value("sensitivity_id") == "A13" &
        character_value("analysis_id") == "RUBIN_INFORMATION_METRICS"
    },
    SENS_LANDMARK = {
      require_columns(c("estimate_status", "sensitivity_id", "analysis_id"))
      analysis <- character_value("analysis_id")
      status == "ESTIMABLE" & character_value("sensitivity_id") == "B01" &
        !is.na(analysis) & grepl("^LANDMARK_[13]_MONTH__FIXED$", analysis)
    },
    SENS_JOINT_D1 = {
      require_columns(c("estimate_status", "sensitivity_id", "analysis_id", "contrast"))
      missing_status <- is.na(status) | !nzchar(trimws(status))
      analysis <- character_value("analysis_id")
      missing_analysis <- is.na(analysis) | !nzchar(trimws(analysis))
      missing_status & missing_analysis & character_value("sensitivity_id") == "B03" &
        character_value("contrast") == "AST_ALT_JOINT_D1"
    },
    stop("CANONICAL_APPLICABILITY_SELECTOR_UNKNOWN: ", selector_id, call. = FALSE)
  )
  result[is.na(result)] <- FALSE
  as.logical(result)
}

.canonical_applicability_permitted_nonfinite_v43 <- function(
    data, project_root, source_file) {
  numeric_columns <- names(data)[vapply(data, is.numeric, logical(1))]
  allowed <- matrix(
    FALSE, nrow = nrow(data), ncol = length(numeric_columns),
    dimnames = list(NULL, numeric_columns)
  )
  if (!length(numeric_columns) || !nrow(data)) return(allowed)
  required <- c(
    "estimand_id", "estimate_status", "not_estimable_reason_code", "between_variance",
    "rubin_df", "valid_imputation_n", "beta", "se", "hr", "lower_95_ci",
    "upper_95_ci", "p_value", "within_variance", "total_variance"
  )
  eligible <- if (all(required %in% names(data))) {
    as.character(data$estimate_status) == "ESTIMABLE" & !is.na(data$rubin_df)
  } else rep(FALSE, nrow(data))
  eligible[is.na(eligible)] <- FALSE
  if (any(eligible)) {
    if (!exists("assert_rubin_df_contract_v43", mode = "function")) {
      source(file.path(project_root, "R", "canonical_results.R"))
    }
    rubin_audit <- assert_rubin_df_contract_v43(
      data[eligible, , drop = FALSE], project_root,
      paste0("canonical_applicability/", source_file)
    )
    eligible_rows <- which(eligible)
    allowed_rows <- eligible_rows[rubin_audit$allowed_positive_infinite_rubin_df]
    if (length(allowed_rows) && "rubin_df" %in% numeric_columns) {
      allowed[allowed_rows, "rubin_df"] <- TRUE
    }
  }
  allowed
}

audit_canonical_value_applicability_v43 <- function(
    data, source_file, project_root = ".", registry = NULL,
    validate_registry = TRUE) {
  project_root <- normalizePath(project_root, mustWork = TRUE)
  if (is.null(registry)) registry <- read_canonical_value_applicability_registry_v43(project_root)
  if (isTRUE(validate_registry)) {
    .validate_canonical_value_applicability_registry_v43(registry, project_root)
  }
  if (!is.data.frame(data) || nrow(data) < 1L || any(!nzchar(names(data))) ||
      anyDuplicated(names(data))) {
    stop("CANONICAL_APPLICABILITY_SOURCE_SCHEMA_INVALID: ", source_file, call. = FALSE)
  }
  profiles <- registry[registry$source_file == source_file, , drop = FALSE]
  if (!nrow(profiles)) {
    stop("CANONICAL_APPLICABILITY_PROFILE_MISSING: ", source_file, call. = FALSE)
  }
  matches <- do.call(cbind, lapply(profiles$selector_id, function(selector_id) {
    .canonical_applicability_selector_v43(data, selector_id)
  }))
  if (is.null(dim(matches))) matches <- matrix(matches, ncol = nrow(profiles))
  row_cardinality <- rowSums(matches)
  if (any(row_cardinality != 1L)) {
    stop(
      "CANONICAL_APPLICABILITY_PROFILE_CARDINALITY_INVALID: ", source_file,
      "; rows=", paste(which(row_cardinality != 1L), collapse = "|"), call. = FALSE
    )
  }
  profile_index <- max.col(matches, ties.method = "first")
  selected_profiles <- profiles[profile_index, , drop = FALSE]
  profile_ids <- as.character(selected_profiles$profile_id)

  if (all(c("estimate_status", "not_estimable_reason_code") %in% names(data))) {
    status <- as.character(data$estimate_status)
    reason <- as.character(data$not_estimable_reason_code)
    reason_registry <- utils::read.csv(
      file.path(project_root, "config", "not_estimable_reason_registry.csv"),
      stringsAsFactors = FALSE, check.names = FALSE, na.strings = character()
    )
    typed <- !is.na(status) & status == "NOT_ESTIMABLE" &
      !is.na(reason) & nzchar(trimws(reason))
    unknown <- unique(reason[typed & !reason %in% reason_registry$reason_code])
    if (length(unknown)) {
      stop(
        "CANONICAL_APPLICABILITY_REASON_UNREGISTERED: ", source_file, "/",
        paste(sort(unknown, method = "radix"), collapse = "|"), call. = FALSE
      )
    }
    missing_status <- is.na(status) | !nzchar(trimws(status))
    invalid_status <- !missing_status & !status %in% c("ESTIMABLE", "NOT_ESTIMABLE")
    reason_mismatch <- (!missing_status & status == "ESTIMABLE" &
      !is.na(reason) & nzchar(trimws(reason))) |
      (!missing_status & status == "NOT_ESTIMABLE" & !typed)
    missing_not_allowed <- missing_status & !selected_profiles$allow_missing_estimate_status
    if (any(invalid_status | reason_mismatch | missing_not_allowed)) {
      stop(
        "CANONICAL_APPLICABILITY_STATUS_REASON_INVALID: ", source_file,
        "; rows=", paste(which(invalid_status | reason_mismatch | missing_not_allowed),
          collapse = "|"), call. = FALSE
      )
    }
  } else {
    typed <- rep(FALSE, nrow(data))
    missing_status <- rep(FALSE, nrow(data))
  }

  numeric_columns <- names(data)[vapply(data, is.numeric, logical(1))]
  if (length(numeric_columns) && any(vapply(data[numeric_columns], function(value) {
      any(is.nan(value))
    }, logical(1)))) {
    stop("CANONICAL_APPLICABILITY_NAN_FORBIDDEN: ", source_file, call. = FALSE)
  }
  nonfinite <- if (length(numeric_columns)) {
    do.call(cbind, lapply(data[numeric_columns], function(value) {
      !is.na(value) & !is.finite(value)
    }))
  } else matrix(FALSE, nrow = nrow(data), ncol = 0L)
  if (length(numeric_columns)) colnames(nonfinite) <- numeric_columns
  permitted_nonfinite <- .canonical_applicability_permitted_nonfinite_v43(
    data, project_root, source_file
  )
  if (length(nonfinite) && any(nonfinite & !permitted_nonfinite)) {
    stop("CANONICAL_APPLICABILITY_NONFINITE_FORBIDDEN: ", source_file, call. = FALSE)
  }

  actual_na <- if (length(numeric_columns)) {
    do.call(cbind, lapply(data[numeric_columns], is.na))
  } else matrix(FALSE, nrow = nrow(data), ncol = 0L)
  if (length(numeric_columns)) colnames(actual_na) <- numeric_columns
  allowed_na <- matrix(
    FALSE, nrow = nrow(data), ncol = length(numeric_columns),
    dimnames = list(NULL, numeric_columns)
  )
  invalid_pattern <- logical(nrow(data))
  for (row_index in seq_len(nrow(data))) {
    allowed_columns <- canonical_applicability_columns_v43(
      selected_profiles$allowed_numeric_na_columns[[row_index]]
    )
    missing_allowed_columns <- setdiff(allowed_columns, numeric_columns)
    if (length(missing_allowed_columns)) {
      stop(
        "CANONICAL_APPLICABILITY_REGISTERED_COLUMNS_MISSING: ", source_file, "/",
        paste(missing_allowed_columns, collapse = "|"), call. = FALSE
      )
    }
    if (length(allowed_columns)) allowed_na[row_index, allowed_columns] <- TRUE
    actual_columns <- numeric_columns[actual_na[row_index, ]]
    rule <- selected_profiles$na_match_rule[[row_index]]
    invalid_pattern[[row_index]] <- if (identical(rule, "EXACT")) {
      !identical(
        sort(actual_columns, method = "radix"),
        sort(allowed_columns, method = "radix")
      )
    } else {
      length(setdiff(actual_columns, allowed_columns)) > 0L ||
        length(actual_columns) < as.integer(selected_profiles$minimum_na_count[[row_index]])
    }
  }
  if (any(invalid_pattern)) {
    stop(
      "CANONICAL_APPLICABILITY_NA_PATTERN_INVALID: ", source_file,
      "; rows=", paste(which(invalid_pattern), collapse = "|"), call. = FALSE
    )
  }
  structural_rows <- !typed & rowSums(actual_na) > 0L
  profile_table <- sort(table(profile_ids), method = "radix")
  list(
    source_file = source_file,
    row_count = as.integer(nrow(data)),
    profile_id_by_row = profile_ids,
    row_profile_cardinality = as.integer(row_cardinality),
    allowed_na_matrix = allowed_na,
    structural_na_row = structural_rows,
    structural_na_row_n = as.integer(sum(structural_rows)),
    structural_na_cell_n = as.integer(sum(actual_na[structural_rows, , drop = FALSE])),
    typed_not_estimable_row_n = as.integer(sum(typed)),
    missing_status_row_n = as.integer(sum(missing_status)),
    permitted_nonfinite_cell_n = as.integer(sum(permitted_nonfinite)),
    profile_counts = paste(names(profile_table), as.integer(profile_table), sep = "=", collapse = "|"),
    status = "PASS"
  )
}

.read_canonical_applicability_source_v43 <- function(
    path, source_file, project_root, registry) {
  header <- names(utils::read.csv(
    path, stringsAsFactors = FALSE, check.names = FALSE, nrows = 0L
  ))
  schema <- utils::read.csv(
    file.path(project_root, "schemas", "canonical_result_schema.csv"),
    stringsAsFactors = FALSE, check.names = FALSE, na.strings = character()
  )
  profiles <- registry[registry$source_file == source_file, , drop = FALSE]
  registered_numeric <- unique(unlist(lapply(
    profiles$allowed_numeric_na_columns, canonical_applicability_columns_v43
  ), use.names = FALSE))
  numeric_columns <- unique(c(
    schema$column[schema$type %in% c("numeric", "integer")],
    publication_semantic_numeric_columns(header), registered_numeric
  ))
  character_columns <- schema$column[schema$type == "character"]
  logical_columns <- publication_semantic_logical_columns(header)
  col_classes <- rep(NA_character_, length(header))
  col_classes[header %in% numeric_columns] <- "numeric"
  col_classes[header %in% character_columns] <- "character"
  col_classes[header %in% logical_columns] <- "logical"
  display <- grepl("(^p_display$|_p_display$|_display$|^significance_symbol$)", header)
  col_classes[display] <- "character"
  tryCatch(
    utils::read.csv(
      path, stringsAsFactors = FALSE, check.names = FALSE,
      colClasses = col_classes, na.strings = c("", "NA")
    ),
    error = function(error) {
      stop(
        "CANONICAL_APPLICABILITY_SOURCE_PARSE_FAILED: ", source_file, "; ",
        conditionMessage(error), call. = FALSE
      )
    }
  )
}

build_canonical_value_applicability_receipt_v43 <- function(
    canonical_dir, project_root = ".") {
  canonical_dir <- normalizePath(canonical_dir, mustWork = TRUE)
  project_root <- normalizePath(project_root, mustWork = TRUE)
  selection <- read_canonical_structural_na_selection_v43(project_root)
  registry <- read_canonical_value_applicability_registry_v43(project_root)
  recipes <- utils::read.csv(
    file.path(project_root, "config", "output_recipe_registry.csv"),
    stringsAsFactors = FALSE, check.names = FALSE, na.strings = character()
  )
  sources <- unique(recipes[
    recipes$source_kind == "CANONICAL", c("source_file", "producer_stage"), drop = FALSE
  ])
  sources <- sources[order(sources$source_file, method = "radix"), , drop = FALSE]
  source_audits <- lapply(seq_len(nrow(sources)), function(index) {
    source_file <- sources$source_file[[index]]
    source_path <- file.path(canonical_dir, source_file)
    if (!file.exists(source_path) || file.info(source_path)$isdir) {
      stop("CANONICAL_APPLICABILITY_SOURCE_MISSING: ", source_file, call. = FALSE)
    }
    data <- .read_canonical_applicability_source_v43(
      source_path, source_file, project_root, registry
    )
    audit <- publication_canonical_audit(
      data, source_file, sources$producer_stage[[index]], project_root, registry
    )
    list(
      source_file = source_file,
      producer_stage = sources$producer_stage[[index]],
      source_sha256 = .canonical_applicability_sha256_file_v43(source_path),
      row_count = audit$row_count,
      profile_counts = audit$profile_counts,
      structural_na_row_count = audit$structural_na_row_n,
      structural_na_cell_count = audit$structural_na_cell_n,
      typed_not_estimable_row_count = audit$typed_not_estimable_row_n,
      missing_status_row_count = audit$missing_status_row_n,
      permitted_nonfinite_cell_count = audit$permitted_nonfinite_cell_n,
      status = "PASS"
    )
  })
  receipt <- list(
    schema_version = "1.0.0",
    selection_sha256 = selection$selection_sha256,
    selection_receipt_file_sha256 = attr(selection, "receipt_file_sha256"),
    registry_sha256 = attr(registry, "registry_sha256"),
    canonical_file_registry_sha256 = .canonical_applicability_sha256_file_v43(
      file.path(project_root, "config", "canonical_file_registry.csv")
    ),
    canonical_abi_registry_sha256 = attr(
      read_canonical_abi_registry(project_root), "registry_sha256"
    ),
    source_file_count = as.integer(length(source_audits)),
    source_row_count = as.integer(sum(vapply(source_audits, `[[`, integer(1), "row_count"))),
    structural_na_row_count = as.integer(sum(vapply(
      source_audits, `[[`, integer(1), "structural_na_row_count"
    ))),
    structural_na_cell_count = as.integer(sum(vapply(
      source_audits, `[[`, integer(1), "structural_na_cell_count"
    ))),
    typed_not_estimable_row_count = as.integer(sum(vapply(
      source_audits, `[[`, integer(1), "typed_not_estimable_row_count"
    ))),
    missing_status_row_count = as.integer(sum(vapply(
      source_audits, `[[`, integer(1), "missing_status_row_count"
    ))),
    permitted_nonfinite_cell_count = as.integer(sum(vapply(
      source_audits, `[[`, integer(1), "permitted_nonfinite_cell_count"
    ))),
    source_audits = unname(source_audits)
  )
  receipt$receipt_sha256 <- .canonical_applicability_sha256_text_v43(
    .canonical_applicability_json_v43(receipt)
  )
  receipt
}

validate_canonical_value_applicability_receipt_v43 <- function(
    receipt, canonical_dir, project_root = ".") {
  if (!is.list(receipt) || !is.character(receipt$receipt_sha256) ||
      length(receipt$receipt_sha256) != 1L ||
      !grepl("^[0-9a-f]{64}$", receipt$receipt_sha256)) return(FALSE)
  expected <- tryCatch(
    build_canonical_value_applicability_receipt_v43(canonical_dir, project_root),
    error = function(error) NULL
  )
  !is.null(expected) && identical(
    .canonical_applicability_json_v43(receipt),
    .canonical_applicability_json_v43(expected)
  )
}

write_canonical_value_applicability_receipt_v43 <- function(
    canonical_dir, project_root = ".",
    file_name = "canonical_value_applicability_receipt.json") {
  # 加载 JSON 包并原子输出确定性的 canonical applicability receipt。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  receipt <- build_canonical_value_applicability_receipt_v43(canonical_dir, project_root)
  destination <- file.path(canonical_dir, file_name)
  staging <- tempfile("canonical-applicability-", tmpdir = canonical_dir, fileext = ".json")
  on.exit(if (file.exists(staging)) unlink(staging, force = TRUE), add = TRUE)
  writeLines(
    as.character(jsonlite::toJSON(
      receipt, auto_unbox = TRUE, pretty = TRUE, null = "null", na = "null", digits = 17
    )),
    staging, useBytes = TRUE
  )
  reloaded <- tryCatch(
    jsonlite::read_json(staging, simplifyVector = FALSE),
    error = function(error) NULL
  )
  if (is.null(reloaded) ||
      !validate_canonical_value_applicability_receipt_v43(
        reloaded, canonical_dir, project_root
      ) || file.exists(destination) || !file.rename(staging, destination)) {
    stop("CANONICAL_APPLICABILITY_RECEIPT_ATOMIC_WRITE_FAILED", call. = FALSE)
  }
  invisible(destination)
}

publication_recipe_selector_ids <- function() {
  c(
    "ALL_ROWS", "PRIMARY_TERTILE", "PRIMARY_CONTINUOUS",
    "PRIMARY_M5_TERTILE", "PRIMARY_M5_CONTINUOUS", "PRIMARY_M5_CONTINUOUS_SD",
    "PRIMARY_KM", "FLOW_NUMERIC", "SUBGROUP_M5", "MISSING_VARIABLES",
    "IMPUTATION_KEY3", "IMPUTATION_ALB", "IMPUTATION_CREATININE", "IMPUTATION_LYMPH",
    "SENSITIVITY_ALL", "SENSITIVITY_IMPUTATION", "SENS_COMPLETE_CASE",
    "SENS_ALT_COVARIATES", "SENS_ALT_TIME", "SENS_MED_PRE_MIN", "SENS_LANDMARK",
    "SENS_NORMAL_TRANSAMINASE", "SENS_COMPONENT", "PH_PUBLIC_ALL", "PH_RUTHERFORD",
    "TVE_RUTHERFORD", "LOIO_M5_CONTINUOUS_SD", "LOCO_M5_CONTINUOUS_SD",
    "SECONDARY_M5_CONTINUOUS", "MODEL_STABILITY_SAFE", "OUTPUT_CLOSURE",
    paste0("SCHOENFELD_SF", 19:22),
    "CUTOFF_KM_RCS_STABLE", paste0("CUTOFF_KM_IPCW_M", c("06", "12", "24", "36"))
  )
}

publication_runtime_derived_columns <- function(selector_id, output_columns = character()) {
  selector_columns <- switch(
    selector_id,
    FLOW_NUMERIC = "value_numeric",
    SECONDARY_M5_CONTINUOUS = c("effect_type", "effect_time_order", "effect_time_label"),
    character()
  )
  annotation_columns <- intersect(
    output_columns,
    c(
      "p_display", "joint_p_display", "annotation_p", "annotation_p_display",
      "annotation_p_type", "significance_symbol"
    )
  )
  unique(c(selector_columns, annotation_columns))
}

load_publication_recipes <- function(project_root = ".") {
  path <- file.path(project_root, "config", "output_recipe_registry.csv")
  if (!file.exists(path)) stop("Publication recipe registry is missing: config/output_recipe_registry.csv", call. = FALSE)
  utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE)
}

validate_publication_ingress_file <- function(source_file, producer_stage = "") {
  source_file <- basename(source_file)
  forbidden_exact <- c(
    "design_matrix_qc.csv", "fixed_cox_diagnostics.csv",
    "ph_per_imputation_term_results.csv", "ph_parent_joint_results.csv",
    "ph_per_imputation_dummy_results.csv", "collinearity_per_imputation.csv.gz",
    "model_fit_status.csv", "model_diagnostic_linkage.csv",
    "unique_design_matrix_request_registry.csv", "unique_fit_diagnostic_request_registry.csv",
    "coefficient_parameter_consistency.csv"
  )
  forbidden_pattern <- "fit_records?|vcov|covariance_matrix|per_imputation|design_matrix|model_objects?"
  unsafe <- source_file %in% forbidden_exact ||
    (identical(producer_stage, "A03") && grepl(forbidden_pattern, source_file, ignore.case = TRUE, perl = TRUE))
  if (unsafe) {
    stop(
      "Forbidden A07 ingress from ", producer_stage, ": ", source_file,
      ". A07 accepts publication-safe summaries only.",
      call. = FALSE
    )
  }
  invisible(TRUE)
}

validate_publication_recipes <- function(output_registry, recipes) {
  required_columns <- c(
    "recipe_version", "output_id", "source_kind", "source_file", "producer_stage",
    "source_classification", "selector_id", "selector_expression", "output_columns",
    "sort_columns", "cardinality_rule", "min_rows", "max_rows", "plot_type",
    "x_column", "y_column", "lower_column", "upper_column", "group_column",
    "facet_column", "label_column", "value_column", "reference_line"
  )
  missing_columns <- setdiff(required_columns, names(recipes))
  if (length(missing_columns)) {
    stop("Publication recipe registry columns missing: ", paste(missing_columns, collapse = ", "), call. = FALSE)
  }
  if (anyDuplicated(output_registry$output_id)) stop("output_registry has duplicate output_id", call. = FALSE)
  if (anyDuplicated(recipes$output_id)) stop("Publication recipe registry has duplicate output_id", call. = FALSE)
  missing_recipes <- setdiff(output_registry$output_id, recipes$output_id)
  extra_recipes <- setdiff(recipes$output_id, output_registry$output_id)
  if (length(missing_recipes) || length(extra_recipes)) {
    stop(
      "Publication recipe/output closure mismatch; missing=",
      paste(missing_recipes, collapse = "|"), "; extra=", paste(extra_recipes, collapse = "|"),
      call. = FALSE
    )
  }
  recipes <- recipes[match(output_registry$output_id, recipes$output_id), , drop = FALSE]
  if (!identical(
    as.character(output_registry$source_canonical_file),
    as.character(recipes$source_file)
  )) {
    mismatch <- output_registry$output_id[
      as.character(output_registry$source_canonical_file) != as.character(recipes$source_file)
    ]
    stop(
      "PUBLICATION_SOURCE_OWNER_MISMATCH: ", paste(mismatch, collapse = "|"),
      call. = FALSE
    )
  }
  if (any(recipes$recipe_version != "r04")) stop("All publication recipes must use recipe_version r04", call. = FALSE)
  required_text <- c(
    "source_kind", "source_file", "producer_stage", "source_classification",
    "selector_id", "selector_expression", "output_columns", "sort_columns", "cardinality_rule"
  )
  empty_text <- vapply(required_text, function(column) any(is.na(recipes[[column]]) | !nzchar(trimws(recipes[[column]]))), logical(1))
  if (any(empty_text)) stop("Publication recipes contain empty required fields: ", paste(names(empty_text)[empty_text], collapse = ", "), call. = FALSE)
  if (any(!recipes$source_kind %in% c("CANONICAL", "CONFIG", "GENERATED"))) stop("Invalid publication source_kind", call. = FALSE)
  if (any(!recipes$source_classification %in% c("PUBLICATION_SAFE_SUMMARY", "CONFIG_REGISTRY", "GENERATED_AGGREGATE"))) {
    stop("Invalid publication source_classification", call. = FALSE)
  }
  expected_classification <- c(
    CANONICAL = "PUBLICATION_SAFE_SUMMARY",
    CONFIG = "CONFIG_REGISTRY",
    GENERATED = "GENERATED_AGGREGATE"
  )
  observed_classification <- unname(expected_classification[recipes$source_kind])
  if (any(recipes$source_classification != observed_classification)) stop("Publication source kind/classification mismatch", call. = FALSE)
  if (any(!recipes$selector_id %in% publication_recipe_selector_ids())) {
    stop(
      "Unknown publication selector_id: ",
      paste(unique(recipes$selector_id[!recipes$selector_id %in% publication_recipe_selector_ids()]), collapse = ", "),
      call. = FALSE
    )
  }
  if (any(!recipes$cardinality_rule %in% c("EXACT", "BETWEEN"))) stop("Invalid publication cardinality_rule", call. = FALSE)
  if (any(is.na(recipes$min_rows) | recipes$min_rows < 0L)) stop("Publication min_rows must be nonnegative", call. = FALSE)
  invalid_max <- is.na(recipes$max_rows) |
    (recipes$cardinality_rule == "EXACT" & recipes$max_rows != recipes$min_rows) |
    (recipes$cardinality_rule == "BETWEEN" & recipes$max_rows != -1L & recipes$max_rows < recipes$min_rows)
  if (any(invalid_max)) stop("Invalid publication max_rows/cardinality combination", call. = FALSE)
  if (any(basename(recipes$source_file) != recipes$source_file & recipes$source_kind != "GENERATED")) {
    stop("Publication source_file must be a basename", call. = FALSE)
  }
  config_files <- recipes$source_file[recipes$source_kind == "CONFIG"]
  if (any(!config_files %in% c("endpoint_registry.csv", "model_registry.csv"))) stop("Unapproved CONFIG publication source", call. = FALSE)
  generated_files <- recipes$source_file[recipes$source_kind == "GENERATED"]
  if (any(generated_files != "OUTPUT_REGISTRY_CLOSURE")) stop("Unapproved GENERATED publication source", call. = FALSE)
  canonical_rows <- recipes$source_kind == "CANONICAL"
  invisible(mapply(
    validate_publication_ingress_file,
    recipes$source_file[canonical_rows],
    recipes$producer_stage[canonical_rows],
    SIMPLIFY = FALSE
  ))
  if (any(recipes$producer_stage != output_registry$producer_stage)) {
    stop("Publication recipe producer_stage must match output_registry", call. = FALSE)
  }
  for (i in seq_len(nrow(recipes))) {
    output_columns <- publication_recipe_columns(recipes$output_columns[[i]])
    sort_columns <- publication_recipe_columns(recipes$sort_columns[[i]])
    if (!length(output_columns) || anyDuplicated(output_columns)) {
      stop("Invalid explicit output_columns for ", recipes$output_id[[i]], call. = FALSE)
    }
    if (!length(sort_columns) || !all(sort_columns %in% output_columns)) {
      stop("Invalid explicit sort_columns for ", recipes$output_id[[i]], call. = FALSE)
    }
    registry_format <- output_registry$format[[i]]
    if (registry_format == "CSV" && recipes$plot_type[[i]] != "NONE") {
      stop("CSV recipe must use plot_type NONE: ", recipes$output_id[[i]], call. = FALSE)
    }
    if (registry_format == "SVG") {
      if (!recipes$plot_type[[i]] %in% c(
        "COLUMN", "LINE", "LINE_CI", "POINT", "POINT_CI", "FOREST", "HEATMAP",
        "RCS_CUTOFF", "IPCW_ROC", "KM"
      )) {
        stop("SVG recipe has invalid plot_type: ", recipes$output_id[[i]], call. = FALSE)
      }
      if (!nzchar(recipes$x_column[[i]]) || !nzchar(recipes$y_column[[i]])) {
        stop("SVG recipe must declare x_column and y_column: ", recipes$output_id[[i]], call. = FALSE)
      }
      plot_columns <- unlist(recipes[i, c(
        "x_column", "y_column", "lower_column", "upper_column", "group_column",
        "facet_column", "label_column", "value_column"
      )], use.names = FALSE)
      plot_columns <- as.character(plot_columns)
      plot_columns <- plot_columns[!is.na(plot_columns) & nzchar(plot_columns)]
      if (!all(plot_columns %in% output_columns)) {
        stop("SVG recipe references undeclared output columns: ", recipes$output_id[[i]], call. = FALSE)
      }
      if (recipes$plot_type[[i]] == "HEATMAP" && !nzchar(recipes$value_column[[i]])) {
        stop("HEATMAP recipe must declare value_column: ", recipes$output_id[[i]], call. = FALSE)
      }
    }
  }
  invisible(TRUE)
}

atomic_replace_publication_directory <- function(staging, destination, label = "publication directory") {
  if (!dir.exists(staging)) stop("Staging directory does not exist for ", label, call. = FALSE)
  parent <- dirname(destination)
  dir.create(parent, recursive = TRUE, showWarnings = FALSE)
  backup <- paste0(destination, ".previous.", Sys.getpid())
  if (dir.exists(backup)) stop("Stale atomic-publication backup exists: ", basename(backup), call. = FALSE)
  destination_existed <- dir.exists(destination)
  if (destination_existed && !file.rename(destination, backup)) {
    stop("Could not move existing ", label, " to backup", call. = FALSE)
  }
  published <- file.rename(staging, destination)
  if (!published) {
    if (destination_existed) file.rename(backup, destination)
    stop("Atomic publication failed for ", label, call. = FALSE)
  }
  if (destination_existed) unlink(backup, recursive = TRUE)
  invisible(destination)
}

# A07 仅在 Layer 2 -> Layer 3 发布投影中将已知的 HR 尺度正溢出分型为不可估计；
# 上游 A05 批准包保持只读且其字节不被改写。
.project_a07_subgroup_numeric_overflow_v43 <- function(
    staging, source_file, producer_stage, project_root = ".") {
  if (!identical(source_file, "subgroup_results.csv") ||
      !identical(producer_stage, "A05")) {
    stop("A07_SUBGROUP_OVERFLOW_SOURCE_INVALID", call. = FALSE)
  }
  project_root <- normalizePath(project_root, mustWork = TRUE)
  source_path <- file.path(staging, source_file)
  information_path <- file.path(staging, "subgroup_information_audit.csv")
  if (!file.exists(source_path) || !file.exists(information_path) ||
      file.info(source_path)$isdir || file.info(information_path)$isdir ||
      nzchar(Sys.readlink(source_path)) || nzchar(Sys.readlink(information_path))) {
    stop("A07_SUBGROUP_OVERFLOW_SOURCE_INVALID", call. = FALSE)
  }
  registry <- read_canonical_value_applicability_registry_v43(project_root)
  data <- .read_canonical_applicability_source_v43(
    source_path, source_file, project_root, registry
  )
  information <- utils::read.csv(
    information_path, stringsAsFactors = FALSE, check.names = FALSE,
    na.strings = character()
  )
  required_data <- c(
    "subgroup_id", "subgroup_variable", "subgroup_level", "estimate_status",
    "not_estimable_reason_code", "not_estimable_reason_detail", "stability_flag",
    "beta", "se", "hr", "lower_95_ci", "upper_95_ci", "p_value", "joint_p",
    "within_variance", "between_variance", "total_variance", "rubin_df",
    "valid_imputation_n", "annotation_p", "p_display", "joint_p_display",
    "annotation_p_display", "annotation_p_type", "significance_symbol"
  )
  required_information <- c(
    "subgroup_id", "variable", "level", "information_flag"
  )
  if (nrow(data) != 100L || length(setdiff(required_data, names(data))) ||
      length(setdiff(required_information, names(information)))) {
    stop("A07_SUBGROUP_OVERFLOW_SHAPE_INVALID", call. = FALSE)
  }
  data_key <- paste(
    data$subgroup_id, data$subgroup_variable, data$subgroup_level, sep = "\r"
  )
  information_key <- paste(
    information$subgroup_id, information$variable, information$level, sep = "\r"
  )
  if (anyDuplicated(information_key) || anyNA(match(data_key, information_key))) {
    stop("A07_SUBGROUP_OVERFLOW_INFORMATION_BINDING_INVALID", call. = FALSE)
  }
  information_flag <- as.character(
    information$information_flag[match(data_key, information_key)]
  )
  low_information <- !is.na(information_flag) & information_flag == "LOW_INFORMATION"
  positive_overflow <- !is.na(data$upper_95_ci) &
    is.infinite(data$upper_95_ci) & data$upper_95_ci > 0
  positive_overflow[is.na(positive_overflow)] <- FALSE
  if (!identical(low_information, positive_overflow) || sum(positive_overflow) != 8L) {
    stop("A07_SUBGROUP_OVERFLOW_CARDINALITY_INVALID", call. = FALSE)
  }

  numeric_columns <- names(data)[vapply(data, is.numeric, logical(1))]
  if (any(vapply(data[numeric_columns], function(value) any(is.nan(value)), logical(1))) ||
      any(vapply(data[numeric_columns], function(value) {
        any(!is.na(value) & is.infinite(value) & value < 0)
      }, logical(1)))) {
    stop("A07_SUBGROUP_OVERFLOW_NONFINITE_INVALID", call. = FALSE)
  }
  positive_infinite <- do.call(cbind, lapply(data[numeric_columns], function(value) {
    !is.na(value) & is.infinite(value) & value > 0
  }))
  colnames(positive_infinite) <- numeric_columns
  permitted_positive_infinite <- matrix(
    FALSE, nrow = nrow(data), ncol = length(numeric_columns),
    dimnames = list(NULL, numeric_columns)
  )
  permitted_positive_infinite[positive_overflow, "upper_95_ci"] <- TRUE
  if ("rubin_df" %in% numeric_columns) {
    permitted_rubin <- !is.na(data$rubin_df) & is.infinite(data$rubin_df) &
      data$rubin_df > 0 & data$between_variance == 0 &
      as.character(data$estimate_status) == "ESTIMABLE"
    permitted_rubin[is.na(permitted_rubin)] <- FALSE
    permitted_positive_infinite[permitted_rubin, "rubin_df"] <- TRUE
  }
  if (any(positive_infinite & !permitted_positive_infinite)) {
    stop("A07_SUBGROUP_OVERFLOW_NONFINITE_INVALID", call. = FALSE)
  }

  candidate <- positive_overflow
  reason_empty <- function(value) is.na(value) | !nzchar(trimws(as.character(value)))
  required_finite <- c(
    "beta", "se", "hr", "lower_95_ci", "p_value", "within_variance",
    "between_variance", "total_variance", "annotation_p"
  )
  finite_fields_valid <- Reduce(`&`, lapply(required_finite, function(column) {
    !is.na(data[[column]]) & is.finite(data[[column]])
  }))
  optional_joint_valid <- (is.na(data$joint_p) & !is.nan(data$joint_p)) |
    (is.finite(data$joint_p) & data$joint_p >= 0 & data$joint_p <= 1)
  valid_imputation <- is.finite(data$valid_imputation_n) &
    data$valid_imputation_n == floor(data$valid_imputation_n) &
    data$valid_imputation_n >= 2
  domains_valid <- data$se >= 0 & data$within_variance >= 0 &
    data$between_variance >= 0 & data$total_variance >= 0 &
    data$lower_95_ci <= data$hr & data$p_value >= 0 & data$p_value <= 1 &
    data$annotation_p >= 0 & data$annotation_p <= 1
  precondition <- as.character(data$estimate_status) == "ESTIMABLE" &
    reason_empty(data$not_estimable_reason_code) &
    reason_empty(data$not_estimable_reason_detail) & finite_fields_valid &
    optional_joint_valid & valid_imputation & domains_valid
  precondition[is.na(precondition)] <- FALSE
  if (!all(precondition[candidate])) {
    stop("A07_SUBGROUP_OVERFLOW_PRECONDITION_INVALID", call. = FALSE)
  }

  reason_registry <- utils::read.csv(
    file.path(project_root, "config", "not_estimable_reason_registry.csv"),
    stringsAsFactors = FALSE, check.names = FALSE, na.strings = character()
  )
  reason <- reason_registry[
    reason_registry$reason_code == "NE_NUMERIC_OVERFLOW", , drop = FALSE
  ]
  if (nrow(reason) != 1L || !nzchar(reason$description[[1L]])) {
    stop("A07_SUBGROUP_OVERFLOW_REASON_INVALID", call. = FALSE)
  }
  numeric_clear <- c(
    "beta", "se", "hr", "lower_95_ci", "upper_95_ci", "p_value", "joint_p",
    "within_variance", "between_variance", "total_variance", "rubin_df", "annotation_p"
  )
  for (column in numeric_clear) data[[column]][candidate] <- NA_real_
  for (column in c(
      "p_display", "joint_p_display", "annotation_p_display",
      "annotation_p_type", "significance_symbol")) {
    data[[column]][candidate] <- ""
  }
  data$estimate_status[candidate] <- "NOT_ESTIMABLE"
  data$not_estimable_reason_code[candidate] <- "NE_NUMERIC_OVERFLOW"
  data$not_estimable_reason_detail[candidate] <- reason$description[[1L]]
  data$stability_flag[candidate] <- "LOW_INFORMATION"

  if (!exists("assert_rubin_df_contract_v43", mode = "function")) {
    source(file.path(project_root, "R", "canonical_results.R"))
  }
  rubin_audit <- assert_rubin_df_contract_v43(
    data, project_root, "A07/subgroup_results.csv"
  )
  applicability <- audit_canonical_value_applicability_v43(
    data, source_file, project_root, registry = registry
  )
  if (rubin_audit$typed_not_estimable_row_n != 8L ||
      rubin_audit$invalid_row_n != 0L ||
      applicability$typed_not_estimable_row_n != 8L ||
      !identical(applicability$status, "PASS")) {
    stop("A07_SUBGROUP_OVERFLOW_POSTCONDITION_INVALID", call. = FALSE)
  }
  utils::write.csv(data, source_path, row.names = FALSE, na = "")
  sealed <- .read_canonical_applicability_source_v43(
    source_path, source_file, project_root, registry
  )
  sealed_audit <- audit_canonical_value_applicability_v43(
    sealed, source_file, project_root, registry = registry
  )
  if (nrow(sealed) != 100L || sealed_audit$typed_not_estimable_row_n != 8L ||
      !identical(sealed_audit$status, "PASS")) {
    stop("A07_SUBGROUP_OVERFLOW_SEAL_INVALID", call. = FALSE)
  }
  invisible(list(source_row_n = 100L, projected_row_n = 8L))
}

collect_approved_canonical_results <- function(context = stage_context()) {
  output_registry <- utils::read.csv(
    file.path(context$project_root, "config", "output_registry.csv"),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  recipes <- load_publication_recipes(context$project_root)
  validate_publication_recipes(output_registry, recipes)
  destination <- file.path(context$run_root, "canonical_results")
  staging <- paste0(destination, ".staging.", Sys.getpid())
  if (dir.exists(staging)) stop("Stale canonical staging directory exists", call. = FALSE)
  dir.create(staging, recursive = TRUE, showWarnings = FALSE)
  on.exit(if (dir.exists(staging)) unlink(staging, recursive = TRUE), add = TRUE)
  canonical_recipes <- unique(recipes[
    recipes$source_kind == "CANONICAL",
    c("source_file", "producer_stage"),
    drop = FALSE
  ])
  if (anyDuplicated(canonical_recipes$source_file)) {
    stop("A canonical publication source is assigned to multiple producer stages", call. = FALSE)
  }
  manifest_rows <- list()
  index <- 1L
  a03_rubin_receipt <- NULL
  a03_rubin_receipt_source_path <- ""
  if (!exists(".required_stage_artifact", mode = "function")) {
    source(file.path(context$project_root, "R", "stage_execution.R"))
  }
  for (stage in c("A01", "A02", "A03", "A04", "A05", "A06")) {
    required_files <- canonical_recipes$source_file[canonical_recipes$producer_stage == stage]
    artifact <- .required_stage_artifact(stage, context, require_restricted = FALSE)
    bundle <- artifact$public_bundle
    manifest <- utils::read.csv(
      file.path(bundle, "bundle_manifest.csv"),
      stringsAsFactors = FALSE, check.names = FALSE
    )
    absent <- setdiff(required_files, manifest$file_name)
    if (length(absent)) {
      stop(
        "Required publication source is missing from approved ", stage, " bundle: ",
        paste(absent, collapse = ", "),
        call. = FALSE
      )
    }
    if (identical(stage, "A03")) {
      receipt_rows <- manifest[manifest$file_name == "rubin_df_qc_receipt.json", , drop = FALSE]
      fixed_rows <- manifest[manifest$file_name == "fixed_cox_results.csv", , drop = FALSE]
      if (nrow(receipt_rows) != 1L || nrow(fixed_rows) != 1L) {
        stop("RUBIN_DF_QC_RECEIPT_BUNDLE_CLOSURE_FAILED", call. = FALSE)
      }
      if (!exists("validate_rubin_df_qc_receipt_v43", mode = "function")) {
        source(file.path(context$project_root, "R", "canonical_results.R"))
      }
      receipt_path <- file.path(bundle, receipt_rows$relative_path[[1L]])
      fixed_path <- file.path(bundle, fixed_rows$relative_path[[1L]])
      # 加载 A03 Rubin df 回执并对其源 CSV、选择 owner 与计数重新验算。
      if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
      a03_rubin_receipt <- tryCatch(
        jsonlite::read_json(receipt_path, simplifyVector = TRUE),
        error = function(error) NULL
      )
      if (is.null(a03_rubin_receipt) ||
          !validate_rubin_df_qc_receipt_v43(
            a03_rubin_receipt, fixed_path, context$project_root
          )) {
        stop("RUBIN_DF_QC_RECEIPT_VALIDATION_FAILED", call. = FALSE)
      }
      a03_rubin_receipt_source_path <- receipt_path
    }
    for (source_file in required_files) {
      validate_publication_ingress_file(source_file, stage)
      manifest_row <- manifest[manifest$file_name == source_file, , drop = FALSE]
      if (nrow(manifest_row) != 1L) stop("Approved bundle source is not unique: ", source_file, call. = FALSE)
      source_path <- file.path(bundle, manifest_row$relative_path[[1L]])
      if (!file.exists(source_path)) stop("Approved bundle manifest points to a missing file: ", source_file, call. = FALSE)
      target_path <- file.path(staging, source_file)
      if (!file.copy(source_path, target_path, overwrite = FALSE)) {
        stop("Could not stage required publication source: ", source_file, call. = FALSE)
      }
      manifest_rows[[index]] <- data.frame(
        canonical_file = source_file,
        producer_stage = stage,
        source_bundle_schema = manifest_row$bundle_schema_version[[1L]],
        source_artifact_envelope_sha256 = artifact$sha256,
        source_stage_request_semantic_sha256 = artifact$envelope$stage_request_semantic_sha256,
        sha256 = file_sha256(target_path),
        source_classification = "PUBLICATION_SAFE_SUMMARY",
        stringsAsFactors = FALSE
      )
      index <- index + 1L
    }
  }
  output <- if (length(manifest_rows)) do.call(rbind, manifest_rows) else data.frame()
  if (!identical(sort(output$canonical_file), sort(canonical_recipes$source_file))) {
    stop("Canonical publication ingress closure failed", call. = FALSE)
  }
  projection <- .project_a07_subgroup_numeric_overflow_v43(
    staging, "subgroup_results.csv", "A05", context$project_root
  )
  projected_row <- output$canonical_file == "subgroup_results.csv" &
    output$producer_stage == "A05"
  if (sum(projected_row) != 1L || projection$source_row_n != 100L ||
      projection$projected_row_n != 8L) {
    stop("A07_SUBGROUP_OVERFLOW_MANIFEST_BINDING_INVALID", call. = FALSE)
  }
  output$sha256[projected_row] <- file_sha256(
    file.path(staging, "subgroup_results.csv")
  )
  sealed_hashes <- vapply(
    output$canonical_file,
    function(source) file_sha256(file.path(staging, source)),
    character(1)
  )
  if (!identical(unname(sealed_hashes), unname(as.character(output$sha256)))) {
    stop("A07_CANONICAL_MANIFEST_HASH_INVALID", call. = FALSE)
  }
  if (is.null(a03_rubin_receipt)) stop("RUBIN_DF_QC_RECEIPT_NOT_CONSUMED", call. = FALSE)
  receipt_copy <- file.path(staging, "rubin_df_qc_receipt.json")
  # 原字节复制验证后的 A03 回执到 Layer 2 ingress，供 release-only 再次验证。
  if (!file.copy(a03_rubin_receipt_source_path, receipt_copy, overwrite = FALSE)) {
    stop("RUBIN_DF_QC_RECEIPT_CANONICAL_COPY_FAILED", call. = FALSE)
  }
  if (!validate_rubin_df_qc_receipt_v43(
      jsonlite::read_json(receipt_copy, simplifyVector = TRUE),
      file.path(staging, "fixed_cox_results.csv"), context$project_root
    )) {
    stop("RUBIN_DF_QC_RECEIPT_CANONICAL_COPY_INVALID", call. = FALSE)
  }
  # 输出仅含允许进入 A07 的 canonical 汇总来源清单。
  utils::write.csv(output, file.path(staging, "canonical_source_manifest.csv"), row.names = FALSE)
  # 原子生成并反向验证 STRUCT_NA_1A 全 canonical 适用性回执，禁止 A07 使用未分型缺失。
  applicability_receipt_path <- write_canonical_value_applicability_receipt_v43(
    staging, context$project_root
  )
  applicability_receipt <- jsonlite::read_json(
    applicability_receipt_path, simplifyVector = FALSE
  )
  if (!validate_canonical_value_applicability_receipt_v43(
      applicability_receipt, staging, context$project_root
    )) {
    stop("CANONICAL_APPLICABILITY_RECEIPT_CANONICAL_COPY_INVALID", call. = FALSE)
  }
  atomic_replace_publication_directory(staging, destination, "canonical publication layer")
  output
}

generated_output_closure <- function(context) {
  output_registry <- utils::read.csv(
    file.path(context$project_root, "config", "output_registry.csv"),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  recipes <- load_publication_recipes(context$project_root)
  data.frame(
    output_id = output_registry$output_id,
    file_name = output_registry$file_name,
    required = output_registry$required,
    recipe_present = output_registry$output_id %in% recipes$output_id,
    source_kind = recipes$source_kind[match(output_registry$output_id, recipes$output_id)],
    source_file = recipes$source_file[match(output_registry$output_id, recipes$output_id)],
    selector_id = recipes$selector_id[match(output_registry$output_id, recipes$output_id)],
    status = ifelse(output_registry$output_id %in% recipes$output_id, "DECLARED", "MISSING_RECIPE"),
    stringsAsFactors = FALSE
  )
}

read_publication_source <- function(registry_row, recipe_row = NULL, context = stage_context()) {
  if (is.null(recipe_row)) {
    recipes <- load_publication_recipes(context$project_root)
    recipe_row <- recipes[recipes$output_id == registry_row$output_id[[1L]], , drop = FALSE]
  }
  if (nrow(recipe_row) != 1L) stop("Publication recipe must resolve to exactly one row", call. = FALSE)
  source_kind <- recipe_row$source_kind[[1L]]
  source_file <- recipe_row$source_file[[1L]]
  if (source_kind == "GENERATED") {
    if (source_file != "OUTPUT_REGISTRY_CLOSURE") stop("Unknown generated publication source", call. = FALSE)
    return(generated_output_closure(context))
  }
  if (source_kind == "CONFIG") {
    path <- file.path(context$project_root, "config", source_file)
  } else {
    validate_publication_ingress_file(source_file, recipe_row$producer_stage[[1L]])
    path <- file.path(context$run_root, "canonical_results", source_file)
  }
  if (!file.exists(path) || dir.exists(path)) {
    stop(
      "Required publication source is missing for ", registry_row$output_id[[1L]],
      ": ", source_file,
      call. = FALSE
    )
  }
  data <- tryCatch(
    {
      header <- names(utils::read.csv(
        path, stringsAsFactors = FALSE, check.names = FALSE, nrows = 0L
      ))
      col_classes <- rep(NA_character_, length(header))
      canonical_schema_path <- file.path(
        context$project_root, "schemas", "canonical_result_schema.csv"
      )
      if (file.exists(canonical_schema_path)) {
        canonical_schema <- utils::read.csv(
          canonical_schema_path, stringsAsFactors = FALSE, check.names = FALSE
        )
        numeric_contract <- canonical_schema$column[
          canonical_schema$type %in% c("numeric", "integer")
        ]
        numeric_contract <- unique(c(
          numeric_contract, publication_semantic_numeric_columns(header)
        ))
        col_classes[header %in% numeric_contract] <- "numeric"
        character_contract <- canonical_schema$column[canonical_schema$type == "character"]
        col_classes[header %in% character_contract] <- "character"
        logical_contract <- publication_semantic_logical_columns(header)
        col_classes[header %in% logical_contract] <- "logical"
      }
      display_columns <- grepl("(^p_display$|_p_display$|_display$|^significance_symbol$)", header, perl = TRUE)
      col_classes[display_columns] <- "character"
      utils::read.csv(
        path, stringsAsFactors = FALSE, check.names = FALSE,
        colClasses = col_classes, na.strings = c("", "NA")
      )
    },
    error = function(condition) {
      stop(
        "Required publication source cannot be parsed for ", registry_row$output_id[[1L]],
        ": ", source_file, "; ", conditionMessage(condition),
        call. = FALSE
      )
    }
  )
  if (identical(source_kind, "CANONICAL")) {
    validate_canonical_abi_source(
      data, source_file, recipe_row$producer_stage[[1L]], context$project_root
    )
  }
  data
}

require_publication_columns <- function(data, columns, output_id, contract_part) {
  missing <- setdiff(columns, names(data))
  if (length(missing)) {
    stop(
      "Publication ", contract_part, " columns missing for ", output_id, ": ",
      paste(missing, collapse = ", "),
      call. = FALSE
    )
  }
  invisible(TRUE)
}

apply_publication_selector <- function(data, selector_id, output_id) {
  keep <- rep(TRUE, nrow(data))
  require_columns <- function(columns) require_publication_columns(data, columns, output_id, "selector")
  if (selector_id %in% c("ALL_ROWS", "SENSITIVITY_ALL", "PH_PUBLIC_ALL", "MODEL_STABILITY_SAFE", "OUTPUT_CLOSURE")) {
    return(data)
  }
  if (selector_id == "PRIMARY_TERTILE") {
    require_columns(c("endpoint", "exposure_parameterization"))
    keep <- data$endpoint == "All_Cause_Death" & data$exposure_parameterization == "AST_ALT_Tertile"
  } else if (selector_id == "PRIMARY_CONTINUOUS") {
    require_columns(c("endpoint", "exposure_parameterization"))
    keep <- data$endpoint == "All_Cause_Death" & data$exposure_parameterization == "log2_AST_ALT"
  } else if (selector_id == "PRIMARY_M5_TERTILE") {
    require_columns(c("endpoint", "model_id", "exposure_parameterization"))
    keep <- data$endpoint == "All_Cause_Death" & data$model_id == "M5" &
      data$exposure_parameterization == "AST_ALT_Tertile"
  } else if (selector_id == "PRIMARY_M5_CONTINUOUS") {
    require_columns(c("endpoint", "model_id", "exposure_parameterization"))
    keep <- data$endpoint == "All_Cause_Death" & data$model_id == "M5" &
      data$exposure_parameterization == "log2_AST_ALT"
  } else if (selector_id == "PRIMARY_M5_CONTINUOUS_SD") {
    require_columns(c("endpoint", "model_id", "exposure_parameterization", "contrast"))
    keep <- data$endpoint == "All_Cause_Death" & data$model_id == "M5" &
      data$exposure_parameterization == "log2_AST_ALT" & data$contrast == "per_1_SD"
  } else if (selector_id == "PRIMARY_KM") {
    require_columns("stratum")
    keep <- data$stratum %in% c("T1", "T2", "T3")
  } else if (selector_id == "FLOW_NUMERIC") {
    require_columns(c("metric", "value"))
    data$value_numeric <- suppressWarnings(as.numeric(data$value))
    if (any(!is.finite(data$value_numeric))) stop("Publication flow values are not all numeric", call. = FALSE)
    return(data)
  } else if (selector_id == "SUBGROUP_M5") {
    require_columns(c("endpoint", "model_id", "exposure_parameterization"))
    keep <- data$endpoint == "All_Cause_Death" & data$model_id == "M5" &
      data$exposure_parameterization == "log2_AST_ALT"
  } else if (selector_id == "MISSING_VARIABLES") {
    require_columns("imputed_n_total")
    keep <- !is.na(data$imputed_n_total) & data$imputed_n_total > 0
  } else if (selector_id == "IMPUTATION_KEY3") {
    require_columns("variable")
    keep <- data$variable %in% c("ALB", "Creatinine", "LYMPH")
  } else if (selector_id == "IMPUTATION_ALB") {
    require_columns("variable")
    keep <- data$variable == "ALB"
  } else if (selector_id == "IMPUTATION_CREATININE") {
    require_columns("variable")
    keep <- data$variable == "Creatinine"
  } else if (selector_id == "IMPUTATION_LYMPH") {
    require_columns("variable")
    keep <- data$variable == "LYMPH"
  } else if (selector_id == "SENSITIVITY_IMPUTATION") {
    require_columns("sensitivity_id")
    keep <- data$sensitivity_id %in% c("A04", "A05", "A13")
  } else if (selector_id == "SENS_COMPLETE_CASE") {
    require_columns("sensitivity_id")
    keep <- data$sensitivity_id == "A04"
  } else if (selector_id == "SENS_ALT_COVARIATES") {
    require_columns("sensitivity_id")
    keep <- data$sensitivity_id == "A07"
  } else if (selector_id == "SENS_ALT_TIME") {
    require_columns("sensitivity_id")
    keep <- data$sensitivity_id == "A02"
  } else if (selector_id == "SENS_MED_PRE_MIN") {
    require_columns("sensitivity_id")
    keep <- data$sensitivity_id %in% c("A10", "A11", "A12")
  } else if (selector_id == "SENS_LANDMARK") {
    require_columns("sensitivity_id")
    keep <- data$sensitivity_id == "B01"
  } else if (selector_id == "SENS_NORMAL_TRANSAMINASE") {
    require_columns("sensitivity_id")
    keep <- data$sensitivity_id == "B02"
  } else if (selector_id == "SENS_COMPONENT") {
    require_columns("sensitivity_id")
    keep <- data$sensitivity_id == "B03"
  } else if (selector_id == "PH_RUTHERFORD") {
    require_columns(c("parent_term", "model_id"))
    keep <- data$parent_term == "Rutherford_cat" & data$model_id == "M5"
  } else if (selector_id == "TVE_RUTHERFORD") {
    require_columns("contrast")
    keep <- grepl("Rutherford", data$contrast, ignore.case = TRUE)
  } else if (grepl("^SCHOENFELD_SF(19|20|21|22)$", selector_id)) {
    require_columns("diagnostic_id")
    keep <- data$diagnostic_id == sub("^SCHOENFELD_", "", selector_id)
  } else if (grepl("^CUTOFF_KM_", selector_id)) {
    require_columns("cutoff_source")
    expected_source <- sub("^CUTOFF_KM_", "", selector_id)
    keep <- data$cutoff_source == expected_source
  } else if (selector_id == "LOIO_M5_CONTINUOUS_SD") {
    require_columns(c("model_id", "exposure_form", "contrast"))
    keep <- data$model_id == "M5" & data$exposure_form == "log2_AST_ALT" & data$contrast == "per_1_SD"
  } else if (selector_id == "LOCO_M5_CONTINUOUS_SD") {
    require_columns(c("model_id", "exposure_parameterization", "contrast"))
    keep <- data$model_id == "M5" & data$exposure_parameterization == "log2_AST_ALT" &
      data$contrast == "per_1_SD"
  } else if (selector_id == "SECONDARY_M5_CONTINUOUS") {
    require_columns(c(
      "estimand_id", "endpoint", "model_id", "exposure_parameterization",
      "contrast", "time_month"
    ))
    keep <- data$model_id == "M5" & data$exposure_parameterization == "LOG2_AST_ALT"
    keep[is.na(keep)] <- FALSE
    selected <- data[keep, , drop = FALSE]
    if (!is.numeric(selected$time_month)) {
      stop("Secondary endpoint time_month must be numeric", call. = FALSE)
    }
    invalid_time <- is.nan(selected$time_month) |
      (!is.na(selected$time_month) &
        (!is.finite(selected$time_month) |
          !selected$time_month %in% c(6, 12, 24, 36)))
    if (any(invalid_time)) {
      stop("Secondary endpoint projection contains an unregistered time", call. = FALSE)
    }
    selected$effect_type <- ifelse(
      is.na(selected$time_month), "FIXED_HR", "TIME_SPECIFIC_HR"
    )
    selected$effect_time_order <- ifelse(
      is.na(selected$time_month), 0, selected$time_month
    )
    selected$effect_time_label <- ifelse(
      selected$effect_time_order == 0,
      "FIXED",
      sprintf("M%02d", as.integer(selected$effect_time_order))
    )
    expected <- expand.grid(
      endpoint = c("CV_CBV_Death", "MACE"),
      contrast = c("PER_1_SD", "PER_DOUBLING", "PER_IQR"),
      effect_time_order = c(0, 6, 12, 24, 36),
      stringsAsFactors = FALSE
    )
    key <- function(value) do.call(paste, c(value, sep = "\r"))
    observed <- selected[c("endpoint", "contrast", "effect_time_order")]
    if (nrow(selected) != 30L || anyDuplicated(selected$estimand_id) ||
        anyDuplicated(observed) ||
        !identical(sort(key(observed)), sort(key(expected)))) {
      stop("SEC_EP_1C exact endpoint/scale/effect-time closure failed", call. = FALSE)
    }
    return(selected)
  } else {
    stop("Publication selector is not implemented: ", selector_id, call. = FALSE)
  }
  keep[is.na(keep)] <- FALSE
  data[keep, , drop = FALSE]
}

# 将原始数值 P 值与展示文本、星号来源统一写入 publication 数据层。
add_publication_annotations <- function(data) {
  p_columns <- names(data)[
    vapply(data, is.numeric, logical(1)) &
      grepl("(^p_|_p_|p_value$|^joint_p$|^trend_p$|^adjusted_p)", names(data), ignore.case = TRUE)
  ]
  for (column in p_columns) {
    display_column <- if (column == "p_value") "p_display" else paste0(column, "_display")
    expected_display <- ifelse(
      is.na(data[[column]]), "",
      ifelse(data[[column]] < 0.001, "<0.001", sprintf("%.3f", data[[column]]))
    )
    if (!display_column %in% names(data)) {
      data[[display_column]] <- expected_display
    } else {
      observed_display <- as.character(data[[display_column]])
      missing_display <- is.na(observed_display) | !nzchar(observed_display)
      observed_display[missing_display] <- expected_display[missing_display]
      data[[display_column]] <- observed_display
    }
  }
  if (!"annotation_p" %in% names(data)) {
    priority <- intersect(
      c("adjusted_p_overall", "adjusted_p_time", "p_interaction_overall", "p_interaction_time", "p_value", "joint_p"),
      names(data)
    )
    data$annotation_p <- if (length(priority)) data[[priority[[1L]]]] else rep(NA_real_, nrow(data))
    data$annotation_p_type <- rep(if (length(priority)) priority[[1L]] else "not_applicable", nrow(data))
  }
  if (!"annotation_p_display" %in% names(data)) {
    data$annotation_p_display <- ifelse(
      is.na(data$annotation_p), "",
      ifelse(data$annotation_p < 0.001, "<0.001", sprintf("%.3f", data$annotation_p))
    )
  } else {
    expected_display <- .publication_p_display(data$annotation_p)
    observed_display <- as.character(data$annotation_p_display)
    missing_display <- is.na(observed_display) | !nzchar(observed_display)
    observed_display[missing_display] <- expected_display[missing_display]
    data$annotation_p_display <- observed_display
  }
  if (!"significance_symbol" %in% names(data)) {
    data$significance_symbol <- .publication_significance_symbol(
      data$annotation_p, data$annotation_p_type
    )
  } else {
    expected_symbol <- .publication_significance_symbol(
      data$annotation_p, data$annotation_p_type
    )
    observed_symbol <- as.character(data$significance_symbol)
    missing_symbol <- is.na(observed_symbol)
    observed_symbol[missing_symbol] <- expected_symbol[missing_symbol]
    data$significance_symbol <- observed_symbol
  }
  data
}

.publication_p_columns <- function(data) {
  names(data)[vapply(data, is.numeric, logical(1)) & grepl(
    "(^p_value$|^joint_p$|^trend_p$|^annotation_p$|^p_interaction_|^adjusted_p_|_p_value$)",
    names(data), ignore.case = TRUE, perl = TRUE
  )]
}

.publication_p_display <- function(value) {
  ifelse(is.na(value), "", ifelse(value < 0.001, "<0.001", sprintf("%.3f", value)))
}

.publication_significance_symbol <- function(value, annotation_p_type = NULL) {
  symbol <- ifelse(
    is.na(value), "",
    ifelse(value < 0.001, "***", ifelse(value < 0.01, "**", ifelse(value < 0.05, "*", "")))
  )
  if (!is.null(annotation_p_type)) {
    descriptive <- !is.na(annotation_p_type) &
      annotation_p_type == "DESCRIPTIVE_POST_SELECTION"
    symbol[descriptive] <- ""
  }
  symbol
}

.publication_require_rubin_df_contract_v43 <- function(project_root = ".") {
  if (!exists("evaluate_rubin_df_contract_v43", mode = "function") ||
      !exists("assert_rubin_df_contract_v43", mode = "function")) {
    path <- file.path(project_root, "R", "canonical_results.R")
    if (!file.exists(path)) stop("RUBIN_DF_CONTRACT_ENGINE_MISSING", call. = FALSE)
    # 加载唯一 Rubin df 合同引擎，禁止出版层复制或放宽科学规则。
    source(path)
  }
  invisible(TRUE)
}

.publication_rubin_df_audit_v43 <- function(data, project_root = ".", source_id = "") {
  if (!"rubin_df" %in% names(data)) return(NULL)
  .publication_require_rubin_df_contract_v43(project_root)
  if (!all(c("estimate_status", "not_estimable_reason_code") %in% names(data))) {
    stop("RUBIN_DF_SOURCE_COLUMNS_MISSING: estimate_status|not_estimable_reason_code", call. = FALSE)
  }
  status <- as.character(data$estimate_status)
  eligible <- (!is.na(status) & status == "ESTIMABLE" & !is.na(data$rubin_df)) |
    (!is.na(status) & status == "NOT_ESTIMABLE")
  eligible[is.na(eligible)] <- FALSE
  allowed <- rep(FALSE, nrow(data))
  if (any(eligible)) {
    audit <- assert_rubin_df_contract_v43(
      data[eligible, , drop = FALSE], project_root, source_id
    )
    allowed[which(eligible)] <- audit$allowed_positive_infinite_rubin_df
  } else {
    selection <- read_rubin_df_selection_v43(project_root)
    audit <- list(
      selection_sha256 = selection$selection_sha256,
      selection_receipt_file_sha256 = selection$selection_receipt_file_sha256
    )
  }
  audit$source_row_n <- as.integer(nrow(data))
  audit$eligible_row_n <- as.integer(sum(eligible))
  audit$allowed_positive_infinite_rubin_df <- allowed
  audit
}

validate_publication_data_integrity <- function(
    data, output_id, critical_columns = NULL, project_root = ".",
    allowed_na_matrix = NULL) {
  if (!is.data.frame(data)) stop("PUBLICATION_DATA_NOT_DATA_FRAME", call. = FALSE)
  numeric_columns <- names(data)[vapply(data, is.numeric, logical(1))]
  rubin_df_audit <- .publication_rubin_df_audit_v43(
    data, project_root, paste0("publication_output/", output_id)
  )
  typed_reason <- rep(FALSE, nrow(data))
  if (all(c("estimate_status", "not_estimable_reason_code") %in% names(data))) {
    typed_reason <- !is.na(data$estimate_status) & data$estimate_status != "ESTIMABLE" &
      !is.na(data$not_estimable_reason_code) & nzchar(trimws(as.character(data$not_estimable_reason_code)))
  }
  nonfinite_rows <- rep(FALSE, nrow(data))
  for (column in numeric_columns) {
    value <- data[[column]]
    invalid_nonfinite <- is.nan(value) | (!is.na(value) & !is.finite(value))
    if (identical(column, "rubin_df") && !is.null(rubin_df_audit)) {
      invalid_nonfinite <- invalid_nonfinite & !rubin_df_audit$allowed_positive_infinite_rubin_df
    }
    nonfinite_rows <- nonfinite_rows | invalid_nonfinite
  }
  critical_columns <- intersect(unique(critical_columns), numeric_columns)
  missing_critical_matrix <- if (length(critical_columns)) {
    output <- do.call(cbind, lapply(data[critical_columns], is.na))
    colnames(output) <- critical_columns
    output
  } else matrix(FALSE, nrow = nrow(data), ncol = 0L)
  if (!is.null(allowed_na_matrix)) {
    if (!is.matrix(allowed_na_matrix) || nrow(allowed_na_matrix) != nrow(data) ||
        (ncol(allowed_na_matrix) > 0L && is.null(colnames(allowed_na_matrix)))) {
      stop("PUBLICATION_ALLOWED_NA_MATRIX_INVALID: ", output_id, call. = FALSE)
    }
    permitted <- matrix(
      FALSE, nrow = nrow(data), ncol = length(critical_columns),
      dimnames = list(NULL, critical_columns)
    )
    shared <- intersect(critical_columns, colnames(allowed_na_matrix))
    if (length(shared)) permitted[, shared] <- allowed_na_matrix[, shared, drop = FALSE]
  } else {
    permitted <- matrix(FALSE, nrow = nrow(data), ncol = length(critical_columns))
  }
  missing_critical <- if (length(critical_columns)) {
    rowSums(missing_critical_matrix & !permitted) > 0L
  } else rep(FALSE, nrow(data))
  invalid_rows <- nonfinite_rows | missing_critical
  if (any(invalid_rows & !typed_reason)) {
    stop(
      "PUBLICATION_NONFINITE_WITHOUT_REASON: ", output_id,
      "; rows=", paste(which(invalid_rows & !typed_reason), collapse = "|"),
      call. = FALSE
    )
  }
  for (column in .publication_p_columns(data)) {
    value <- data[[column]]
    invalid_domain <- !is.na(value) & (!is.finite(value) | value < 0 | value > 1)
    if (any(invalid_domain)) stop("PUBLICATION_P_VALUE_DOMAIN_INVALID: ", output_id, "/", column, call. = FALSE)
    display_column <- if (identical(column, "p_value")) "p_display" else paste0(column, "_display")
    if (display_column %in% names(data)) {
      observed <- as.character(data[[display_column]])
      observed[is.na(observed)] <- ""
      if (!identical(observed, .publication_p_display(value))) {
        stop("PUBLICATION_P_DISPLAY_MISMATCH: ", output_id, "/", column, call. = FALSE)
      }
    }
  }
  if ("annotation_p" %in% names(data)) {
    if ("annotation_p_type" %in% names(data) &&
        any(!is.na(data$annotation_p) & (is.na(data$annotation_p_type) | !nzchar(data$annotation_p_type)))) {
      stop("PUBLICATION_ANNOTATION_P_TYPE_MISSING: ", output_id, call. = FALSE)
    }
    if ("significance_symbol" %in% names(data)) {
      observed <- as.character(data$significance_symbol)
      observed[is.na(observed)] <- ""
      expected_symbol <- .publication_significance_symbol(
        data$annotation_p,
        if ("annotation_p_type" %in% names(data)) data$annotation_p_type else NULL
      )
      if (!identical(observed, expected_symbol)) {
        stop("PUBLICATION_SIGNIFICANCE_SYMBOL_MISMATCH: ", output_id, call. = FALSE)
      }
    }
  }
  TRUE
}

add_publication_metadata <- function(data, registry_row) {
  row_n <- nrow(data)
  data$output_id <- rep(registry_row$output_id[[1L]], row_n)
  data$output_title_en <- rep(registry_row$title_en[[1L]], row_n)
  data$output_title_cn <- rep(registry_row$title_cn[[1L]], row_n)
  data$content_description_cn <- rep(registry_row$content_cn[[1L]], row_n)
  data
}

validate_publication_cardinality <- function(data, recipe_row) {
  observed <- nrow(data)
  minimum <- as.integer(recipe_row$min_rows[[1L]])
  maximum <- as.integer(recipe_row$max_rows[[1L]])
  rule <- recipe_row$cardinality_rule[[1L]]
  pass <- if (rule == "EXACT") {
    observed == minimum
  } else {
    observed >= minimum && (maximum == -1L || observed <= maximum)
  }
  if (!pass) {
    stop(
      "Publication cardinality failed for ", recipe_row$output_id[[1L]],
      ": observed=", observed, "; rule=", rule, "; min=", minimum, "; max=", maximum,
      call. = FALSE
    )
  }
  invisible(TRUE)
}

# 校验 recipe 排序列对所选行构成总排序键，避免上游行序改变正式输出哈希。
validate_publication_sort_key <- function(data, sort_columns, output_id) {
  require_publication_columns(data, sort_columns, output_id, "sort")
  duplicate_index <- if (nrow(data) > 1L) anyDuplicated(data[sort_columns]) else 0L
  if (duplicate_index > 0L) {
    stop(
      "Publication sort key is not unique for ", output_id,
      "; first_duplicate_row=", duplicate_index,
      call. = FALSE
    )
  }
  invisible(TRUE)
}

apply_publication_recipe <- function(
    data, recipe_row, registry_row, project_root = ".",
    applicability_audit = NULL) {
  output_id <- recipe_row$output_id[[1L]]
  source_row_column <- ".canonical_applicability_source_row_v43"
  if (!is.null(applicability_audit)) {
    if (!is.list(applicability_audit) ||
        length(applicability_audit$profile_id_by_row) != nrow(data) ||
        !is.matrix(applicability_audit$allowed_na_matrix)) {
      stop("PUBLICATION_APPLICABILITY_AUDIT_INVALID: ", output_id, call. = FALSE)
    }
    data[[source_row_column]] <- seq_len(nrow(data))
  }
  data <- apply_publication_selector(data, recipe_row$selector_id[[1L]], output_id)
  selected_source_rows <- if (source_row_column %in% names(data)) {
    as.integer(data[[source_row_column]])
  } else integer()
  data <- add_publication_annotations(data)
  output_columns <- publication_recipe_columns(recipe_row$output_columns[[1L]])
  require_publication_columns(data, output_columns, output_id, "output")
  data <- data[output_columns]
  allowed_na_matrix <- if (!is.null(applicability_audit)) {
    applicability_audit$allowed_na_matrix[selected_source_rows, , drop = FALSE]
  } else NULL
  plot_columns <- as.character(unlist(recipe_row[1L, c(
    "y_column", "lower_column", "upper_column", "value_column"
  )], use.names = FALSE))
  critical_columns <- unique(c(
    intersect(c("estimate", "beta", "se", "hr", "lower_95_ci", "upper_95_ci"), names(data)),
    plot_columns[!is.na(plot_columns) & nzchar(plot_columns)]
  ))
  validate_publication_data_integrity(
    data, output_id, critical_columns, project_root,
    allowed_na_matrix = allowed_na_matrix
  )
  sort_columns <- publication_recipe_columns(recipe_row$sort_columns[[1L]])
  validate_publication_sort_key(data, sort_columns, output_id)
  if (nrow(data) > 1L) {
    ordering <- do.call(order, c(unname(data[sort_columns]), list(na.last = TRUE, method = "radix")))
    data <- data[ordering, , drop = FALSE]
    rownames(data) <- NULL
  }
  validate_publication_cardinality(data, recipe_row)
  add_publication_metadata(data, registry_row)
}

.publication_display_field_label_v43 <- function(column) {
  labels <- c(
    analysis_id = "Analysis", at_risk_fraction = "At-risk fraction",
    coefficient = "Coefficient", contrast = "Contrast",
    effect_time_label = "Effect time", fpr = "False-positive rate",
    hr = "Hazard ratio", imputed_n_total = "Imputed values, n",
    median_abs_rho = "Median absolute correlation", median_rho = "Median correlation",
    metric = "Metric", model_id = "Model", omitted_center = "Omitted center",
    parent_term = "Covariate", sensitivity_id = "Sensitivity analysis",
    standardized_mean_shift = "Standardized mean shift", subgroup_level = "Subgroup",
    survival = "Survival probability", time_month = "Time (months)",
    tpr = "True-positive rate", transformed_time = "Transformed time",
    trend_median = "Median trend", valid_imputation_n = "Valid imputations, n",
    value_numeric = "Value", variable = "Variable", x_ast_alt = "AST/ALT ratio",
    y_value = "Value"
  )
  if (!is.character(column) || length(column) != 1L || is.na(column) ||
      !nzchar(column) || !column %in% names(labels)) {
    stop("PUBLICATION_DISPLAY_FIELD_UNREGISTERED: ", column, call. = FALSE)
  }
  unname(labels[[column]])
}

.publication_display_value_map_v43 <- function(output_id, column, values) {
  maps <- list()
  maps[[paste("MF01", "metric", sep = "\r")]] <- c(
    eligible_n = "Eligible", excluded_n = "Excluded",
    max_identity_difference = "Maximum identity difference",
    nonfinite_exposure_n = "Non-finite AST/ALT",
    nonpositive_ALT_n = "Non-positive ALT", nonpositive_AST_n = "Non-positive AST",
    source_n = "Source cohort", tertile_mismatch_n = "Tertile mismatch"
  )
  maps[[paste("MF03", "contrast", sep = "\r")]] <- c(
    T2_vs_T1 = "T2 vs T1", T3_vs_T1 = "T3 vs T1"
  )
  maps[[paste("MF06", "subgroup_variable", sep = "\r")]] <- c(
    Age = "Age", BMI = "BMI", CKD_bin = "Chronic kidney disease", DM = "Diabetes",
    Heart_Disease = "Heart disease", HTN_bin = "Hypertension",
    Lipid_Lowering = "Lipid-lowering therapy", Rutherford_cat = "Rutherford category",
    Sex = "Sex", Smoking = "Smoking", Surgery_Type_cat = "Surgery type"
  )
  maps[[paste("MF06", "time_month", sep = "\r")]] <- c(
    `6` = "6 months", `12` = "12 months", `24` = "24 months", `36` = "36 months"
  )
  maps[[paste("SF09", "contrast", sep = "\r")]] <- c(
    Rutherford_Grade_3_4 = "Rutherford grade 3-4",
    Rutherford_Grade_5_6 = "Rutherford grade 5-6"
  )
  maps[[paste("SF09", "exposure_parameterization", sep = "\r")]] <- c(
    Rutherford_TVE_ADJUSTED_AST_ALT_TERTILE = "Adjusted for AST/ALT tertiles",
    Rutherford_TVE_ADJUSTED_LOG2_AST_ALT = "Adjusted for continuous AST/ALT"
  )
  maps[[paste("SF12", "endpoint", sep = "\r")]] <- c(
    All_Cause_Death = "All-cause death", CV_CBV_Death = "Cardiovascular/cerebrovascular death",
    MACE = "Major adverse cardiovascular events"
  )
  maps[[paste("SF15", "contrast", sep = "\r")]] <- c(
    per_1_SD = "Per 1 SD", per_doubling = "Per doubling", per_IQR = "Per IQR"
  )
  laboratory_labels <- c(
    SBP = "Systolic blood pressure", DBP = "Diastolic blood pressure",
    HGB = "Hemoglobin", WBC = "White blood cells", Creatinine = "Creatinine",
    HR = "Heart rate", NEUT = "Neutrophils", PLT = "Platelets",
    LYMPH = "Lymphocytes", RR = "Respiratory rate", ALB = "Albumin",
    RBC = "Red blood cells", ESO = "Eosinophils", MCH = "Mean corpuscular hemoglobin",
    BASO = "Basophils", RDW_CV = "RDW-CV", PDW = "Platelet distribution width",
    MONO = "Monocytes", MCHC = "Mean corpuscular hemoglobin concentration",
    MCV = "Mean corpuscular volume", MPV = "Mean platelet volume",
    HCT = "Hematocrit", INR = "INR", RDW_SD = "RDW-SD", FIB = "Fibrinogen",
    APTT = "Activated partial thromboplastin time", PT = "Prothrombin time",
    PT_Activity = "Prothrombin activity", D_Dimer = "D-dimer",
    FBG = "Fasting blood glucose", Weight_kg = "Weight", Urea = "Urea",
    TP = "Total protein", TT = "Thrombin time", Height_cm = "Height",
    Ca = "Calcium", Barthel_Admission = "Admission Barthel Index"
  )
  maps[[paste("SF01", "variable", sep = "\r")]] <- laboratory_labels
  maps[[paste("SF02", "variable", sep = "\r")]] <- laboratory_labels
  common_contrasts <- c(
    T2_vs_T1 = "T2 vs T1", T3_vs_T1 = "T3 vs T1",
    per_1_SD = "Per 1 SD", per_IQR = "Per IQR", per_doubling = "Per doubling"
  )
  maps[[paste("SF06", "contrast", sep = "\r")]] <- common_contrasts
  maps[[paste("SF06", "analysis_id", sep = "\r")]] <- c(
    COMPLETE_CASE_FROZEN_SET__FIXED = "Complete-case: fixed effect",
    COMPLETE_CASE_FROZEN_SET__G12_TVE = "Complete-case: time-varying effect",
    ORIGINALLY_OBSERVED_ALB_CREATININE_LYMPH__FIXED = "Observed labs: fixed effect",
    ORIGINALLY_OBSERVED_ALB_CREATININE_LYMPH__G12_TVE = "Observed labs: time-varying effect",
    RUBIN_INFORMATION_METRICS = "Rubin information metrics"
  )
  maps[[paste("SF06", "sensitivity_id", sep = "\r")]] <- c(
    A04 = "Complete-case analysis", A05 = "Observed-laboratory subset",
    A13 = "MI information"
  )
  exposure_labels <- c(
    AST_ALT_Tertile = "AST/ALT tertiles", log2_AST_ALT = "Continuous AST/ALT"
  )
  maps[[paste("SF07", "exposure_form", sep = "\r")]] <- exposure_labels
  maps[[paste("SF08", "exposure_form", sep = "\r")]] <- exposure_labels
  maps[[paste("SF18", "exposure_parameterization", sep = "\r")]] <- exposure_labels
  model_labels <- c(M1 = "Model 1", M2 = "Model 2", M3 = "Model 3", M4 = "Model 4", M5 = "Model 5")
  maps[[paste("SF07", "model_id", sep = "\r")]] <- model_labels
  maps[[paste("SF18", "model_id", sep = "\r")]] <- model_labels
  maps[[paste("SF07", "parent_term", sep = "\r")]] <- c(
    AST_ALT_Tertile = "AST/ALT tertiles", log2_AST_ALT = "Continuous AST/ALT",
    Age = "Age", Sex = "Sex", BMI = "BMI", DM = "Diabetes",
    Dyslipidemia = "Dyslipidemia", HTN_bin = "Hypertension", Smoking = "Smoking",
    Anemia = "Anemia", CKD_bin = "Chronic kidney disease", COPD = "COPD", CVD = "CVD",
    HF_NYHA_bin = "Heart failure / NYHA", Heart_Disease = "Heart disease",
    Antihypertensive = "Antihypertensive therapy", Antiplatelet = "Antiplatelet therapy",
    Lipid_Lowering = "Lipid-lowering therapy",
    Prior_LE_Surgery_cat = "Prior lower-extremity surgery",
    Rutherford_cat = "Rutherford category", Surgery_Type_cat = "Surgery type"
  )
  maps[[paste("SF08", "coefficient", sep = "\r")]] <- c(
    `Rutherford_catGrade 3-4` = "Rutherford grade 3-4",
    `Rutherford_catGrade 5-6` = "Rutherford grade 5-6"
  )
  maps[[paste("SF10", "contrast", sep = "\r")]] <- c(
    per_1_SD = "Per 1 SD", per_IQR = "Per IQR", per_doubling = "Per doubling"
  )
  month_labels <- c(`6` = "6 months", `12` = "12 months", `24` = "24 months", `36` = "36 months")
  maps[[paste("SF10", "time_month", sep = "\r")]] <- month_labels
  maps[[paste("SF13", "omitted_center", sep = "\r")]] <- setNames(
    paste("Center", c("36", "38", "39", "48", "52", "54", "55")),
    c("36", "38", "39", "48", "52", "54", "55")
  )
  maps[[paste("SF13", "time_month", sep = "\r")]] <- month_labels
  maps[[paste("SF14", "sensitivity_id", sep = "\r")]] <- setNames(
    paste("Analysis", c("A01", "A02", "A03", "A04", "A05", "A07", "A09", "A10", "A11", "A12", "A13", "B01", "B02", "B03", "B05")),
    c("A01", "A02", "A03", "A04", "A05", "A07", "A09", "A10", "A11", "A12", "A13", "B01", "B02", "B03", "B05")
  )
  maps[[paste("SF16", "contrast", sep = "\r")]] <- c(
    ALT_CONDITIONAL_PER_DOUBLING = "ALT, conditional per doubling",
    AST_CONDITIONAL_PER_DOUBLING = "AST, conditional per doubling",
    AST_ALT_JOINT_D1 = "AST and ALT joint test"
  )
  maps[[paste("SF17", "contrast", sep = "\r")]] <- c(
    PER_1_SD = "Per 1 SD", PER_DOUBLING = "Per doubling", PER_IQR = "Per IQR"
  )
  maps[[paste("SF17", "endpoint", sep = "\r")]] <- c(
    CV_CBV_Death = "Cardiovascular/cerebrovascular death",
    MACE = "Major adverse cardiovascular events"
  )
  maps[[paste("SF17", "effect_time_label", sep = "\r")]] <- c(
    FIXED = "Fixed effect", M06 = "6 months", M12 = "12 months",
    M24 = "24 months", M36 = "36 months"
  )
  maps[[paste("SF21", "series_id", sep = "\r")]] <- c(AST_ALT = "AST/ALT")
  maps[[paste("SF22", "series_id", sep = "\r")]] <- c(
    RUTHERFORD_GRADE_3_4 = "Rutherford grade 3-4",
    RUTHERFORD_GRADE_5_6 = "Rutherford grade 5-6",
    RUTHERFORD_PARENT = "Rutherford global test"
  )
  maps[[paste("SF22", "legend_label", sep = "\r")]] <- c(
    `RUTHERFORD GRADE 3 4` = "Rutherford grade 3-4",
    `RUTHERFORD GRADE 5 6` = "Rutherford grade 5-6",
    `RUTHERFORD PARENT` = "Rutherford global test"
  )
  maps[[paste("SF23", "panel", sep = "\r")]] <- c(
    RCS_ANALYTIC_DERIVATIVE = "Analytic derivative", RCS_LOG_HR = "Log hazard ratio"
  )
  maps[[paste("SF25", "group", sep = "\r")]] <- c(
    NOT_ESTIMABLE = "Cutoff not estimable"
  )
  maps[[paste("SF25", "not_estimable_reason_code", sep = "\r")]] <- c(
    INVALID_CUTOFF = "Registered cutoff unavailable"
  )
  cutoff_groups <- c(
    `AST_ALT <= cutoff` = "AST/ALT at or below cutoff",
    `AST_ALT > cutoff` = "AST/ALT above cutoff"
  )
  for (id in paste0("SF", 26:29)) {
    maps[[paste(id, "group", sep = "\r")]] <- cutoff_groups
  }
  key <- paste(output_id, column, sep = "\r")
  if (!key %in% names(maps)) return(values)
  mapping <- maps[[key]]
  observed <- unique(as.character(values))
  unknown <- setdiff(observed[!is.na(observed)], names(mapping))
  if (length(unknown)) {
    stop(
      "PUBLICATION_DISPLAY_VALUE_UNREGISTERED: ", output_id, ":", column, ":",
      paste(unknown, collapse = "|"), call. = FALSE
    )
  }
  unname(mapping[as.character(values)])
}

.publication_sf14_display_contract_v43 <- function() {
  registry_name <- c(
    A01 = "Fixed_vs_TVE", A02 = "Alternative_time_function",
    A03 = "Exposure_parameterization", A04 = "Complete_case",
    A05 = "Observed_QC_subset", A06 = "Leave_one_imputation_out",
    A07 = "Alternative_renal_anemia", A08 = "Leave_one_center_out",
    A09 = "RCS_shape_stability", A10 = "Medication_excluded",
    A11 = "Omit_surgery_type_covariate", A12 = "Minimal_clinical",
    A13 = "MI_information", B01 = "Landmark_30d_90d",
    B02 = "Normal_transaminase", B03 = "Component_decomposition",
    B04 = "Secondary_endpoints", B05 = "Key_subgroup_tertile"
  )
  sensitivity <- c(
    A01 = "A01 - Fixed vs time-varying effect",
    A02 = "A02 - Alternative time function",
    A03 = "A03 - Exposure parameterization",
    A04 = "A04 - Complete-case analysis",
    A05 = "A05 - Observed-laboratory subset",
    A06 = "A06 - Leave-one-imputation-out",
    A07 = "A07 - Alternative renal/anemia representation",
    A08 = "A08 - Leave-one-center-out",
    A09 = "A09 - RCS shape stability",
    A10 = "A10 - Medication-excluded model",
    A11 = "A11 - Omit surgery-type covariate",
    A12 = "A12 - Minimal clinical model",
    A13 = "A13 - MI information",
    B01 = "B01 - Landmark analyses (30/90 days)",
    B02 = "B02 - Normal-transaminase subset",
    B03 = "B03 - Component decomposition",
    B04 = "B04 - Secondary endpoints",
    B05 = "B05 - Key-subgroup tertiles"
  )
  analysis <- c(
    `<PRIMARY>` = "Primary analysis",
    COMPLETE_CASE = "Complete case",
    COMPLETE_CASE_FROZEN_SET__FIXED = "Complete case, fixed effect",
    COMPLETE_CASE_FROZEN_SET__G12_TVE = "Complete case, time-varying effect",
    DERIVED_FROM_REUSED_FIXED_M5 = "Derived fixed Model 5",
    DERIVED_FROM_REUSED_G12_TVE_M5 = "Derived time-varying Model 5",
    JOINT_LOG2_AST_LOG2_ALT = "Joint AST and ALT components",
    LANDMARK_1_MONTH__FIXED = "30-day landmark",
    LANDMARK_3_MONTH__FIXED = "90-day landmark",
    MI_FULL = "Multiple imputation",
    OMIT_SURGERY_TYPE_SAME_POPULATION__FIXED = "Omit surgery type, fixed effect",
    OMIT_SURGERY_TYPE_SAME_POPULATION__G12_TVE = "Omit surgery type, time-varying effect",
    OMIT_THREE_MEDICATIONS__FIXED = "Omit medications, fixed effect",
    OMIT_THREE_MEDICATIONS__G12_TVE = "Omit medications, time-varying effect",
    OPTIONAL_TERTILE_DESCRIPTION = "Tertile description",
    ORIGINAL_AST_ALT_LE_40__FIXED = "AST/ALT <=40, fixed effect",
    ORIGINAL_AST_ALT_LE_40__G12_TVE = "AST/ALT <=40, time-varying effect",
    ORIGINALLY_OBSERVED_ALB_CREATININE_LYMPH__FIXED = "Observed labs, fixed effect",
    ORIGINALLY_OBSERVED_ALB_CREATININE_LYMPH__G12_TVE = "Observed labs, time-varying effect",
    P1_P99_RESTRICTED = "1st-99th percentile",
    PIECEWISE_TIME_INTERVAL = "Piecewise time intervals",
    REGISTERED_M3__FIXED = "Registered Model 3, fixed effect",
    REGISTERED_M3__G12_TVE = "Registered Model 3, time-varying effect",
    REPLACE_CKD_ANEMIA_WITH_EGFR_HGB__FIXED = "eGFR/HGB replacement, fixed effect",
    REPLACE_CKD_ANEMIA_WITH_EGFR_HGB__G12_TVE = "eGFR/HGB replacement, time-varying effect",
    REUSED_FIXED_M5 = "Reused fixed Model 5",
    REUSED_G12_TVE_M5 = "Reused time-varying Model 5",
    RUBIN_INFORMATION_METRICS = "Rubin information metrics"
  )
  contrast <- c(
    ALT_CONDITIONAL_PER_DOUBLING = "ALT, conditional per doubling",
    AST_ALT_JOINT_D1 = "AST and ALT joint test",
    AST_CONDITIONAL_PER_DOUBLING = "AST, conditional per doubling",
    `INTERVAL_>36` = ">36 months", `INTERVAL_0-6` = "0-6 months",
    `INTERVAL_12-24` = "12-24 months", `INTERVAL_24-36` = "24-36 months",
    `INTERVAL_6-12` = "6-12 months",
    MAX_ABS_LOG_HR_DIFFERENCE_VS_MI_FULL = "Maximum absolute log-HR difference vs MI",
    per_1_SD = "Per 1 SD", per_doubling = "Per doubling", per_IQR = "Per IQR",
    per_plus_1_raw_ratio_at_frozen_median = "Per +1 AST/ALT at frozen median",
    T2_vs_T1 = "T2 vs T1", T3_vs_T1 = "T3 vs T1"
  )
  list(
    registry_name = registry_name, sensitivity = sensitivity, analysis = analysis,
    contrast = contrast, model = c(M3 = "Model 3", M5 = "Model 5"),
    exposure = c(
      AST_ALT_Tertile = "AST/ALT tertiles",
      JOINT_LOG2_AST_LOG2_ALT = "Joint log2 AST and ALT",
      log2_AST_ALT = "Log2 AST/ALT", RCS_LOG2_AST_ALT = "RCS log2 AST/ALT"
    ),
    time = c(`6` = "6 months", `12` = "12 months", `24` = "24 months",
             `36` = "36 months", `<NA>` = "No fixed time")
  )
}

.publication_sf14_closed_map_v43 <- function(values, mapping, field) {
  key <- as.character(values)
  if (identical(field, "analysis_id")) {
    key[is.na(key) | !nzchar(key)] <- "<PRIMARY>"
  } else if (identical(field, "time_month")) {
    key[is.na(values)] <- "<NA>"
  }
  unknown <- setdiff(unique(key), names(mapping))
  if (length(unknown)) {
    stop(
      "PUBLICATION_SF14_DISPLAY_VALUE_UNREGISTERED: ", field, ":",
      paste(unknown, collapse = "|"), call. = FALSE
    )
  }
  unname(mapping[key])
}

.publication_sf14_projection_v43 <- function(data) {
  required <- c(
    "sensitivity_id", "analysis_id", "endpoint", "model_id", "exposure_form",
    "contrast", "time_month", "hr", "lower_95_ci", "upper_95_ci", "estimate_status"
  )
  require_publication_columns(data, required, "SF14", "display")
  if (nrow(data) != 271L || any(as.character(data$endpoint) != "All_Cause_Death") ||
      anyDuplicated(data[c(
        "sensitivity_id", "analysis_id", "endpoint", "model_id", "exposure_form",
        "contrast", "time_month"
      )])) {
    stop("PUBLICATION_SF14_DISPLAY_SHAPE_INVALID", call. = FALSE)
  }
  contract <- .publication_sf14_display_contract_v43()
  display <- data
  display$.display_sensitivity <- .publication_sf14_closed_map_v43(
    data$sensitivity_id, contract$sensitivity, "sensitivity_id"
  )
  display$.display_analysis <- .publication_sf14_closed_map_v43(
    data$analysis_id, contract$analysis, "analysis_id"
  )
  display$.display_contrast <- .publication_sf14_closed_map_v43(
    data$contrast, contract$contrast, "contrast"
  )
  display$.display_time <- .publication_sf14_closed_map_v43(
    data$time_month, contract$time, "time_month"
  )
  display$.display_model <- .publication_sf14_closed_map_v43(
    data$model_id, contract$model, "model_id"
  )
  .publication_sf14_closed_map_v43(
    data$exposure_form, contract$exposure, "exposure_form"
  )
  row_key_fields <- data[c(
    "sensitivity_id", "analysis_id", "contrast", "time_month", "model_id"
  )]
  row_key_fields[] <- lapply(row_key_fields, function(value) {
    value <- as.character(value)
    value[is.na(value)] <- "<NA>"
    value
  })
  display$.display_row_key <- do.call(paste, c(row_key_fields, sep = "\r"))
  if (anyDuplicated(display$.display_row_key)) {
    stop("PUBLICATION_SF14_DISPLAY_ROW_IDENTITY_DUPLICATED", call. = FALSE)
  }
  display$.display_row_label <- paste(
    display$.display_analysis, display$.display_contrast,
    display$.display_time, display$.display_model, sep = " | "
  )
  display$.display_row <- factor(
    display$.display_row_key, levels = rev(unique(display$.display_row_key))
  )
  display$.display_sensitivity <- factor(
    display$.display_sensitivity, levels = unname(contract$sensitivity)
  )
  finite <- is.finite(display$hr) & is.finite(display$lower_95_ci) &
    is.finite(display$upper_95_ci)
  if (any(finite & display$estimate_status != "ESTIMABLE")) {
    stop("PUBLICATION_SF14_FINITE_STATUS_INVALID", call. = FALSE)
  }
  nonfinite <- !finite
  all_missing <- is.na(display$hr) & is.na(display$lower_95_ci) &
    is.na(display$upper_95_ci)
  shape_diagnostic <- display$sensitivity_id == "A09" &
    display$contrast == "MAX_ABS_LOG_HR_DIFFERENCE_VS_MI_FULL"
  joint_test <- display$sensitivity_id == "B03" &
    display$contrast == "AST_ALT_JOINT_D1"
  if (any(nonfinite & (!all_missing | (!shape_diagnostic & !joint_test)))) {
    stop("PUBLICATION_SF14_NONFINITE_CONTEXT_INVALID", call. = FALSE)
  }
  display$.display_nonfinite_reason <- ""
  display$.display_nonfinite_reason[nonfinite & shape_diagnostic] <-
    "Shape diagnostic (no hazard ratio)"
  display$.display_nonfinite_reason[nonfinite & joint_test] <-
    "Joint test (no hazard ratio)"
  display
}

.publication_mf06_subgroup_label_v43 <- function(data) {
  mapping <- c(
    `Age\r<70` = "Age <70 years", `Age\r>=70` = "Age >=70 years",
    `BMI\r<24` = "BMI <24 kg/m2", `BMI\r>=24` = "BMI >=24 kg/m2",
    `CKD_bin\r0` = "Chronic kidney disease: no", `CKD_bin\r1` = "Chronic kidney disease: yes",
    `DM\r0` = "Diabetes: no", `DM\r1` = "Diabetes: yes",
    `Heart_Disease\r0` = "Heart disease: no", `Heart_Disease\r1` = "Heart disease: yes",
    `HTN_bin\r0` = "Hypertension: no", `HTN_bin\r1` = "Hypertension: yes",
    `Lipid_Lowering\r0` = "Lipid-lowering therapy: no", `Lipid_Lowering\r1` = "Lipid-lowering therapy: yes",
    `Rutherford_cat\rGrade 0-2` = "Rutherford grade 0-2",
    `Rutherford_cat\rGrade 3-4` = "Rutherford grade 3-4",
    `Rutherford_cat\rGrade 5-6` = "Rutherford grade 5-6",
    `Sex\rFemale` = "Sex: female", `Sex\rMale` = "Sex: male",
    `Smoking\r0` = "Smoking: no", `Smoking\r1` = "Smoking: yes",
    `Surgery_Type_cat\rAmputation` = "Surgery: amputation",
    `Surgery_Type_cat\rNone` = "Surgery: none",
    `Surgery_Type_cat\rOther` = "Surgery: other",
    `Surgery_Type_cat\rProcedure` = "Surgery: procedure"
  )
  key <- paste(data$subgroup_variable, data$subgroup_level, sep = "\r")
  unknown <- setdiff(unique(key), names(mapping))
  if (length(unknown)) {
    stop("PUBLICATION_MF06_SUBGROUP_LABEL_UNREGISTERED", call. = FALSE)
  }
  unname(mapping[key])
}

.publication_display_projection_v43 <- function(data, output_id, recipe_row) {
  display <- data
  for (column in unique(c(
    recipe_row$x_column[[1L]], recipe_row$y_column[[1L]],
    recipe_row$group_column[[1L]], recipe_row$facet_column[[1L]],
    recipe_row$label_column[[1L]]
  ))) {
    if (!is.na(column) && nzchar(column) && column %in% names(display)) {
      display[[column]] <- .publication_display_value_map_v43(
        output_id, column, display[[column]]
      )
    }
  }
  if (identical(output_id, "MF01")) {
    display$metric <- factor(display$metric, levels = rev(unique(display$metric)))
  }
  if (identical(output_id, "MF06")) {
    display$.display_subgroup <- .publication_mf06_subgroup_label_v43(data)
    display$.display_subgroup <- factor(
      display$.display_subgroup, levels = rev(unique(display$.display_subgroup))
    )
    display$.display_time <- factor(
      display$time_month, levels = c("6 months", "12 months", "24 months", "36 months")
    )
  }
  if (identical(output_id, "SF06")) {
    display$sensitivity_id <- factor(
      display$sensitivity_id,
      levels = c("Complete-case analysis", "Observed-laboratory subset", "MI information")
    )
  }
  if (identical(output_id, "SF17")) {
    display$effect_time_label <- factor(
      display$effect_time_label,
      levels = c("Fixed effect", "6 months", "12 months", "24 months", "36 months")
    )
  }
  display
}

render_registered_svg <- function(
    data, registry_row, recipe_row, figure_path, caption_note = "") {
  # 加载绘图包以从 recipe 锁定的同一 figure-data 生成正式多格式图形。
  if (!requireNamespace("ggplot2", quietly = TRUE)) stop("ggplot2 is required", call. = FALSE)
  plot_type <- recipe_row$plot_type[[1L]]
  x <- recipe_row$x_column[[1L]]
  y <- recipe_row$y_column[[1L]]
  required <- c(x, y)
  optional <- unlist(recipe_row[1L, c(
    "lower_column", "upper_column", "group_column", "facet_column",
    "label_column", "value_column"
  )], use.names = FALSE)
  optional <- as.character(optional)
  required <- unique(c(required, optional[!is.na(optional) & nzchar(optional)]))
  require_publication_columns(data, required, registry_row$output_id[[1L]], "plot")
  if (plot_type != "HEATMAP" && !is.numeric(data[[y]])) {
    stop("Formal plot y_column must be numeric: ", registry_row$output_id[[1L]], call. = FALSE)
  }
  group <- recipe_row$group_column[[1L]]
  facet <- recipe_row$facet_column[[1L]]
  lower <- recipe_row$lower_column[[1L]]
  upper <- recipe_row$upper_column[[1L]]
  value <- recipe_row$value_column[[1L]]
  output_id <- registry_row$output_id[[1L]]
  plot_data <- .publication_display_projection_v43(data, output_id, recipe_row)
  label <- recipe_row$label_column[[1L]]
  if (nzchar(group)) {
    group_values <- if (nzchar(label)) plot_data[[label]] else plot_data[[group]]
    plot_data$.recipe_group <- factor(group_values, levels = unique(group_values))
  }
  special_plot <- plot_type %in% c("RCS_CUTOFF", "IPCW_ROC", "KM") ||
    output_id %in% c("MF01", "MF06", "SF14")
  x_label <- .publication_display_field_label_v43(x)
  y_label <- .publication_display_field_label_v43(y)
  if (output_id == "MF01") {
    if (nrow(plot_data) != 8L || anyDuplicated(as.character(plot_data$metric))) {
      stop("PUBLICATION_MF01_DISPLAY_SHAPE_INVALID", call. = FALSE)
    }
    plot <- ggplot2::ggplot(
      plot_data, ggplot2::aes(x = .data$metric, y = .data$value_numeric)
    ) +
      ggplot2::geom_col(width = 0.72, fill = "#1F4E79", na.rm = TRUE) +
      ggplot2::coord_flip(clip = "off")
    x_label <- NULL
    y_label <- "Value"
  } else if (output_id == "MF06") {
    estimable <- plot_data$estimate_status == "ESTIMABLE" &
      is.finite(plot_data$hr) & is.finite(plot_data$lower_95_ci) &
      is.finite(plot_data$upper_95_ci)
    not_estimable <- plot_data$estimate_status == "NOT_ESTIMABLE" &
      is.na(plot_data$hr) & is.na(plot_data$lower_95_ci) & is.na(plot_data$upper_95_ci)
    estimable[is.na(estimable)] <- FALSE
    not_estimable[is.na(not_estimable)] <- FALSE
    if (nrow(plot_data) != 100L || sum(estimable) != 92L || sum(not_estimable) != 8L ||
        any(!estimable & !not_estimable) || !grepl(
          "8 of 100 low-information estimates", caption_note, fixed = TRUE
        )) {
      stop("PUBLICATION_MF06_DISPLAY_CONTRACT_INVALID", call. = FALSE)
    }
    finite <- plot_data[estimable, , drop = FALSE]
    typed <- plot_data[not_estimable, , drop = FALSE]
    annotation_x <- max(finite$upper_95_ci)
    typed$.not_estimable_x <- annotation_x
    span <- diff(range(c(finite$lower_95_ci, finite$upper_95_ci)))
    if (!is.finite(span) || span <= 0) span <- 1
    significance <- finite[nzchar(finite$significance_symbol), , drop = FALSE]
    significance$.significance_x <- significance$upper_95_ci + 0.025 * span
    plot <- ggplot2::ggplot() +
      ggplot2::geom_errorbar(
        data = finite,
        ggplot2::aes(
          x = .data$.display_subgroup, ymin = .data$lower_95_ci,
          ymax = .data$upper_95_ci, colour = .data$subgroup_variable
        ), width = 0.16, linewidth = 0.38
      ) +
      ggplot2::geom_point(
        data = finite,
        ggplot2::aes(x = .data$.display_subgroup, y = .data$hr, colour = .data$subgroup_variable),
        size = 1.35
      ) +
      ggplot2::geom_text(
        data = typed,
        ggplot2::aes(x = .data$.display_subgroup, y = .data$.not_estimable_x),
        label = "Not estimable", hjust = -0.05, size = 2.15, colour = "#555555"
      ) +
      ggplot2::geom_text(
        data = significance,
        ggplot2::aes(
          x = .data$.display_subgroup, y = .data$.significance_x,
          label = .data$significance_symbol
        ), size = 2.3, colour = "#333333"
      ) +
      ggplot2::geom_hline(yintercept = 1, linetype = 2, colour = "#666666") +
      ggplot2::facet_wrap(~.display_time, ncol = 2L) +
      ggplot2::scale_x_discrete(drop = FALSE) +
      ggplot2::scale_y_continuous(expand = ggplot2::expansion(mult = c(0.05, 0.34))) +
      ggplot2::coord_flip(clip = "off") +
      ggplot2::guides(colour = "none")
    x_label <- NULL
    y_label <- "Hazard ratio"
  } else if (output_id == "SF14") {
    plot_data <- .publication_sf14_projection_v43(data)
    finite <- is.finite(plot_data$hr) & is.finite(plot_data$lower_95_ci) &
      is.finite(plot_data$upper_95_ci)
    nonfinite <- !finite
    row_labels <- stats::setNames(
      plot_data$.display_row_label, as.character(plot_data$.display_row)
    )
    span <- diff(range(c(plot_data$lower_95_ci[finite], plot_data$upper_95_ci[finite])))
    if (!is.finite(span) || span <= 0) span <- 1
    marker_x <- 1 + 0.04 * span
    plot_data$.display_marker_x <- marker_x
    plot <- ggplot2::ggplot() +
      ggplot2::geom_segment(
        data = plot_data[finite, , drop = FALSE],
        ggplot2::aes(
          x = .data$lower_95_ci, xend = .data$upper_95_ci,
          y = .data$.display_row, yend = .data$.display_row
        ), linewidth = 0.34, colour = "#486A8C"
      ) +
      ggplot2::geom_point(
        data = plot_data[finite, , drop = FALSE],
        ggplot2::aes(x = .data$hr, y = .data$.display_row),
        size = 1.05, colour = "#1F4E79"
      ) +
      ggplot2::geom_text(
        data = plot_data[nonfinite, , drop = FALSE],
        ggplot2::aes(
          x = .data$.display_marker_x, y = .data$.display_row,
          label = .data$.display_nonfinite_reason
        ), hjust = 0, size = 1.9, colour = "#555555"
      ) +
      ggplot2::geom_vline(xintercept = 1, linetype = 2, colour = "#666666") +
      ggplot2::facet_wrap(~.display_sensitivity, ncol = 3L, scales = "free_y") +
      ggplot2::scale_y_discrete(labels = row_labels, drop = TRUE) +
      ggplot2::scale_x_continuous(
        expand = ggplot2::expansion(mult = c(0.05, 0.08))
      ) +
      ggplot2::coord_cartesian(clip = "off") +
      ggplot2::theme(
        axis.text.y = ggplot2::element_text(size = 6.4),
        strip.text = ggplot2::element_text(size = 8, face = "bold"),
        panel.spacing = grid::unit(1.1, "lines")
      )
    x_label <- "Hazard ratio"
    y_label <- NULL
    caption_note <- paste(
      "All 271 registered sensitivity rows are shown;",
      "four diagnostic-only rows do not report a hazard ratio"
    )
  } else if (plot_type == "RCS_CUTOFF") {
    shape_label <- .publication_display_value_map_v43(output_id, "panel", "RCS_LOG_HR")
    derivative_label <- .publication_display_value_map_v43(
      output_id, "panel", "RCS_ANALYTIC_DERIVATIVE"
    )
    shape <- plot_data[plot_data$panel == shape_label, , drop = FALSE]
    derivative <- plot_data[plot_data$panel == derivative_label, , drop = FALSE]
    if (nrow(shape) != 200L || nrow(derivative) != 200L) {
      stop("RCS cutoff figure requires two exact 200-point panels", call. = FALSE)
    }
    references <- data.frame(
      panel = c("RCS_LOG_HR", "RCS_ANALYTIC_DERIVATIVE"),
      reference = c(1, 0), stringsAsFactors = FALSE
    )
    references$panel <- .publication_display_value_map_v43(
      output_id, "panel", references$panel
    )
    plot <- ggplot2::ggplot(plot_data, ggplot2::aes(x = .data$x_ast_alt, y = .data$y_value)) +
      ggplot2::geom_ribbon(
        data = shape,
        ggplot2::aes(ymin = .data$lower_value, ymax = .data$upper_value),
        fill = "#4C78A8", alpha = 0.18, colour = NA, na.rm = TRUE
      ) +
      ggplot2::geom_line(colour = "#1F4E79", linewidth = 0.8, na.rm = TRUE) +
      ggplot2::geom_hline(
        data = references, ggplot2::aes(yintercept = .data$reference),
        inherit.aes = FALSE, linetype = 2, colour = "#666666"
      ) +
      ggplot2::facet_wrap(~panel, ncol = 1L, scales = "free_y")
    cutoff <- unique(plot_data$cutoff_ast_alt[is.finite(plot_data$cutoff_ast_alt)])
    if (length(cutoff) == 1L) {
      plot <- plot + ggplot2::geom_vline(
        xintercept = cutoff, linetype = 3, linewidth = 0.6, colour = "#B22222"
      )
    }
    x_label <- "AST/ALT"
    y_label <- "Hazard ratio / analytic derivative"
  } else if (plot_type == "IPCW_ROC") {
    plot_data$.time_label <- factor(
      sprintf("%d months", as.integer(plot_data$time_month)),
      levels = sprintf("%d months", c(6, 12, 24, 36))
    )
    annotation <- plot_data[!duplicated(plot_data$time_month), , drop = FALSE]
    annotation$.time_label <- factor(
      sprintf("%d months", as.integer(annotation$time_month)),
      levels = levels(plot_data$.time_label)
    )
    annotation$youden_fpr <- 1 - annotation$specificity
    annotation$auc_label <- sprintf(
      "AUC %.3f (95%% CI %.3f-%.3f)\ncutoff %.3f; cases/controls %d/%d",
      annotation$auc, annotation$auc_lower_95_ci, annotation$auc_upper_95_ci,
      annotation$cutoff, as.integer(annotation$case_n), as.integer(annotation$control_n)
    )
    plot <- ggplot2::ggplot(
      plot_data, ggplot2::aes(x = .data$fpr, y = .data$tpr)
    ) +
      ggplot2::geom_abline(slope = 1, intercept = 0, linetype = 2, colour = "#777777") +
      ggplot2::geom_line(colour = "#1F4E79", linewidth = 0.85, na.rm = TRUE) +
      ggplot2::geom_point(
        data = annotation,
        ggplot2::aes(x = .data$youden_fpr, y = .data$sensitivity),
        inherit.aes = FALSE, colour = "#B22222", size = 2, na.rm = TRUE
      ) +
      ggplot2::geom_text(
        data = annotation,
        ggplot2::aes(x = 0.04, y = 0.96, label = .data$auc_label),
        inherit.aes = FALSE, hjust = 0, vjust = 1, size = 2.7, na.rm = TRUE
      ) +
      ggplot2::facet_wrap(~.time_label, ncol = 2L) +
      ggplot2::coord_equal(xlim = c(0, 1), ylim = c(0, 1))
    x_label <- "False-positive rate"
    y_label <- "True-positive rate"
  } else if (plot_type == "KM") {
    estimable <- plot_data$estimate_status == "ESTIMABLE" &
      is.finite(plot_data$time_month) & is.finite(plot_data$survival)
    estimable[is.na(estimable)] <- FALSE
    if (!any(estimable)) {
      reason <- unique(plot_data$not_estimable_reason_code[nzchar(plot_data$not_estimable_reason_code)])
      reason <- .publication_display_value_map_v43(
        output_id, "not_estimable_reason_code", reason
      )
      label <- paste("Not estimable", paste(reason, collapse = " | "), sep = "\n")
      plot <- ggplot2::ggplot() +
        ggplot2::annotate("text", x = 0.5, y = 0.5, label = label, size = 4) +
        ggplot2::xlim(0, 1) + ggplot2::ylim(0, 1) + ggplot2::theme_void()
    } else {
      curve <- plot_data[estimable, , drop = FALSE]
      curve$.recipe_group <- factor(curve$.recipe_group, levels = unique(curve$.recipe_group))
      summary_row <- curve[1L, , drop = FALSE]
      summary_label <- sprintf(
        "cutoff %.3f; n/events %d/%d; log-rank P %s\nDescriptive post-selection analysis",
        summary_row$cutoff, as.integer(summary_row$analysis_n), as.integer(summary_row$event_n),
        summary_row$p_display
      )
      plot <- ggplot2::ggplot(
        curve,
        ggplot2::aes(
          x = .data$time_month, y = .data$survival,
          colour = .data$.recipe_group, group = .data$.recipe_group
        )
      ) +
        ggplot2::geom_ribbon(
          ggplot2::aes(
            ymin = .data$lower_95_ci, ymax = .data$upper_95_ci,
            fill = .data$.recipe_group
          ),
          alpha = 0.12, colour = NA, na.rm = TRUE
        ) +
        ggplot2::geom_step(linewidth = 0.8, na.rm = TRUE) +
        ggplot2::annotate(
          "text", x = Inf, y = 0.04, label = summary_label,
          hjust = 1.02, vjust = 0, size = 2.8
        ) +
        ggplot2::scale_y_continuous(limits = c(0, 1))
    }
    x_label <- "Months"
    y_label <- "Survival probability"
  } else if (plot_type == "HEATMAP") {
    if (!is.numeric(plot_data[[value]])) stop("HEATMAP value_column must be numeric", call. = FALSE)
    plot <- ggplot2::ggplot(plot_data, ggplot2::aes(x = .data[[x]], y = .data[[y]], fill = .data[[value]])) +
      ggplot2::geom_tile(colour = "white", linewidth = 0.2) +
      ggplot2::scale_fill_viridis_c(option = "C", na.value = "#EEEEEE")
  } else {
    mapping <- if (nzchar(group)) {
      ggplot2::aes(x = .data[[x]], y = .data[[y]], colour = .data$.recipe_group, group = .data$.recipe_group)
    } else {
      ggplot2::aes(x = .data[[x]], y = .data[[y]])
    }
    plot <- ggplot2::ggplot(plot_data, mapping)
    if (plot_type == "COLUMN") {
      plot <- plot + ggplot2::geom_col(width = 0.72, na.rm = TRUE)
    } else if (plot_type %in% c("LINE", "LINE_CI")) {
      if (plot_type == "LINE_CI") {
        if (!nzchar(lower) || !nzchar(upper) || !is.numeric(plot_data[[lower]]) || !is.numeric(plot_data[[upper]])) {
          stop("LINE_CI requires numeric lower and upper columns", call. = FALSE)
        }
        plot <- plot + ggplot2::geom_ribbon(
          ggplot2::aes(ymin = .data[[lower]], ymax = .data[[upper]]),
          inherit.aes = TRUE, alpha = 0.15, colour = NA, na.rm = TRUE
        )
      }
      plot <- plot + ggplot2::geom_line(linewidth = 0.75, na.rm = TRUE) +
        ggplot2::geom_point(size = 1.5, na.rm = TRUE)
    } else if (plot_type %in% c("POINT", "POINT_CI", "FOREST")) {
      if (plot_type %in% c("POINT_CI", "FOREST")) {
        if (!nzchar(lower) || !nzchar(upper) || !is.numeric(plot_data[[lower]]) || !is.numeric(plot_data[[upper]])) {
          stop(plot_type, " requires numeric lower and upper columns", call. = FALSE)
        }
        plot <- plot + ggplot2::geom_errorbar(
          ggplot2::aes(ymin = .data[[lower]], ymax = .data[[upper]]),
          width = 0.15, linewidth = 0.45, na.rm = TRUE
        )
      }
      plot <- plot + ggplot2::geom_point(size = 1.8, na.rm = TRUE)
      if (plot_type == "FOREST") plot <- plot + ggplot2::coord_flip()
    } else {
      stop("Unsupported explicit plot_type: ", plot_type, call. = FALSE)
    }
    if (output_id %in% c("SF01", "SF02")) {
      plot <- plot + ggplot2::coord_flip(clip = "off")
    }
  }
  reference <- suppressWarnings(as.numeric(recipe_row$reference_line[[1L]]))
  if (length(reference) == 1L && is.finite(reference) &&
      plot_type != "HEATMAP" && !special_plot) {
    plot <- plot + ggplot2::geom_hline(yintercept = reference, linetype = 2, colour = "#666666")
  }
  if (nzchar(facet) && !special_plot) {
    plot <- plot + ggplot2::facet_wrap(stats::as.formula(paste("~", facet)), scales = "free_x")
  }
  if (!special_plot && !identical(output_id, "SF06") &&
      "significance_symbol" %in% names(plot_data) &&
      any(nzchar(plot_data$significance_symbol))) {
    annotation <- plot_data[nzchar(plot_data$significance_symbol), , drop = FALSE]
    plot <- plot + ggplot2::geom_text(
      data = annotation,
      ggplot2::aes(label = .data$significance_symbol),
      vjust = -0.7, size = 3, show.legend = FALSE, na.rm = TRUE
    )
  }
  evidence <- character()
  if ("analysis_n" %in% names(data)) {
    n_value <- unique(data$analysis_n[is.finite(data$analysis_n)])
    if (length(n_value) == 1L) evidence <- c(evidence, paste0("n=", n_value[[1L]]))
  }
  if ("event_n" %in% names(data)) {
    event_value <- unique(data$event_n[is.finite(data$event_n)])
    if (length(event_value) == 1L) evidence <- c(evidence, paste0("events=", event_value[[1L]]))
  }
  if (!is.character(caption_note) || length(caption_note) != 1L || is.na(caption_note) ||
      grepl("[\r\n]", caption_note)) {
    stop("PUBLICATION_CAPTION_NOTE_INVALID", call. = FALSE)
  }
  if (nzchar(caption_note)) evidence <- c(evidence, caption_note)
  caption <- paste(evidence, collapse = " | ")
  if (nzchar(caption)) caption <- paste(strwrap(caption, width = 88L), collapse = "\n")
  display_title <- if (identical(output_id, "MF04")) {
    "Time-varying HR per 1-SD AST/ALT"
  } else {
    registry_row$title_en[[1L]]
  }
  plot <- plot +
    ggplot2::labs(
      title = display_title,
      caption = caption,
      x = x_label, y = y_label, colour = NULL,
      fill = if (nzchar(value)) .publication_display_field_label_v43(value) else NULL
    ) +
    ggplot2::theme_classic(base_size = 10, base_family = "sans") +
    ggplot2::theme(
      panel.grid = ggplot2::element_blank(),
      plot.background = ggplot2::element_rect(fill = "white", colour = NA),
      plot.title = ggplot2::element_text(face = "bold"),
      plot.caption = ggplot2::element_text(hjust = 0, size = 8),
      plot.title.position = "plot", plot.caption.position = "plot",
      plot.margin = ggplot2::margin(8, 14, 8, 10)
    )
  if (identical(output_id, "SF07")) {
    plot <- plot + ggplot2::theme(
      axis.text.x = ggplot2::element_text(angle = 45, hjust = 1, vjust = 1)
    )
  }
  if (identical(output_id, "SF14")) {
    plot <- plot + ggplot2::theme(
      axis.text.y = ggplot2::element_text(size = 6.4),
      strip.text = ggplot2::element_text(size = 8, face = "bold"),
      panel.spacing = grid::unit(1.1, "lines")
    )
  }
  if (identical(output_id, "SF17")) {
    plot <- plot +
      ggplot2::theme(legend.position = "bottom") +
      ggplot2::guides(colour = ggplot2::guide_legend(nrow = 1L, byrow = TRUE))
  }
  dir.create(dirname(figure_path), recursive = TRUE, showWarnings = FALSE)
  pdf_path <- sub("[.]svg$", ".pdf", figure_path, ignore.case = TRUE)
  png_path <- sub("[.]svg$", ".png", figure_path, ignore.case = TRUE)
  width <- as.numeric(registry_row$width_in[[1L]])
  height <- as.numeric(registry_row$height_in[[1L]])
  # 输出由 R 生成、白底且无网格的正式 SVG。
  ggplot2::ggsave(
    figure_path, plot = plot, device = "svg",
    width = width, height = height, bg = "white"
  )
  # 输出与 SVG 共用同一 plot 对象的正式 PDF。
  # 图内文字锁为英文，中文标题保留在 registry 与 HTML，避免依赖系统 CJK 字体回退。
  stable_pdf_device <- function(filename, ...) {
    grDevices::pdf(
      file = filename, ..., timestamp = FALSE, producer = FALSE, compress = FALSE
    )
  }
  ggplot2::ggsave(
    pdf_path, plot = plot, device = stable_pdf_device,
    width = width, height = height, bg = "white"
  )
  # 输出与 SVG 共用同一 plot 对象的 300-dpi 正式 PNG。
  ggplot2::ggsave(
    png_path, plot = plot, device = "png", dpi = 300,
    width = width, height = height, bg = "white"
  )
  if (!all(file.exists(c(figure_path, pdf_path, png_path)))) {
    stop("PUBLICATION_MULTIFORMAT_FIGURE_EXPORT_INCOMPLETE", call. = FALSE)
  }
  figure_path
}

.a07_mf06_caption_note_v43 <- function(data, registry_row, recipe_row) {
  if (!identical(registry_row$output_id[[1L]], "MF06")) return("")
  if (!identical(recipe_row$source_kind[[1L]], "CANONICAL") ||
      !identical(recipe_row$source_file[[1L]], "subgroup_results.csv") ||
      !identical(recipe_row$producer_stage[[1L]], "A05") ||
      nrow(data) != 100L || length(setdiff(c(
        "estimate_status", "not_estimable_reason_code", "stability_flag"
      ), names(data)))) {
    stop("A07_MF06_OVERFLOW_CAPTION_SOURCE_INVALID", call. = FALSE)
  }
  overflow <- as.character(data$estimate_status) == "NOT_ESTIMABLE" &
    as.character(data$not_estimable_reason_code) == "NE_NUMERIC_OVERFLOW" &
    as.character(data$stability_flag) == "LOW_INFORMATION"
  overflow[is.na(overflow)] <- FALSE
  if (sum(overflow) != 8L) {
    stop("A07_MF06_OVERFLOW_CAPTION_CARDINALITY_INVALID", call. = FALSE)
  }
  paste(
    "8 of 100 low-information estimates had HR-scale numeric overflow;",
    "rows are shown as Not estimable without points or confidence intervals"
  )
}

publication_source_sha <- function(recipe_row, context) {
  source_kind <- recipe_row$source_kind[[1L]]
  if (source_kind == "GENERATED") {
    paths <- c(
      file.path(context$project_root, "config", "output_registry.csv"),
      file.path(context$project_root, "config", "output_recipe_registry.csv")
    )
    identity <- paste(
      basename(paths), vapply(paths, file_sha256, character(1)), sep = "=", collapse = "\n"
    )
    if (!requireNamespace("digest", quietly = TRUE)) stop("digest is required", call. = FALSE)
    return(digest::digest(identity, algo = "sha256", serialize = FALSE))
  }
  path <- if (source_kind == "CONFIG") {
    file.path(context$project_root, "config", recipe_row$source_file[[1L]])
  } else {
    file.path(context$run_root, "canonical_results", recipe_row$source_file[[1L]])
  }
  file_sha256(path)
}

publication_recipe_row_sha256 <- function(recipe_row) {
  if (!requireNamespace("digest", quietly = TRUE)) stop("digest is required", call. = FALSE)
  values <- vapply(recipe_row[1L, , drop = FALSE], function(value) {
    value <- as.character(value[[1L]])
    if (is.na(value)) "<NA>" else value
  }, character(1))
  digest::digest(
    paste(names(values), values, sep = "=", collapse = "\n"),
    algo = "sha256", serialize = FALSE
  )
}

.publication_receipt_sha256 <- function(row) {
  if (!requireNamespace("digest", quietly = TRUE)) stop("digest is required", call. = FALSE)
  values <- vapply(row[1L, setdiff(names(row), "receipt_sha256"), drop = FALSE], function(value) {
    value <- as.character(value[[1L]])
    if (is.na(value)) "<NA>" else value
  }, character(1))
  digest::digest(
    paste(names(values), values, sep = "=", collapse = "\n"),
    algo = "sha256", serialize = FALSE
  )
}

build_publication_source_integrity_receipts <- function(
    context, output_registry, recipes, audit_dir) {
  recipes <- recipes[match(output_registry$output_id, recipes$output_id), , drop = FALSE]
  canonical_recipe_present <- any(recipes$source_kind == "CANONICAL")
  applicability_receipt <- NULL
  applicability_receipt_file_sha256 <- "NOT_APPLICABLE"
  applicability_registry <- NULL
  if (canonical_recipe_present) {
    canonical_dir <- file.path(context$run_root, "canonical_results")
    applicability_receipt_path <- file.path(
      canonical_dir, "canonical_value_applicability_receipt.json"
    )
    if (!file.exists(applicability_receipt_path) || file.info(applicability_receipt_path)$isdir) {
      stop("CANONICAL_APPLICABILITY_RECEIPT_MISSING", call. = FALSE)
    }
    # 加载并反向复核全 Layer 2 applicability receipt，禁止仅验证被 recipe 选中的行。
    if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
    applicability_receipt <- tryCatch(
      jsonlite::read_json(applicability_receipt_path, simplifyVector = FALSE),
      error = function(error) NULL
    )
    if (is.null(applicability_receipt) ||
        !validate_canonical_value_applicability_receipt_v43(
          applicability_receipt, canonical_dir, context$project_root
        )) {
      stop("CANONICAL_APPLICABILITY_RECEIPT_INVALID", call. = FALSE)
    }
    applicability_receipt_file_sha256 <- file_sha256(applicability_receipt_path)
    applicability_registry <- read_canonical_value_applicability_registry_v43(
      context$project_root
    )
  }
  fixed_recipe_present <- any(
    recipes$source_kind == "CANONICAL" & recipes$source_file == "fixed_cox_results.csv"
  )
  rubin_receipt <- NULL
  rubin_receipt_file_sha256 <- "NOT_APPLICABLE"
  if (fixed_recipe_present) {
    rubin_receipt_path <- file.path(
      context$run_root, "canonical_results", "rubin_df_qc_receipt.json"
    )
    fixed_source_path <- file.path(
      context$run_root, "canonical_results", "fixed_cox_results.csv"
    )
    if (!file.exists(rubin_receipt_path) || !file.exists(fixed_source_path)) {
      stop("RUBIN_DF_QC_RECEIPT_OR_SOURCE_MISSING", call. = FALSE)
    }
    .publication_require_rubin_df_contract_v43(context$project_root)
    # 加载并复核 A03 typed receipt，确保 A07/release 消费同一 fixed source 身份。
    if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
    rubin_receipt <- tryCatch(
      jsonlite::read_json(rubin_receipt_path, simplifyVector = TRUE),
      error = function(error) NULL
    )
    if (is.null(rubin_receipt) ||
        !validate_rubin_df_qc_receipt_v43(
          rubin_receipt, fixed_source_path, context$project_root
        )) {
      stop("RUBIN_DF_QC_RECEIPT_RELEASE_VALIDATION_FAILED", call. = FALSE)
    }
    rubin_receipt_file_sha256 <- file_sha256(rubin_receipt_path)
  }
  source_key <- paste(recipes$source_kind, recipes$source_file, sep = "\r")
  source_groups <- split(seq_len(nrow(recipes)), source_key)
  reason_registry <- utils::read.csv(
    file.path(context$project_root, "config", "not_estimable_reason_registry.csv"),
    stringsAsFactors = FALSE, check.names = FALSE, na.strings = character()
  )
  canonical_registry <- utils::read.csv(
    file.path(context$project_root, "config", "canonical_file_registry.csv"),
    stringsAsFactors = FALSE, check.names = FALSE, na.strings = character()
  )
  canonical_schema <- utils::read.csv(
    file.path(context$project_root, "schemas", "canonical_result_schema.csv"),
    stringsAsFactors = FALSE, check.names = FALSE, na.strings = character()
  )
  rows <- lapply(source_groups, function(indices) {
    recipe_group <- recipes[indices, , drop = FALSE]
    registry_group <- output_registry[indices, , drop = FALSE]
    source_kind <- recipe_group$source_kind[[1L]]
    source_file <- recipe_group$source_file[[1L]]
    data <- read_publication_source(registry_group[1L, , drop = FALSE], recipe_group[1L, , drop = FALSE], context)
    if (!is.data.frame(data) || any(!nzchar(names(data))) || anyDuplicated(names(data))) {
      stop("PUBLICATION_SOURCE_SCHEMA_INVALID: ", source_kind, "/", source_file, call. = FALSE)
    }
    applicability_audit <- if (identical(source_kind, "CANONICAL")) {
      publication_canonical_audit(
        data, source_file, recipe_group$producer_stage[[1L]],
        context$project_root, applicability_registry
      )
    } else NULL
    rubin_df_audit <- .publication_rubin_df_audit_v43(
      data, context$project_root, paste0(source_kind, "/", source_file)
    )
    required_by_recipe <- unique(unlist(lapply(seq_len(nrow(recipe_group)), function(index) {
      recipe <- recipe_group[index, , drop = FALSE]
      columns <- c(
        publication_recipe_columns(recipe$output_columns[[1L]]),
        publication_recipe_columns(recipe$sort_columns[[1L]]),
        as.character(unlist(recipe[1L, c(
          "x_column", "y_column", "lower_column", "upper_column", "group_column",
          "facet_column", "label_column", "value_column"
        )], use.names = FALSE))
      )
      columns[!is.na(columns) & nzchar(columns)]
    }), use.names = FALSE))
    runtime_derived_columns <- unique(unlist(lapply(seq_len(nrow(recipe_group)), function(index) {
      publication_runtime_derived_columns(
        recipe_group$selector_id[[index]],
        publication_recipe_columns(recipe_group$output_columns[[index]])
      )
    }), use.names = FALSE))
    selector_identity_columns <- c(
      "estimand_id", "analysis_id", "sensitivity_id", "subgroup_id", "endpoint",
      "model_id", "exposure_parameterization", "exposure_form", "contrast",
      "time_month", "parent_term", "coefficient", "variable", "stratum", "metric",
      "source_population", "qc_item", "level", "omitted_imputation", "omitted_center"
    )
    required_columns <- unique(c(
      setdiff(required_by_recipe, runtime_derived_columns),
      intersect(selector_identity_columns, names(data))
    ))
    require_publication_columns(data, required_columns, source_file, "source schema")
    canonical_row <- canonical_registry[
      canonical_registry$source_canonical_file == source_file, , drop = FALSE
    ]
    if (identical(source_kind, "CANONICAL") && nrow(canonical_row) != 1L) {
      stop("PUBLICATION_CANONICAL_REGISTRY_CARDINALITY: ", source_file, call. = FALSE)
    }
    if (identical(source_kind, "CANONICAL") &&
        (!identical(canonical_row$producer_stage[[1L]], unique(recipe_group$producer_stage)) ||
          !nzchar(canonical_row$canonical_schema_id[[1L]]) ||
          !identical(canonical_row$patient_level_allowed[[1L]], FALSE))) {
      stop("PUBLICATION_CANONICAL_REGISTRY_CONTRACT_MISMATCH: ", source_file, call. = FALSE)
    }
    schema_id <- if (identical(source_kind, "CANONICAL")) {
      canonical_row$canonical_schema_id[[1L]]
    } else if (identical(source_kind, "CONFIG")) {
      paste0("CONFIG_", toupper(sub("[.]csv$", "", source_file)), "_V1")
    } else "GENERATED_OUTPUT_REGISTRY_CLOSURE_V1"
    numeric_required <- unique(c(
      intersect(
        c(
          "n", "events", "at_risk_n", "estimate", "beta", "se", "hr",
          "lower_95_ci", "upper_95_ci", "p_value", "joint_p", "annotation_p",
          "within_variance", "between_variance", "total_variance", "rubin_df",
          "valid_imputation_n"
        ),
        required_columns
      ),
      unlist(lapply(seq_len(nrow(recipe_group)), function(index) {
        recipe <- recipe_group[index, , drop = FALSE]
        roles <- if (identical(recipe$plot_type[[1L]], "HEATMAP")) {
          "value_column"
        } else if (!identical(recipe$plot_type[[1L]], "NONE")) {
          c("y_column", "lower_column", "upper_column")
        } else character()
        columns <- if (length(roles)) {
          as.character(unlist(recipe[1L, roles, drop = FALSE], use.names = FALSE))
        } else character()
        columns[!is.na(columns) & nzchar(columns)]
      }), use.names = FALSE)
    ))
    numeric_required <- intersect(unique(c(
      numeric_required, publication_semantic_numeric_columns(required_columns)
    )), names(data))
    nonnumeric <- numeric_required[!vapply(data[numeric_required], is.numeric, logical(1))]
    if (length(nonnumeric)) {
      stop(
        "PUBLICATION_SOURCE_TYPE_INVALID: ", source_file, "/",
        paste(nonnumeric, collapse = "|"), call. = FALSE
      )
    }
    numeric_columns <- names(data)[vapply(data, is.numeric, logical(1))]
    nonfinite_cell_n <- sum(vapply(data[numeric_columns], function(value) {
      sum(is.nan(value) | (!is.na(value) & !is.finite(value)))
    }, integer(1)))
    permitted_rubin_df_positive_infinity_n <- if (is.null(rubin_df_audit)) {
      0L
    } else {
      as.integer(sum(rubin_df_audit$allowed_positive_infinite_rubin_df))
    }
    disallowed_nonfinite_cell_n <- as.integer(
      nonfinite_cell_n - permitted_rubin_df_positive_infinity_n
    )
    if (disallowed_nonfinite_cell_n > 0L) {
      stop("PUBLICATION_SOURCE_NONFINITE: ", source_file, call. = FALSE)
    }
    generic_schema_applies <- identical(source_kind, "CANONICAL") &&
      all(c("estimand_id", "estimate_status") %in% names(data))
    if (generic_schema_applies) {
      required_schema_columns <- canonical_schema$column[canonical_schema$required]
      missing_required_schema <- setdiff(required_schema_columns, names(data))
      if (length(missing_required_schema)) {
        stop(
          "PUBLICATION_CANONICAL_SCHEMA_REQUIRED_MISSING: ", source_file, "/",
          paste(missing_required_schema, collapse = "|"), call. = FALSE
        )
      }
    }
    if (identical(source_kind, "CANONICAL") &&
        isTRUE(canonical_row$required_model_signature[[1L]])) {
      if (!"model_signature_sha256" %in% names(data) ||
          any(!grepl("^[0-9a-f]{64}$", as.character(data$model_signature_sha256)))) {
        stop("PUBLICATION_CANONICAL_MODEL_SIGNATURE_INVALID: ", source_file, call. = FALSE)
      }
    }
    expected_numeric <- canonical_schema$column[
      canonical_schema$type %in% c("numeric", "integer") &
        canonical_schema$column %in% names(data)
    ]
    invalid_schema_type <- expected_numeric[!vapply(data[expected_numeric], is.numeric, logical(1))]
    if (length(invalid_schema_type)) {
      stop(
        "PUBLICATION_CANONICAL_SCHEMA_TYPE_INVALID: ", source_file, "/",
        paste(invalid_schema_type, collapse = "|"), call. = FALSE
      )
    }
    expected_character <- canonical_schema$column[
      canonical_schema$type == "character" & canonical_schema$column %in% names(data)
    ]
    invalid_character_type <- expected_character[
      !vapply(data[expected_character], is.character, logical(1))
    ]
    if (length(invalid_character_type)) {
      stop(
        "PUBLICATION_CANONICAL_CHARACTER_TYPE_INVALID: ", source_file, "/",
        paste(invalid_character_type, collapse = "|"), call. = FALSE
      )
    }
    expected_integer <- canonical_schema$column[
      canonical_schema$type == "integer" & canonical_schema$column %in% names(data)
    ]
    expected_integer <- unique(c(
      expected_integer, publication_semantic_integer_columns(required_columns)
    ))
    expected_integer <- intersect(expected_integer, names(data))
    noninteger <- expected_integer[vapply(data[expected_integer], function(value) {
      any(!is.na(value) & value != floor(value))
    }, logical(1))]
    if (length(noninteger)) {
      stop(
        "PUBLICATION_CANONICAL_INTEGER_TYPE_INVALID: ", source_file, "/",
        paste(noninteger, collapse = "|"), call. = FALSE
      )
    }
    expected_logical <- intersect(
      publication_semantic_logical_columns(required_columns), names(data)
    )
    invalid_logical <- expected_logical[
      !vapply(data[expected_logical], is.logical, logical(1))
    ]
    if (length(invalid_logical)) {
      stop(
        "PUBLICATION_CANONICAL_LOGICAL_TYPE_INVALID: ", source_file, "/",
        paste(invalid_logical, collapse = "|"), call. = FALSE
      )
    }
    typed_reason <- rep(FALSE, nrow(data))
    if (all(c("estimate_status", "not_estimable_reason_code") %in% names(data))) {
      reason <- as.character(data$not_estimable_reason_code)
      status <- as.character(data$estimate_status)
      typed_reason <- !is.na(data$estimate_status) & data$estimate_status != "ESTIMABLE" &
        !is.na(reason) & nzchar(trimws(reason))
      if (is.null(applicability_audit)) {
        valid_status <- status %in% c("ESTIMABLE", "NOT_ESTIMABLE")
        if (any(!valid_status)) {
          stop("PUBLICATION_ESTIMATE_STATUS_INVALID: ", source_file, call. = FALSE)
        }
        unknown <- unique(reason[typed_reason & !reason %in% reason_registry$reason_code])
        if (length(unknown)) {
          stop(
            "PUBLICATION_TYPED_NA_REASON_UNREGISTERED: ", source_file, "/",
            paste(sort(unknown), collapse = "|"), call. = FALSE
          )
        }
        missing_nonestimable_reason <- status != "ESTIMABLE" & !typed_reason
        estimable_with_reason <- status == "ESTIMABLE" &
          !is.na(reason) & nzchar(trimws(reason))
        if (any(missing_nonestimable_reason) || any(estimable_with_reason)) {
          stop("PUBLICATION_ESTIMATE_STATUS_REASON_MISMATCH: ", source_file, call. = FALSE)
        }
      }
    }
    na_matrix <- if (length(numeric_columns) && nrow(data)) {
      do.call(cbind, lapply(data[numeric_columns], is.na))
    } else matrix(FALSE, nrow = nrow(data), ncol = 0L)
    typed_na_cell_n <- if (length(na_matrix)) sum(na_matrix[typed_reason, , drop = FALSE]) else 0L
    structural_na_cell_n <- if (is.null(applicability_audit)) {
      if (length(na_matrix)) sum(na_matrix[!typed_reason, , drop = FALSE]) else 0L
    } else applicability_audit$structural_na_cell_n
    critical_numeric <- intersect(
      c("estimate", "beta", "se", "hr", "lower_95_ci", "upper_95_ci", "p_value"),
      numeric_columns
    )
    critical_na <- if (length(critical_numeric)) {
      Reduce(`|`, lapply(data[critical_numeric], is.na), init = rep(FALSE, nrow(data)))
    } else rep(FALSE, nrow(data))
    critical_disallowed <- critical_na & !typed_reason
    if (!is.null(applicability_audit) && length(critical_numeric)) {
      critical_disallowed <- apply(
        na_matrix[, critical_numeric, drop = FALSE] &
          !applicability_audit$allowed_na_matrix[, critical_numeric, drop = FALSE],
        1L, any
      ) & !typed_reason
    }
    if (any(critical_disallowed)) {
      stop(
        "PUBLICATION_SOURCE_CRITICAL_NA_WITHOUT_TYPED_REASON: ", source_file,
        "; rows=", paste(which(critical_disallowed), collapse = "|"),
        call. = FALSE
      )
    }
    explicit_key <- if (identical(source_kind, "CANONICAL") &&
        !identical(canonical_row$primary_key[[1L]], "registry_defined_composite_key")) {
      publication_key_columns(canonical_row$primary_key[[1L]])
    } else character()
    available_identity_candidates <- c(
      "estimand_id", "analysis_id", "sensitivity_id", "subgroup_id", "endpoint",
      "model_id", "exposure_parameterization", "exposure_form", "contrast",
      "time_month", "parent_term", "coefficient", "variable", "stratum", "metric",
      "source_population", "qc_item", "level", "omitted_imputation", "omitted_center",
      "output_id", "file_name"
    )
    available_identity_key <- unique(c(
      explicit_key,
      unique(unlist(lapply(
        recipe_group$sort_columns, publication_recipe_columns
      ), use.names = FALSE)),
      intersect(available_identity_candidates, required_columns)
    ))
    available_identity_key <- available_identity_key[available_identity_key %in% names(data)]
    if (!length(available_identity_key)) {
      available_identity_key <- intersect(available_identity_candidates, names(data))
    }
    if (!length(available_identity_key)) {
      stop("PUBLICATION_CANONICAL_AVAILABLE_IDENTITY_KEY_MISSING: ", source_file, call. = FALSE)
    }
    duplicate_key_n <- sum(duplicated(data[available_identity_key]))
    if (duplicate_key_n > 0L) {
      stop(
        "PUBLICATION_CANONICAL_WHOLE_FILE_KEY_DUPLICATE: ", source_file,
        "; key=", paste(available_identity_key, collapse = "|"), call. = FALSE
      )
    }
    selected_row_n <- 0L
    for (index in seq_len(nrow(recipe_group))) {
      # 对每个消费 recipe 运行同一 selector、投影、typed-NA 与总排序键合同。
      selected <- apply_publication_recipe(
        data, recipe_group[index, , drop = FALSE], registry_group[index, , drop = FALSE],
        context$project_root, applicability_audit = applicability_audit
      )
      selected_row_n <- selected_row_n + nrow(selected)
    }
    column_schema <- paste(
      names(data), vapply(data, function(value) paste(class(value), collapse = "/"), character(1)),
      sep = "=", collapse = "\n"
    )
    recipe_key_contract <- paste(
      recipe_group$output_id, recipe_group$selector_id, recipe_group$sort_columns,
      sep = "=", collapse = "\n"
    )
    if (!requireNamespace("digest", quietly = TRUE)) stop("digest is required", call. = FALSE)
    row <- data.frame(
      source_kind = source_kind,
      source_file = source_file,
      producer_stage = paste(sort(unique(recipe_group$producer_stage)), collapse = "|"),
      canonical_schema_id = schema_id,
      registry_primary_key = if (identical(source_kind, "CANONICAL")) {
        canonical_row$primary_key[[1L]]
      } else "NOT_APPLICABLE",
      validated_whole_file_key = paste(available_identity_key, collapse = "|"),
      whole_file_duplicate_key_count = duplicate_key_n,
      output_ids = paste(sort(recipe_group$output_id), collapse = "|"),
      source_sha256 = publication_source_sha(recipe_group[1L, , drop = FALSE], context),
      source_row_count = nrow(data),
      source_column_count = ncol(data),
      selected_row_count = selected_row_n,
      column_schema_sha256 = digest::digest(column_schema, algo = "sha256", serialize = FALSE),
      required_columns_sha256 = digest::digest(
        paste(sort(required_columns), collapse = "\n"), algo = "sha256", serialize = FALSE
      ),
      recipe_key_contract_sha256 = digest::digest(
        recipe_key_contract, algo = "sha256", serialize = FALSE
      ),
      numeric_column_count = length(numeric_columns),
      nonfinite_cell_count = nonfinite_cell_n,
      permitted_rubin_df_positive_infinity_count = permitted_rubin_df_positive_infinity_n,
      disallowed_nonfinite_cell_count = disallowed_nonfinite_cell_n,
      rubin_df_selection_sha256 = if (is.null(rubin_df_audit)) "NOT_APPLICABLE" else rubin_df_audit$selection_sha256,
      rubin_df_selection_receipt_file_sha256 = if (is.null(rubin_df_audit)) "NOT_APPLICABLE" else rubin_df_audit$selection_receipt_file_sha256,
      rubin_df_qc_receipt_sha256 = if (identical(source_file, "fixed_cox_results.csv")) rubin_receipt$receipt_sha256 else "NOT_APPLICABLE",
      rubin_df_qc_receipt_file_sha256 = if (identical(source_file, "fixed_cox_results.csv")) rubin_receipt_file_sha256 else "NOT_APPLICABLE",
      canonical_applicability_selection_sha256 = if (is.null(applicability_audit)) {
        "NOT_APPLICABLE"
      } else applicability_receipt$selection_sha256,
      canonical_applicability_receipt_sha256 = if (is.null(applicability_audit)) {
        "NOT_APPLICABLE"
      } else applicability_receipt$receipt_sha256,
      canonical_applicability_receipt_file_sha256 = if (is.null(applicability_audit)) {
        "NOT_APPLICABLE"
      } else applicability_receipt_file_sha256,
      canonical_applicability_profile_counts = if (is.null(applicability_audit)) {
        "NOT_APPLICABLE"
      } else applicability_audit$profile_counts,
      typed_na_cell_count = typed_na_cell_n,
      structural_na_cell_count = structural_na_cell_n,
      schema_status = "PASS", key_status = "PASS", type_status = "PASS",
      finite_status = "PASS", typed_na_status = "PASS",
      na_policy = if (is.null(applicability_audit)) {
        "WHOLE_FILE_CRITICAL_NA_REQUIRES_REGISTERED_REASON"
      } else {
        "STRUCT_NA_1A_EXACT_ONE_PROFILE_PER_ROW;UNREGISTERED_NA_OR_NONFINITE_FAILS"
      },
      key_policy = if (identical(source_kind, "CANONICAL") &&
          identical(canonical_row$primary_key[[1L]], "registry_defined_composite_key")) {
        "DETERMINISTIC_AVAILABLE_IDENTITY_KEY_FROM_RECIPE_SORT_UNION"
      } else "EXPLICIT_REGISTRY_OR_SOURCE_IDENTITY_KEY",
      status = "PASS",
      stringsAsFactors = FALSE
    )
    row$receipt_sha256 <- .publication_receipt_sha256(row)
    row
  })
  output <- do.call(rbind, rows)
  output <- output[order(output$source_kind, output$source_file, method = "radix"), , drop = FALSE]
  rownames(output) <- NULL
  dir.create(audit_dir, recursive = TRUE, showWarnings = FALSE)
  receipt_path <- file.path(audit_dir, "publication_source_integrity_receipts.csv")
  # 输出每个被消费 source 的 schema/key/type/finite/typed-NA 证据回执。
  utils::write.csv(output, receipt_path, row.names = FALSE, na = "")
  reloaded <- utils::read.csv(receipt_path, stringsAsFactors = FALSE, check.names = FALSE)
  if (nrow(reloaded) != nrow(output) || any(reloaded$status != "PASS") ||
      any(vapply(seq_len(nrow(reloaded)), function(index) {
        !identical(reloaded$receipt_sha256[[index]], .publication_receipt_sha256(reloaded[index, , drop = FALSE]))
      }, logical(1)))) {
    stop("PUBLICATION_SOURCE_RECEIPT_SERIALIZATION_MISMATCH", call. = FALSE)
  }
  reloaded
}

validate_publication_output_closure <- function(
    output_registry, manifest, release_dir, recipes = NULL, context = NULL) {
  if (anyDuplicated(manifest$output_id) || !identical(sort(manifest$output_id), sort(output_registry$output_id))) {
    stop("Publication manifest does not close exactly over output_registry", call. = FALSE)
  }
  if (nrow(manifest) != nrow(output_registry) || !all(manifest$exists)) {
    stop("Publication manifest count/existence closure failed", call. = FALSE)
  }
  expected_tables <- sort(output_registry$file_name[output_registry$format == "CSV"])
  actual_tables <- sort(list.files(file.path(release_dir, "tables"), all.files = TRUE, no.. = TRUE))
  if (!identical(actual_tables, expected_tables)) stop("Publication table filesystem closure failed", call. = FALSE)
  expected_svg <- output_registry$file_name[output_registry$format == "SVG"]
  multiformat_contract <- nrow(output_registry) == 77L &&
    sum(output_registry$format == "CSV") == 42L &&
    sum(output_registry$format == "SVG") == 35L
  expected_figures <- if (multiformat_contract) sort(c(
    expected_svg,
    sub("[.]svg$", ".pdf", expected_svg, ignore.case = TRUE),
    sub("[.]svg$", ".png", expected_svg, ignore.case = TRUE)
  )) else sort(expected_svg)
  actual_figures <- sort(list.files(file.path(release_dir, "figures"), all.files = TRUE, no.. = TRUE))
  if (!identical(actual_figures, expected_figures)) stop("Publication figure filesystem closure failed", call. = FALSE)
  if (multiformat_contract && length(expected_tables) + length(expected_figures) != 147L) {
    stop("Publication physical main-file closure is not 147", call. = FALSE)
  }
  figure_rows <- output_registry$format == "SVG"
  expected_figure_data <- sort(c(
    output_registry$figure_data_csv[figure_rows],
    output_registry$figure_data_hash_sidecar[figure_rows]
  ))
  actual_figure_data <- sort(list.files(file.path(release_dir, "figure_data"), all.files = TRUE, no.. = TRUE))
  if (!identical(actual_figure_data, expected_figure_data)) stop("Publication figure-data filesystem closure failed", call. = FALSE)
  if (!is.null(context) || !is.null(recipes)) {
    if (is.null(context) || is.null(recipes)) stop("PUBLICATION_PROVENANCE_CONTEXT_INCOMPLETE", call. = FALSE)
    provenance_fields <- c(
      "source_canonical_sha256", "recipe_registry_sha256", "recipe_row_sha256",
      "source_integrity_receipt_sha256"
    )
    if (length(setdiff(provenance_fields, names(manifest)))) {
      stop("PUBLICATION_PROVENANCE_FIELDS_MISSING", call. = FALSE)
    }
    recipes <- recipes[match(output_registry$output_id, recipes$output_id), , drop = FALSE]
    receipt_path <- file.path(release_dir, "audit", "publication_source_integrity_receipts.csv")
    if (!file.exists(receipt_path)) stop("PUBLICATION_SOURCE_RECEIPT_MISSING", call. = FALSE)
    receipts <- utils::read.csv(receipt_path, stringsAsFactors = FALSE, check.names = FALSE)
    expected_receipt_keys <- sort(unique(paste(
      recipes$source_kind, recipes$source_file, sep = "\r"
    )), method = "radix")
    observed_receipt_keys <- sort(paste(
      receipts$source_kind, receipts$source_file, sep = "\r"
    ), method = "radix")
    if (!nrow(receipts) || !identical(observed_receipt_keys, expected_receipt_keys) ||
        anyDuplicated(observed_receipt_keys) ||
        any(receipts$status != "PASS") ||
        any(vapply(seq_len(nrow(receipts)), function(index) {
          !identical(receipts$receipt_sha256[[index]], .publication_receipt_sha256(receipts[index, , drop = FALSE]))
        }, logical(1)))) {
      stop("PUBLICATION_SOURCE_RECEIPT_INVALID", call. = FALSE)
    }
    recipe_registry_sha <- file_sha256(
      file.path(context$project_root, "config", "output_recipe_registry.csv")
    )
  }
  for (index in seq_len(nrow(output_registry))) {
    registry_row <- output_registry[index, , drop = FALSE]
    manifest_row <- manifest[manifest$output_id == registry_row$output_id[[1L]], , drop = FALSE]
    artifact <- file.path(
      release_dir,
      if (registry_row$format[[1L]] == "CSV") "tables" else "figures",
      registry_row$file_name[[1L]]
    )
    if (nrow(manifest_row) != 1L ||
        !identical(as.character(manifest_row$file_name[[1L]]), registry_row$file_name[[1L]]) ||
        !identical(as.character(manifest_row$format[[1L]]), registry_row$format[[1L]]) ||
        !identical(as.character(manifest_row$output_sha256[[1L]]), file_sha256(artifact))) {
      stop("PUBLICATION_OUTPUT_SHA_MISMATCH: ", registry_row$output_id[[1L]], call. = FALSE)
    }
    if (!is.null(context)) {
      recipe_row <- recipes[index, , drop = FALSE]
      receipt <- receipts[
        receipts$source_kind == recipe_row$source_kind[[1L]] &
          receipts$source_file == recipe_row$source_file[[1L]], , drop = FALSE
      ]
      expected_source_sha <- publication_source_sha(recipe_row, context)
      expected_recipe_row_sha <- publication_recipe_row_sha256(recipe_row)
      sha_values <- as.character(unlist(manifest_row[1L, c(
        "source_canonical_sha256", "recipe_registry_sha256", "recipe_row_sha256",
        "source_integrity_receipt_sha256"
      )], use.names = FALSE))
      if (nrow(receipt) != 1L || any(!grepl("^[0-9a-f]{64}$", sha_values)) ||
          !identical(manifest_row$source_canonical_sha256[[1L]], expected_source_sha) ||
          !identical(receipt$source_sha256[[1L]], expected_source_sha) ||
          !identical(manifest_row$recipe_registry_sha256[[1L]], recipe_registry_sha) ||
          !identical(manifest_row$recipe_row_sha256[[1L]], expected_recipe_row_sha) ||
          !identical(manifest_row$source_integrity_receipt_sha256[[1L]], receipt$receipt_sha256[[1L]])) {
        stop("PUBLICATION_SOURCE_RECIPE_SHA_MISMATCH: ", registry_row$output_id[[1L]], call. = FALSE)
      }
    }
    if (registry_row$format[[1L]] == "CSV") {
      row_count <- nrow(utils::read.csv(artifact, stringsAsFactors = FALSE, check.names = FALSE))
      if (!identical(as.integer(manifest_row$row_count[[1L]]), as.integer(row_count))) {
        stop("PUBLICATION_OUTPUT_ROW_COUNT_MISMATCH: ", registry_row$output_id[[1L]], call. = FALSE)
      }
    } else {
      data_path <- file.path(release_dir, "figure_data", registry_row$figure_data_csv[[1L]])
      sidecar <- file.path(release_dir, "figure_data", registry_row$figure_data_hash_sidecar[[1L]])
      pdf_path <- sub("[.]svg$", ".pdf", artifact, ignore.case = TRUE)
      png_path <- sub("[.]svg$", ".png", artifact, ignore.case = TRUE)
      data_sha <- file_sha256(data_path)
      expected_sidecar <- paste(data_sha, basename(data_path), sep = "  ")
      row_count <- nrow(utils::read.csv(data_path, stringsAsFactors = FALSE, check.names = FALSE))
      multiformat_invalid <- multiformat_contract && (
        !all(c("pdf_file", "pdf_sha256", "png_file", "png_sha256") %in% names(manifest_row)) ||
        !identical(as.character(manifest_row$pdf_file[[1L]]), basename(pdf_path)) ||
        !identical(as.character(manifest_row$pdf_sha256[[1L]]), file_sha256(pdf_path)) ||
        !identical(as.character(manifest_row$png_file[[1L]]), basename(png_path)) ||
        !identical(as.character(manifest_row$png_sha256[[1L]]), file_sha256(png_path))
      )
      if (!identical(as.character(manifest_row$figure_data_file[[1L]]), basename(data_path)) ||
          !identical(as.character(manifest_row$figure_data_sha256[[1L]]), data_sha) ||
          multiformat_invalid ||
          !identical(trimws(readLines(sidecar, warn = FALSE)), expected_sidecar) ||
          !identical(as.integer(manifest_row$row_count[[1L]]), as.integer(row_count))) {
        stop("PUBLICATION_FIGURE_DATA_CLOSURE_MISMATCH: ", registry_row$output_id[[1L]], call. = FALSE)
      }
    }
  }
  invisible(TRUE)
}

render_publication_outputs <- function(context = stage_context(), release_dir = NULL) {
  output_registry <- utils::read.csv(
    file.path(context$project_root, "config", "output_registry.csv"),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  recipes <- load_publication_recipes(context$project_root)
  validate_publication_recipes(output_registry, recipes)
  recipes <- recipes[match(output_registry$output_id, recipes$output_id), , drop = FALSE]
  release <- if (is.null(release_dir)) file.path(context$run_root, "release") else release_dir
  managed_directories <- file.path(release, c("tables", "figures", "figure_data", "manifest", "audit"))
  for (directory in managed_directories) {
    if (dir.exists(directory)) unlink(directory, recursive = TRUE)
    dir.create(directory, recursive = TRUE, showWarnings = FALSE)
  }
  table_dir <- file.path(release, "tables")
  figure_dir <- file.path(release, "figures")
  figure_data_dir <- file.path(release, "figure_data")
  manifest <- vector("list", nrow(output_registry))
  recipe_sha <- file_sha256(file.path(context$project_root, "config", "output_recipe_registry.csv"))
  receipts <- build_publication_source_integrity_receipts(
    context, output_registry, recipes, file.path(release, "audit")
  )
  applicability_registry <- read_canonical_value_applicability_registry_v43(
    context$project_root
  )
  applicability_cache <- new.env(parent = emptyenv())
  for (i in seq_len(nrow(output_registry))) {
    registry_row <- output_registry[i, , drop = FALSE]
    recipe_row <- recipes[i, , drop = FALSE]
    data <- read_publication_source(registry_row, recipe_row, context)
    caption_note <- .a07_mf06_caption_note_v43(data, registry_row, recipe_row)
    applicability_audit <- NULL
    if (identical(recipe_row$source_kind[[1L]], "CANONICAL")) {
      source_file <- recipe_row$source_file[[1L]]
      if (!exists(source_file, envir = applicability_cache, inherits = FALSE)) {
        assign(
          source_file,
          publication_canonical_audit(
            data, source_file, recipe_row$producer_stage[[1L]],
            context$project_root, applicability_registry
          ),
          envir = applicability_cache
        )
      }
      applicability_audit <- get(
        source_file, envir = applicability_cache, inherits = FALSE
      )
    }
    data <- apply_publication_recipe(
      data, recipe_row, registry_row, context$project_root,
      applicability_audit = applicability_audit
    )
    model_signatures <- if ("model_signature_sha256" %in% names(data)) {
      valid_signature <- !is.na(data$model_signature_sha256) & nzchar(data$model_signature_sha256)
      paste(sort(unique(data$model_signature_sha256[valid_signature])), collapse = "|")
    } else {
      ""
    }
    source_identity <- publication_source_sha(recipe_row, context)
    pdf_file <- ""
    pdf_sha256 <- ""
    png_file <- ""
    png_sha256 <- ""
    if (registry_row$format[[1L]] == "CSV") {
      path <- file.path(table_dir, registry_row$file_name[[1L]])
      # 输出经 recipe 选择、投影和排序后的正式 CSV。
      utils::write.csv(data, path, row.names = FALSE, na = "")
      figure_data <- ""
    } else {
      data$source_data_sha256 <- source_identity
      figure_data <- file.path(figure_data_dir, registry_row$figure_data_csv[[1L]])
      # 输出正式 SVG 唯一允许读取的 figure-data CSV。
      utils::write.csv(data, figure_data, row.names = FALSE, na = "")
      sidecar <- file.path(figure_data_dir, registry_row$figure_data_hash_sidecar[[1L]])
      writeLines(paste(file_sha256(figure_data), basename(figure_data), sep = "  "), sidecar, useBytes = TRUE)
      path <- file.path(figure_dir, registry_row$file_name[[1L]])
      render_registered_svg(data, registry_row, recipe_row, path, caption_note)
      pdf_path <- sub("[.]svg$", ".pdf", path, ignore.case = TRUE)
      png_path <- sub("[.]svg$", ".png", path, ignore.case = TRUE)
      pdf_file <- basename(pdf_path)
      pdf_sha256 <- file_sha256(pdf_path)
      png_file <- basename(png_path)
      png_sha256 <- file_sha256(png_path)
    }
    manifest[[i]] <- data.frame(
      output_id = registry_row$output_id,
      file_name = registry_row$file_name,
      format = registry_row$format,
      title_en = registry_row$title_en,
      title_cn = registry_row$title_cn,
      producer_stage = registry_row$producer_stage,
      registry_source_canonical_file = registry_row$source_canonical_file,
      source_canonical_file = recipe_row$source_file,
      source_kind = recipe_row$source_kind,
      source_classification = recipe_row$source_classification,
      source_canonical_sha256 = source_identity,
      source_integrity_receipt_sha256 = receipts$receipt_sha256[
        match(
          paste(recipe_row$source_kind, recipe_row$source_file, sep = "\r"),
          paste(receipts$source_kind, receipts$source_file, sep = "\r")
        )
      ],
      recipe_version = recipe_row$recipe_version,
      recipe_selector_id = recipe_row$selector_id,
      recipe_registry_sha256 = recipe_sha,
      recipe_row_sha256 = publication_recipe_row_sha256(recipe_row),
      analysis_id = registry_row$analysis_id,
      estimand_id = registry_row$estimand_id,
      model_signature_sha256 = model_signatures,
      output_sha256 = file_sha256(path),
      pdf_file = pdf_file,
      pdf_sha256 = pdf_sha256,
      png_file = png_file,
      png_sha256 = png_sha256,
      figure_data_file = ifelse(nzchar(figure_data), basename(figure_data), ""),
      figure_data_sha256 = ifelse(nzchar(figure_data), file_sha256(figure_data), ""),
      row_count = nrow(data),
      exists = file.exists(path),
      stringsAsFactors = FALSE
    )
  }
  output <- do.call(rbind, manifest)
  validate_publication_output_closure(
    output_registry, output, release, recipes = recipes, context = context
  )
  # 输出与 output_registry 精确一一闭包的 publication manifest。
  utils::write.csv(
    output,
    file.path(release, "manifest", "publication_output_manifest.csv"),
    row.names = FALSE
  )
  serialized <- utils::read.csv(
    file.path(release, "manifest", "publication_output_manifest.csv"),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  validate_publication_output_closure(
    output_registry, serialized, release, recipes = recipes, context = context
  )
  serialized
}
