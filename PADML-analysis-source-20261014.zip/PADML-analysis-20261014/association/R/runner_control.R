# 连续 runner 控制层：每阶段执行、校验、续行或进入人工审核等待。

.runner_utc_now_rfc3339 <- function() {
  format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
}

.runner_sha256_text <- function(text) {
  # 加载摘要包并计算 runner 规范文本哈希。
  if (!requireNamespace("digest", quietly = TRUE)) stop("digest is required", call. = FALSE)
  digest::digest(enc2utf8(paste(text, collapse = "\n")), algo = "sha256", serialize = FALSE)
}

.runner_file_sha256 <- function(path) {
  # 加载摘要包并计算执行文件哈希。
  if (!requireNamespace("digest", quietly = TRUE)) stop("digest is required", call. = FALSE)
  digest::digest(file = path, algo = "sha256")
}

execution_revision_sha256 <- function(project_root, stage) {
  override <- Sys.getenv("AST_ALT_EXECUTION_REVISION_SHA256", unset = "")
  if (nzchar(override)) {
    if (!grepl("^[0-9a-f]{64}$", override)) stop("AST_ALT_EXECUTION_REVISION_SHA256 must be 64hex", call. = FALSE)
    return(override)
  }
  project_root <- normalizePath(project_root, mustWork = TRUE)
  candidates <- c(
    list.files(file.path(project_root, "R"), pattern = "\\.R$", full.names = TRUE),
    file.path(project_root, "_targets", paste0(stage, "_targets.R")),
    list.files(file.path(project_root, "schemas"), pattern = "\\.json$", full.names = TRUE),
    list.files(file.path(project_root, "config"), full.names = TRUE),
    file.path(project_root, c("Main.md", "AGENTS.md", "renv.lock"))
  )
  files <- sort(unique(candidates[file.exists(candidates) & !file.info(candidates)$isdir]))
  if (!length(files)) stop("No execution revision files were found", call. = FALSE)
  root_prefix <- paste0(project_root, .Platform$file.sep)
  relative <- ifelse(startsWith(files, root_prefix), substring(files, nchar(root_prefix) + 1L), basename(files))
  hashes <- vapply(files, .runner_file_sha256, character(1))
  .runner_sha256_text(paste(relative, hashes, sep = "="))
}

.runner_require_control_functions <- function(project_root) {
  required <- c(
    "read_run_state", "initialize_run_state", "transition_run_state",
    "read_contract_index", "compute_project_epochs", "compute_stage_drift_components",
    "build_stage_context_capsule", "canonical_json", "write_stage_heartbeat",
    "read_stage_observability_snapshot", "stage_observability_plan",
    "canonical_failure_signature", "canonicalize_failure_message",
    "update_repair_state", "write_stage_result", "validate_bundle_complete",
    "read_stage_lock"
  )
  files <- c(
    "control_kernel.R", "authority_engine.R", "stage_contract_manifest.R",
    "epoch_guard.R", "observability.R", "stage_gate.R", "bundle_manager.R"
  )
  for (file in files) {
    if (length(setdiff(required, ls(envir = .GlobalEnv)))) source(file.path(project_root, "R", file))
  }
  missing <- required[!vapply(required, exists, logical(1), mode = "function")]
  if (length(missing)) stop("RUNNER_CONTROL_FUNCTION_MISSING: ", paste(missing, collapse = "|"), call. = FALSE)
  invisible(TRUE)
}

.runner_require_observability <- function(project_root) {
  required <- c(
    "write_stage_heartbeat", "read_stage_heartbeat",
    "read_stage_observability_snapshot", "stage_observability_plan"
  )
  target_environment <- environment(.runner_require_observability)
  available <- function(name) exists(
    name, envir = target_environment, inherits = TRUE, mode = "function"
  )
  if (all(vapply(required, available, logical(1)))) return(invisible(TRUE))
  candidates <- unique(c(
    project_root,
    Sys.getenv("AST_ALT_PROJECT_ROOT", unset = ""),
    normalizePath(".", mustWork = TRUE)
  ))
  candidates <- candidates[nzchar(candidates)]
  paths <- file.path(candidates, "R", "observability.R")
  paths <- paths[file.exists(paths)]
  if (!length(paths)) stop("RUNNER_OBSERVABILITY_MODULE_MISSING", call. = FALSE)
  sys.source(paths[[1L]], envir = target_environment)
  missing <- required[!vapply(required, available, logical(1))]
  if (length(missing)) {
    stop("RUNNER_OBSERVABILITY_FUNCTION_MISSING: ", paste(missing, collapse = "|"), call. = FALSE)
  }
  invisible(TRUE)
}

.runner_source_epoch_inputs <- function(profile, project_root, run_root, handoff_zip = "", dry_run = FALSE) {
  if (isTRUE(dry_run)) {
    marker <- .runner_sha256_text("DRY_RUN_NO_SOURCE_CONTENT")
    return(list(
      authoritative_source_epoch = marker,
      source_patient_order_sha256 = "",
      source_handoff_sha256 = marker
    ))
  }
  if (identical(profile, "build_validation")) {
    fixture <- file.path(project_root, "tests", "fixtures", "synthetic_mi_fixture.rds")
    if (!file.exists(fixture)) stop("SYNTHETIC_SOURCE_FIXTURE_MISSING", call. = FALSE)
    fixture_object <- readRDS(fixture)
    if (!is.list(fixture_object) || !is.data.frame(fixture_object$source_data) ||
        !"Patient_ID" %in% names(fixture_object$source_data)) {
      stop("SYNTHETIC_SOURCE_FIXTURE_INVALID", call. = FALSE)
    }
    return(list(
      authoritative_source_epoch = "",
      source_patient_order_sha256 = .runner_sha256_text(
        paste(seq_len(nrow(fixture_object$source_data)), as.character(fixture_object$source_data$Patient_ID), sep = "\t")
      ),
      source_handoff_sha256 = .runner_file_sha256(fixture)
    ))
  }
  if (identical(profile, "production")) {
    if (!nzchar(handoff_zip)) stop("HANDOFF_PATH_REQUIRED_FOR_PRODUCTION", call. = FALSE)
    if (!exists("resolve_approved_handoff", mode = "function")) {
      source(file.path(project_root, "R", "data_handoff_engine.R"))
    }
    approved <- resolve_approved_handoff(handoff_zip, project_root)$identity
    source_epoch <- approved$source_epoch
    missing_source_epoch <- length(source_epoch) == 1L &&
      is.atomic(source_epoch) && is.na(source_epoch[[1L]])
    if (!missing_source_epoch && (
        !is.character(source_epoch) || length(source_epoch) != 1L ||
        (nzchar(source_epoch) && !grepl("^[0-9a-f]{64}$", source_epoch)))) {
      stop("PRODUCTION_SOURCE_EPOCH_INVALID", call. = FALSE)
    }
    return(list(
      authoritative_source_epoch = if (missing_source_epoch) "" else source_epoch,
      source_patient_order_sha256 = approved$expected_patient_order_sha256,
      source_handoff_sha256 = approved$handoff_sha256
    ))
  }
  if (identical(profile, "release_only")) {
    lock_path <- file.path(run_root, "approved_cache", "public", "A06", "stage_lock.json")
    if (!file.exists(lock_path)) stop("RELEASE_ONLY_APPROVED_A06_LOCK_REQUIRED", call. = FALSE)
    # 加载 JSON 包，仅从已批准 Layer 2 锁读取 source epoch，不接触患者对象。
    if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
    lock <- jsonlite::read_json(lock_path, simplifyVector = TRUE)
    if (!is.character(lock$source_epoch) || !grepl("^[0-9a-f]{64}$", lock$source_epoch)) {
      stop("RELEASE_ONLY_SOURCE_EPOCH_INVALID", call. = FALSE)
    }
    return(list(
      authoritative_source_epoch = lock$source_epoch,
      source_patient_order_sha256 = "",
      source_handoff_sha256 = lock$source_handoff_sha256
    ))
  }
  stop("EXECUTION_PROFILE_INVALID", call. = FALSE)
}

.runner_compute_epoch_bundle <- function(
    profile, project_root, run_root, handoff_zip = "", dry_run = FALSE) {
  .runner_require_control_functions(project_root)
  input <- .runner_source_epoch_inputs(
    profile, project_root, run_root, handoff_zip = handoff_zip, dry_run = dry_run
  )
  index <- read_contract_index(project_root)
  epochs <- compute_project_epochs(
    project_root = project_root,
    contract_index = index,
    source_patient_order_sha256 = input$source_patient_order_sha256,
    handoff_sha256 = input$source_handoff_sha256,
    authoritative_source_epoch = input$authoritative_source_epoch
  )
  list(
    epochs = as.list(setNames(
      unname(unlist(epochs[c(
        "source_epoch", "science_epoch", "execution_epoch",
        "runtime_epoch", "publication_epoch"
      )])),
      c("source", "science", "execution", "runtime", "publication")
    )),
    source_handoff_sha256 = input$source_handoff_sha256,
    contract_index = index
  )
}

initialize_pipeline_control <- function(
    project_root, run_root, profile, run_id, handoff_zip = "", dry_run = FALSE) {
  .runner_require_control_functions(project_root)
  git <- git_worktree_identity(project_root)
  if (identical(profile, "production") && length(git$changed_paths)) {
    stop("PRODUCTION_GIT_TREE_NOT_CLEAN", call. = FALSE)
  }
  bundle <- .runner_compute_epoch_bundle(
    profile, project_root, run_root, handoff_zip = handoff_zip, dry_run = dry_run
  )
  path <- file.path(run_root, "control", "RUN_STATE.json")
  if (!file.exists(path)) {
    state <- initialize_run_state(
      run_root = run_root,
      run_id = run_id,
      revision = "v4.3-r00",
      git_commit = git$git_commit,
      git_tree = git$git_tree,
      execution_profile = profile,
      epochs = bundle$epochs,
      primary_next_action = if (isTRUE(dry_run)) "WRITE_DRY_RUN_PLAN" else "RUN_PRE_STAGE_P00"
    )
  } else {
    state <- read_run_state(run_root)
    checks <- c(
      run_id = identical(state$run_id, run_id),
      revision = identical(state$revision, "v4.3-r00"),
      profile = identical(state$execution_profile, profile),
      git_commit = identical(state$git_commit, git$git_commit),
      git_tree = identical(state$git_tree, git$git_tree),
      source = identical(state$source_epoch, bundle$epochs$source),
      science = identical(state$science_epoch, bundle$epochs$science),
      execution = identical(state$execution_epoch, bundle$epochs$execution),
      runtime = identical(state$runtime_epoch, bundle$epochs$runtime),
      publication = identical(state$publication_epoch, bundle$epochs$publication)
    )
    if (!all(checks)) {
      stop("RUN_STATE_RESUME_IDENTITY_MISMATCH: ", paste(names(checks)[!checks], collapse = "|"), call. = FALSE)
    }
  }
  Sys.setenv(AST_ALT_FROZEN_SOURCE_HANDOFF_SHA256 = bundle$source_handoff_sha256)
  list(state = state, epochs = bundle$epochs, source_handoff_sha256 = bundle$source_handoff_sha256)
}

.runner_write_content_addressed_json <- function(run_root, directory, object) {
  text <- canonical_json(object)
  sha <- .control_sha256_text(text)
  relative <- file.path("control", directory, paste0(sha, ".json"))
  path <- file.path(run_root, relative)
  if (file.exists(path)) {
    observed <- paste(readLines(path, warn = FALSE), collapse = "\n")
    if (!identical(observed, text)) stop("CONTROL_CONTENT_ADDRESS_COLLISION", call. = FALSE)
  } else {
    .control_write_atomic(path, text, mode = "0600")
  }
  list(path = path, relative_path = relative, sha256 = sha)
}

.runner_prepare_release_only_control <- function(stage, project_root, run_root, profile, run_id) {
  if (!identical(stage, "A07") || !identical(profile, "release_only")) {
    stop("RELEASE_ONLY_STAGE_SCOPE_INVALID", call. = FALSE)
  }
  .runner_require_control_functions(project_root)
  if (file.exists(file.path(run_root, "control", "RUN_STATE.json"))) {
    stop("RELEASE_ONLY_LEGACY_STATE_FORBIDDEN", call. = FALSE)
  }
  bundle <- .runner_compute_epoch_bundle(profile, project_root, run_root)
  if (!grepl("^[0-9a-f]{64}$", bundle$source_handoff_sha256)) {
    stop("RELEASE_ONLY_SOURCE_HANDOFF_IDENTITY_INVALID", call. = FALSE)
  }
  Sys.setenv(AST_ALT_FROZEN_SOURCE_HANDOFF_SHA256 = bundle$source_handoff_sha256)
  components <- compute_stage_drift_components(
    stage, project_root, run_root, profile, bundle$epochs,
    handoff_sha256 = bundle$source_handoff_sha256
  )
  outer_request <- trimws(Sys.getenv("AST_ALT_MAINCTL_REQUEST_SHA256", unset = ""))
  if (!grepl("^[0-9a-f]{64}$", outer_request)) {
    stop("RELEASE_ONLY_MAINCTL_REQUEST_IDENTITY_REQUIRED", call. = FALSE)
  }
  sentinel <- .runner_write_content_addressed_json(
    run_root, "sentinels", components$sentinel
  )
  task <- utils::read.csv(
    file.path(project_root, "config", "task_registry.csv"),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  task_row <- task[task$stage == stage, , drop = FALSE]
  if (nrow(task_row) != 1L || !identical(task_row$profile[[1L]], "release_only")) {
    stop("RELEASE_ONLY_TASK_REGISTRY_INVALID", call. = FALSE)
  }
  request <- stage_request_semantic_identity(stage, profile, components, bundle$epochs)
  lineage <- list(
    protocol_revision = "v4.3-r00",
    execution_profile = profile,
    consumed_epoch_set = request$consumed_epoch_set,
    stage_request_semantic_sha256 = outer_request,
    source_epoch = bundle$epochs$source,
    science_epoch = bundle$epochs$science,
    execution_epoch = bundle$epochs$execution,
    runtime_epoch = bundle$epochs$runtime,
    publication_epoch = bundle$epochs$publication,
    stage_contract_sha256 = components$contract$sha256,
    stage_contract_file_n = as.integer(components$contract$file_n),
    input_identity_sha256 = components$input_identity_sha256,
    upstream_artifact_sha256 = components$upstream_artifact_sha256,
    exact_consumer_set_sha256 = components$reachable$exact_consumer_set_digest,
    reachable_authority_slice_sha256 = components$reachable$reachable_authority_slice_digest,
    pre_stage_sentinel_sha256 = sentinel$sha256
  )
  capsule_object <- build_stage_context_capsule(
    stage = stage,
    task_id = task_row$task_id[[1L]],
    contract_index = bundle$contract_index,
    project_root = project_root,
    allowed_read_paths = c(
      "AGENTS.md", components$contract$relative_paths,
      file.path("approved_cache", "public", sprintf("A%02d", 1:6))
    ),
    allowed_write_paths = c(
      file.path("stage_work", stage), file.path("cache", "targets", stage),
      file.path("candidate_cache", "public", stage), "canonical_results", "release",
      "control/capsules", "control/sentinels", "runtime"
    ),
    input_identity = components$input_identity_sha256,
    input_schema = list(upstream = "APPROVED_LAYER2_PUBLIC_A01_A06"),
    output_schema = list(bundle = "A07_PUBLIC_BUNDLE_V2", publication = "A07_RELEASE_CANDIDATE"),
    expected_cardinality = list(required = TRUE),
    acceptance_commands = c("R_PARSE", "TARGETS_STAGE_A07", "BUNDLE_VERIFY", "PUBLICATION_QC"),
    primary_next_action = "EXECUTE_STAGE_A07",
    lineage = lineage,
    pre_stage_sentinel = components$sentinel
  )
  capsule <- .runner_write_content_addressed_json(run_root, "capsules", capsule_object)
  list(
    local_only = TRUE,
    capsule_path = capsule$path,
    capsule_relative_path = capsule$relative_path,
    capsule_sha256 = capsule$sha256,
    contract_sha256 = components$contract$sha256,
    stage_request_semantic_sha256 = outer_request,
    consumed_epoch_set = request$consumed_epoch_set
  )
}

prepare_stage_control <- function(stage, project_root, run_root, profile, run_id) {
  if (identical(profile, "release_only")) {
    return(.runner_prepare_release_only_control(stage, project_root, run_root, profile, run_id))
  }
  state_path <- file.path(run_root, "control", "RUN_STATE.json")
  if (!file.exists(state_path)) return(NULL)
  .runner_require_control_functions(project_root)
  state <- read_run_state(run_root)
  frozen_source_handoff <- Sys.getenv("AST_ALT_FROZEN_SOURCE_HANDOFF_SHA256", unset = "")
  source_now <- .runner_source_epoch_inputs(
    profile, project_root, run_root,
    handoff_zip = Sys.getenv("AST_ALT_HANDOFF_ZIP", unset = ""), dry_run = FALSE
  )
  source_epoch_now <- if (nzchar(source_now$authoritative_source_epoch)) {
    source_now$authoritative_source_epoch
  } else {
    compute_source_epoch(
      project_root, source_now$source_patient_order_sha256,
      source_now$source_handoff_sha256
    )
  }
  if (!identical(state$source_epoch, source_epoch_now) ||
      !identical(frozen_source_handoff, source_now$source_handoff_sha256)) {
    stop("PRE_STAGE_DRIFT_DETECTED: source", call. = FALSE)
  }
  index <- read_contract_index(project_root)
  validate_contract_index(index, project_root)
  frozen_epochs <- list(
    source = state$source_epoch,
    science = state$science_epoch,
    execution = state$execution_epoch,
    runtime = state$runtime_epoch,
    publication = state$publication_epoch
  )
  components <- compute_stage_drift_components(
    stage, project_root, run_root, profile, frozen_epochs,
    handoff_sha256 = frozen_source_handoff
  )
  if (!identical(state$git_commit, components$git$git_commit) ||
      !identical(state$git_tree, components$git$git_tree)) {
    stop("PRE_STAGE_GIT_IDENTITY_MISMATCH", call. = FALSE)
  }
  sentinel <- .runner_write_content_addressed_json(
    run_root, "sentinels", components$sentinel
  )
  task <- utils::read.csv(
    file.path(project_root, "config", "task_registry.csv"),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  task_row <- task[task$stage == stage, , drop = FALSE]
  if (nrow(task_row) != 1L) stop("STAGE_TASK_REGISTRY_IDENTITY_INVALID", call. = FALSE)
  request <- stage_request_semantic_identity(stage, profile, components, frozen_epochs)
  lineage <- list(
    protocol_revision = "v4.3-r00",
    execution_profile = profile,
    consumed_epoch_set = request$consumed_epoch_set,
    stage_request_semantic_sha256 = request$sha256,
    source_epoch = frozen_epochs$source,
    science_epoch = frozen_epochs$science,
    execution_epoch = frozen_epochs$execution,
    runtime_epoch = frozen_epochs$runtime,
    publication_epoch = frozen_epochs$publication,
    stage_contract_sha256 = components$contract$sha256,
    stage_contract_file_n = as.integer(components$contract$file_n),
    input_identity_sha256 = components$input_identity_sha256,
    upstream_artifact_sha256 = components$upstream_artifact_sha256,
    exact_consumer_set_sha256 = components$reachable$exact_consumer_set_digest,
    reachable_authority_slice_sha256 = components$reachable$reachable_authority_slice_digest,
    pre_stage_sentinel_sha256 = sentinel$sha256
  )
  capsule_object <- build_stage_context_capsule(
    stage = stage,
    task_id = task_row$task_id[[1L]],
    contract_index = index,
    project_root = project_root,
    allowed_read_paths = c(
      "AGENTS.md", components$contract$relative_paths,
      if (identical(stage, "P00")) character() else file.path("approved_cache", "public", task_row$dependency[[1L]])
    ),
    allowed_write_paths = c(
      file.path("stage_work", stage), file.path("cache", "targets", stage),
      file.path("approved_cache", "public", stage), file.path("approved_cache", "restricted", stage),
      file.path("candidate_cache", "public", stage), file.path("candidate_cache", "restricted", stage),
      file.path("human_review", stage), "control/events", "control/capsules", "control/sentinels"
    ),
    input_identity = components$input_identity_sha256,
    input_schema = list(upstream = "SEALED_STAGE_BUNDLE_OR_ROOT_INPUT"),
    output_schema = list(bundle = paste0(stage, "_BUNDLE_V43")),
    expected_cardinality = list(required = isTRUE(task_row$required[[1L]])),
    acceptance_commands = c("R_PARSE", paste0("TARGETS_STAGE_", stage), "BUNDLE_VERIFY"),
    primary_next_action = paste0("EXECUTE_STAGE_", stage),
    lineage = lineage,
    pre_stage_sentinel = components$sentinel
  )
  capsule <- .runner_write_content_addressed_json(run_root, "capsules", capsule_object)
  transition <- transition_run_state(
    run_root = run_root,
    expected_state_sha256 = state$state_sha256,
    updates = list(
      active_stage = stage,
      active_gate = "PRE_STAGE_DRIFT_SENTINEL_PASS",
      active_task = task_row$task_id[[1L]],
      primary_next_action = paste0("EXECUTE_STAGE_", stage),
      active_transaction_pointer = capsule$relative_path,
      current_contract_identity = components$contract$sha256,
      current_input_identity = components$input_identity_sha256,
      current_output_identity = "",
      active_blocker_id = ""
    ),
    event_type = "PRE_STAGE_ADMISSION",
    reason_code = "PRE_STAGE_DRIFT_SENTINEL_PASS",
    relative_path = capsule$relative_path,
    artifact_sha256 = capsule$sha256
  )
  list(
    state_sha256 = transition$state$state_sha256,
    capsule_path = capsule$path,
    capsule_relative_path = capsule$relative_path,
    capsule_sha256 = capsule$sha256,
    contract_sha256 = components$contract$sha256,
    stage_request_semantic_sha256 = request$sha256,
    consumed_epoch_set = request$consumed_epoch_set
  )
}

mark_stage_execution_started <- function(stage, run_root, control) {
  if (is.null(control)) return(invisible(NULL))
  if (isTRUE(control$local_only)) return(invisible(NULL))
  state <- read_run_state(run_root)
  if (!identical(state$active_stage, stage) ||
      !identical(state$active_gate, "PRE_STAGE_DRIFT_SENTINEL_PASS") ||
      !identical(state$active_transaction_pointer, control$capsule_relative_path)) {
    stop("CONTROL_EXECUTION_ADMISSION_INVALID", call. = FALSE)
  }
  transition_run_state(
    run_root = run_root,
    expected_state_sha256 = state$state_sha256,
    updates = list(
      active_gate = "EXECUTION_ACTIVE",
      primary_next_action = paste0("EXECUTE_TARGETS_", stage)
    ),
    event_type = "STAGE_EXECUTION_STARTED",
    reason_code = "EXECUTION_ADMITTED",
    relative_path = control$capsule_relative_path,
    artifact_sha256 = control$capsule_sha256
  )
}

.runner_relative_under_root <- function(path, root, allow_empty = FALSE) {
  if (isTRUE(allow_empty) && (!is.character(path) || length(path) != 1L || !nzchar(path))) return("")
  root <- normalizePath(root, mustWork = TRUE)
  normalized <- normalizePath(path, mustWork = TRUE)
  prefix <- paste0(root, .Platform$file.sep)
  if (!startsWith(normalized, prefix)) stop("STAGE_ARTIFACT_PATH_OUTSIDE_RUN", call. = FALSE)
  gsub("\\\\", "/", substring(normalized, nchar(prefix) + 1L))
}

.runner_stage_order <- function() {
  c("P00", "A01", "A02", "A03", "A04", "A05", "A06", "A07")
}

.runner_validate_sealed_stage_replay <- function(stage, result, artifact, state) {
  result_fields <- c(
    "stage", "stage_status", "public_bundle", "restricted_bundle", "review_package",
    "candidate", "failure_envelope", "failure_signature_sha256", "created_at"
  )
  artifact_fields <- c(
    "sha256", "relative_path", "envelope", "public_bundle", "restricted_bundle",
    "review_package"
  )
  if (!is.list(result) || !identical(sort(names(result)), sort(result_fields)) ||
      !is.list(artifact) || any(!artifact_fields %in% names(artifact)) ||
      !is.list(artifact$envelope) || !is.list(state)) {
    stop("CONTROL_SEALED_REPLAY_SCHEMA_INVALID", call. = FALSE)
  }
  pass <- result$stage_status %in% c(
    "PASS_AUTO_CONTINUE", "PASS_WITH_NONBLOCKING_WARNINGS", "PASS_HUMAN_APPROVED"
  )
  result_matches <- identical(result$stage, stage) && pass &&
    identical(result$candidate, FALSE) && identical(result$failure_envelope, "") &&
    identical(result$failure_signature_sha256, "") &&
    identical(result$public_bundle, artifact$public_bundle) &&
    identical(result$restricted_bundle, artifact$restricted_bundle) &&
    identical(result$review_package, artifact$review_package) &&
    identical(artifact$envelope$stage, stage) &&
    identical(artifact$envelope$status, "SEALED") &&
    identical(artifact$envelope$verifier_status, "PASS")
  if (!result_matches) stop("CONTROL_SEALED_REPLAY_RESULT_MISMATCH", call. = FALSE)

  stages <- .runner_stage_order()
  replay_index <- match(stage, stages)
  active_index <- match(state$active_stage, stages)
  if (is.na(replay_index) || is.na(active_index) || active_index < replay_index) {
    stop("CONTROL_SEALED_REPLAY_STATE_INCONSISTENT", call. = FALSE)
  }
  if (identical(active_index, replay_index)) {
    state_matches <- identical(state$active_gate, "STAGE_VERIFIED_AND_SEALED") &&
      identical(state$active_transaction_pointer, artifact$relative_path) &&
      identical(state$current_output_identity, artifact$sha256)
    if (!state_matches) stop("CONTROL_SEALED_REPLAY_STATE_INCONSISTENT", call. = FALSE)
  }
  TRUE
}

.runner_read_sealed_stage_replay <- function(stage, project_root, run_root) {
  directory <- file.path(run_root, "control", "artifacts", stage)
  if (!dir.exists(directory)) return(NULL)
  members <- list.files(directory, all.files = TRUE, no.. = TRUE, full.names = TRUE)
  valid_name <- grepl("^[0-9a-f]{64}[.]json$", basename(members))
  if (length(members) != 1L || !all(valid_name) ||
      isTRUE(file.info(members[[1L]])$isdir) || nzchar(Sys.readlink(members[[1L]]))) {
    stop("CONTROL_SEALED_REPLAY_ARTIFACT_CLOSURE_INVALID", call. = FALSE)
  }
  if (!exists("read_stage_artifact_envelope", mode = "function")) {
    source(file.path(project_root, "R", "epoch_guard.R"))
  }
  if (!exists("read_run_state", mode = "function")) {
    source(file.path(project_root, "R", "control_kernel.R"))
  }
  artifact <- read_stage_artifact_envelope(stage, run_root, verify_bundles = TRUE)
  artifact$relative_path <- .runner_relative_under_root(artifact$path, run_root)
  result_path <- file.path(run_root, "runtime", paste0("stage_result_", stage, ".json"))
  if (!file.exists(result_path) || isTRUE(file.info(result_path)$isdir) ||
      nzchar(Sys.readlink(result_path))) {
    stop("CONTROL_SEALED_REPLAY_STAGE_RESULT_MISSING", call. = FALSE)
  }
  # 加载 JSON 包以读取已 SEALED 阶段的 terminal result；本路径只读且不重启 targets。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  result <- jsonlite::read_json(result_path, simplifyVector = TRUE)
  state <- read_run_state(run_root)
  .runner_validate_sealed_stage_replay(stage, result, artifact, state)
  list(result = result, artifact = artifact, replayed = TRUE)
}

seal_stage_artifact_envelope <- function(result, run_root, control) {
  if (!result$stage_status %in% c(
    "PASS_AUTO_CONTINUE", "PASS_WITH_NONBLOCKING_WARNINGS", "PASS_HUMAN_APPROVED"
  )) stop("Only a passing stage can be sealed", call. = FALSE)
  if (!exists("validate_bundle_complete", mode = "function")) {
    source(file.path(Sys.getenv("AST_ALT_PROJECT_ROOT", unset = "."), "R", "bundle_manager.R"))
  }
  validate_bundle_complete(
    result$public_bundle, expected_stage = result$stage,
    expected_classification = "PUBLIC_AGGREGATE"
  )
  public_lock_path <- file.path(result$public_bundle, "stage_lock.json")
  public_lock <- read_stage_lock(result$public_bundle)
  restricted_relative <- ""
  restricted_lock_sha <- ""
  restricted_bundle_sha <- ""
  if (nzchar(result$restricted_bundle)) {
    validate_bundle_complete(result$restricted_bundle, expected_stage = result$stage)
    restricted_lock <- read_stage_lock(result$restricted_bundle)
    lineage_fields <- c(
      "stage_request_semantic_sha256", "stage_capsule_sha256", "consumed_epoch_set",
      "source_epoch", "science_epoch", "execution_epoch", "runtime_epoch",
      "publication_epoch", "source_handoff_sha256", "stage_contract_sha256",
      "input_identity_sha256", "upstream_artifact_sha256",
      "exact_consumer_set_sha256", "reachable_authority_slice_sha256",
      "pre_stage_sentinel_sha256", "pre_seal_sentinel_sha256"
    )
    if (any(!vapply(lineage_fields, function(field) {
      identical(public_lock[[field]], restricted_lock[[field]])
    }, logical(1)))) stop("PUBLIC_RESTRICTED_LINEAGE_MISMATCH", call. = FALSE)
    restricted_relative <- .runner_relative_under_root(result$restricted_bundle, run_root)
    restricted_lock_sha <- .runner_file_sha256(file.path(result$restricted_bundle, "stage_lock.json"))
    restricted_bundle_sha <- restricted_lock$bundle_sha256
  }
  if (!identical(public_lock$stage_request_semantic_sha256, control$stage_request_semantic_sha256) ||
      !identical(public_lock$stage_capsule_sha256, control$capsule_sha256) ||
      !identical(public_lock$stage_contract_sha256, control$contract_sha256) ||
      !identical(public_lock$stage_status, result$stage_status) ||
      !grepl("^[0-9a-f]{64}$", public_lock$pre_seal_sentinel_sha256)) {
    stop("STAGE_ARTIFACT_CONTROL_LINEAGE_MISMATCH", call. = FALSE)
  }
  if (!file.exists(result$review_package) || isTRUE(file.info(result$review_package)$isdir)) {
    stop("STAGE_ARTIFACT_REVIEW_PACKAGE_MISSING", call. = FALSE)
  }
  if (!exists("scan_review_package_privacy", mode = "function")) {
    source(file.path(Sys.getenv("AST_ALT_PROJECT_ROOT", unset = "."), "R", "review_pack.R"))
  }
  review_privacy <- scan_review_package_privacy(result$review_package)
  if (nrow(review_privacy) && any(review_privacy$status != "PASS")) {
    stop("STAGE_ARTIFACT_REVIEW_PACKAGE_PRIVACY_FAILED", call. = FALSE)
  }
  semantic_sha <- .runner_sha256_text(c(
    paste0("stage=", result$stage),
    paste0("request=", control$stage_request_semantic_sha256),
    paste0("public=", public_lock$bundle_sha256),
    paste0("restricted=", restricted_bundle_sha)
  ))
  envelope <- list(
    schema_version = "1.0.0",
    stage = result$stage,
    status = "SEALED",
    verifier_status = "PASS",
    stage_request_semantic_sha256 = control$stage_request_semantic_sha256,
    stage_capsule_sha256 = control$capsule_sha256,
    public_bundle_relative_path = .runner_relative_under_root(result$public_bundle, run_root),
    public_lock_sha256 = .runner_file_sha256(public_lock_path),
    public_bundle_sha256 = public_lock$bundle_sha256,
    restricted_bundle_relative_path = restricted_relative,
    restricted_lock_sha256 = restricted_lock_sha,
    restricted_bundle_sha256 = restricted_bundle_sha,
    review_package_relative_path = .runner_relative_under_root(result$review_package, run_root),
    review_package_sha256 = .runner_file_sha256(result$review_package),
    artifact_semantic_sha256 = semantic_sha,
    created_at = public_lock$created_at
  )
  sealed <- .runner_write_content_addressed_json(
    run_root, file.path("artifacts", result$stage), envelope
  )
  directory <- dirname(sealed$path)
  existing <- list.files(directory, pattern = "^[0-9a-f]{64}[.]json$", full.names = TRUE)
  if (length(existing) != 1L || !identical(normalizePath(existing[[1L]]), normalizePath(sealed$path))) {
    stop("STAGE_ARTIFACT_RESULT_CONFLICT", call. = FALSE)
  }
  c(sealed, list(semantic_sha256 = semantic_sha))
}

finalize_stage_control <- function(result, run_root, control) {
  if (is.null(control) || !file.exists(file.path(run_root, "control", "RUN_STATE.json"))) {
    return(invisible(NULL))
  }
  state <- read_run_state(run_root)
  if (!identical(state$active_stage, result$stage)) {
    stop("CONTROL_STAGE_TERMINAL_STAGE_MISMATCH", call. = FALSE)
  }
  pass <- result$stage_status %in% c(
    "PASS_AUTO_CONTINUE", "PASS_WITH_NONBLOCKING_WARNINGS", "PASS_HUMAN_APPROVED"
  )
  if (pass && !identical(state$active_gate, "PRE_SEAL_DRIFT_SENTINEL_PASS")) {
    stop("CONTROL_PRE_SEAL_EVENT_REQUIRED", call. = FALSE)
  }
  failure_signature <- if (is.character(result$failure_signature_sha256) &&
      length(result$failure_signature_sha256) == 1L &&
      grepl("^[0-9a-f]{64}$", result$failure_signature_sha256)) {
    result$failure_signature_sha256
  } else ""
  artifact <- if (pass) seal_stage_artifact_envelope(result, run_root, control) else NULL
  output_identity <- if (!is.null(artifact)) {
    artifact$sha256
  } else if (nzchar(failure_signature)) {
    failure_signature
  } else {
    ""
  }
  blocker <- if (pass) "" else .runner_sha256_text(c(result$stage, result$stage_status, output_identity))
  transition_run_state(
    run_root = run_root,
    expected_state_sha256 = state$state_sha256,
    updates = list(
      active_gate = if (pass) "STAGE_VERIFIED_AND_SEALED" else result$stage_status,
      primary_next_action = if (pass) paste0("RUN_NEXT_STAGE_AFTER_", result$stage) else "WAIT_FOR_REVIEW_OR_REPAIR",
      active_transaction_pointer = if (pass) artifact$relative_path else control$capsule_relative_path,
      current_output_identity = output_identity,
      active_blocker_id = blocker,
      current_repair_signature = failure_signature,
      current_repair_attempt = if (!is.null(result$repair_round)) as.integer(result$repair_round) else 0L
    ),
    event_type = if (pass) "STAGE_SEALED" else "STAGE_TERMINAL_BLOCKER",
    reason_code = result$stage_status,
    relative_path = if (pass) artifact$relative_path else "",
    artifact_sha256 = output_identity
  )
}

capture_stage_failure <- function(
    stage, condition, project_root, run_root, profile, run_id,
    target = "tar_make", failure_code = "UNHANDLED_STAGE_ERROR",
    execution_revision = execution_revision_sha256(project_root, stage),
    update_control_state = FALSE) {
  signature <- canonical_failure_signature(stage, condition, target, failure_code)
  integrity <- failure_code %in% c(
    "PRE_STAGE_DRIFT_DETECTED", "MID_STAGE_DRIFT_DETECTED",
    "STAGE_ARTIFACT_RESULT_CONFLICT", "FAILED_INTEGRITY"
  )
  repair <- if (identical(profile, "release_only")) {
    list(
      allowed = FALSE, event_type = "LOCAL_RELEASE_DIAGNOSTIC_ONLY",
      repair_round = 0L, ledger_event_index = 0L, ledger_event_sha256 = signature
    )
  } else if (integrity) {
    list(
      allowed = FALSE, event_type = "INTEGRITY_BLOCKER_NO_TECHNICAL_REPAIR",
      repair_round = 0L, ledger_event_index = 0L, ledger_event_sha256 = signature
    )
  } else {
    update_repair_state(
      stage = stage,
      failure_signature = signature,
      root = run_root,
      revision = execution_revision,
      stop_on_exceeded = FALSE
    )
  }
  status <- if (integrity) "STOP_PROJECT" else if (isTRUE(repair$allowed)) "FAIL_WAITING_FOR_HUMAN_REVIEW" else "STOP_PROJECT"
  envelope <- list(
    envelope_schema_version = "STAGE_FAILURE_ENVELOPE_V43_V1",
    stage = stage,
    stage_status = status,
    failure_code = failure_code,
    condition_class = class(condition)[[1L]],
    canonical_message = canonicalize_failure_message(conditionMessage(condition)),
    failure_signature_sha256 = signature,
    execution_revision_sha256 = execution_revision,
    target = target,
    profile = profile,
    run_id = run_id,
    repair_event_type = repair$event_type,
    repair_round = repair$repair_round,
    repair_allowed = isTRUE(repair$allowed),
    ledger_event_index = repair$ledger_event_index,
    ledger_event_sha256 = repair$ledger_event_sha256,
    occurred_at = .runner_utc_now_rfc3339()
  )
  envelope_dir <- file.path(run_root, "runtime", "failure_envelopes")
  dir.create(envelope_dir, recursive = TRUE, showWarnings = FALSE)
  envelope_path <- file.path(
    envelope_dir,
    sprintf("FAILURE_%s_%06d.json", stage, as.integer(repair$ledger_event_index))
  )
  # 加载 JSON 包并写入统一异常信封。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  jsonlite::write_json(envelope, envelope_path, auto_unbox = TRUE, pretty = TRUE)
  Sys.chmod(envelope_path, mode = "0600", use_umask = FALSE)
  write_stage_result(
    stage = stage,
    status = status,
    candidate = FALSE,
    root = run_root,
    failure_envelope = envelope_path,
    failure_signature_sha256 = signature
  )
  plan <- stage_observability_plan(stage, project_root)
  existing_heartbeat <- tryCatch(
    read_stage_heartbeat(run_root, required = FALSE),
    error = function(condition) NULL
  )
  write_stage_heartbeat(
    run_id = run_id,
    stage = stage,
    target = if (stage %in% c("A05", "A06")) plan$target else target,
    completed = NULL,
    total = plan$total,
    stage_request_sha256 = if (is.null(existing_heartbeat)) "" else existing_heartbeat$stage_request_sha256,
    status = status,
    warning_status = "NONE",
    failure_code = failure_code,
    next_checkpoint = if (integrity) "RECONCILE_IDENTITY_DRIFT" else "WAIT_FOR_REVIEW_OR_REPAIR",
    root = run_root,
    project_root = project_root
  )
  if (isTRUE(update_control_state) && file.exists(file.path(run_root, "control", "RUN_STATE.json"))) {
    state <- read_run_state(run_root)
    transition_run_state(
      run_root = run_root,
      expected_state_sha256 = state$state_sha256,
      updates = list(
        active_stage = stage,
        active_gate = status,
        active_task = paste0(stage, "_PRE_STAGE_CONTROL"),
        primary_next_action = if (integrity) "RECONCILE_IDENTITY_DRIFT" else "WAIT_FOR_REVIEW_OR_REPAIR",
        current_output_identity = signature,
        active_blocker_id = signature,
        current_repair_signature = if (integrity) "" else signature,
        current_repair_attempt = if (integrity) 0L else as.integer(repair$repair_round)
      ),
      event_type = if (integrity) "INTEGRITY_BLOCKER" else "STAGE_TERMINAL_BLOCKER",
      reason_code = failure_code,
      artifact_sha256 = signature
    )
  }
  list(
    stage = stage,
    stage_status = status,
    public_bundle = "",
    restricted_bundle = "",
    review_package = "",
    candidate = FALSE,
    failure_envelope = envelope_path,
    failure_signature_sha256 = signature,
    execution_revision_sha256 = execution_revision,
    repair_round = repair$repair_round
  )
}

.runner_failed_target <- function(store, fallback = "tar_make") {
  metadata <- tryCatch(
    targets::tar_meta(store = store, fields = c(name, error)),
    error = function(condition) NULL
  )
  if (is.null(metadata) || !nrow(metadata)) return(fallback)
  failed <- metadata[!is.na(metadata$error) & nzchar(metadata$error), , drop = FALSE]
  if (!nrow(failed)) return(fallback)
  as.character(tail(failed$name, 1L))
}

.runner_stage_backend <- function(stage, profile) {
  compute_node <- identical(
    Sys.getenv("AST_ALT_STATELESS_COMPUTE_NODE", unset = ""), "TRUE"
  )
  if (identical(stage, "A07")) {
    if (compute_node) stop("A07_LOCAL_ONLY", call. = FALSE)
    if (!identical(profile, "release_only")) stop("A07_RELEASE_PROFILE_REQUIRED", call. = FALSE)
    return("LOCAL")
  }
  if (compute_node) {
    workers <- suppressWarnings(as.integer(Sys.getenv("AST_ALT_WORKERS", unset = "")))
    if (is.na(workers) || workers != 24L) {
      stop("STATELESS_TARGET_WORKER_CONTRACT_INVALID", call. = FALSE)
    }
    return("REMOTE_24")
  }
  if (identical(profile, "build_validation")) return("LOCAL")
  stop("REMOTE_STAGE_COMPUTE_NODE_REQUIRED", call. = FALSE)
}

run_one_stage <- function(stage, project_root, run_root, profile, run_id) {
  # 加载 targets 包以执行独立阶段 store。
  if (!requireNamespace("targets", quietly = TRUE)) stop("targets is required", call. = FALSE)
  prior_frozen_handoff <- Sys.getenv("AST_ALT_FROZEN_SOURCE_HANDOFF_SHA256", unset = NA_character_)
  on.exit({
    if (is.na(prior_frozen_handoff)) {
      Sys.unsetenv("AST_ALT_FROZEN_SOURCE_HANDOFF_SHA256")
    } else {
      Sys.setenv(AST_ALT_FROZEN_SOURCE_HANDOFF_SHA256 = prior_frozen_handoff)
    }
  }, add = TRUE)
  .runner_require_observability(project_root)
  script <- file.path(project_root, "_targets", paste0(stage, "_targets.R"))
  if (!file.exists(script)) stop("Stage targets script is missing: ", stage, call. = FALSE)
  control_outcome <- tryCatch(
    list(ok = TRUE, control = prepare_stage_control(stage, project_root, run_root, profile, run_id)),
    error = function(condition) list(ok = FALSE, condition = condition)
  )
  if (!isTRUE(control_outcome$ok)) {
    message_text <- conditionMessage(control_outcome$condition)
    integrity <- grepl(
      "PRE_STAGE_DRIFT_DETECTED|PRE_STAGE_GIT_IDENTITY_MISMATCH|UPSTREAM_ARTIFACT|RUN_STATE_RESUME_IDENTITY_MISMATCH",
      message_text, perl = TRUE
    )
    return(capture_stage_failure(
      stage = stage,
      condition = control_outcome$condition,
      project_root = project_root,
      run_root = run_root,
      profile = profile,
      run_id = run_id,
      target = "PRE_STAGE_CONTROL",
      failure_code = if (integrity) "PRE_STAGE_DRIFT_DETECTED" else "PRE_STAGE_CONTROL_FAILED",
      execution_revision = execution_revision_sha256(project_root, stage),
      update_control_state = !identical(profile, "release_only")
    ))
  }
  control <- control_outcome$control
  store <- file.path(
    run_root, "cache", "targets", stage,
    if (!is.null(control)) control$stage_request_semantic_sha256 else "legacy_unbound"
  )
  revision <- if (!is.null(control)) control$contract_sha256 else execution_revision_sha256(project_root, stage)
  Sys.setenv(
    AST_ALT_PROJECT_ROOT = project_root,
    AST_ALT_RUN_ROOT = run_root,
    AST_ALT_EXECUTION_PROFILE = profile,
    AST_ALT_RUN_ID = run_id,
    AST_ALT_ACTIVE_STAGE = stage,
    AST_ALT_EXECUTION_REVISION_SHA256 = revision
  )
  if (!is.null(control)) {
    Sys.setenv(
      AST_ALT_STAGE_CAPSULE = control$capsule_path,
      AST_ALT_STAGE_CAPSULE_SHA256 = control$capsule_sha256
    )
  }
  on.exit(Sys.unsetenv(c(
    "AST_ALT_STAGE_CAPSULE", "AST_ALT_STAGE_CAPSULE_SHA256",
    "AST_ALT_ACTIVE_STAGE", "AST_ALT_EXECUTION_REVISION_SHA256"
  )), add = TRUE)
  progress_plan <- stage_observability_plan(stage, project_root)
  write_stage_heartbeat(
    run_id = run_id,
    stage = stage,
    target = progress_plan$target,
    completed = 0L,
    total = progress_plan$total,
    stage_request_sha256 = if (!is.null(control)) control$stage_request_semantic_sha256 else "",
    status = "RUNNING",
    warning_status = "NONE",
    failure_code = "",
    next_checkpoint = progress_plan$next_checkpoint,
    root = run_root,
    project_root = project_root
  )
  caller_working_directory <- getwd()
  outcome <- tryCatch(
    {
      # targets evaluates project scripts and their private relative sources from
      # the project root. Restore the supervisor's working directory afterwards.
      setwd(project_root)
      mark_stage_execution_started(stage, run_root, control)
      backend <- .runner_stage_backend(stage, profile)
      if (identical(backend, "REMOTE_24")) {
        # 远端仅使用24个 targets 外层 worker；每个科学分支内部保持顺序执行。
        targets::tar_make_future(
          script = script, store = store, workers = 24L,
          callr_function = NULL
        )
      } else {
        # A07 与非科学 build-validation 可在本地执行；production P00-A06 不存在本地计算 fallback。
        targets::tar_make(script = script, store = store, callr_function = NULL)
      }
      result_path <- file.path(run_root, "runtime", paste0("stage_result_", stage, ".json"))
      if (!file.exists(result_path)) stop("Stage did not publish a stage result: ", stage, call. = FALSE)
      # 加载 JSON 包并读取阶段结果。
      if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
      list(ok = TRUE, result = jsonlite::read_json(result_path, simplifyVector = TRUE))
    },
    error = function(condition) list(ok = FALSE, condition = condition),
    finally = setwd(caller_working_directory)
  )
  if (!isTRUE(outcome$ok)) {
    message_text <- conditionMessage(outcome$condition)
    drift <- grepl("MID_STAGE_DRIFT_DETECTED", message_text, fixed = TRUE)
    control_integrity <- grepl("CONTROL_EXECUTION_ADMISSION_INVALID", message_text, fixed = TRUE)
    failure <- capture_stage_failure(
      stage = stage,
      condition = outcome$condition,
      project_root = project_root,
      run_root = run_root,
      profile = profile,
      run_id = run_id,
      target = .runner_failed_target(store),
      failure_code = if (drift) {
        "MID_STAGE_DRIFT_DETECTED"
      } else if (control_integrity) {
        "FAILED_INTEGRITY"
      } else {
        "UNHANDLED_STAGE_ERROR"
      },
      execution_revision = revision,
      update_control_state = !identical(profile, "release_only")
    )
    if (!is.null(control)) failure$.control <- control
    return(failure)
  }
  result <- outcome$result
  warning_status <- if (identical(result$stage_status, "PASS_WITH_NONBLOCKING_WARNINGS")) {
    "NONBLOCKING_WARNING"
  } else if (grepl("WAITING_FOR_HUMAN_REVIEW", result$stage_status, fixed = TRUE)) {
    "BLOCKING_WARNING"
  } else {
    "NONE"
  }
  write_stage_heartbeat(
    run_id = run_id,
    stage = stage,
    target = if (stage %in% c("A05", "A06")) progress_plan$target else paste0(stage, "_stage_result"),
    completed = progress_plan$total,
    total = progress_plan$total,
    stage_request_sha256 = if (!is.null(control)) control$stage_request_semantic_sha256 else "",
    status = result$stage_status,
    warning_status = warning_status,
    failure_code = "",
    next_checkpoint = if (result$stage_status %in% c(
      "PASS_AUTO_CONTINUE", "PASS_WITH_NONBLOCKING_WARNINGS", "PASS_HUMAN_APPROVED"
    )) "NEXT_STAGE" else "WAIT_FOR_REVIEW_OR_REPAIR",
    root = run_root,
    project_root = project_root
  )
  if (!is.null(control)) result$.control <- control
  result
}
