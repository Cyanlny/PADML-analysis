# Release 管理模块：只处理已批准的 aggregate canonical 汇总结果。

validate_release_rubin_df_receipt_v43 <- function(
    canonical_dir, project_root = ".",
    receipt_file = "rubin_df_qc_receipt.json",
    source_file = "fixed_cox_results.csv") {
  if (!exists("validate_rubin_df_qc_receipt_v43", mode = "function")) {
    # 加载唯一 Rubin df 合同引擎，以源 CSV 反向验证 A03 typed receipt。
    source(file.path(project_root, "R", "canonical_results.R"))
  }
  receipt_path <- file.path(canonical_dir, receipt_file)
  source_path <- file.path(canonical_dir, source_file)
  if (!file.exists(receipt_path) || !file.exists(source_path) ||
      file.info(receipt_path)$isdir || file.info(source_path)$isdir) {
    stop("RELEASE_RUBIN_DF_QC_RECEIPT_OR_SOURCE_MISSING", call. = FALSE)
  }
  # 加载 A03 typed receipt；release-only 不读取模型或患者级对象。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  receipt <- tryCatch(
    jsonlite::read_json(receipt_path, simplifyVector = TRUE),
    error = function(error) NULL
  )
  if (is.null(receipt) ||
      !validate_rubin_df_qc_receipt_v43(receipt, source_path, project_root)) {
    stop("RELEASE_RUBIN_DF_QC_RECEIPT_INVALID", call. = FALSE)
  }
  TRUE
}

validate_release_canonical_applicability_receipt_v43 <- function(
    canonical_dir, project_root = ".",
    receipt_file = "canonical_value_applicability_receipt.json") {
  if (!exists("validate_canonical_value_applicability_receipt_v43", mode = "function")) {
    # 加载 publication 合同引擎，以全 canonical CSV 反向验证 STRUCT_NA_1A 回执。
    source(file.path(project_root, "R", "publication_renderer.R"))
  }
  receipt_path <- file.path(canonical_dir, receipt_file)
  if (!file.exists(receipt_path) || file.info(receipt_path)$isdir) {
    stop("RELEASE_CANONICAL_APPLICABILITY_RECEIPT_MISSING", call. = FALSE)
  }
  # 加载 aggregate applicability receipt；release-only 不读取模型或患者级对象。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  receipt <- tryCatch(
    jsonlite::read_json(receipt_path, simplifyVector = FALSE),
    error = function(error) NULL
  )
  if (is.null(receipt) ||
      !validate_canonical_value_applicability_receipt_v43(
        receipt, canonical_dir, project_root
      )) {
    stop("RELEASE_CANONICAL_APPLICABILITY_RECEIPT_INVALID", call. = FALSE)
  }
  TRUE
}

build_static_code_appendix <- function(project_root = ".", report_root = file.path(project_root, "report")) {
  source_files <- c(
    list.files(file.path(project_root, "R"), pattern = "\\.R$", full.names = TRUE),
    list.files(file.path(project_root, "_targets"), pattern = "\\.R$", full.names = TRUE),
    list.files(file.path(project_root, "scripts"), pattern = "\\.R$", full.names = TRUE)
  )
  source_files <- sort(unique(source_files[file.exists(source_files)]))
  out_dir <- file.path(report_root, "generated", "code_appendix")
  if (dir.exists(out_dir)) unlink(out_dir, recursive = TRUE)
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  project_normalized <- normalizePath(project_root, mustWork = TRUE)
  relative_files <- vapply(source_files, function(path) {
    normalized <- normalizePath(path, mustWork = TRUE)
    prefix <- paste0(project_normalized, .Platform$file.sep)
    if (!startsWith(normalized, prefix)) stop("Code provenance source escaped project root", call. = FALSE)
    substring(normalized, nchar(prefix) + 1L)
  }, character(1))
  manifest <- data.frame(
    source_file = relative_files,
    source_file_sha256 = vapply(source_files, file_sha256, character(1)),
    appendix_file = rep("generated/code_appendix/ALL_CODE_APPENDIX.qmd", length(source_files)),
    disclosure_class = rep("PUBLIC_HASH_ONLY", length(source_files)),
    stringsAsFactors = FALSE
  )
  appendix <- c(
    "# Execution Source Provenance / 执行源码溯源", "",
    "公开报告仅披露相对文件名与 SHA-256；源码正文不嵌入公开 QMD 或 HTML。完整源码审核必须在受限环境中进行。", "",
    "| Relative source | SHA-256 |",
    "|---|---|"
  )
  if (nrow(manifest)) {
    appendix <- c(
      appendix,
      paste0("| `", manifest$source_file, "` | `", manifest$source_file_sha256, "` |")
    )
  }
  # 输出仅含相对文件名和哈希的公开代码溯源附录。
  writeLines(appendix, file.path(out_dir, "ALL_CODE_APPENDIX.qmd"), useBytes = TRUE)
  # 输出代码来源哈希清单，不复制源码正文。
  utils::write.csv(manifest, file.path(out_dir, "code_source_manifest.csv"), row.names = FALSE)
  manifest
}

markdown_table_preview <- function(data, max_rows = 20L, max_columns = 14L) {
  if (!nrow(data) || !ncol(data)) return(c("_No rows available / 当前无可展示行。_", ""))
  data <- data[
    seq_len(min(nrow(data), max_rows)),
    seq_len(min(ncol(data), max_columns)),
    drop = FALSE
  ]
  data[] <- lapply(data, function(value) {
    value <- ifelse(is.na(value), "", as.character(value))
    gsub("|", "\\|", value, fixed = TRUE)
  })
  header <- paste0("| ", paste(names(data), collapse = " | "), " |")
  separator <- paste0("| ", paste(rep("---", ncol(data)), collapse = " | "), " |")
  rows <- apply(data, 1L, function(value) paste0("| ", paste(value, collapse = " | "), " |"))
  c(header, separator, rows, "")
}

publication_relative_link <- function(prefix, directory, file_name) {
  path <- paste(directory, file_name, sep = "/")
  if (!nzchar(prefix)) path else paste(prefix, path, sep = "/")
}

publication_block <- function(registry_row, release_dir, runtime_link_prefix = "") {
  file_name <- registry_row$file_name[[1L]]
  lines <- c(
    paste0("### ", registry_row$title_en[[1L]]), "",
    paste0("**中文标题：** ", registry_row$title_cn[[1L]]), "",
    paste0("**中文内容说明：** ", registry_row$content_cn[[1L]]), "",
    paste0("**核心指标：** ", registry_row$core_indicators[[1L]]), "",
    paste0("**Location：** ", registry_row$manuscript_location[[1L]]), ""
  )
  if (identical(registry_row$format[[1L]], "CSV")) {
    path <- file.path(release_dir, "tables", file_name)
    if (!file.exists(path)) stop("Registered release table is missing: ", file_name, call. = FALSE)
    data <- utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE)
    preview_limit <- if (registry_row$location[[1L]] == "main_table") 100L else 20L
    link <- publication_relative_link(runtime_link_prefix, "tables", file_name)
    lines <- c(
      lines,
      paste0("[Complete CSV / 完整表格](", link, ")"), "",
      markdown_table_preview(data, max_rows = preview_limit),
      if (nrow(data) > preview_limit) {
        paste0("_Preview shows ", preview_limit, " of ", nrow(data), " rows; use the CSV link for the complete table._")
      } else {
        ""
      },
      ""
    )
  } else {
    figure_data <- registry_row$figure_data_csv[[1L]]
    figure_link <- publication_relative_link(runtime_link_prefix, "figures", file_name)
    data_link <- publication_relative_link(runtime_link_prefix, "figure_data", figure_data)
    lines <- c(
      lines,
      paste0("![", registry_row$title_en[[1L]], "](", figure_link, "){fig-alt=\"", registry_row$title_cn[[1L]], "\"}"), "",
      paste0("[Figure data / 图片数据](", data_link, ")"), ""
    )
  }
  lines
}

populate_report_children <- function(
    run_root, project_root, report_root,
    release_dir = file.path(run_root, "release"),
    runtime_link_prefix = "") {
  registry <- utils::read.csv(
    file.path(project_root, "config", "output_registry.csv"),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  child_dir <- file.path(report_root, "children")
  dir.create(child_dir, recursive = TRUE, showWarnings = FALSE)
  section_spec <- list(
    `00_overview.qmd` = list(
      title = "# Overview and Execution Contract / 概览与执行合同",
      filter = registry$producer_stage == "A07"
    ),
    `01_population.qmd` = list(
      title = "# Population, Exposure, Table 1 and KM / 人群、暴露、基线表与KM",
      filter = registry$producer_stage == "A01"
    ),
    `02_imputation_qc.qmd` = list(
      title = "# Imputation QC / 插补质控",
      filter = registry$producer_stage == "A02"
    ),
    `03_fixed_cox_ph.qmd` = list(
      title = "# Fixed Cox and PH / 固定Cox与PH",
      filter = registry$producer_stage == "A03"
    ),
    `04_tve_rcs.qmd` = list(
      title = "# TVE and RCS / 时间变化效应与RCS",
      filter = registry$producer_stage == "A04"
    ),
    `05_subgroup.qmd` = list(
      title = "# Subgroup and Interaction / 亚组与交互",
      filter = registry$producer_stage == "A05"
    ),
    `06_sensitivity.qmd` = list(
      title = "# Sensitivity Analyses / 敏感性分析",
      filter = registry$producer_stage == "A06" & !grepl("Secondary|Secondary_Endpoints", registry$file_name)
    ),
    `07_secondary.qmd` = list(
      title = "# Supplementary Endpoints / 补充结局",
      filter = registry$producer_stage == "A06" & grepl("Secondary|Secondary_Endpoints", registry$file_name)
    ),
    `08_methods_results.qmd` = list(
      title = "# Methods, Interpretation and Output Map / 方法、解释与输出映射",
      filter = rep(FALSE, nrow(registry))
    )
  )
  for (name in names(section_spec)) {
    spec <- section_spec[[name]]
    rows <- registry[spec$filter, , drop = FALSE]
    intro <- c(
      spec$title, "",
      "本章节只展示已通过阶段 gate 的 aggregate canonical outputs；不执行或重拟合任何科学模型。", ""
    )
    blocks <- unlist(
      lapply(seq_len(nrow(rows)), function(i) {
        publication_block(
          rows[i, , drop = FALSE],
          release_dir,
          runtime_link_prefix = runtime_link_prefix
        )
      }),
      use.names = FALSE
    )
    if (identical(name, "08_methods_results.qmd")) {
      blocks <- c(
        "## Frozen interpretation rules / 冻结解释规则", "",
        "- 时间特异性 TVE 结果是主解释对象；PH 违反时 fixed HR 仅为整个观察期的平均参考。",
        "- RCS 描述整个观察期内的平均函数形态，不能解释为任一特定时间点的剂量—反应关系。",
        "- 亚组结论依据 pooled interaction P，而不是某一亚组水平内的 P 值。",
        "- 补充结局和敏感性分析不得升级为主要结论。", "",
        "## Complete output map / 完整输出映射", "",
        markdown_table_preview(
          registry[c(
            "output_id", "file_name", "title_en", "title_cn",
            "producer_stage", "manuscript_location"
          )],
          max_rows = nrow(registry),
          max_columns = 6L
        )
      )
    }
    # 输出禁用执行的报告子章节 QMD。
    writeLines(c(intro, blocks), file.path(child_dir, name), useBytes = TRUE)
  }
  executive <- c(
    "---", 'title: "AST/ALT Cox Executive Review"', 'subtitle: "AST/ALT Cox分析集中审核摘要"',
    "format:", "  html:", "    toc: true", "    self-contained: true",
    "execute:", "  enabled: false", "---", "",
    "# Review scope / 审核范围", "",
    "本报告只读取已批准的 aggregate outputs，不含个体记录，也不运行科学分析。", "",
    paste0("- Registered tables: ", sum(registry$format == "CSV")),
    paste0("- Registered figures: ", sum(registry$format == "SVG")),
    paste0("- Main outputs: ", sum(grepl("^Main_", registry$file_name))),
    paste0("- Supplementary outputs: ", sum(grepl("^Supp_", registry$file_name))), "",
    "# Review links / 审核入口", "",
    "- [Full report / 完整报告](AST_ALT_Cox_Full_Report.html)",
    "- [Publication manifest / 正式输出清单](manifest/publication_output_manifest.csv)",
    "- [Tables / 表格](tables/)", "- [Figures / 图片](figures/)", "",
    "正式研究结论只能在 production 数据运行并完成相应人工审核后形成。"
  )
  # 输出禁用执行的集中审核摘要 QMD。
  writeLines(executive, file.path(report_root, "AST_ALT_Cox_Executive_Review.qmd"), useBytes = TRUE)
  invisible(TRUE)
}

assemble_release_qmd <- function(report_root, release_dir) {
  child_files <- file.path(report_root, "children", c(
    "00_overview.qmd", "01_population.qmd", "02_imputation_qc.qmd", "03_fixed_cox_ph.qmd",
    "04_tve_rcs.qmd", "05_subgroup.qmd", "06_sensitivity.qmd", "07_secondary.qmd",
    "08_methods_results.qmd"
  ))
  if (!all(file.exists(child_files))) stop("Release report child QMD is incomplete", call. = FALSE)
  body <- unlist(lapply(child_files, readLines, warn = FALSE), use.names = FALSE)
  provenance_path <- file.path(report_root, "generated", "code_appendix", "ALL_CODE_APPENDIX.qmd")
  if (!file.exists(provenance_path)) stop("Public code provenance appendix is missing", call. = FALSE)
  provenance <- readLines(provenance_path, warn = FALSE)
  header <- c(
    "---", 'title: "AST/ALT Cox Analysis Report"', 'subtitle: "AST/ALT Cox分析完整报告"',
    "format:", "  html:", "    toc: true", "    self-contained: true",
    "execute:", "  enabled: false", "---", ""
  )
  # 输出独立交付且不含源码正文的完整 QMD。
  writeLines(c(header, body, provenance), file.path(release_dir, "AST_ALT_Cox_Full_Report.qmd"), useBytes = TRUE)
  executive <- readLines(file.path(report_root, "AST_ALT_Cox_Executive_Review.qmd"), warn = FALSE)
  # 输出独立交付的集中审核摘要 QMD。
  writeLines(executive, file.path(release_dir, "AST_ALT_Cox_Executive_Review.qmd"), useBytes = TRUE)
  manifest_source <- file.path(report_root, "generated", "code_appendix", "code_source_manifest.csv")
  if (!file.copy(
    manifest_source,
    file.path(release_dir, "manifest", "code_source_manifest.csv"),
    overwrite = TRUE
  )) {
    stop("Could not publish code provenance manifest", call. = FALSE)
  }
  invisible(TRUE)
}

extract_release_html_links <- function(text) {
  tag_pattern <- "(?is)<(?:a|img|script|link|iframe|source)\\b[^>]*(?:href|src)\\s*=\\s*['\"][^'\"]+['\"][^>]*>"
  tags <- regmatches(text, gregexpr(tag_pattern, text, perl = TRUE))[[1L]]
  if (!length(tags) || identical(tags, "")) return(character())
  links <- vapply(tags, function(tag) {
    match <- regmatches(
      tag,
      regexpr("(?is)(?:href|src)\\s*=\\s*['\"][^'\"]+['\"]", tag, perl = TRUE)
    )
    value <- sub("(?is)^(?:href|src)\\s*=\\s*['\"]", "", match, perl = TRUE)
    sub("['\"]$", "", value)
  }, character(1))
  unique(links[nzchar(links)])
}

audit_release_html_links <- function(release_dir) {
  html_files <- list.files(release_dir, pattern = "\\.html$", full.names = TRUE)
  rows <- list()
  index <- 1L
  for (html in html_files) {
    text <- paste(readLines(html, warn = FALSE, encoding = "UTF-8"), collapse = "\n")
    links <- extract_release_html_links(text)
    links <- links[!grepl("^(https?:|mailto:|data:|javascript:|#)", links)]
    links <- sub("[?#].*$", "", links)
    links <- unique(links[nzchar(links)])
    for (link in links) {
      target <- file.path(dirname(html), utils::URLdecode(link))
      exists <- file.exists(target) || dir.exists(target)
      rows[[index]] <- data.frame(
        html_file = basename(html),
        relative_link = link,
        exists = exists,
        status = ifelse(exists, "PASS", "FAIL"),
        stringsAsFactors = FALSE
      )
      index <- index + 1L
    }
  }
  result <- if (length(rows)) {
    do.call(rbind, rows)
  } else {
    data.frame(
      html_file = character(), relative_link = character(),
      exists = logical(), status = character(), stringsAsFactors = FALSE
    )
  }
  # 输出完整 HTML 文本解析后的本地链接审计结果。
  utils::write.csv(
    result,
    file.path(release_dir, "audit", "qc_html_link_integrity.csv"),
    row.names = FALSE
  )
  if (nrow(result) && any(result$status == "FAIL")) stop("Release HTML contains broken local links", call. = FALSE)
  result
}

validate_public_qmd_tokens <- function(release_dir) {
  qmd_files <- list.files(release_dir, pattern = "\\.qmd$", full.names = TRUE, recursive = TRUE)
  patient_identifier_pattern <- "(?i)(^|[^A-Za-z0-9])patient[_ -]?id([^A-Za-z0-9]|$)"
  for (path in qmd_files) {
    text <- paste(readLines(path, warn = FALSE, encoding = "UTF-8"), collapse = "\n")
    if (grepl(patient_identifier_pattern, text, perl = TRUE) ||
        grepl("restricted_cache", tolower(text), fixed = TRUE)) {
      stop("Public QMD contains a forbidden token: ", basename(path), call. = FALSE)
    }
    if (grepl("(^|[[:space:]\"'(=])/(Users|Volumes|home|root|mnt|private|tmp|var)/", text, perl = TRUE) ||
        grepl("[A-Za-z]:\\\\", text, perl = TRUE)) {
      stop("Public QMD contains an absolute local path: ", basename(path), call. = FALSE)
    }
  }
  invisible(TRUE)
}

atomic_publish_release <- function(staging_dir, final_dir, validator = function(path) TRUE) {
  if (!dir.exists(staging_dir)) stop("Release staging directory does not exist", call. = FALSE)
  validation <- tryCatch(
    isTRUE(validator(staging_dir)),
    error = function(condition) {
      stop("Release staging validation failed: ", conditionMessage(condition), call. = FALSE)
    }
  )
  if (!validation) stop("Release staging validation returned FALSE", call. = FALSE)
  backup_dir <- paste0(final_dir, ".previous.", Sys.getpid())
  if (dir.exists(backup_dir)) stop("Stale release backup directory exists", call. = FALSE)
  final_existed <- dir.exists(final_dir)
  if (final_existed && !file.rename(final_dir, backup_dir)) {
    stop("Could not move current release to atomic backup", call. = FALSE)
  }
  if (!file.rename(staging_dir, final_dir)) {
    if (final_existed) file.rename(backup_dir, final_dir)
    stop("Atomic release publication failed", call. = FALSE)
  }
  if (final_existed) unlink(backup_dir, recursive = TRUE)
  invisible(final_dir)
}

prepare_release_runtime_qmd <- function(report_runtime) {
  main_qmd <- file.path(report_runtime, "AST_ALT_Cox_Full_Report.qmd")
  if (!file.exists(main_qmd)) stop("Full report QMD template is missing", call. = FALSE)
  lines <- readLines(main_qmd, warn = FALSE, encoding = "UTF-8")
  lines <- sub("self-contained:[[:space:]]*false", "self-contained: true", lines)
  # 固化 release-only 报告为自包含且禁用执行的 QMD。
  writeLines(lines, main_qmd, useBytes = TRUE)
  invisible(main_qmd)
}

link_release_assets_for_quarto <- function(report_runtime, staging_dir) {
  for (name in c("tables", "figures", "figure_data", "manifest", "audit")) {
    link <- file.path(report_runtime, name)
    if (file.exists(link) || dir.exists(link)) unlink(link, recursive = TRUE)
    if (!file.symlink(file.path(staging_dir, name), link)) {
      stop("Could not expose staged release assets to Quarto: ", name, call. = FALSE)
    }
  }
  invisible(TRUE)
}

validate_release_staging <- function(staging_dir, project_root, run_root) {
  required <- c(
    "AST_ALT_Cox_Full_Report.qmd",
    "AST_ALT_Cox_Full_Report.html",
    "AST_ALT_Cox_Executive_Review.qmd",
    "AST_ALT_Cox_Executive_Review.html",
    file.path("manifest", "publication_output_manifest.csv"),
    file.path("manifest", "code_source_manifest.csv"),
    file.path("audit", "publication_source_integrity_receipts.csv"),
    file.path("audit", "qc_html_link_integrity.csv")
  )
  if (!all(file.exists(file.path(staging_dir, required)))) {
    stop("Release staging is missing required publication files", call. = FALSE)
  }
  output_registry <- utils::read.csv(
    file.path(project_root, "config", "output_registry.csv"),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  recipes <- load_publication_recipes(project_root)
  manifest <- utils::read.csv(
    file.path(staging_dir, "manifest", "publication_output_manifest.csv"),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  validate_publication_output_closure(
    output_registry, manifest, staging_dir, recipes = recipes,
    context = list(
      project_root = normalizePath(project_root, mustWork = TRUE),
      run_root = normalizePath(run_root, mustWork = TRUE),
      profile = "release_only", run_id = "release_only"
    )
  )
  validate_release_rubin_df_receipt_v43(
    file.path(run_root, "canonical_results"), project_root
  )
  validate_release_canonical_applicability_receipt_v43(
    file.path(run_root, "canonical_results"), project_root
  )
  validate_public_qmd_tokens(staging_dir)
  if (!exists("scan_review_package_privacy", mode = "function", inherits = TRUE)) {
    # 加载严格隐私扫描器以验证完整 release staging。
    source(file.path(project_root, "R", "review_pack.R"))
  }
  privacy <- scan_review_package_privacy(staging_dir)
  if (!nrow(privacy) || any(privacy$status != "PASS")) {
    stop("Release staging strict privacy scan failed", call. = FALSE)
  }
  TRUE
}

build_release_from_canonical <- function(run_root = ".", project_root = run_root) {
  # 加载 JSON 包以记录 release-only 的非科学性重建状态。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  source(file.path(project_root, "R", "bundle_manager.R"))
  source(file.path(project_root, "R", "stage_context.R"))
  source(file.path(project_root, "R", "publication_renderer.R"))
  canonical_dir <- file.path(run_root, "canonical_results")
  canonical_files <- list.files(canonical_dir, pattern = "\\.csv$", full.names = TRUE)
  if (!length(canonical_files)) stop("No approved canonical results are available", call. = FALSE)
  validate_release_rubin_df_receipt_v43(canonical_dir, project_root)
  validate_release_canonical_applicability_receipt_v43(canonical_dir, project_root)
  final_release <- file.path(run_root, "release")
  staging_dir <- tempfile(pattern = "release.staging.", tmpdir = run_root)
  report_runtime <- tempfile(pattern = "report_runtime.", tmpdir = run_root)
  dir.create(staging_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(report_runtime, recursive = TRUE, showWarnings = FALSE)
  on.exit({
    if (dir.exists(staging_dir)) unlink(staging_dir, recursive = TRUE)
    if (dir.exists(report_runtime)) unlink(report_runtime, recursive = TRUE)
  }, add = TRUE)
  report_source <- file.path(project_root, "report")
  copied <- file.copy(
    list.files(report_source, full.names = TRUE, all.files = TRUE, no.. = TRUE),
    report_runtime,
    recursive = TRUE
  )
  if (!length(copied) || !all(copied)) stop("Could not stage report templates", call. = FALSE)
  context <- list(
    project_root = normalizePath(project_root),
    run_root = normalizePath(run_root),
    profile = "release_only",
    run_id = "release_only"
  )
  # 从 canonical 汇总层重建全部 CSV、SVG 和 figure-data 到干净 staging。
  render_publication_outputs(context, release_dir = staging_dir)
  build_static_code_appendix(project_root, report_runtime)
  populate_report_children(
    run_root, project_root, report_runtime,
    release_dir = staging_dir,
    runtime_link_prefix = ""
  )
  prepare_release_runtime_qmd(report_runtime)
  link_release_assets_for_quarto(report_runtime, staging_dir)
  quarto_home <- tempfile(pattern = "quarto-home.", tmpdir = run_root)
  quarto_cache <- tempfile(pattern = "quarto-cache.", tmpdir = run_root)
  dir.create(quarto_home, recursive = TRUE, showWarnings = FALSE)
  dir.create(quarto_cache, recursive = TRUE, showWarnings = FALSE)
  on.exit({
    if (dir.exists(quarto_home)) unlink(quarto_home, recursive = TRUE)
    if (dir.exists(quarto_cache)) unlink(quarto_cache, recursive = TRUE)
  }, add = TRUE)
  old_wd <- getwd()
  on.exit(setwd(old_wd), add = TRUE)
  setwd(report_runtime)
  # 渲染禁用执行的完整 QMD 报告，不运行任何科学代码。
  status <- system2(
    "quarto",
    c(
      "render", "AST_ALT_Cox_Full_Report.qmd",
      "--output-dir", normalizePath(staging_dir, mustWork = FALSE)
    ),
    env = c(
      paste0("HOME=", normalizePath(quarto_home, mustWork = FALSE)),
      paste0("DENO_DIR=", normalizePath(file.path(quarto_cache, "deno"), mustWork = FALSE))
    )
  )
  if (!identical(status, 0L)) stop("Quarto release render failed", call. = FALSE)
  # 渲染禁用执行的集中人工审核摘要。
  executive_status <- system2(
    "quarto",
    c(
      "render", "AST_ALT_Cox_Executive_Review.qmd",
      "--output-dir", normalizePath(staging_dir, mustWork = FALSE)
    ),
    env = c(
      paste0("HOME=", normalizePath(quarto_home, mustWork = FALSE)),
      paste0("DENO_DIR=", normalizePath(file.path(quarto_cache, "deno"), mustWork = FALSE))
    )
  )
  if (!identical(executive_status, 0L)) stop("Quarto executive review render failed", call. = FALSE)
  assemble_release_qmd(report_runtime, staging_dir)
  audit_release_html_links(staging_dir)
  atomic_publish_release(
    staging_dir,
    final_release,
    validator = function(path) validate_release_staging(path, project_root, run_root)
  )
  dir.create(file.path(run_root, "runtime"), recursive = TRUE, showWarnings = FALSE)
  # 记录 release-only 重建完成状态；该记录不包含个体数据或模型对象。
  jsonlite::write_json(
    list(
      execution_profile = "release_only",
      canonical_layer_only = TRUE,
      individual_record_accessed = FALSE,
      model_fit_executed = FALSE,
      release_rebuild_status = "PASS"
    ),
    file.path(run_root, "runtime", "release_only_rebuild.json"),
    auto_unbox = TRUE,
    pretty = TRUE
  )
  invisible(final_release)
}
