# 患者身份守卫：患者级键只保存在受限缓存，公开输出仅使用汇总和不可逆哈希。

hash_patient_identifier <- function(ids) {
  # 加载摘要包以生成不可逆患者键哈希。
  if (!requireNamespace("digest", quietly = TRUE)) stop("digest is required", call. = FALSE)
  vapply(as.character(ids), function(x) digest::digest(x, algo = "sha256", serialize = FALSE), character(1))
}

validate_patient_identity <- function(imp0, completed) {
  if (anyNA(imp0$Patient_ID) || anyDuplicated(imp0$Patient_ID)) stop("Invalid .imp=0 patient identity", call. = FALSE)
  reference <- as.character(imp0$Patient_ID)
  rows <- lapply(seq_along(completed), function(i) {
    ids <- as.character(completed[[i]]$Patient_ID)
    data.frame(
      imputation = i,
      n = length(ids),
      missing_id_n = sum(is.na(ids) | !nzchar(ids)),
      duplicate_id_n = sum(duplicated(ids)),
      same_set = setequal(ids, reference),
      same_order = identical(ids, reference),
      stringsAsFactors = FALSE
    )
  })
  result <- do.call(rbind, rows)
  result$status <- ifelse(
    result$missing_id_n == 0L & result$duplicate_id_n == 0L & result$same_set & result$same_order,
    "PASS", "FAIL"
  )
  if (any(result$status != "PASS")) stop("Patient identity differs across imputations", call. = FALSE)
  result
}

write_private_identity <- function(data, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE, mode = "0700")
  # 保存患者级身份对象到受限缓存，不导出 CSV。
  saveRDS(data, path, compress = "xz")
  invisible(Sys.chmod(path, mode = "0600", use_umask = FALSE))
  path
}
