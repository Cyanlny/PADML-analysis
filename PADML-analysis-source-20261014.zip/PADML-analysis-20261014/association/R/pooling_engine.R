# Rubin 标量合并：统一处理单参数估计。
pool_scalar_rubin <- function(estimates, variances, conf_level = 0.95) {
  keep <- is.finite(estimates) & is.finite(variances) & variances >= 0
  q <- estimates[keep]
  u <- variances[keep]
  m <- length(q)
  if (m < 2L) stop("At least two valid imputations are required", call. = FALSE)
  qbar <- mean(q)
  ubar <- mean(u)
  b <- stats::var(q)
  total <- ubar + (1 + 1 / m) * b
  if (!is.finite(total) || total < 0) stop("Invalid total variance", call. = FALSE)
  r <- if (ubar > 0) ((1 + 1 / m) * b) / ubar else Inf
  df <- if (is.finite(r) && r > 0) (m - 1) * (1 + 1 / r)^2 else Inf
  alpha <- 1 - conf_level
  critical <- if (is.finite(df)) stats::qt(1 - alpha / 2, df = df) else stats::qnorm(1 - alpha / 2)
  se <- sqrt(total)
  statistic <- qbar / se
  p <- if (is.finite(df)) 2 * stats::pt(-abs(statistic), df = df) else 2 * stats::pnorm(-abs(statistic))
  data.frame(
    pooled_estimate = qbar, within_variance = ubar, between_variance = b,
    total_variance = total, se = se, lower = qbar - critical * se,
    upper = qbar + critical * se, statistic = statistic, df = df,
    p_value = p, valid_imputation_n = m
  )
}

# D1 多参数合并：只调用锁定的 mice 实现，不采用平均P值替代。
pool_joint_wald_d1 <- function(full_mira, reduced_mira, dfcom = NULL) {
  # 加载 mice 包以执行预注册 D1 pooled Wald 检验。
  if (!requireNamespace("mice", quietly = TRUE)) stop("mice is required", call. = FALSE)
  result <- mice::D1(full_mira, reduced_mira, dfcom = dfcom)
  if (!is.matrix(result$result) || !all(c("F.value", "df1", "df2", "P(>F)", "RIV") %in% colnames(result$result))) {
    stop("Unexpected mice::D1 result schema", call. = FALSE)
  }
  result
}

# 线性对比合并：每套插补先计算完整方差，再执行Rubin合并。
pool_linear_contrast_rubin <- function(beta_list, covariance_list, contrast) {
  if (length(beta_list) != length(covariance_list)) stop("Mismatched input lengths", call. = FALSE)
  estimates <- numeric(length(beta_list))
  variances <- numeric(length(beta_list))
  for (i in seq_along(beta_list)) {
    beta <- beta_list[[i]]
    covariance <- covariance_list[[i]]
    if (!all(names(contrast) %in% names(beta))) stop("Contrast term missing", call. = FALSE)
    idx <- match(names(contrast), names(beta))
    cvec <- as.numeric(contrast)
    estimates[[i]] <- sum(cvec * beta[idx])
    variances[[i]] <- as.numeric(t(cvec) %*% covariance[idx, idx, drop = FALSE] %*% cvec)
  }
  pool_scalar_rubin(estimates, variances)
}
