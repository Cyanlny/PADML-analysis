# 加载 targets 包以定义 A04 TVE 与 RCS DAG。
library(targets)
project_root <- Sys.getenv("AST_ALT_PROJECT_ROOT", unset = normalizePath("."))
source(file.path(project_root, "R", "stage_context.R"))
invisible(lapply(setdiff(list.files(file.path(project_root, "R"), pattern = "\\.R$", full.names = TRUE), file.path(project_root, "R", "stage_context.R")), source))
tar_option_set(error = "stop", memory = "transient")

list(
  tar_target(A04_base_context, stage_context(), cue = tar_cue(mode = "always")),
  tar_target(A04_contract_files, stage_contract_files("A04", A04_base_context$project_root), format = "file"),
  tar_target(A04_context, context_with_contract(A04_base_context, A04_contract_files)),
  tar_target(A04_previous_bundle, validate_previous_public_bundle("A04", A04_context)),
  tar_target(A04_previous_state, load_previous_analysis_state("A04", A04_context)),
  tar_target(A04_primary_endpoint, A04_previous_state$endpoint_registry[A04_previous_state$endpoint_registry$endpoint_id == "EP01", , drop = FALSE]),
  tar_target(A04_nuisance_terms, approved_nuisance_tve_terms(A04_context)),
  tar_target(A04_scientific_config, effective_scientific_config("A04", A04_context)),
  tar_target(
    A04_tve_branch_spec,
    make_tve_branch_specs(
      A04_previous_state$exposure$completed, A04_primary_endpoint,
      A04_context$project_root, A04_nuisance_terms,
      A04_scientific_config$revision
    ),
    iteration = "list"
  ),
  tar_target(
    A04_tve_branch,
    fit_tve_branch(A04_previous_state$exposure$completed, A04_tve_branch_spec),
    pattern = map(A04_tve_branch_spec), iteration = "list"
  ),
  tar_target(
    A04_tve,
    combine_tve_branches(
      A04_tve_branch, A04_previous_state$exposure$exposure_scale,
      A04_previous_state$riskset, A04_context$project_root
    )
  ),
  tar_target(
    A04_rcs_branch_spec,
    make_rcs_branch_specs(
      A04_previous_state$exposure$completed, A04_primary_endpoint,
      A04_previous_state$exposure$exposure_scale, A04_context$project_root
    ),
    iteration = "list"
  ),
  tar_target(
    A04_rcs_branch,
    fit_rcs_branch(A04_previous_state$exposure$completed, A04_rcs_branch_spec),
    pattern = map(A04_rcs_branch_spec), iteration = "list"
  ),
  tar_target(
    A04_rcs,
    combine_rcs_branches(
      A04_previous_state$exposure$completed, A04_rcs_branch,
      A04_previous_state$exposure$exposure_scale, A04_context$project_root
    )
  ),
  tar_target(A04_analysis, combine_a04_analysis(A04_tve, A04_rcs, A04_nuisance_terms)),
  tar_target(A04_qc, qc_a04_analysis(A04_analysis, A04_previous_state$exposure$exposure_scale)),
  tar_target(A04_status, determine_stage_status("A04", A04_qc)),
  tar_target(A04_artifacts, materialize_a04(A04_previous_state, A04_analysis, A04_context)),
  tar_target(A04_stage_result, publish_stage_analysis(
    "A04", A04_status, A04_artifacts$public_files, A04_artifacts$restricted_files,
    A04_qc, key_results = A04_analysis$tve$canonical[A04_analysis$tve$canonical$model_id == "M5", ],
    context = A04_context
  ), format = "file")
)
