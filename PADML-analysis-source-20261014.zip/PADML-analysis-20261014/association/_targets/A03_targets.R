# 加载 targets 包以定义 A03 固定 Cox 与正式 PH DAG。
library(targets)
project_root <- Sys.getenv("AST_ALT_PROJECT_ROOT", unset = normalizePath("."))
source(file.path(project_root, "R", "stage_context.R"))
invisible(lapply(setdiff(list.files(file.path(project_root, "R"), pattern = "\\.R$", full.names = TRUE), file.path(project_root, "R", "stage_context.R")), source))
tar_option_set(error = "stop", memory = "transient")

list(
  tar_target(A03_base_context, stage_context(), cue = tar_cue(mode = "always")),
  tar_target(A03_contract_files, stage_contract_files("A03", A03_base_context$project_root), format = "file"),
  tar_target(A03_context, context_with_contract(A03_base_context, A03_contract_files)),
  tar_target(A03_previous_bundle, validate_previous_public_bundle("A03", A03_context)),
  tar_target(A03_previous_state, load_previous_analysis_state("A03", A03_context)),
  tar_target(A03_primary_endpoint, A03_previous_state$endpoint_registry[A03_previous_state$endpoint_registry$endpoint_id == "EP01", , drop = FALSE]),
  tar_target(A03_branch_spec, make_a03_branch_specs(A03_previous_state$exposure$completed), iteration = "list"),
  tar_target(
    A03_fit_bundle,
    fit_fixed_cox_branch(A03_previous_state$exposure$completed, A03_branch_spec, A03_primary_endpoint, A03_context$project_root),
    pattern = map(A03_branch_spec), iteration = "list"
  ),
  tar_target(A03_fit_bundles, flatten_a03_fit_bundles(A03_fit_bundle)),
  tar_target(A03_fixed, combine_a03_fit_bundles(A03_fit_bundles, A03_context$project_root)),
  tar_target(A03_ph, run_formal_ph_stage(A03_fixed, A03_context$project_root)),
  tar_target(A03_schoenfeld, run_a03_schoenfeld_extensions(A03_fixed, A03_context$project_root)),
  tar_target(A03_diagnostic_requests, fit_bundles_to_requests(A03_fit_bundles)),
  tar_target(A03_design_request, unname(A03_diagnostic_requests$design$unique_requests), iteration = "list"),
  tar_target(
    A03_design_diagnostic,
    diagnose_design_request_target(A03_design_request, A03_context$profile),
    pattern = map(A03_design_request), iteration = "list"
  ),
  tar_target(A03_fit_request, unname(A03_diagnostic_requests$fit$unique_requests), iteration = "list"),
  tar_target(
    A03_fit_diagnostic,
    diagnose_fit_request_target(A03_fit_request),
    pattern = map(A03_fit_request), iteration = "list"
  ),
  tar_target(
    A03_collinearity,
    assemble_a03_collinearity(A03_diagnostic_requests, A03_design_diagnostic, A03_fit_diagnostic, A03_fixed)
  ),
  tar_target(A03_diagnostic_write_guard, a03_diagnostic_write_guard(A03_collinearity, A03_context$profile)),
  tar_target(A03_analysis, {
    A03_diagnostic_write_guard
    list(
      fixed = A03_fixed, ph = A03_ph,
      schoenfeld = A03_schoenfeld, collinearity = A03_collinearity
    )
  }),
  tar_target(A03_qc_candidate, qc_a03_analysis(A03_analysis, A03_context$profile, A03_context$project_root)),
  tar_target(A03_qc, A03_qc_candidate$qc),
  tar_target(A03_status, determine_stage_status("A03", A03_qc, scientific_config_candidate = nrow(A03_qc_candidate$candidate) > 0L && A03_context$profile == "production")),
  tar_target(A03_artifacts, materialize_a03(
    A03_previous_state, A03_analysis, A03_qc_candidate$candidate, A03_context,
    A03_qc_candidate$rubin_df_audit
  )),
  tar_target(A03_config_diff, if (nrow(A03_qc_candidate$candidate)) transform(A03_qc_candidate$candidate, change_type = "candidate_nuisance_tve_not_yet_approved") else data.frame()),
  tar_target(A03_stage_result, publish_stage_analysis(
    "A03", A03_status, A03_artifacts$public_files, A03_artifacts$restricted_files,
    A03_qc, key_results = A03_analysis$fixed$canonical, config_diff = A03_config_diff,
    cache_audit = A03_analysis$collinearity$cache_audit,
    review_sections = list(
      key_tables = list("multicollinearity_summary.csv" = A03_analysis$collinearity$summary),
      exception_tables = list("collinearity_exception_publication.csv" = A03_analysis$collinearity$exception_publication),
      machine_audit = list(
        "vif_summary_receipt.csv" = A03_analysis$collinearity$receipt,
        "coefficient_parameter_consistency.csv" = A03_analysis$collinearity$parameter_consistency
      ),
      full_canonical_index = list("model_diagnostic_linkage.csv" = A03_analysis$collinearity$diagnostic_linkage)
    ),
    context = A03_context
  ), format = "file")
)
