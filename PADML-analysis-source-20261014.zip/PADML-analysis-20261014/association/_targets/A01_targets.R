# 加载 targets 包以定义 A01 人群、暴露、Table 1 与 KM DAG。
library(targets)
project_root <- Sys.getenv("AST_ALT_PROJECT_ROOT", unset = normalizePath("."))
source(file.path(project_root, "R", "stage_context.R"))
invisible(lapply(setdiff(list.files(file.path(project_root, "R"), pattern = "\\.R$", full.names = TRUE), file.path(project_root, "R", "stage_context.R")), source))
tar_option_set(error = "stop", memory = "transient")

list(
  tar_target(A01_base_context, stage_context(), cue = tar_cue(mode = "always")),
  tar_target(A01_contract_files, stage_contract_files("A01", A01_base_context$project_root), format = "file"),
  tar_target(A01_context, context_with_contract(A01_base_context, A01_contract_files)),
  tar_target(A01_previous_bundle, validate_previous_public_bundle("A01", A01_context)),
  tar_target(A01_sources, load_analysis_sources(A01_context$profile, A01_context$project_root, Sys.getenv("AST_ALT_HANDOFF_ZIP", ""), A01_context$run_root)),
  tar_target(A01_analysis, run_a01_analysis(A01_sources, A01_context)),
  tar_target(A01_qc, qc_a01_analysis(A01_analysis)),
  tar_target(A01_status, determine_stage_status("A01", A01_qc)),
  tar_target(A01_artifacts, materialize_a01(A01_analysis, A01_context)),
  tar_target(A01_stage_result, publish_stage_analysis(
    "A01", A01_status, A01_artifacts$public_files, A01_artifacts$restricted_files,
    A01_qc, key_results = A01_analysis$exposure$exposure_scale,
    context = A01_context
  ), format = "file")
)
