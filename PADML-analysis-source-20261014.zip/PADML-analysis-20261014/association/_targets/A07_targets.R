# 加载 targets 包以定义 A07 只读 canonical 发布 DAG。
library(targets)
project_root <- Sys.getenv("AST_ALT_PROJECT_ROOT", unset = normalizePath("."))
source(file.path(project_root, "R", "stage_context.R"))
invisible(lapply(setdiff(list.files(file.path(project_root, "R"), pattern = "\\.R$", full.names = TRUE), file.path(project_root, "R", "stage_context.R")), source))
tar_option_set(error = "stop", memory = "transient")

list(
  tar_target(A07_base_context, stage_context(), cue = tar_cue(mode = "always")),
  tar_target(A07_contract_files, stage_contract_files("A07", A07_base_context$project_root), format = "file"),
  tar_target(A07_context, context_with_contract(A07_base_context, A07_contract_files)),
  tar_target(A07_previous_bundle, validate_previous_public_bundle("A07", A07_context)),
  tar_target(A07_canonical_manifest, collect_approved_canonical_results(A07_context)),
  tar_target(A07_analysis, run_a07_release(A07_canonical_manifest, A07_context)),
  tar_target(A07_qc, qc_a07_release(A07_analysis, A07_context)),
  tar_target(A07_status, determine_stage_status("A07", A07_qc)),
  tar_target(A07_artifacts, materialize_a07(A07_analysis, A07_qc, A07_context)),
  tar_target(A07_stage_result, publish_stage_analysis(
    "A07", A07_status, A07_artifacts$public_files, character(), A07_qc,
    key_results = A07_analysis$manifest, context = A07_context
  ), format = "file")
)
