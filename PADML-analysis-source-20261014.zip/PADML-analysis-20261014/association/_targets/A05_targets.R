# 加载 targets 包以定义 A05 亚组与交互 DAG。
library(targets)
project_root <- Sys.getenv("AST_ALT_PROJECT_ROOT", unset = normalizePath("."))
source(file.path(project_root, "R", "stage_context.R"))
invisible(lapply(setdiff(list.files(file.path(project_root, "R"), pattern = "\\.R$", full.names = TRUE), file.path(project_root, "R", "stage_context.R")), source))
tar_option_set(error = "stop", memory = "transient")

list(
  tar_target(A05_base_context, stage_context(), cue = tar_cue(mode = "always")),
  tar_target(A05_contract_files, stage_contract_files("A05", A05_base_context$project_root), format = "file"),
  tar_target(A05_context, context_with_contract(A05_base_context, A05_contract_files)),
  tar_target(A05_previous_bundle, validate_previous_public_bundle("A05", A05_context)),
  tar_target(A05_previous_state, load_previous_analysis_state("A05", A05_context)),
  tar_target(
    A05_subgroup_spec,
    make_subgroup_branch_specs(A05_context$project_root),
    iteration = "list"
  ),
  tar_target(
    A05_subgroup_branch,
    {
      branch <- run_subgroup_branch(
        A05_subgroup_spec,
        A05_previous_state$exposure$completed,
        A05_previous_state$endpoint_registry[
          A05_previous_state$endpoint_registry$endpoint_id == "EP01", , drop = FALSE
        ],
        A05_previous_state$exposure$exposure_scale,
        A05_context$project_root
      )
      record_subgroup_branch_progress(branch, A05_context)
      branch
    },
    pattern = map(A05_subgroup_spec),
    iteration = "list"
  ),
  tar_target(
    A05_progress_receipt,
    record_subgroup_branch_progress(A05_subgroup_branch, A05_context),
    pattern = map(A05_subgroup_branch),
    format = "file"
  ),
  tar_target(A05_analysis, {
    invisible(A05_progress_receipt)
    combine_subgroup_branches(A05_subgroup_branch, A05_context$project_root)
  }),
  tar_target(A05_qc, qc_a05_analysis(A05_analysis, A05_context)),
  tar_target(A05_status, determine_stage_status("A05", A05_qc)),
  tar_target(A05_artifacts, materialize_a05(A05_previous_state, A05_analysis, A05_context)),
  tar_target(A05_stage_result, publish_stage_analysis(
    "A05", A05_status, A05_artifacts$public_files, A05_artifacts$restricted_files,
    A05_qc, key_results = A05_analysis$interactions, context = A05_context
  ), format = "file")
)
