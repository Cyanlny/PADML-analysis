# 加载 targets 包以定义 A02 插补 QC DAG。
library(targets)
project_root <- Sys.getenv("AST_ALT_PROJECT_ROOT", unset = normalizePath("."))
source(file.path(project_root, "R", "stage_context.R"))
invisible(lapply(setdiff(list.files(file.path(project_root, "R"), pattern = "\\.R$", full.names = TRUE), file.path(project_root, "R", "stage_context.R")), source))
tar_option_set(error = "stop", memory = "transient")

list(
  tar_target(A02_base_context, stage_context(), cue = tar_cue(mode = "always")),
  tar_target(A02_contract_files, stage_contract_files("A02", A02_base_context$project_root), format = "file"),
  tar_target(A02_context, context_with_contract(A02_base_context, A02_contract_files)),
  tar_target(A02_previous_bundle, validate_previous_public_bundle("A02", A02_context)),
  tar_target(A02_previous_state, load_previous_analysis_state("A02", A02_context)),
  tar_target(A02_analysis, run_a02_analysis(A02_previous_state, A02_context)),
  tar_target(A02_qc, qc_a02_analysis(A02_analysis)),
  tar_target(A02_status, determine_stage_status("A02", A02_qc)),
  tar_target(A02_artifacts, materialize_a02(A02_previous_state, A02_analysis, A02_context)),
  tar_target(A02_warnings, warning_frame(
    "A02", if (nrow(A02_analysis$logged_events)) "W_BLOCKING_LOGGED_EVENT" else character(),
    if (nrow(A02_analysis$logged_events)) "BLOCKING_WARNING" else character(),
    if (nrow(A02_analysis$logged_events)) "存在待解释的 MICE logged events" else character(),
    if (nrow(A02_analysis$logged_events)) "人工审核 logged events 后再继续" else character()
  )),
  tar_target(A02_stage_result, publish_stage_analysis(
    "A02", A02_status, A02_artifacts$public_files, A02_artifacts$restricted_files,
    A02_qc, warnings = A02_warnings, key_results = A02_analysis$distribution_qc,
    context = A02_context
  ), format = "file")
)
