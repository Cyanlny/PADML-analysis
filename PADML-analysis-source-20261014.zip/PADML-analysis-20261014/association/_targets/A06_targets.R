# 加载 targets 包以定义 A06 敏感性与补充结局 DAG。
library(targets)
project_root <- Sys.getenv("AST_ALT_PROJECT_ROOT", unset = normalizePath("."))
source(file.path(project_root, "R", "stage_context.R"))
invisible(lapply(setdiff(list.files(file.path(project_root, "R"), pattern = "\\.R$", full.names = TRUE), file.path(project_root, "R", "stage_context.R")), source))
tar_option_set(error = "stop", memory = "transient")

list(
  tar_target(A06_base_context, stage_context(), cue = tar_cue(mode = "always")),
  tar_target(A06_contract_files, stage_contract_files("A06", A06_base_context$project_root), format = "file"),
  tar_target(A06_context, context_with_contract(A06_base_context, A06_contract_files)),
  tar_target(A06_previous_bundle, validate_previous_public_bundle("A06", A06_context)),
  tar_target(A06_previous_state, load_previous_analysis_state("A06", A06_context)),
  tar_target(A06_ipcw_time, as.list(c(6, 12, 24, 36)), iteration = "list"),
  tar_target(
    A06_ipcw_branch,
    run_a06_ipcw_timepoint(A06_previous_state, A06_ipcw_time, A06_context),
    pattern = map(A06_ipcw_time), iteration = "list"
  ),
  tar_target(A06_ipcw, combine_a06_ipcw_timepoints(A06_ipcw_branch)),
  tar_target(
    A06_sensitivity_spec,
    make_sensitivity_branch_specs(A06_context$project_root, A06_context$run_root),
    iteration = "list"
  ),
  tar_target(
    A06_sensitivity_branch,
    {
      branch <- run_sensitivity_branch(
        A06_sensitivity_spec, A06_previous_state, A06_context
      )
      record_sensitivity_branch_progress(branch, A06_context)
      branch
    },
    pattern = map(A06_sensitivity_spec),
    iteration = "list"
  ),
  tar_target(
    A06_progress_receipt,
    record_sensitivity_branch_progress(A06_sensitivity_branch, A06_context),
    pattern = map(A06_sensitivity_branch),
    format = "file"
  ),
  tar_target(A06_analysis, {
    invisible(A06_progress_receipt)
    base <- combine_sensitivity_branches(A06_sensitivity_branch, A06_context$project_root)
    finalize_a06_diagnostic_extensions(
      A06_previous_state, base, A06_ipcw, A06_context
    )
  }),
  tar_target(A06_qc, qc_a06_analysis(A06_analysis, A06_context)),
  tar_target(A06_status, determine_stage_status("A06", A06_qc)),
  tar_target(A06_artifacts, materialize_a06(A06_previous_state, A06_analysis, A06_context)),
  tar_target(A06_stage_result, publish_stage_analysis(
    "A06", A06_status, A06_artifacts$public_files, A06_artifacts$restricted_files,
    A06_qc, key_results = A06_analysis$standard, context = A06_context
  ), format = "file")
)
