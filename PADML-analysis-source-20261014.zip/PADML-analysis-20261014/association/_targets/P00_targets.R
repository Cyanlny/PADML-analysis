# 加载 targets 包以定义 P00 生产预检 DAG。
library(targets)
project_root <- Sys.getenv("AST_ALT_PROJECT_ROOT", unset = normalizePath("."))
source(file.path(project_root, "R", "stage_context.R"))
invisible(lapply(setdiff(list.files(file.path(project_root, "R"), pattern = "\\.R$", full.names = TRUE), file.path(project_root, "R", "stage_context.R")), source))
tar_option_set(error = "stop", memory = "transient")

list(
  tar_target(P00_base_context, stage_context(), cue = tar_cue(mode = "always")),
  tar_target(P00_contract_files, stage_contract_files("P00", P00_base_context$project_root), format = "file"),
  tar_target(P00_context, context_with_contract(P00_base_context, P00_contract_files)),
  tar_target(P00_analysis, run_p00_preflight(P00_context)),
  tar_target(P00_qc, P00_analysis$qc),
  tar_target(P00_status, determine_stage_status("P00", P00_qc)),
  tar_target(P00_public_files, c(
    write_stage_csv(P00_analysis$handoff_qc, "P00", "handoff_structure_qc.csv", P00_context),
    write_stage_csv(P00_analysis$registries, "P00", "registry_presence_qc.csv", P00_context),
    write_stage_csv(P00_analysis$formula_checks, "P00", "model_formula_parse_qc.csv", P00_context),
    write_stage_csv(P00_analysis$structure, "P00", "production_structure_canary_qc.csv", P00_context),
    write_stage_csv(P00_analysis$contract, "P00", "handoff_contract_qc.csv", P00_context),
    write_stage_csv(P00_qc, "P00", "p00_preflight_qc.csv", P00_context)
  )),
  tar_target(P00_stage_result, publish_stage_analysis(
    "P00", P00_status, P00_public_files, qc_results = P00_qc,
    key_results = P00_analysis$structure, context = P00_context
  ), format = "file")
)
