# PAD 开发队列 AST/ALT 与临床结局 Cox 分析 Protocol

**版本**：v4.2-r03 Cox-Only Production Staged Agent  
**状态**：`FROZEN_BUILD_VALIDATED`（完整合成 P00-A07、故障恢复与 release-only 重建已通过；尚未读取真实患者数据或运行真实分析）  
**主要结局**：`All_Cause_Death` / `Death_Followup_months`  
**补充结局**：`MACE`、`CV_CBV_Death`  
**预设时间点**：6、12、24、36 个月  
**主模型**：M5  

本 protocol 仅规定 Cox 关联分析、时间变化效应、RCS、亚组、敏感性分析及其执行治理。本构建阶段只使用合成数据验证代码和合同，不读取患者级数据、不拟合真实模型、不产生研究结果。

## 1. 单一执行链

正式执行遵循：

```text
Registry lock -> Task DAG -> Stage targets -> Canonical results -> Publication outputs
```

运行 profile：

| Profile | 患者数据 | 科学模型 | 正式 release |
|---|---:|---:|---:|
| `build_validation` | 禁止 | 仅合成 smoke | 否 |
| `production` | 允许 | 允许 | 允许 |
| `release_only` | 禁止 | 禁止 | 允许 |

`release_only` 只能读取已批准的 aggregate canonical results。`--dry-run` 只解析 DAG、Schema、hash、输入存在性、预计输出和资源预算，不读取患者数据内容。

## 2. 数据来源合同

正式模型唯一读取 `original_frozen_completed_analysis_list.rds`。`.imp=0` 主分析队列、冻结暴露、Table 1、KM 和风险集来自 `original_frozen_mids.rds$data`。MI 结构与诊断元数据来自 `original_frozen_mids.rds`。20 套 CSV 和 long data 仅用于跨格式一致性审核。

禁止重新调用 `complete()` 生成正式模型数据，除非逐元素证明其与冻结 completed list 完全一致。上游 handoff 始终只读。

## 3. 人群与暴露

主暴露资格只由 `.imp=0` 中原始实测值定义：

```text
is.finite(AST) AND AST > 0
AND is.finite(ALT) AND ALT > 0
```

权威暴露为 `AST_ALT_original = AST_original / ALT_original`。A01 生成受限患者级暴露 identity 和仅含 hash ID 的审核统计。20 套完成数据中的 AST、ALT、AST_ALT 或三分位不得重新定义主暴露。

原始暴露恒等式使用 `all.equal(tolerance=1e-8)`；三分位组必须完全一致。切点来自 `.imp=0` 暴露合格队列的未四舍五入值，规则固定为：`x <= cut1` 为 T1，`cut1 < x <= cut2` 为 T2，`x > cut2` 为 T3。

连续模型使用 `X = log2(AST_ALT_original)`。per 1 SD、per doubling 和 per IQR 由同一模型的系数与协方差派生，不重复拟合。

## 4. 终点合同

| Endpoint | Event | Time | Estimand |
|---|---|---|---|
| All-cause death | `All_Cause_Death` | `Death_Followup_months` | Primary Cox |
| MACE | `MACE` | `MACE_Followup_months` | Supplementary Cox |
| CV/CBV death | `CV_CBV_Death` | `Death_Followup_months` | Cause-specific Cox |

事件编码固定为 1，删失固定为 0，时间单位为月，时间原点为基线。CV/CBV death 分析中，非目标原因死亡在死亡时间删失，不执行 Fine-Gray。

零、负或缺失随访时间，以及缺失结局，均为上游合同失败；不得加 epsilon、插补或静默删除。

## 5. Model 1-5

| Model | Covariates |
|---|---|
| M1 | Exposure only |
| M2 | M1 + `Age + Sex` |
| M3 | M2 + `Smoking + BMI + DM + HTN_bin + Dyslipidemia` |
| M4 | M3 + `Heart_Disease + HF_NYHA_bin + CVD + CKD_bin + COPD + Anemia` |
| M5 | M4 + `Rutherford_cat + Prior_LE_Surgery_cat + Surgery_Type_cat + Antihypertensive + Lipid_Lowering + Antiplatelet` |

Cox 固定使用 `ties="efron"`、95% CI、`na.action=na.fail`。不默认使用 robust variance、cluster、frailty 或 Center 调整。Center 永不进入关联模型，仅用于预设的 leave-one-center-out 影响性分析。

M1-M5 正文模型要求 20/20 套成功。M1-M4 不足 20/20 时暂停人工审核；M5 不足 20/20 为阻断。固定与 TVE 模型分别报告参数自由度、增加的 TVE 自由度、总有效自由度及 events/df。

### 5.1 A03 fit-once 与 VIF/GVIF 合同

A03 固定为 `20 imputations × 2 exposure forms` 的 40 个拟合分支；每个分支一次加载数据并按固定顺序首次拟合 M1-M5，总计划内 fixed Cox 拟合数为 200。scientific extraction、PH、设计矩阵诊断和 VIF/GVIF 必须读取同一拟合对象，禁止因 PH、VIF 或设计诊断重新拟合。硬门禁为：计划内拟合数恰为 200，诊断触发的额外拟合数均为 0。

VIF 和 GVIF 使用每个预设 fixed Cox 的系数相关矩阵及 Fox-Monette 公式，评价模型项之间的数值依赖；不使用辅助线性回归。它们不评价因果混杂或临床重要性，也不用于变量选择。阈值 2.5、5 和 10 仅为预注册的工程化审计分层，`threshold_type=HEURISTIC_DIAGNOSTIC`、`selection_effect=NONE`，不得据此删除变量、重编码、改变参考水平或修改公式。

数值路径固定为：相关矩阵对称化、finite/symmetry 检查、一次特征值可逆性检查、Cholesky 线性求解、仅在矩阵仍通过冻结门禁时采用对称特征分解 fallback，并使用 log-determinant 计算 GVIF。禁止显式构造完整逆矩阵、伪逆、运行时 ridge 或 epsilon 修复。容差固定为 QR `1e-12`、相对 SVD/eigen `1e-10`；满秩设计的条件数大于 `1e8` 进入数值稳定性审核，但不自动删除变量。

设计诊断与拟合后诊断使用双层缓存。设计层只复用 rank、alias、SVD、`design_condition_number_2`、零方差及父变量 df；拟合后层必须额外绑定 fit hash、covariance hash、endpoint 和 event-time identity，才能复用 VIF/GVIF。设计相同但结局、风险集或协方差不同的模型不得共享 GVIF。

每条诊断分别记录 `model_estimate_status`、`diagnostic_estimate_status` 和 `parent_estimability_status`。局部 VIF 不可定义不得覆盖可用的 Cox 或 PH 结果。冻结因子水平缺失时记录 expected/realized df、结构零列和局部状态；若 required parameter 或 D1 参数集合跨插补不一致，则保留全部已生成结果并进入阻断性人工审核。`protected=TRUE` 仅限制修改权限，不绕过秩、协方差或可逆性门禁。

## 6. PH 与 TVE

P01 只验证 PH 提取函数。A03 才对 20 套数据执行正式 PH 诊断。多水平变量按父变量 joint test 处理，不按单个 dummy 擅自改变模型。

主时间函数固定为：

```text
g12(t) = log1p(t) - log(13)
```

输入时间为月，不取整、不转换为天；必须满足 `abs(g12(12)) <= 1e-15`。每套插补先计算线性对比及包含 beta-gamma covariance 的完整方差，再执行 Rubin pooling。

其他协变量成为 nuisance TVE 的机械触发条件为：有效插补数 >=18、P<0.05 的插补数 >=16、方向一致率 >=0.80、median |rho| >=0.10。触发后只生成候选科学配置并进入人工审核，不直接修改冻结 registry。

## 7. MI pooling

单参数使用 Rubin scalar pooling。三分位 joint、多分类父变量、亚组交互、RCS overall 和 nonlinearity 使用 `pool_joint_wald_d1()` 对 `mice::D1()` 的锁定封装。

禁止平均 HR、系数或 P 值；禁止 Fisher 合并 P 值；禁止选一套插补完成 joint test。参数顺序、协方差顺序、自由度算法、最少有效插补数和奇异矩阵处理由 `multiparameter_pooling_registry.csv` 冻结。

## 8. RCS

RCS 仅评价平均函数形状，不替代 TVE，也不用于定义临床阈值。实现固定为 `Hmisc::rcspline.eval()`：

```text
quantile_type = 7
knot_probs = 0.05, 0.35, 0.65, 0.95
prediction_grid_n = 200
grid_scale = log2
reference = frozen median
extrapolation = prohibited
```

所有插补使用同一 knots、basis、参考值和预测网格。软件包版本写入 `renv.lock`。

RCS 结果只描述整个观察期内的平均暴露—结局函数形态。由于 AST/ALT 允许时间变化效应，该曲线不得解释为任一特定时间点的剂量—反应关系。

## 9. Table 1 与 KM

Table 1 和 KM 均使用 `.imp=0` 冻结暴露合格队列。Table 1 按可观察值描述并报告 missing N/%，不使用任意 completed dataset，也不平均 20 套结果。

展示和检验方法由 `table_registry.csv` 预锁定；正式运行不按 Shapiro-Wilk 动态切换。SMD 为主要描述，P 值仅作补充，不用于变量选择。

## 10. 阶段任务

| Stage | Required work |
|---|---|
| P00 | 环境、handoff 结构、资源、安全和 profile 预检 |
| P01 | Registry、Schema、函数及 PH 技术 smoke |
| P02 | 合成三级 canary；production 仅增加真实结构 canary，不拟合模型 |
| A01 | 冻结人群、暴露、切点、尺度、风险集、Table 1、KM |
| A02 | 插补分布、链、范围、偏移和 observed/missing profile QC |
| A03 | 40个fit-once分支、M1-M5 fixed Cox、正式PH、双层缓存VIF/GVIF和nuisance candidate |
| A04 | TVE、四时间点 HR、尺度恒等式和 pooled RCS |
| A05 | 11 个冻结亚组及 interaction |
| A06 | complete case、LOIO、LOCO、landmark、限制性及补充终点 |
| A07 | 只读 canonical results，导出 CSV/SVG/QMD/HTML；禁止科学拟合 |

## 11. Canonical result layer

结果分为三层：Layer 1 为受限模型对象和诊断；Layer 2 为无患者标识的 canonical numeric CSV；Layer 3 为论文表图和报告。A07 与 `release_only` 只能读取 Layer 2，不得从模型对象重新计算统计量。

A03 共线性长表的唯一权威文件为 `collinearity_per_imputation.csv.gz`；默认不建立 Parquet。未压缩体量超过 100 MB 时进入 `PARQUET_REVIEW_REQUIRED`，不得自动建立第二权威来源。正式 ST10 只读取 `collinearity_s10_results.csv`，集中展示 parent、两种暴露形式、median/P90/maximum、超过 2.5/5/10 的比例、最差插补、protected 与状态；`Adjusted GVIF = GVIF^(1/(2×Df))` 必须明确标注。A07 不得读取长表、vcov、模型矩阵或 fit records。

失败估计保留结构化行，必须填写 `estimate_status`、`not_estimable_reason_code` 和 detail。不得删除失败行、填入 0/Inf、合并水平或自动修改模型。

## 12. 敏感性和补充分析

Tier A 固定包含 fixed/TVE、替代时间函数、多尺度、complete case、observed-QC subset、LOIO、替代肾功能/贫血表达、LOCO、RCS 稳定性、药物移除、pre-treatment-only、minimal model 和 MI information diagnostics。

Tier B 固定包含 30/90 天 landmark、正常转氨酶限制、AST/ALT 组成分析、两个补充终点和关键亚组三分位描述。LOIO 每轮删除一整套插补并对剩余 19 套重新 pooling；LOCO 每轮删除一个 Center，但 Center 仍不得进入模型。

## 13. 输出合同

正式输出为 6 张正文 CSV、6 张正文 SVG、32 张补充 CSV 和 18 张补充 SVG。每个条目必须有英文标题、中文说明、核心指标、位置和 QC。所有 SVG 由 R 生成，白色背景、无网格，并配套 figure-data CSV 与 hash sidecar。

P 值同时保存 numeric 与 display 字段。显著性符号由统一函数从 canonical P 值生成，SVG 不得重新计算。

## 14. 报告与解释

最终 QMD 设置 `execute: enabled: false`，只读取正式 CSV、SVG、manifest 和静态代码附录。A07 不得执行 `coxph()`、PH、RCS、亚组拟合或 pooling。

主结论基于时间特异性关联；固定 HR 在 PH 违反时仅为平均参考；RCS 不提供阈值；亚组依据 interaction 而非组内 P 值；补充终点不升级为主结论。

## 15. 集中人工审核包

每一阶段均生成单独审核目录；runner 还必须在每次阶段结束后刷新唯一累计包：

```text
human_review/consolidated/AST_ALT_HUMAN_REVIEW_<run_id>.zip
```

累计包必须集中包含：P00–A07 状态矩阵、全部 acceptance/QC/warning、关键汇总结果、expected-vs-actual outputs、配置差异、偏离与缓存审计、软件包与 session 信息、各阶段决定模板、隐私/路径 QC。A07 后还必须包含脱敏的 `publication_outputs/`，其中汇总全部正文/补充 CSV、SVG、figure-data、hash sidecar、QMD/HTML 与 publication manifest。

集中审核包不得包含 `Patient_ID`、患者级记录、受限模型对象、绝对本机路径或 restricted cache。只有发生阻断性 warning、科学配置候选或 `stagewise` 模式时，填写并签署相应 `REVIEW_DECISION_<STAGE>.json`；自动通过阶段保留空模板用于审计，不得伪造人工批准。

## 16. 完成状态

允许的 completion class：

```text
COMPLETE_ALL_REQUIRED
COMPLETE_PRIMARY_WITH_DECLARED_SUPPLEMENTARY_LIMITATIONS
INCOMPLETE_REQUIRED_OUTPUTS
```

正文 required 输出缺失时只能标记 `INCOMPLETE_REQUIRED_OUTPUTS`。部分补充分析按预设规则 `not_estimable` 不等同于主分析失败。
