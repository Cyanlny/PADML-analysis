# 注册表生成脚本仅用于构建冻结配置，不读取患者数据。
options(stringsAsFactors = FALSE)

root <- normalizePath(file.path(dirname(commandArgs(trailingOnly = FALSE)[grep("--file=", commandArgs(trailingOnly = FALSE))]), ".."), mustWork = FALSE)
if (!dir.exists(file.path(root, "config"))) root <- normalizePath(".")

# 生成全部预注册 estimand，禁止正式运行时临时扩展。
endpoints <- data.frame(
  endpoint = c("All_Cause_Death", "MACE", "CV_CBV_Death"),
  endpoint_role = c("primary", "supplementary", "supplementary"),
  time_variable = c("Death_Followup_months", "MACE_Followup_months", "Death_Followup_months"),
  stringsAsFactors = FALSE
)
models <- paste0("M", 1:5)
times <- c(6, 12, 24, 36)

rows <- list()
add_row <- function(...) rows[[length(rows) + 1L]] <<- data.frame(..., stringsAsFactors = FALSE)

for (i in seq_len(nrow(endpoints))) {
  ep <- endpoints[i, ]
  for (model in models) {
    for (contrast in c("T2_vs_T1", "T3_vs_T1")) {
      add_row(
        estimand_id = paste(ep$endpoint, "FIXED_TERTILE", model, contrast, sep = "__"),
        endpoint = ep$endpoint, endpoint_role = ep$endpoint_role,
        analysis_population = "MAIN_EXPOSURE_ELIGIBLE",
        exposure_parameterization = "AST_ALT_TERTILE", contrast = contrast,
        model_id = model, time_month = NA_integer_, estimand_type = "FIXED_HR",
        pooling_method = "Rubin_scalar", primary_secondary = ep$endpoint_role,
        required = ep$endpoint == "All_Cause_Death",
        output_table_id = if (ep$endpoint == "All_Cause_Death") "MT02" else "ST30",
        output_figure_id = NA_character_
      )
    }
    for (scale in c("PER_1_SD", "PER_DOUBLING", "PER_IQR")) {
      add_row(
        estimand_id = paste(ep$endpoint, "FIXED_CONTINUOUS", model, scale, sep = "__"),
        endpoint = ep$endpoint, endpoint_role = ep$endpoint_role,
        analysis_population = "MAIN_EXPOSURE_ELIGIBLE",
        exposure_parameterization = "LOG2_AST_ALT", contrast = scale,
        model_id = model, time_month = NA_integer_, estimand_type = "FIXED_HR",
        pooling_method = "Rubin_scalar", primary_secondary = ep$endpoint_role,
        required = ep$endpoint == "All_Cause_Death",
        output_table_id = if (ep$endpoint == "All_Cause_Death") "MT04" else "ST30",
        output_figure_id = NA_character_
      )
    }
    for (tm in times) {
      for (contrast in c("T2_vs_T1", "T3_vs_T1")) {
        add_row(
          estimand_id = paste(ep$endpoint, "TVE_TERTILE", model, contrast, paste0("M", tm), sep = "__"),
          endpoint = ep$endpoint, endpoint_role = ep$endpoint_role,
          analysis_population = "MAIN_EXPOSURE_ELIGIBLE",
          exposure_parameterization = "AST_ALT_TERTILE", contrast = contrast,
          model_id = model, time_month = tm, estimand_type = "TIME_SPECIFIC_HR",
          pooling_method = "Rubin_scalar", primary_secondary = ep$endpoint_role,
          required = ep$endpoint == "All_Cause_Death",
          output_table_id = if (ep$endpoint == "All_Cause_Death") "MT03" else "ST30",
          output_figure_id = if (ep$endpoint == "All_Cause_Death" && model == "M5") "MF03" else NA_character_
        )
      }
      for (scale in c("PER_1_SD", "PER_DOUBLING", "PER_IQR")) {
        add_row(
          estimand_id = paste(ep$endpoint, "TVE_CONTINUOUS", model, scale, paste0("M", tm), sep = "__"),
          endpoint = ep$endpoint, endpoint_role = ep$endpoint_role,
          analysis_population = "MAIN_EXPOSURE_ELIGIBLE",
          exposure_parameterization = "LOG2_AST_ALT", contrast = scale,
          model_id = model, time_month = tm, estimand_type = "TIME_SPECIFIC_HR",
          pooling_method = "Rubin_scalar", primary_secondary = ep$endpoint_role,
          required = ep$endpoint == "All_Cause_Death",
          output_table_id = if (ep$endpoint == "All_Cause_Death") "MT04" else "ST30",
          output_figure_id = if (ep$endpoint == "All_Cause_Death" && model == "M5" && scale == "PER_1_SD") "MF04" else NA_character_
        )
      }
    }
  }
}

for (joint in c("TERTILE_FIXED_JOINT", "TERTILE_TIME_JOINT", "TERTILE_ANY_TIME_JOINT", "RCS_OVERALL", "RCS_NONLINEARITY")) {
  add_row(
    estimand_id = paste("All_Cause_Death", joint, "M5", sep = "__"),
    endpoint = "All_Cause_Death", endpoint_role = "primary",
    analysis_population = "MAIN_EXPOSURE_ELIGIBLE",
    exposure_parameterization = if (grepl("RCS", joint)) "RCS_LOG2_AST_ALT" else "AST_ALT_TERTILE",
    contrast = joint, model_id = "M5", time_month = NA_integer_, estimand_type = "JOINT_TEST",
    pooling_method = "D1_pooled_Wald", primary_secondary = "primary", required = TRUE,
    output_table_id = if (grepl("RCS", joint)) "ST16" else "ST11",
    output_figure_id = if (grepl("RCS", joint)) "MF05" else NA_character_
  )
}

estimands <- do.call(rbind, rows)
estimands <- estimands[order(estimands$endpoint, estimands$model_id, estimands$estimand_id), ]
row.names(estimands) <- NULL
write.csv(estimands, file.path(root, "config", "estimand_registry.csv"), row.names = FALSE, na = "")

# `output_registry.csv`在r01升级时已扩展为逐项来源、Schema、figure-data、尺寸、
# 注释规则和producer/publication stage合同。这里仅验证，不再用旧简化模板覆盖它。
output_path <- file.path(root, "config", "output_registry.csv")
if (!file.exists(output_path)) stop("Frozen output_registry.csv is missing", call. = FALSE)
output_registry <- read.csv(output_path, stringsAsFactors = FALSE, check.names = FALSE)
required_columns <- c(
  "output_id", "location", "file_name", "title_en", "title_cn", "required", "format",
  "core_indicators", "content_cn", "schema_id", "source_cache", "source_canonical_file",
  "analysis_id", "estimand_id", "figure_data_csv", "figure_data_hash_sidecar",
  "producer_stage", "publication_stage"
)
if (!all(required_columns %in% names(output_registry))) stop("Frozen output registry schema is incomplete", call. = FALSE)
expected_counts <- c(main_table = 6L, main_figure = 6L, supp_table = 32L, supp_figure = 18L)
actual_counts <- table(factor(output_registry$location, levels = names(expected_counts)))
if (!identical(as.integer(actual_counts), as.integer(expected_counts))) stop("Frozen output registry counts are incorrect", call. = FALSE)
if (anyDuplicated(output_registry$output_id) || anyDuplicated(output_registry$file_name)) stop("Frozen output registry IDs or filenames are duplicated", call. = FALSE)
message("Frozen estimand registry regenerated; extended output registry validated without overwrite.")
