# v4.3 sealed request 构建器：本地绑定代码、runtime、handoff、五 epoch 与用户授权 receipt。

args <- commandArgs(trailingOnly = TRUE)
bootstrap_root <- normalizePath(if (file.exists("AGENTS.md")) "." else "..", mustWork = TRUE)
source(file.path(bootstrap_root, "R", "control_kernel.R"))
source(file.path(bootstrap_root, "remote", "remote_contract.R"))
parsed <- remote_parse_strict_named_args(
  args,
  allowed = c(
    "--project-root", "--run-root", "--code-bundle", "--runtime-bundle",
    "--profile", "--run-id", "--execution-mode", "--handoff-zip",
    "--approval-id", "--authorization-receipt", "--output"
  ),
  required = c(
    "--project-root", "--run-root", "--code-bundle", "--runtime-bundle",
    "--profile", "--run-id", "--execution-mode", "--output"
  )
)
value <- function(flag, default = "") if (is.null(parsed[[flag]])) default else parsed[[flag]]

project_root <- normalizePath(value("--project-root"), mustWork = TRUE)
run_root <- normalizePath(value("--run-root"), mustWork = FALSE)
code_archive <- normalizePath(value("--code-bundle"), mustWork = TRUE)
runtime_archive <- normalizePath(value("--runtime-bundle"), mustWork = TRUE)
profile <- value("--profile")
run_id <- value("--run-id")
execution_mode <- value("--execution-mode")
handoff_zip <- value("--handoff-zip")
approval_id <- value("--approval-id")
authorization_path <- value("--authorization-receipt")
output_path <- value("--output")

if (!profile %in% c("build_validation", "production", "release_only")) {
  .remote_stop("REMOTE_REQUEST_PROFILE_INVALID")
}
if (!execution_mode %in% c("continuous", "stagewise") || !grepl("^[A-Za-z0-9._-]+$", run_id)) {
  .remote_stop("REMOTE_REQUEST_RUN_ID_OR_MODE_INVALID")
}
if (identical(profile, "production") && (!nzchar(handoff_zip) || !nzchar(approval_id))) {
  .remote_stop("REMOTE_PRODUCTION_HANDOFF_REQUIRED")
}
if (!identical(profile, "production") && (nzchar(handoff_zip) || nzchar(approval_id))) {
  .remote_stop("REMOTE_NONPRODUCTION_HANDOFF_FORBIDDEN")
}

code_sha <- remote_sha256_file(code_archive)
runtime_sha <- remote_sha256_file(runtime_archive)
code <- verify_remote_bundle_archive(code_archive, code_sha, "CODE_BUNDLE")
runtime <- verify_remote_bundle_archive(runtime_archive, runtime_sha, "RUNTIME_BUNDLE")

source(file.path(project_root, "R", "authority_engine.R"))
source(file.path(project_root, "R", "epoch_guard.R"))
source(file.path(project_root, "R", "runner_control.R"))
source(file.path(project_root, "R", "source_input_adapter.R"))
source(file.path(project_root, "R", "data_handoff_engine.R"))
local_git <- git_worktree_identity(project_root)
if (length(local_git$changed_paths) ||
    !identical(local_git$git_commit, code$origin_git_commit) ||
    !identical(local_git$git_tree, code$origin_git_tree)) {
  .remote_stop("REMOTE_CODE_BUNDLE_LOCAL_GIT_MISMATCH")
}

old_runtime_identity <- Sys.getenv("AST_ALT_VERIFIED_RUNTIME_IDENTITY_SHA256", unset = NA_character_)
on.exit({
  if (is.na(old_runtime_identity)) {
    Sys.unsetenv("AST_ALT_VERIFIED_RUNTIME_IDENTITY_SHA256")
  } else {
    Sys.setenv(AST_ALT_VERIFIED_RUNTIME_IDENTITY_SHA256 = old_runtime_identity)
  }
}, add = TRUE)
Sys.setenv(AST_ALT_VERIFIED_RUNTIME_IDENTITY_SHA256 = runtime$runtime_identity_sha256)

handoff_identity <- NULL
if (identical(profile, "production")) {
  handoff_zip <- normalizePath(handoff_zip, mustWork = TRUE)
  handoff_identity <- resolve_approved_handoff(handoff_zip, project_root)$identity
  if (!identical(as.character(handoff_identity$approval_id), approval_id)) {
    .remote_stop("REMOTE_HANDOFF_APPROVAL_ID_MISMATCH")
  }
}
epoch_bundle <- .runner_compute_epoch_bundle(
  profile = profile,
  project_root = project_root,
  run_root = run_root,
  handoff_zip = handoff_zip,
  dry_run = FALSE
)
digests <- authority_digests(epoch_bundle$contract_index, project_root)
restricted_input <- if (identical(profile, "production")) {
  list(
    kind = "APPROVED_HANDOFF",
    archive_sha256 = handoff_identity$handoff_sha256,
    approval_id = handoff_identity$approval_id,
    source_epoch = handoff_identity$source_epoch
  )
} else if (identical(profile, "build_validation")) {
  list(
    kind = "SYNTHETIC_FIXTURE",
    archive_sha256 = epoch_bundle$source_handoff_sha256,
    approval_id = "",
    source_epoch = epoch_bundle$epochs$source
  )
} else {
  list(kind = "NONE", archive_sha256 = "", approval_id = "", source_epoch = epoch_bundle$epochs$source)
}

payload <- list(
  schema_version = "1.0.0",
  request_type = "REMOTE_EXECUTION_V43",
  revision = "v4.3-r00",
  run_id = run_id,
  execution_profile = profile,
  execution_mode = execution_mode,
  runtime_profile_id = "AUTODL_UBUNTU2204_V43",
  code_bundle = remote_bundle_request_identity(c(code, list(archive_sha256 = code_sha))),
  runtime_bundle = remote_bundle_request_identity(c(runtime, list(archive_sha256 = runtime_sha))),
  restricted_input = restricted_input,
  epochs = epoch_bundle$epochs,
  reachable_authority_slice_sha256 = digests$reachable_authority_slice_digest,
  exact_consumer_set_sha256 = digests$exact_consumer_set_digest,
  authorization_receipt_sha256 = ""
)
request <- finalize_remote_execution_request(payload)
request_status <- "READY_NONPRODUCTION"
if (identical(profile, "production")) {
  if (nzchar(authorization_path)) {
    authorization_path <- normalizePath(authorization_path, mustWork = TRUE)
    payload$authorization_receipt_sha256 <- remote_sha256_file(authorization_path)
    request <- finalize_remote_execution_request(payload)
    validate_remote_execution_request(request, authorization_path = authorization_path)
    request_status <- "READY_FOR_PRODUCTION_ADMISSION"
  } else {
    request_status <- "WAITING_FOR_RUN_PRODUCTION_P00_A07_AUTHORIZATION"
  }
} else {
  validate_remote_execution_request(request)
}

if (file.exists(output_path)) .remote_stop("REMOTE_REQUEST_OUTPUT_EXISTS")
# 原子写入本地 sealed request；production 未授权时保持不可 admission 状态。
.remote_write_atomic(output_path, remote_canonical_json(request), mode = "0600")
cat(paste(
  paste0("status=", request_status),
  paste0("request_sha256=", request$request_sha256),
  paste0("request_semantic_sha256=", request$request_semantic_sha256),
  paste0("production_authorized=", identical(request_status, "READY_FOR_PRODUCTION_ADMISSION")),
  sep = "\n"
), "\n", sep = "")
