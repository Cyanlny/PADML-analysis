# 唯一上游入口：读取私有 Excel，发布受限审计或候选 handoff；正式 P00–A07 不调用本脚本。
args <- commandArgs(trailingOnly = TRUE)
project_root <- normalizePath(".", mustWork = TRUE)
source(file.path(project_root, "R", "source_input_adapter.R"))
result <- prepare_source_handoff_main(args, project_root)
if (is.list(result) && !is.null(result$mode)) {
  message("SOURCE_PREPARATION_TERMINAL=", toupper(gsub("-", "_", result$mode, fixed = TRUE)))
  if (!is.null(result$status)) message("SOURCE_PREPARATION_STATUS=", result$status)
  if (!is.null(result$reason_code)) message("SOURCE_PREPARATION_REASON_CODE=", result$reason_code)
  if (!is.null(result$request_sha256)) message("SOURCE_PREPARATION_REQUEST_SHA256=", result$request_sha256)
  if (!is.null(result$primary_next_action)) message("SOURCE_PREPARATION_NEXT_ACTION=", result$primary_next_action)
  if (identical(result$status, "EXTERNAL_INPUT_BLOCKED")) quit(save = "no", status = 20L)
}
