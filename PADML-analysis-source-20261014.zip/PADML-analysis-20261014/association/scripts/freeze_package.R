# v4.3-r15 非生产 source-tree 冻结脚本；final commit/tree 由 post-commit external evidence 另行实测。

freeze_scientific_mask_v43 <- function(relative_path) {
  patterns <- c(
    "^Main[.]md$",
    "^protocol/(amendments|decisions/(approved|pending))/",
    paste0(
      "^config/(contract_index|endpoint_registry|exposure_registry|model_registry|",
      "estimand_registry|timepoint_registry|subgroup_registry|sensitivity_registry|",
      "ph_rule_registry|multiparameter_pooling_registry|not_estimable_reason_registry|",
      "qc_gate_registry|scientific_question_output_map|",
      "collinearity_registry|collinearity_decision_matrix|output_registry|",
      "output_recipe_registry|canonical_value_applicability_registry)[.]csv$"
    ),
    "^config/vif_addendum_downstream_impact_manifest[.]json$",
    paste0(
      "^R/(canonical_results|model_signature|pooling_engine|tve_engine|rcs_engine|",
      "collinearity_engine|publication_renderer)[.]R$"
    )
  )
  Reduce(`|`, lapply(patterns, grepl, x = relative_path, perl = TRUE))
}

freeze_execution_mask_v43 <- function(relative_path) {
  patterns <- c(
    "^AGENTS[.]md$", "^agents/", "^_targets/", "^scripts/", "^schemas/",
    "^remote/", "^R/", "^config/", "^templates/", "^report/", "^protocol/",
    "^tests/", "^renv([.]lock|/)", "^[.]Rprofile$", "^Makefile$", "^Main[.]md$",
    "^BUILD_VALIDATION_REPORT[.]md$", "^CHANGELOG_v4[.]3-r15[.]md$",
    "(^|/)(RUNBOOK|START_HERE|EXECUTION_ORDER)"
  )
  Reduce(`|`, lapply(patterns, grepl, x = relative_path, perl = TRUE))
}

.freeze_build_report_valid_v43 <- function(report) {
  is.character(report) && length(report) == 1L && !is.na(report) &&
    grepl("Status: PASS_SYNTHETIC_BUILD_VALIDATION", report, fixed = TRUE) &&
    grepl("- Build revision: v4.3-r15", report, fixed = TRUE)
}

.freeze_publish_set_atomic_v43 <- function(
    staged_paths, final_paths, rename_fun = file.rename) {
  if (!length(staged_paths) || length(staged_paths) != length(final_paths) ||
      any(!file.exists(staged_paths)) || any(file.exists(final_paths))) {
    stop("V43_R15_FREEZE_PUBLISH_PRECONDITION_FAILED", call. = FALSE)
  }
  parents <- unique(normalizePath(dirname(final_paths), mustWork = TRUE))
  if (length(parents) != 1L) stop("V43_R15_FREEZE_DESTINATION_SPLIT", call. = FALSE)
  lease <- file.path(parents, ".freeze-v4.3-r15.publish.lock")
  if (!dir.create(lease, showWarnings = FALSE)) stop("V43_R15_FREEZE_PUBLISH_LOCKED", call. = FALSE)
  on.exit(if (dir.exists(lease)) unlink(lease, recursive = TRUE), add = TRUE)
  published <- character()
  for (index in seq_along(staged_paths)) {
    if (!isTRUE(rename_fun(staged_paths[[index]], final_paths[[index]]))) {
      if (length(published)) unlink(published, force = TRUE)
      stop("V43_R15_FREEZE_ATOMIC_PUBLISH_FAILED", call. = FALSE)
    }
    published <- c(published, final_paths[[index]])
  }
  invisible(final_paths)
}

freeze_source_inventory_v43 <- function(root) {
  output <- suppressWarnings(system2(
    "git",
    c(
      "-C", shQuote(root), "-c", "core.quotepath=false", "ls-files",
      "--cached", "--others", "--exclude-standard"
    ),
    stdout = TRUE, stderr = TRUE
  ))
  if (!is.null(attr(output, "status")) || !length(output) || any(!nzchar(output)) ||
      anyDuplicated(output) || any(grepl("^/|^[A-Za-z]:|(^|/)[.][.](/|$)|[\r\n]", output, perl = TRUE))) {
    stop("V43_R15_FREEZE_GIT_INVENTORY_INVALID", call. = FALSE)
  }
  relative <- sort(gsub("\\\\", "/", enc2utf8(output)), method = "radix")
  files <- file.path(root, relative)
  if (any(!file.exists(files)) || any(file.info(files)$isdir) || any(nzchar(Sys.readlink(files)))) {
    stop("V43_R15_FREEZE_GIT_INVENTORY_FILE_INVALID", call. = FALSE)
  }
  list(relative = relative, files = files)
}

freeze_package_v43_r15 <- function(root = ".") {
  # 中文备注：加载摘要包以生成 source-tree SHA-256 快照。
  if (!requireNamespace("digest", quietly = TRUE)) stop("digest is required", call. = FALSE)
  # 中文备注：加载 JSON 包以写入 production_ready=false 的冻结收据。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  root <- normalizePath(root, mustWork = TRUE)
  report_path <- file.path(root, "BUILD_VALIDATION_REPORT.md")
  report <- if (file.exists(report_path)) paste(readLines(report_path, warn = FALSE), collapse = "\n") else ""
  if (!.freeze_build_report_valid_v43(report)) {
    stop("V43_R15_SYNTHETIC_BUILD_VALIDATION_NOT_PASS", call. = FALSE)
  }
  output_names <- c(
    "scientific_contract_snapshot_v4.3-r15.sha256",
    "execution_contract_snapshot_v4.3-r15.sha256",
    "protocol_content_snapshot_v4.3-r15.sha256",
    "PACKAGE_MANIFEST_v4.3-r15.csv",
    "FREEZE_STATUS_v4.3-r15.json"
  )
  output_paths <- file.path(root, output_names)
  if (any(file.exists(output_paths))) stop("V43_R15_FREEZE_OUTPUT_EXISTS", call. = FALSE)
  excluded <- paste0(
    "(^|/)([.]git|cache|tmp|runtime|release|approved_cache|candidate_cache|human_review|runs|",
    "data_raw|source_packages|remote_build|preproduction_validation|logs)(/|$)|tests/output|",
    "(^|/)restricted_cache/(?!README_SECURITY[.]md)|[.]DS_Store$|__MACOSX|",
    "(^|/)([.]env([.]|$)|.*(credential|password|passwd|token).*|id_(rsa|ed25519).*|.*[.](pem|key))$|",
    "^(FREEZE_STATUS(_v[^/]+)?[.]json|PACKAGE_MANIFEST_v[^/]+[.]csv|",
    ".*_snapshot(_v[^/]+)?[.]sha256)$"
  )
  inventory <- freeze_source_inventory_v43(root)
  files <- inventory$files
  relative <- inventory$relative
  keep <- !grepl(excluded, relative, perl = TRUE)
  files <- files[keep]
  relative <- relative[keep]
  ordering <- order(relative, method = "radix")
  files <- files[ordering]
  relative <- relative[ordering]
  sha256 <- vapply(files, function(path) {
    digest::digest(file = path, algo = "sha256", serialize = FALSE)
  }, character(1))
  scientific <- freeze_scientific_mask_v43(relative)
  execution <- freeze_execution_mask_v43(relative)
  required_scientific <- c(
    "config/contract_index.csv", "config/ph_rule_registry.csv",
    "config/qc_gate_registry.csv", "config/not_estimable_reason_registry.csv",
    "config/scientific_question_output_map.csv", "config/collinearity_registry.csv",
    "config/collinearity_decision_matrix.csv",
    "config/vif_addendum_downstream_impact_manifest.json",
    "R/canonical_results.R",
    "protocol/decisions/pending/RUBIN_DF_ZERO_INFORMATION_V43_001.json",
    "protocol/decisions/approved/RUBIN_DF_ZERO_INFORMATION_V43_001_SELECTION.json",
    "config/canonical_value_applicability_registry.csv",
    "protocol/decisions/pending/CANONICAL_STRUCTURAL_NA_V43_001.json",
    "protocol/decisions/approved/CANONICAL_STRUCTURAL_NA_V43_001_SELECTION.json"
  )
  required_execution <- c("AGENTS.md", "R/stage_execution.R", "scripts/run_pipeline.R")
  if (!all(required_scientific %in% relative[scientific]) ||
      !all(required_execution %in% relative[execution])) {
    stop("V43_R15_FREEZE_MASK_INCOMPLETE", call. = FALSE)
  }
  staging_root <- tempfile("freeze-v4.3-r15-", tmpdir = root)
  dir.create(staging_root, mode = "0700")
  on.exit(if (dir.exists(staging_root)) unlink(staging_root, recursive = TRUE), add = TRUE)
  staged_paths <- file.path(staging_root, output_names)
  write_snapshot <- function(mask, path) {
    lines <- paste(relative[mask], sha256[mask], sep = "\t")
    writeLines(lines, path, useBytes = TRUE)
    digest::digest(paste(lines, collapse = "\n"), algo = "sha256", serialize = FALSE)
  }
  scientific_sha <- write_snapshot(scientific, staged_paths[[1L]])
  execution_sha <- write_snapshot(execution, staged_paths[[2L]])
  content_sha <- write_snapshot(rep(TRUE, length(relative)), staged_paths[[3L]])
  manifest <- data.frame(
    relative_path = relative, sha256 = sha256,
    size_bytes = as.character(file.info(files)$size), stringsAsFactors = FALSE
  )
  # 输出 v4.3-r15 source-tree inventory；排除患者数据、cache、bundle、凭据和冻结输出自身。
  utils::write.csv(manifest, staged_paths[[4L]], row.names = FALSE, na = "")
  output_registry <- utils::read.csv(
    file.path(root, "config", "output_registry.csv"),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  if (nrow(output_registry) != 62L || anyDuplicated(output_registry$output_id)) {
    stop("V43_R15_PUBLICATION_OUTPUT_CLOSURE_INVALID", call. = FALSE)
  }
  status <- list(
    schema_version = "1.1.0",
    build_revision = "v4.3-r15",
    scientific_execution_owner_revision = "v4.3-r00",
    freeze_status = "FROZEN_PREPRODUCTION_SOURCE_TREE_BUILD_VALIDATED",
    freeze_subject = "SOURCE_TREE_CONTENT_EXCLUDING_FREEZE_OUTPUTS_AND_EXTERNAL_VALIDATION_EVIDENCE",
    scientific_contract_sha256 = scientific_sha,
    execution_contract_sha256 = execution_sha,
    subject_tree_content_sha256 = content_sha,
    subject_file_count = length(relative),
    build_validation_status = "PASS_SYNTHETIC_ONLY",
    build_validation_report_sha256 = digest::digest(
      file = report_path, algo = "sha256", serialize = FALSE
    ),
    publication_output_count = nrow(output_registry),
    active_scientific_selections = c(
      "MI_PRED_1A", "SENS_PUB_1C", "RUTH_TVE_1C", "SEC_EP_1C", "RUBIN_DF_1A",
      "STRUCT_NA_1A"
    ),
    scientific_owner_change_authorized = FALSE,
    scientific_owner_change_scope =
      "NONE_R15_RUNTIME_HISTORICAL_INSTANCE_REQUEST_ROOT_IN_PINNED_R_PACKAGE_ELF_NOT_APPROVED_TECHNICAL_REPAIR_ONLY",
    inherited_scientific_selection_authorization_scope =
      "RUBIN_DF_1A_AND_STRUCT_NA_1A_ONLY_BY_EXPLICIT_USER_SELECTION_IN_V4.3_R01",
    production_ready = FALSE,
    run_formal_mice_handoff_authorized = FALSE,
    run_production_p00_a07_authorized = FALSE,
    formal_mice_executed = FALSE,
    autodl_production_started = FALSE,
    autodl_nonproduction_validation_status = "PENDING",
    active_gate = "REMOTE_NONPRODUCTION_VALIDATION_REQUIRED",
    final_commit_tree_binding = "PENDING_POST_COMMIT_EXTERNAL_SEALED_EVIDENCE",
    synthetic_run_state_claim_scope = "NAMED_BUILD_VALIDATION_RUN_ONLY_NOT_PRODUCTION_STAGE_EVIDENCE",
    real_patient_data_accessed = FALSE,
    real_analysis_executed = FALSE,
    real_results_generated = FALSE,
    production_results_available = FALSE,
    upstream_data_modified = FALSE
  )
  # 输出明确区分 build r15 与 scientific execution owner r00 的非生产冻结收据。
  writeLines(
    as.character(jsonlite::toJSON(status, auto_unbox = TRUE, pretty = TRUE)),
    staged_paths[[5L]], useBytes = TRUE
  )
  .freeze_publish_set_atomic_v43(staged_paths, output_paths)
  invisible(status)
}

if (sys.nframe() == 0L) freeze_package_v43_r15(normalizePath("."))
