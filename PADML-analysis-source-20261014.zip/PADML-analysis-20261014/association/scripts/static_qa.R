# 静态QA：检查协议、registry、代码与输出合同，不读取患者数据。

.is_documented_absolute_path_literal <- function(relative_path, line) {
  relative_path <- gsub("\\\\", "/", relative_path)
  r_scanner_literal <- identical(relative_path, "scripts/static_qa.R") &&
    grepl("grep|grepl", line, perl = TRUE) &&
    grepl("/Users/", line, fixed = TRUE)
  shell_scanner_literal <- identical(relative_path, "remote/verifier.sh") &&
    grepl("Patient_ID\\|/Users/", line, perl = TRUE) &&
    grepl("restricted_cache", line, fixed = TRUE)
  runtime_security_scanner_literal <- relative_path %in% c(
    "remote/assemble_runtime.sh",
    "remote/capture_runtime.R",
    "scripts/build_remote_execution_package.R"
  ) && (grepl("grep|grepl", line, perl = TRUE) ||
    grepl("\"(/Users/|/home/", line, fixed = TRUE)) &&
    grepl("/Users/", line, fixed = TRUE)
  negative_assertion <- startsWith(relative_path, "tests/") &&
    grepl("assert(_true)?\\s*\\(", line, perl = TRUE) &&
    grepl("!grepl\\(", line, perl = TRUE) &&
    grepl("/Users/", line, fixed = TRUE)
  explicit_negative_fixture <- startsWith(relative_path, "tests/") &&
    grepl("(writeLines|writeBin|charToRaw).*?/Users/example/", line, perl = TRUE)
  runtime_package_negative_fixture <-
    identical(relative_path, "tests/test_remote_package_v43.R") &&
    grepl("public upstream example /Users/example/project", line, fixed = TRUE)
  r_scanner_literal || shell_scanner_literal || runtime_security_scanner_literal ||
    negative_assertion || explicit_negative_fixture || runtime_package_negative_fixture
}
run_static_qa <- function(root = ".") {
  # 加载JSON包以验证Schema文件。
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required", call. = FALSE)
  # 加载YAML包以验证运行预算。
  if (!requireNamespace("yaml", quietly = TRUE)) stop("yaml is required", call. = FALSE)

  checks <- list()
  add <- function(item, pass, detail) checks[[length(checks) + 1L]] <<- data.frame(qc_item = item, status = if (isTRUE(pass)) "PASS" else "FAIL", details = detail, stringsAsFactors = FALSE)

  output <- utils::read.csv(file.path(root, "config", "output_registry.csv"), stringsAsFactors = FALSE)
  add("main_table_count", sum(output$location == "main_table") == 6L, sum(output$location == "main_table"))
  add("main_figure_count", sum(output$location == "main_figure") == 6L, sum(output$location == "main_figure"))
  add("supp_table_count", sum(output$location == "supp_table") == 36L, sum(output$location == "supp_table"))
  add("supp_figure_count", sum(output$location == "supp_figure") == 29L, sum(output$location == "supp_figure"))
  add("logical_output_closure_77", nrow(output) == 77L && sum(output$format == "CSV") == 42L && sum(output$format == "SVG") == 35L, paste(nrow(output), sum(output$format == "CSV"), sum(output$format == "SVG"), sep = "|"))
  add("physical_main_file_contract_147", sum(output$format == "CSV") + 3L * sum(output$format == "SVG") == 147L, sum(output$format == "CSV") + 3L * sum(output$format == "SVG"))
  add("formal_formats_csv_svg", all(output$format %in% c("CSV", "SVG")), paste(unique(output$format), collapse = "|"))
  add("bilingual_output_metadata", all(nzchar(output$title_en) & nzchar(output$title_cn) & nzchar(output$content_cn)), "English title and Chinese description present")
  provenance_fields <- c(
    "schema_id", "source_cache", "source_canonical_file", "analysis_id", "estimand_id",
    "model_signature_sha256", "figure_data_csv", "figure_data_hash_sidecar", "producer_stage", "publication_stage"
  )
  add("output_registry_provenance_schema", all(provenance_fields %in% names(output)), paste(setdiff(provenance_fields, names(output)), collapse = "|"))
  add("output_registry_unique_ids", !anyDuplicated(output$output_id) && !anyDuplicated(output$file_name), "output_id and file_name are unique")

  required_configs <- c(
    "data_source_registry.csv", "endpoint_registry.csv", "estimand_registry.csv", "model_registry.csv",
    "multiparameter_pooling_registry.csv", "not_estimable_reason_registry.csv", "runtime_budget.yml",
    "collinearity_registry.csv", "collinearity_decision_matrix.csv",
    "canonical_value_applicability_registry.csv", "canonical_abi_registry.csv",
    "diagnostic_extension_registry.csv", "cutoff_registry.csv",
    "stage_execution_registry.csv", "stage_artifact_registry.csv",
    "identity_slice_registry.csv", "vif_addendum_downstream_impact_manifest.json"
  )
  add("required_config_files", all(file.exists(file.path(root, "config", required_configs))), paste(required_configs[!file.exists(file.path(root, "config", required_configs))], collapse = "|"))
  yaml::read_yaml(file.path(root, "config", "runtime_budget.yml"))

  json_files <- list.files(file.path(root, "schemas"), pattern = "\\.json$", full.names = TRUE)
  json_ok <- vapply(json_files, function(path) !inherits(try(jsonlite::read_json(path), silent = TRUE), "try-error"), logical(1))
  add("json_schemas_parse", all(json_ok), paste(basename(json_files[!json_ok]), collapse = "|"))

  r_files <- list.files(root, pattern = "\\.R$", recursive = TRUE, full.names = TRUE)
  r_files <- r_files[!grepl("tests/output|approved_cache|release", r_files)]
  parse_ok <- vapply(r_files, function(path) !inherits(try(parse(path), silent = TRUE), "try-error"), logical(1))
  add("r_files_parse", all(parse_ok), paste(basename(r_files[!parse_ok]), collapse = "|"))

  stage_ids <- c("P00", paste0("A0", 1:7))
  target_files <- file.path(root, "_targets", paste0(stage_ids, "_targets.R"))
  target_layers_ok <- vapply(seq_along(target_files), function(i) {
    text <- paste(readLines(target_files[[i]], warn = FALSE), collapse = "\n")
    stage <- stage_ids[[i]]
    required <- if (identical(stage, "P00")) {
      c(paste0(stage, "_analysis"), paste0(stage, "_qc"), paste0(stage, "_status"), paste0(stage, "_stage_result"))
    } else {
      c(paste0(stage, "_analysis"), paste0(stage, "_qc"), paste0(stage, "_artifacts"), paste0(stage, "_stage_result"))
    }
    all(vapply(required, grepl, logical(1), x = text, fixed = TRUE))
  }, logical(1))
  add("stage_targets_real_dag_layers", all(target_layers_ok), paste(stage_ids[!target_layers_ok], collapse = "|"))

  qmd_files <- list.files(root, pattern = "\\.qmd$", recursive = TRUE, full.names = TRUE)
  qmd_text <- if (length(qmd_files)) unlist(lapply(qmd_files, readLines, warn = FALSE), use.names = FALSE) else character()
  add("qmd_execution_disabled", !any(grepl("eval:[[:space:]]*true|enabled:[[:space:]]*true", qmd_text, ignore.case = TRUE)), "No executable scientific QMD chunks")

  active_files <- list.files(root, recursive = TRUE, full.names = TRUE)
  active_files <- active_files[file.info(active_files)$isdir %in% FALSE]
  active_files <- active_files[!grepl("CHANGELOG|docs/revision_log|tests/output|protocol_.*sha256", active_files)]
  # 运行输入、挂载审计、缓存与发布产物不属于冻结 active contract；其隐私由阶段和 A07 专用 gate 检查。
  operational_pattern <- paste0(
    "(^|/)(runtime|restricted_cache|data_raw|source_packages|cache|approved_cache|",
    "candidate_cache|human_review|runs|release|remote_build|preproduction_validation|logs)(/|$)"
  )
  active_files <- active_files[!grepl(operational_pattern, active_files)]
  # Python 导入缓存是可重建二进制，不属于 active contract，也不得按 UTF-8 文本扫描。
  active_files <- active_files[!grepl("(^|/)__pycache__(/|$)|[.]py[co]$", active_files)]
  # QA扫描器必须保存禁用词模式，因此不将自身计入active contract命中。
  active_files <- active_files[basename(active_files) != "static_qa.R"]
  legacy_terms <- c("Elastic Net", "Random Survival Forest", "XGBoost", "SHAP", "nested cross-validation", "time-dependent AUC", "Brier score", "decision curve", "config/ml", "schemas/ml", "ML_FULL_REPORT")
  legacy_hit <- function(term, text) {
    if (identical(term, "SHAP")) {
      return(any(grepl("(^|[^[:alnum:]_])SHAP([^[:alnum:]_]|$)", text, perl = TRUE)))
    }
    any(grepl(term, text, fixed = TRUE))
  }
  legacy_hits <- character()
  for (path in active_files) {
    if (grepl("\\.(rds|svg|png|pdf|zip)$", path, ignore.case = TRUE)) next
    text <- try(readLines(path, warn = FALSE, encoding = "UTF-8"), silent = TRUE)
    if (inherits(text, "try-error")) next
    if (any(vapply(legacy_terms, legacy_hit, logical(1), text = text))) legacy_hits <- c(legacy_hits, path)
  }
  add("active_legacy_extension_count_zero", length(legacy_hits) == 0L, paste(basename(legacy_hits), collapse = "|"))

  absolute_hits <- character()
  normalized_root <- normalizePath(root, mustWork = TRUE)
  root_prefix <- paste0(normalized_root, .Platform$file.sep)
  for (path in active_files) {
    if (grepl("\\.(rds|svg|zip)$", path, ignore.case = TRUE)) next
    text <- try(readLines(path, warn = FALSE), silent = TRUE)
    if (inherits(text, "try-error")) next
    normalized_path <- normalizePath(path, mustWork = TRUE)
    relative_path <- if (startsWith(normalized_path, root_prefix)) {
      substring(normalized_path, nchar(root_prefix) + 1L)
    } else {
      basename(normalized_path)
    }
    literal_hit <- grepl("/Users/", text, fixed = TRUE)
    documented_literal <- vapply(
      text,
      function(line) .is_documented_absolute_path_literal(relative_path, line),
      logical(1)
    )
    if (any(literal_hit & !documented_literal)) absolute_hits <- c(absolute_hits, path)
  }
  absolute_hits <- absolute_hits[!grepl("README|START_HERE|PRODUCTION_RUNBOOK|CHANGELOG", absolute_hits)]
  add("no_active_absolute_paths", length(absolute_hits) == 0L, paste(basename(absolute_hits), collapse = "|"))

  a07_exec <- c(file.path(root, "_targets", "A07_targets.R"), file.path(root, "R", "release_manager.R"))
  a07_exec <- a07_exec[file.exists(a07_exec)]
  forbidden_calls <- c("coxph(", "cox.zph(", "pool_scalar_rubin(", "pool_joint_wald_d1(", "rcspline.eval(")
  a07_hits <- character()
  for (path in a07_exec) {
    text <- paste(readLines(path, warn = FALSE), collapse = "\n")
    if (any(vapply(forbidden_calls, function(term) grepl(term, text, fixed = TRUE), logical(1)))) a07_hits <- c(a07_hits, path)
  }
  add("a07_no_scientific_fit", length(a07_hits) == 0L, paste(basename(a07_hits), collapse = "|"))

  review_text <- paste(readLines(file.path(root, "R", "review_pack.R"), warn = FALSE), collapse = "\n")
  review_required <- c(
    "build_consolidated_review_package", "publication_outputs",
    "13_PRIVACY_AND_PATH_QC.csv", "14_PUBLICATION_OUTPUT_MANIFEST.csv",
    "privacy_publication_binary_signature", "privacy_png_metadata_text"
  )
  add("consolidated_human_review_builder", all(vapply(review_required, grepl, logical(1), x = review_text, fixed = TRUE)), paste(review_required[!vapply(review_required, grepl, logical(1), x = review_text, fixed = TRUE)], collapse = "|"))

  canonical_registry <- utils::read.csv(file.path(root, "config", "canonical_file_registry.csv"), stringsAsFactors = FALSE, check.names = FALSE)
  required_ph_files <- c("ph_parent_joint_results.csv", "ph_per_imputation_dummy_results.csv", "ph_dummy_direction_summary.csv", "ph_trigger_summary.csv")
  add("ph_multilevel_machine_outputs_registered", all(required_ph_files %in% canonical_registry$source_canonical_file), paste(setdiff(required_ph_files, canonical_registry$source_canonical_file), collapse = "|"))

  collinearity_files <- c("multicollinearity_summary.csv", "collinearity_s10_results.csv", "collinearity_exception_publication.csv")
  add("a03_collinearity_publication_files_registered", all(collinearity_files %in% canonical_registry$source_canonical_file), paste(setdiff(collinearity_files, canonical_registry$source_canonical_file), collapse = "|"))
  forbidden_a07_files <- c(
    "collinearity_per_imputation.csv.gz", "unique_design_matrix_request_registry.csv",
    "unique_fit_diagnostic_request_registry.csv", "model_fit_status.csv", "model_diagnostic_linkage.csv"
  )
  add("a07_collinearity_long_files_not_registered", !any(forbidden_a07_files %in% canonical_registry$source_canonical_file), paste(intersect(forbidden_a07_files, canonical_registry$source_canonical_file), collapse = "|"))

  diagnostic_canonical <- c(
    "schoenfeld_trend_a03.csv", "schoenfeld_status_a03.csv",
    "rcs_cutoff_candidate.csv", "rcs_derivative_grid.csv", "rcs_cutoff_figure_data.csv",
    "schoenfeld_trend_a06.csv", "schoenfeld_status_a06.csv", "schoenfeld_status_all.csv",
    "rcs_cutoff_stability.csv", "ipcw_roc_summary.csv", "ipcw_roc_curve.csv",
    "ipcw_roc_gate.csv", "cutoff_km_status.csv", "cutoff_km_statistics.csv",
    "cutoff_km_curve.csv", "cutoff_km_riskset.csv", "cutoff_km_publication.csv"
  )
  add("diagnostic_canonical_registry_closure", all(diagnostic_canonical %in% canonical_registry$source_canonical_file), paste(setdiff(diagnostic_canonical, canonical_registry$source_canonical_file), collapse = "|"))
  canonical_abi <- utils::read.csv(file.path(root, "config", "canonical_abi_registry.csv"), stringsAsFactors = FALSE, check.names = FALSE)
  add("diagnostic_canonical_abi_unique_public", nrow(canonical_abi) == 17L && !anyDuplicated(canonical_abi$source_canonical_file) && all(canonical_abi$data_classification == "PUBLIC_AGGREGATE") && !any(canonical_abi$patient_level_allowed), nrow(canonical_abi))
  forbidden_public_fields <- c("Patient_ID", "event_index", "event_time", "scaled_residual", "zph_object", "threshold", "marker_value", "patient_level")
  abi_forbidden <- unique(unlist(strsplit(canonical_abi$forbidden_columns, "|", fixed = TRUE), use.names = FALSE))
  add("diagnostic_abi_forbids_patient_event_threshold_fields", all(forbidden_public_fields %in% abi_forbidden), paste(setdiff(forbidden_public_fields, abi_forbidden), collapse = "|"))

  recipes <- utils::read.csv(file.path(root, "config", "output_recipe_registry.csv"), stringsAsFactors = FALSE, check.names = FALSE)
  st32 <- recipes[recipes$output_id == "ST32", , drop = FALSE]
  add("st32_exact_77", nrow(st32) == 1L && st32$min_rows[[1L]] == 77L && st32$max_rows[[1L]] == 77L, if (nrow(st32)) paste(st32$min_rows, st32$max_rows, sep = "|") else "MISSING")
  stage_execution <- utils::read.csv(file.path(root, "config", "stage_execution_registry.csv"), stringsAsFactors = FALSE, check.names = FALSE)
  add("stateless_stage_authority_boundary", nrow(stage_execution) == 8L && all(stage_execution$execution_plane[stage_execution$stage != "A07"] == "AUTODL_STATELESS") && identical(stage_execution$execution_plane[stage_execution$stage == "A07"], "LOCAL_CONTROL") && !any(stage_execution$auto_retry) && !any(stage_execution$auto_continue), paste(stage_execution$stage, stage_execution$execution_plane, collapse = "|"))

  renderer_text <- paste(readLines(file.path(root, "R", "publication_renderer.R"), warn = FALSE), collapse = "\n")
  add("publication_multiformat_stable_pdf", all(vapply(c("timestamp = FALSE", "producer = FALSE", "device = stable_pdf_device", "device = \"svg\"", "device = \"png\""), grepl, logical(1), x = renderer_text, fixed = TRUE)), "SVG/PDF/PNG use one plot and timestamp-free PDF")
  worker_text <- paste(readLines(file.path(root, "remote", "stateless_worker.py"), warn = FALSE), collapse = "\n")
  add("stateless_worker_no_continuation_authority", all(vapply(c("retry_performed", "approval_performed", "publication_performed", "freeze_performed", "next_request_created"), grepl, logical(1), x = worker_text, fixed = TRUE)), "terminal receipt declares all authority flags")

  collinearity_engine_text <- paste(readLines(file.path(root, "R", "collinearity_engine.R"), warn = FALSE), collapse = "\n")
  forbidden_numeric_patterns <- c("(^|[^[:alnum:]_])solve\\(", "ginv\\(", "MASS::ginv", "pseudoinverse")
  numeric_hits <- forbidden_numeric_patterns[vapply(forbidden_numeric_patterns, grepl, logical(1), x = collinearity_engine_text, perl = TRUE, ignore.case = TRUE)]
  required_numeric_tokens <- c("backsolve", "forwardsolve", "cholesky_logdet", "eigen_logdet", "relative_invertibility_tolerance", "ill_conditioned_warning_threshold")
  add("vif_stable_numeric_implementation", !length(numeric_hits) && all(vapply(required_numeric_tokens, grepl, logical(1), x = collinearity_engine_text, fixed = TRUE)), paste(numeric_hits, collapse = "|"))

  a03_target_text <- paste(readLines(file.path(root, "_targets", "A03_targets.R"), warn = FALSE), collapse = "\n")
  a03_tokens <- c("make_a03_branch_specs", "fit_fixed_cox_branch", "A03_ph", "A03_design_diagnostic", "A03_fit_diagnostic", "A03_collinearity")
  add("a03_fit_once_diagnostic_branches", all(vapply(a03_tokens, grepl, logical(1), x = a03_target_text, fixed = TRUE)), paste(a03_tokens[!vapply(a03_tokens, grepl, logical(1), x = a03_target_text, fixed = TRUE)], collapse = "|"))

  downstream_impact <- jsonlite::read_json(file.path(root, "config", "vif_addendum_downstream_impact_manifest.json"), simplifyVector = TRUE)
  downstream_closed <- identical(as.integer(downstream_impact$unresolved_downstream_consumer_count), 0L) &&
    identical(as.integer(downstream_impact$old_new_schema_mix_count), 0L) &&
    all(downstream_impact$objects$compatibility_status == "CLOSED")
  add("vif_downstream_schema_closure", downstream_closed, paste(unique(downstream_impact$objects$compatibility_status), collapse = "|"))

  active_semantic_files <- c(
    file.path(root, "Main.md"), file.path(root, "AGENTS.md"),
    list.files(file.path(root, "agents"), recursive = TRUE, full.names = TRUE),
    list.files(file.path(root, "config"), recursive = TRUE, full.names = TRUE),
    list.files(file.path(root, "report"), recursive = TRUE, full.names = TRUE)
  )
  active_semantic_files <- active_semantic_files[file.info(active_semantic_files)$isdir %in% FALSE]
  external_only_terms <- c("outer fold", "Policy A", "Policy B", "CP-S00", "S20-VIF", "SF14-VIF", "M079", "M080")
  external_semantic_hits <- character()
  for (path in active_semantic_files) {
    text <- try(readLines(path, warn = FALSE, encoding = "UTF-8"), silent = TRUE)
    if (inherits(text, "try-error")) next
    if (any(vapply(external_only_terms, function(term) any(grepl(term, text, fixed = TRUE)), logical(1)))) external_semantic_hits <- c(external_semantic_hits, path)
  }
  add("external_requirement_terms_absent_from_active_contract", !length(external_semantic_hits), paste(basename(external_semantic_hits), collapse = "|"))

  recovery_text <- paste(readLines(file.path(root, "tests", "validate_a03_recovery.R"), warn = FALSE), collapse = "\n")
  recovery_tokens <- c("a03_recovery_validation.csv", "a03_recovery_summary.csv", "a03_recovery_fit_cache_lineage.csv", "build_consolidated_review_package")
  add("a03_recovery_evidence_enters_review_package", all(vapply(recovery_tokens, grepl, logical(1), x = recovery_text, fixed = TRUE)), paste(recovery_tokens[!vapply(recovery_tokens, grepl, logical(1), x = recovery_text, fixed = TRUE)], collapse = "|"))

  result <- do.call(rbind, checks)
  dir.create(file.path(root, "tests", "output"), recursive = TRUE, showWarnings = FALSE)
  # 输出静态QA结果。
  utils::write.csv(result, file.path(root, "tests", "output", "static_qa.csv"), row.names = FALSE)
  if (!all(result$status == "PASS")) stop("Static QA failed", call. = FALSE)
  invisible(result)
}

if (sys.nframe() == 0L) run_static_qa(normalizePath("."))
