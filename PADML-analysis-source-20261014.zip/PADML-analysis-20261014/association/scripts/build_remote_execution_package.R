# v4.3 AutoDL 离线包构建器：代码与 Linux-64 runtime 分包、内容寻址且不嵌入数据。

.remote_builder_project_root <- function() {
  candidates <- c(
    Sys.getenv("AST_ALT_PROJECT_ROOT", unset = ""),
    normalizePath(".", mustWork = TRUE),
    normalizePath("..", mustWork = TRUE)
  )
  candidates <- unique(candidates[nzchar(candidates)])
  hit <- candidates[file.exists(file.path(candidates, "remote", "remote_contract.R"))]
  if (!length(hit)) stop("REMOTE_CONTRACT_ROOT_NOT_FOUND", call. = FALSE)
  hit[[1L]]
}

if (!exists("verify_remote_bundle_archive", mode = "function")) {
  source(file.path(.remote_builder_project_root(), "remote", "remote_contract.R"))
}
if (!exists(".r_source_patch_expected_provenance", mode = "function")) {
  # 中文备注：加载内容寻址的 R 4.6 源码兼容补丁合同以验证 runtime bundle。
  source(file.path(.remote_builder_project_root(), "remote", "apply_r_source_compatibility_patches.R"))
}
if (!exists("validate_runtime_path_receipt_v43", mode = "function")) {
  # 中文备注：加载唯一的 runtime executable/ELF 路径回执验证器。
  source(file.path(.remote_builder_project_root(), "remote", "normalize_runtime_paths.R"))
}

.remote_builder_git <- function(root, args, code = "REMOTE_GIT_COMMAND_FAILED") {
  previous <- getwd()
  on.exit(setwd(previous), add = TRUE)
  setwd(root)
  output <- suppressWarnings(system2("git", args, stdout = TRUE, stderr = TRUE))
  status <- attr(output, "status")
  if (is.null(status)) status <- 0L
  if (status != 0L) .remote_stop(code, paste(output, collapse = " "))
  enc2utf8(output)
}

.remote_builder_git_identity <- function(
    root,
    external_roots = c("remote_build", "preproduction_validation", "runtime", "tests/output", "logs")) {
  root <- normalizePath(root, mustWork = TRUE)
  inside <- .remote_builder_git(root, c("rev-parse", "--is-inside-work-tree"))
  if (!identical(inside, "true")) .remote_stop("REMOTE_CODE_GIT_WORKTREE_REQUIRED")
  status <- .remote_builder_git(root, c("status", "--porcelain=v1", "--untracked-files=all"))
  normalized_roots <- paste0(gsub("\\\\", "/", external_roots), "/")
  permitted_external <- if (length(status)) vapply(status, function(line) {
    if (!startsWith(line, "?? ")) return(FALSE)
    path <- gsub("\\\\", "/", substring(line, 4L))
    any(startsWith(path, normalized_roots))
  }, logical(1)) else logical()
  if (length(status) && !all(permitted_external)) {
    .remote_stop("REMOTE_CODE_GIT_TREE_NOT_CLEAN", paste(status[!permitted_external], collapse = "|"))
  }
  commit <- .remote_builder_git(root, c("rev-parse", "HEAD"))
  tree <- .remote_builder_git(root, c("rev-parse", "HEAD^{tree}"))
  if (length(commit) != 1L || !grepl("^[0-9a-f]{40}$", commit) ||
      length(tree) != 1L || !grepl("^[0-9a-f]{40}$", tree)) {
    .remote_stop("REMOTE_CODE_GIT_IDENTITY_INVALID")
  }
  list(
    commit = unname(commit), tree = unname(tree),
    clean_scope = "TRACKED_AND_SOURCE_UNTRACKED_EXCLUDING_CONTRACTED_EXTERNAL_ROOTS",
    excluded_external_roots = external_roots
  )
}

.remote_code_root_files <- function() {
  c(
    "AGENTS.md", "Main.md", "README.md", "START_HERE.md", "EXECUTION_ORDER.md",
    "PRODUCTION_RUNBOOK.md", "HUMAN_REVIEW_RUNBOOK.md", "renv.lock"
  )
}

.remote_code_prefixes <- function() {
  c(
    "R/", "_targets/", "config/", "schemas/", "scripts/", "templates/",
    "report/", "reference/", "remote/", "tests/"
  )
}

.remote_code_excluded <- function(path) {
  prefixes <- c(
    "audit/", "canonical_results/", "docs/", "agents/", "tests/output/",
    "tests/fixtures/", "runtime/", "runs/", "cache/", "restricted_cache/",
    "approved_cache/", "candidate_cache/", "human_review/", "release/",
    "source_packages/", "data_raw/"
  )
  root_freeze_artifact <- grepl(
    "^(FREEZE_STATUS(_v[^/]+)?[.]json|PACKAGE_MANIFEST_v[^/]+[.]csv|CHANGELOG_v[^/]+[.]md|BUILD_VALIDATION_REPORT[.]md|PRE_PRODUCTION_REMOTE_VALIDATION_REPORT[.]md|.*_snapshot(_v[^/]+)?[.]sha256)$",
    path, perl = TRUE
  )
  any(startsWith(path, prefixes)) || root_freeze_artifact ||
    grepl("[.](rds|rda|RData|xlsx|xls|zip|tar|tar[.]gz|tgz|csv[.]gz)$", path, ignore.case = TRUE) ||
    path %in% c(
      "FREEZE_STATUS.json", "DO_NOT_EDIT_AFTER_FREEZE", "PACKAGE_MANIFEST_v4.2.csv",
      "PROTOCOL_QC_REPORT_v4.2.csv", "BUILD_VALIDATION_REPORT.md", "CHANGELOG_v4.2.md",
      "scientific_contract_snapshot.sha256", "execution_contract_snapshot.sha256",
      "protocol_content_snapshot.sha256", "execution_stability_change.sha256",
      "vif_addendum_scientific.sha256", "PAUSE_CHECKSUMS_r04_after_A02_before_A06.sha256",
      "PAUSE_HANDOFF_r04_after_A02_before_A06.md"
    )
}

.remote_runtime_inventory_scan_projection <- function(path, upstream_path_receipts) {
  inventory <- .remote_read_json(path)
  embedded <- inventory$upstream_path_receipts
  if (is.list(embedded) && !is.data.frame(embedded) && !length(embedded)) embedded <- data.frame()
  if (!is.data.frame(embedded) ||
      !identical(remote_canonical_json(embedded), remote_canonical_json(upstream_path_receipts))) {
    .remote_stop("REMOTE_RUNTIME_UPSTREAM_PATH_RECEIPT_INVALID")
  }
  bytes <- readBin(path, what = "raw", n = file.info(path)$size)
  canonical <- charToRaw(enc2utf8(paste0(remote_canonical_json(inventory), "\n")))
  if (!identical(bytes, canonical)) .remote_stop("REMOTE_RUNTIME_INVENTORY_SCHEMA_INVALID")
  receipt_text <- paste(upstream_path_receipts$relative_path, collapse = "\n")
  if (grepl("-----BEGIN (RSA |OPENSSH |EC )?PRIVATE KEY-----", receipt_text, perl = TRUE) ||
      grepl("AKIA[0-9A-Z]{16}", receipt_text, perl = TRUE) ||
      grepl("Patient_ID", receipt_text, fixed = TRUE)) {
    .remote_stop(
      "REMOTE_BUNDLE_SECRET_PRIVACY_OR_ABSOLUTE_PATH_CONTENT_REJECTED",
      "RUNTIME_PACKAGE_INVENTORY.json"
    )
  }
  if (nrow(embedded)) {
    embedded$relative_path <- vapply(
      embedded$relative_path,
      function(relative) paste0("VALIDATED_RELATIVE_SHA256_", remote_sha256_text(relative)),
      character(1)
    )
    inventory$upstream_path_receipts <- embedded
  }
  charToRaw(enc2utf8(paste0(remote_canonical_json(inventory), "\n")))
}

.remote_documented_private_key_placeholder <- function(path) {
  size <- file.info(path)$size
  if (length(size) != 1L || is.na(size) || size < 1L || size > 4L * 1024L^2L) return(FALSE)
  connection <- file(path, open = "rb")
  on.exit(close(connection), add = TRUE)
  bytes <- readBin(connection, what = "raw", n = as.integer(size))
  values <- as.integer(bytes)
  bytes[!(values %in% c(9L, 10L, 13L) | (values >= 32L & values <= 126L))] <-
    charToRaw(" ")
  text <- rawToChar(bytes)
  begin_matches <- gregexpr(
    "-----BEGIN (RSA |OPENSSH |EC )?PRIVATE KEY-----", text,
    perl = TRUE, useBytes = TRUE
  )[[1L]]
  end_matches <- gregexpr(
    "-----END (RSA |OPENSSH |EC )?PRIVATE KEY-----", text,
    perl = TRUE, useBytes = TRUE
  )[[1L]]
  if (begin_matches[[1L]] < 0L || end_matches[[1L]] < 0L ||
      length(begin_matches) != 1L || length(end_matches) != 1L) return(FALSE)
  begin_token <- regmatches(text, list(begin_matches))[[1L]][[1L]]
  end_token <- regmatches(text, list(end_matches))[[1L]][[1L]]
  if (!identical(end_token, sub("-----BEGIN ", "-----END ", begin_token, fixed = TRUE))) {
    return(FALSE)
  }
  begin_end <- begin_matches[[1L]] + attr(begin_matches, "match.length")[[1L]] - 1L
  end_end <- end_matches[[1L]] + attr(end_matches, "match.length")[[1L]] - 1L
  if (end_matches[[1L]] <= begin_end ||
      !identical(substr(text, begin_end + 1L, end_matches[[1L]] - 1L), "\\n...\\n")) {
    return(FALSE)
  }
  comment_matches <- gregexpr("(?s:/[*].*?[*]/)", text, perl = TRUE, useBytes = TRUE)[[1L]]
  if (comment_matches[[1L]] < 0L) return(FALSE)
  comment_ends <- comment_matches + attr(comment_matches, "match.length") - 1L
  sum(comment_matches <= begin_matches[[1L]] & comment_ends >= end_end) == 1L
}

.remote_sha256_raw <- function(value) {
  if (!is.raw(value)) .remote_stop("REMOTE_RAW_HASH_INPUT_INVALID")
  # 中文备注：加载 digest 命名空间以校验冻结的二进制 payload 身份。
  if (!requireNamespace("digest", quietly = TRUE)) {
    .remote_stop("REMOTE_DEPENDENCY_MISSING", "digest")
  }
  digest::digest(value, algo = "sha256", serialize = FALSE)
}

.remote_mirai_doc_marker_contract <- function() {
  list(
    package = "mirai",
    version = "2.5.0",
    source = "CRAN_ARCHIVE:src/contrib/Archive/mirai/mirai_2.5.0.tar.gz",
    members = data.frame(
      relative_path = c(
        "lib/R/library/mirai/doc/mirai.Rmd",
        "lib/R/library/mirai/doc/mirai.html"
      ),
      file_sha256 = c(
        "c22ed9f235175a876fcc0d49119cfa822d74cc4179dde41e50ad7363c9d0dbc7",
        "d474e026f62199b647836466a561d66d861065f567cbedfa50ee903623b8bd91"
      ),
      wrapper = c("RMD_BACKTICK_AND", "HTML_CODE_TAG_AND"),
      stringsAsFactors = FALSE
    )
  )
}

.remote_mask_exact_mirai_doc_marker_pair <- function(
    bytes, expected_file_sha256, wrapper) {
  if (!is.raw(bytes) || !.remote_is_sha256(expected_file_sha256) ||
      !identical(.remote_sha256_raw(bytes), expected_file_sha256) ||
      !.remote_is_scalar_string(wrapper) ||
      !wrapper %in% c("RMD_BACKTICK_AND", "HTML_CODE_TAG_AND")) {
    .remote_stop("REMOTE_MIRAI_DOC_MARKER_CONTRACT_INVALID")
  }
  begin_marker <- paste0("-----BEGIN ", "PRIVATE KEY-----")
  end_marker <- paste0("-----END ", "PRIVATE KEY-----")
  text <- rawToChar(bytes)
  begin_matches <- gregexpr(begin_marker, text, fixed = TRUE, useBytes = TRUE)[[1L]]
  end_matches <- gregexpr(end_marker, text, fixed = TRUE, useBytes = TRUE)[[1L]]
  if (begin_matches[[1L]] < 0L || end_matches[[1L]] < 0L ||
      length(begin_matches) != 1L || length(end_matches) != 1L) {
    .remote_stop("REMOTE_MIRAI_DOC_MARKER_CONTRACT_INVALID")
  }
  begin_start <- begin_matches[[1L]]
  begin_end <- begin_start + nchar(begin_marker, type = "bytes") - 1L
  end_start <- end_matches[[1L]]
  end_end <- end_start + nchar(end_marker, type = "bytes") - 1L
  wrapper_valid <- if (identical(wrapper, "RMD_BACKTICK_AND")) {
    begin_start > 1L && end_end < length(bytes) && end_start > begin_end &&
      identical(bytes[[begin_start - 1L]], charToRaw("`")[[1L]]) &&
      identical(bytes[(begin_end + 1L):(end_start - 1L)], charToRaw("` and `")) &&
      identical(bytes[[end_end + 1L]], charToRaw("`")[[1L]])
  } else {
    html_open <- charToRaw("<code>")
    html_close <- charToRaw("</code>")
    begin_start > length(html_open) &&
      end_end + length(html_close) <= length(bytes) && end_start > begin_end &&
      identical(
        bytes[(begin_start - length(html_open)):(begin_start - 1L)], html_open
      ) &&
      identical(
        bytes[(begin_end + 1L):(end_start - 1L)], charToRaw("</code> and <code>")
      ) &&
      identical(bytes[(end_end + 1L):(end_end + length(html_close))], html_close)
  }
  if (!wrapper_valid) {
    .remote_stop("REMOTE_MIRAI_DOC_MARKER_CONTRACT_INVALID")
  }
  bytes[begin_start:begin_end] <- as.raw(rep(32L, nchar(begin_marker, type = "bytes")))
  bytes[end_start:end_end] <- as.raw(rep(32L, nchar(end_marker, type = "bytes")))
  bytes
}

.remote_mirai_doc_scan_projections <- function(runtime_root, scan_files) {
  contract <- .remote_mirai_doc_marker_contract()
  required <- c("package", "version", "source", "members")
  member_required <- c("relative_path", "file_sha256", "wrapper")
  if (!is.list(contract) || !identical(sort(names(contract)), sort(required)) ||
      any(!vapply(contract[required[-4L]], .remote_is_scalar_string, logical(1))) ||
      !is.data.frame(contract$members) ||
      !identical(names(contract$members), member_required) ||
      nrow(contract$members) != 2L || anyDuplicated(contract$members$relative_path) > 0L ||
      any(!vapply(contract$members$relative_path, .remote_safe_relative_path, logical(1))) ||
      any(!vapply(contract$members$file_sha256, .remote_is_sha256, logical(1))) ||
      !identical(
        sort(contract$members$wrapper, method = "radix"),
        sort(c("RMD_BACKTICK_AND", "HTML_CODE_TAG_AND"), method = "radix")
      )) {
    .remote_stop("REMOTE_MIRAI_DOC_MARKER_CONTRACT_INVALID")
  }
  member_index <- which(contract$members$relative_path %in% scan_files)
  if (!length(member_index)) return(list())
  inventory_path <- file.path(runtime_root, "RUNTIME_PACKAGE_INVENTORY.json")
  if (!file.exists(inventory_path)) {
    .remote_stop("REMOTE_MIRAI_DOC_MARKER_CONTRACT_INVALID")
  }
  inventory <- .remote_read_json(inventory_path)
  packages <- inventory$packages
  package_index <- if (is.data.frame(packages) && "package" %in% names(packages)) {
    which(packages$package == contract$package)
  } else {
    integer()
  }
  if (length(package_index) != 1L ||
      !all(c("version", "source") %in% names(packages)) ||
      !identical(packages$version[[package_index]], contract$version) ||
      !identical(packages$source[[package_index]], contract$source)) {
    .remote_stop("REMOTE_MIRAI_DOC_MARKER_CONTRACT_INVALID")
  }
  projections <- lapply(member_index, function(index) {
    member_path <- file.path(runtime_root, contract$members$relative_path[[index]])
    member_info <- file.info(member_path)
    if (!file.exists(member_path) || isTRUE(member_info$isdir) ||
        nzchar(Sys.readlink(member_path)) ||
        bitwAnd(as.integer(member_info$mode), strtoi("111", base = 8L)) != 0L) {
      .remote_stop("REMOTE_MIRAI_DOC_MARKER_CONTRACT_INVALID")
    }
    bytes <- readBin(member_path, what = "raw", n = member_info$size)
    .remote_mask_exact_mirai_doc_marker_pair(
      bytes,
      contract$members$file_sha256[[index]],
      contract$members$wrapper[[index]]
    )
  })
  setNames(projections, contract$members$relative_path[member_index])
}

.remote_quarto_wasm_contract <- function() {
  list(
    quarto_version = "1.9.38",
    owner_id = "quarto=1.9.38=h920450f_0",
    owner_sha256 = "d94e426980932a2dfbcf4a43c48d600d473c355a7b11477911c3b13ad24e4b5d",
    literal_size = 146364L,
    literal_sha256 = "d01ba25653f14266addeef2894ec55d92aa461ac304e26a25c8166adc15d3958",
    decoded_size = 109772L,
    decoded_sha256 = "1161cfac8cdb9d9dc0d47111068d69be2bc4d15f94a8dd24e2efe7847d9cbe73",
    candidates = data.frame(
      relative_path = c(
        paste0(
          "bin/deno_cache/remote/https/deno.land/",
          "8efecf63899c7c1fa2c8132a6f92beb434898222f5938880965cedb7420dade9"
        ),
        "bin/quarto.js"
      ),
      file_sha256 = c(
        "5d3d3418f7cf5296fcd0a6aa3563e1dbc17e4a4fa9895ed0eae2847a2aad0c5a",
        "69ff17042caccca51cc4193abf9a56b2e7f022960237fbadcdecfd80d06f7173"
      ),
      stringsAsFactors = FALSE
    )
  )
}

.remote_mask_exact_quarto_wasm_literal <- function(bytes, contract, expected_file_sha256) {
  if (!is.raw(bytes) || !.remote_is_sha256(expected_file_sha256) ||
      !identical(.remote_sha256_raw(bytes), expected_file_sha256)) {
    .remote_stop("REMOTE_QUARTO_WASM_BASE64_CONTRACT_INVALID")
  }
  values <- as.integer(bytes)
  is_base64 <- (values >= 48L & values <= 57L) |
    (values >= 65L & values <= 90L) |
    (values >= 97L & values <= 122L) |
    values %in% c(43L, 47L, 61L)
  starts <- which(is_base64 & c(TRUE, !head(is_base64, -1L)))
  ends <- which(is_base64 & c(!tail(is_base64, -1L), TRUE))
  expected_length <- as.integer(contract$literal_size)
  candidates <- which((ends - starts + 1L) == expected_length)
  matching <- candidates[vapply(candidates, function(index) {
    .remote_sha256_raw(bytes[starts[[index]]:ends[[index]]]) == contract$literal_sha256
  }, logical(1))]
  if (length(matching) != 1L) {
    .remote_stop("REMOTE_QUARTO_WASM_BASE64_CONTRACT_INVALID")
  }
  index <- matching[[1L]]
  literal <- rawToChar(bytes[starts[[index]]:ends[[index]]])
  if (nchar(literal, type = "bytes") %% 4L != 0L ||
      !grepl("^[A-Za-z0-9+/]+={0,2}$", literal, perl = TRUE, useBytes = TRUE)) {
    .remote_stop("REMOTE_QUARTO_WASM_BASE64_CONTRACT_INVALID")
  }
  # 中文备注：加载 jsonlite 命名空间并严格往返解码冻结的 WASM Base64 literal。
  if (!requireNamespace("jsonlite", quietly = TRUE)) {
    .remote_stop("REMOTE_DEPENDENCY_MISSING", "jsonlite")
  }
  decoded <- tryCatch(
    jsonlite::base64_dec(literal),
    error = function(condition) .remote_stop("REMOTE_QUARTO_WASM_BASE64_CONTRACT_INVALID")
  )
  reencoded <- as.character(jsonlite::base64_enc(decoded))
  reencoded <- gsub("[\r\n]", "", reencoded, perl = TRUE, useBytes = TRUE)
  if (!identical(reencoded, literal) ||
      length(decoded) != as.integer(contract$decoded_size) ||
      !identical(.remote_sha256_raw(decoded), contract$decoded_sha256) ||
      length(decoded) < 4L ||
      !identical(decoded[1:4], as.raw(c(0L, 97L, 115L, 109L)))) {
    .remote_stop("REMOTE_QUARTO_WASM_BASE64_CONTRACT_INVALID")
  }
  decoded_projection <- decoded
  decoded_values <- as.integer(decoded_projection)
  decoded_projection[!(decoded_values %in% c(9L, 10L, 13L) |
    (decoded_values >= 32L & decoded_values <= 126L))] <- charToRaw(" ")
  decoded_text <- rawToChar(decoded_projection)
  if (grepl("-----BEGIN (RSA |OPENSSH |EC )?PRIVATE KEY-----", decoded_text,
        perl = TRUE, useBytes = TRUE) ||
      grepl("AKIA[0-9A-Z]{16}", decoded_text, perl = TRUE, useBytes = TRUE) ||
      grepl("Patient_ID", decoded_text, fixed = TRUE, useBytes = TRUE)) {
    .remote_stop("REMOTE_QUARTO_WASM_BASE64_CONTRACT_INVALID")
  }
  bytes[starts[[index]]:ends[[index]]] <- as.raw(rep(32L, expected_length))
  bytes
}

.remote_quarto_wasm_scan_projections <- function(
    runtime_root, scan_files, contract = .remote_quarto_wasm_contract()) {
  required <- c(
    "quarto_version", "owner_id", "owner_sha256", "literal_size",
    "literal_sha256", "decoded_size", "decoded_sha256", "candidates"
  )
  candidate_fields <- c("relative_path", "file_sha256")
  if (!is.list(contract) || !identical(sort(names(contract)), sort(required)) ||
      !.remote_is_scalar_string(contract$quarto_version) ||
      !.remote_is_scalar_string(contract$owner_id) ||
      !.remote_is_sha256(contract$owner_sha256) ||
      !.remote_is_sha256(contract$literal_sha256) ||
      !.remote_is_sha256(contract$decoded_sha256) ||
      !is.numeric(contract$literal_size) || as.integer(contract$literal_size) <= 0L ||
      !is.numeric(contract$decoded_size) || as.integer(contract$decoded_size) <= 0L ||
      !is.data.frame(contract$candidates) ||
      !identical(sort(names(contract$candidates)), sort(candidate_fields)) ||
      nrow(contract$candidates) != 2L ||
      anyDuplicated(contract$candidates$relative_path) ||
      any(!vapply(contract$candidates$relative_path, .remote_safe_relative_path, logical(1))) ||
      any(!vapply(contract$candidates$file_sha256, .remote_is_sha256, logical(1)))) {
    .remote_stop("REMOTE_QUARTO_WASM_BASE64_CONTRACT_INVALID")
  }
  targets <- intersect(scan_files, contract$candidates$relative_path)
  projections <- setNames(vector("list", length(targets)), targets)
  if (!length(targets)) return(projections)
  identity_path <- file.path(runtime_root, "RUNTIME_IDENTITY.json")
  explicit_path <- file.path(runtime_root, "CONDA_EXPLICIT_SPEC.txt")
  if (!file.exists(identity_path) || !file.exists(explicit_path)) {
    .remote_stop("REMOTE_QUARTO_WASM_BASE64_CONTRACT_INVALID")
  }
  identity <- .remote_read_json(identity_path)
  artifacts <- readLines(explicit_path, warn = FALSE)
  artifacts <- artifacts[grepl("^https://", artifacts)]
  if (!identical(as.character(identity$quarto_version), contract$quarto_version) ||
      length(artifacts) != 120L || anyDuplicated(artifacts)) {
    .remote_stop("REMOTE_QUARTO_WASM_BASE64_CONTRACT_INVALID")
  }
  ownership <- .remote_runtime_conda_ownership(runtime_root, artifacts, targets)
  hits <- match(targets, ownership$relative_path)
  if (anyNA(hits) ||
      any(ownership$source_id[hits] != contract$owner_id) ||
      any(ownership$source_identity_sha256[hits] != contract$owner_sha256)) {
    .remote_stop("REMOTE_QUARTO_WASM_BASE64_CONTRACT_INVALID")
  }
  for (relative in targets) {
    candidate_index <- match(relative, contract$candidates$relative_path)
    path <- file.path(runtime_root, relative)
    if (!file.exists(path) || isTRUE(file.info(path)$isdir) || nzchar(Sys.readlink(path))) {
      .remote_stop("REMOTE_QUARTO_WASM_BASE64_CONTRACT_INVALID")
    }
    bytes <- readBin(path, what = "raw", n = file.info(path)$size)
    projections[[relative]] <- .remote_mask_exact_quarto_wasm_literal(
      bytes, contract, contract$candidates$file_sha256[[candidate_index]]
    )
  }
  projections
}

.remote_scan_bundle_source <- function(
    source_root, relative_files, role, upstream_path_receipts = NULL,
    scan_files = relative_files) {
  if (!length(scan_files) || any(!scan_files %in% relative_files) ||
      any(!vapply(scan_files, .remote_safe_relative_path, logical(1)))) {
    .remote_stop("REMOTE_BUNDLE_SOURCE_PATH_INVALID")
  }
  secret_name <- grepl(
    "(^|/)([.]ssh|[.]env([.]|$)|id_rsa|id_ed25519|private[_-]?key|credentials?|secrets?)(/|$)",
    relative_files, ignore.case = TRUE, perl = TRUE
  )
  patient_path <- grepl(
    "(^|/)(patient[_-]?level|raw[_-]?records?|restricted[_-]?input|source[_-]?workbook)(/|$)",
    relative_files, ignore.case = TRUE, perl = TRUE
  )
  if (any(secret_name) || (identical(role, "RUNTIME") && any(patient_path))) {
    .remote_stop("REMOTE_BUNDLE_SECRET_OR_PRIVACY_PATH_REJECTED")
  }
  receipt_fields <- c(
    "relative_path", "file_sha256", "source_kind", "source_id",
    "source_identity_sha256", "pattern_class", "executable"
  )
  if (identical(role, "RUNTIME")) {
    if (is.null(upstream_path_receipts)) upstream_path_receipts <- data.frame()
    if (nrow(upstream_path_receipts)) {
      if (!is.data.frame(upstream_path_receipts) ||
          !identical(sort(names(upstream_path_receipts)), sort(receipt_fields)) ||
          anyDuplicated(upstream_path_receipts$relative_path) ||
          any(!upstream_path_receipts$relative_path %in% relative_files) ||
          any(!vapply(upstream_path_receipts$relative_path, .remote_safe_relative_path, logical(1))) ||
          any(!vapply(upstream_path_receipts$file_sha256, .remote_is_sha256, logical(1))) ||
          any(!vapply(upstream_path_receipts$source_identity_sha256, .remote_is_sha256, logical(1))) ||
          any(!upstream_path_receipts$source_kind %in% c(
            "RENV_LOCK_RECORD", "PINNED_CRAN_ARCHIVE",
            "PINNED_CRAN_ARCHIVE_COMPAT_PATCHED", "CONDA_EXPLICIT_ARTIFACT"
          )) || any(!nzchar(upstream_path_receipts$source_id)) ||
          any(!grepl(
            paste0(
              "^(INSTANCE_REQUEST_ROOT|PUBLIC_MAC_USERS_EXAMPLE_PATH|PUBLIC_UNIX_HOME_EXAMPLE_PATH)",
              "([+](INSTANCE_REQUEST_ROOT|PUBLIC_MAC_USERS_EXAMPLE_PATH|PUBLIC_UNIX_HOME_EXAMPLE_PATH)){0,2}$"
            ),
            upstream_path_receipts$pattern_class, perl = TRUE
          )) || any(upstream_path_receipts$executable != FALSE)) {
        .remote_stop("REMOTE_RUNTIME_UPSTREAM_PATH_RECEIPT_INVALID")
      }
      receipt_paths <- file.path(source_root, upstream_path_receipts$relative_path)
      receipt_hashes <- vapply(receipt_paths, remote_sha256_file, character(1))
      if (!identical(unname(receipt_hashes), unname(upstream_path_receipts$file_sha256))) {
        .remote_stop("REMOTE_RUNTIME_UPSTREAM_PATH_RECEIPT_FILE_MISMATCH")
      }
      receipt_modes <- as.integer(file.info(receipt_paths)$mode)
      if (any(bitwAnd(receipt_modes, strtoi("111", base = 8L)) != 0L)) {
        .remote_stop("REMOTE_RUNTIME_UPSTREAM_PATH_RECEIPT_EXECUTABLE_FORBIDDEN")
      }
    }
  }
  quarto_wasm_projections <- if (identical(role, "RUNTIME")) {
    .remote_quarto_wasm_scan_projections(source_root, scan_files)
  } else {
    list()
  }
  mirai_doc_projections <- if (identical(role, "RUNTIME")) {
    .remote_mirai_doc_scan_projections(source_root, scan_files)
  } else {
    list()
  }
  for (relative in scan_files) {
    path <- file.path(source_root, relative)
    receipt_index <- if (identical(role, "RUNTIME") && nrow(upstream_path_receipts)) {
      match(relative, upstream_path_receipts$relative_path)
    } else {
      NA_integer_
    }
    receipt_hit <- !is.na(receipt_index)
    if (receipt_hit && bitwAnd(as.integer(file.info(path)$mode), strtoi("111", base = 8L)) != 0L) {
      .remote_stop("REMOTE_RUNTIME_UPSTREAM_PATH_RECEIPT_EXECUTABLE_FORBIDDEN", relative)
    }
    connection <- if (relative %in% names(quarto_wasm_projections)) {
      rawConnection(quarto_wasm_projections[[relative]], open = "r")
    } else if (relative %in% names(mirai_doc_projections)) {
      rawConnection(mirai_doc_projections[[relative]], open = "r")
    } else if (identical(role, "RUNTIME") &&
        identical(relative, "RUNTIME_PACKAGE_INVENTORY.json")) {
      rawConnection(
        .remote_runtime_inventory_scan_projection(path, upstream_path_receipts),
        open = "r"
      )
    } else {
      file(path, open = "rb")
    }
    carry <- raw()
    observed_path_classes <- character()
    repeat {
      bytes <- readBin(connection, what = "raw", n = 1024L * 1024L)
      if (!length(bytes)) break
      combined <- c(carry, bytes)
      values <- as.integer(combined)
      combined[!(values %in% c(9L, 10L, 13L) | (values >= 32L & values <= 126L))] <- charToRaw(" ")
      text <- rawToChar(combined)
      private_key <- grepl("-----BEGIN (RSA |OPENSSH |EC )?PRIVATE KEY-----", text,
        perl = TRUE, useBytes = TRUE) && !.remote_documented_private_key_placeholder(path)
      cloud_key <- grepl("AKIA[0-9A-Z]{16}", text, perl = TRUE, useBytes = TRUE)
      runtime_path_classes <- if (identical(role, "RUNTIME")) {
        .runtime_path_private_path_classes(combined)
      } else {
        c(instance = FALSE, mac_users = FALSE, unix_home = FALSE)
      }
      instance_path <- isTRUE(runtime_path_classes[["instance"]])
      upstream_user_path <- any(runtime_path_classes[c("mac_users", "unix_home")])
      if (isTRUE(runtime_path_classes[["mac_users"]])) {
        observed_path_classes <- c(observed_path_classes, "PUBLIC_MAC_USERS_EXAMPLE_PATH")
      }
      if (isTRUE(runtime_path_classes[["unix_home"]])) {
        observed_path_classes <- c(observed_path_classes, "PUBLIC_UNIX_HOME_EXAMPLE_PATH")
      }
      if (instance_path) {
        observed_path_classes <- c(observed_path_classes, "INSTANCE_REQUEST_ROOT")
      }
      patient_token <- identical(role, "RUNTIME") && grepl("Patient_ID", text,
        fixed = TRUE, useBytes = TRUE)
      if (private_key || cloud_key || patient_token ||
          ((instance_path || upstream_user_path) && !receipt_hit)) {
        close(connection)
        .remote_stop("REMOTE_BUNDLE_SECRET_PRIVACY_OR_ABSOLUTE_PATH_CONTENT_REJECTED", relative)
      }
      carry <- utils::tail(combined, 512L)
    }
    close(connection)
    observed_path_classes <- sort(unique(observed_path_classes), method = "radix")
    if (receipt_hit) {
      expected_classes <- sort(strsplit(
        upstream_path_receipts$pattern_class[[receipt_index]], "+", fixed = TRUE
      )[[1L]], method = "radix")
      if (!identical(observed_path_classes, expected_classes)) {
        .remote_stop("REMOTE_RUNTIME_UPSTREAM_PATH_RECEIPT_PATTERN_MISMATCH", relative)
      }
    }
  }
  invisible(TRUE)
}

.remote_package_tree_sha256 <- function(package_root) {
  package_root <- normalizePath(package_root, mustWork = TRUE)
  paths <- list.files(package_root, recursive = TRUE, full.names = TRUE, all.files = TRUE,
    no.. = TRUE, include.dirs = FALSE)
  if (!length(paths) || any(nzchar(Sys.readlink(paths))) || any(file.info(paths)$isdir)) {
    .remote_stop("REMOTE_RUNTIME_PACKAGE_TREE_INVALID", basename(package_root))
  }
  relative <- gsub("\\\\", "/", substring(paths, nchar(package_root) + 2L))
  ordering <- order(relative, method = "radix")
  projection <- vapply(ordering, function(index) paste(
    relative[[index]], remote_sha256_file(paths[[index]]),
    as.character(file.info(paths[[index]])$size), sep = "\t"
  ), character(1))
  remote_sha256_text(projection)
}

.remote_runtime_conda_ownership <- function(
    runtime_root, artifacts, required_paths = character()) {
  metadata <- list.files(file.path(runtime_root, "conda-meta"), pattern = "[.]json$",
    full.names = TRUE, all.files = TRUE)
  if (length(metadata) != 120L) .remote_stop("REMOTE_RUNTIME_CONDA_METADATA_CARDINALITY_INVALID")
  records <- lapply(metadata, function(path) {
    record <- jsonlite::read_json(path, simplifyVector = FALSE)
    required <- c("name", "version", "build", "sha256", "url")
    if (any(!required %in% names(record)) || !.remote_is_sha256(as.character(record$sha256))) {
      .remote_stop("REMOTE_RUNTIME_CONDA_METADATA_INVALID", basename(path))
    }
    canonical_url <- sub("#[0-9a-f]{64}$", "", as.character(record$url))
    if (grepl(
        "^file:///.+/conda/(linux-64|noarch)/[A-Za-z0-9._+-]+[.](conda|tar[.]bz2)$",
        canonical_url
    )) {
      canonical_url <- paste0(
        "https://conda.anaconda.org/conda-forge/",
        sub("^file:///.+/conda/", "", canonical_url)
      )
    } else {
      canonical_url <- sub(
        "^https://[^/]+(?:/anaconda/cloud)?/conda-forge/",
        "https://conda.anaconda.org/conda-forge/", canonical_url, perl = TRUE
      )
    }
    if (!paste0(canonical_url, "#", record$sha256) %in% artifacts) {
      .remote_stop("REMOTE_RUNTIME_CONDA_METADATA_NOT_IN_EXACT_LOCK", basename(path))
    }
    files <- unlist(record$files, use.names = FALSE)
    if (!length(files) && !is.null(record$paths_data$paths)) {
      files <- vapply(record$paths_data$paths, function(value) {
        as.character(value$`_path`)
      }, character(1))
    }
    files <- unique(gsub("\\\\", "/", files[nzchar(files)]))
    if (any(!vapply(files, .remote_safe_relative_path, logical(1)))) {
      .remote_stop("REMOTE_RUNTIME_CONDA_METADATA_PATH_INVALID", basename(path))
    }
    softlink_paths <- character()
    if (!is.null(record$paths_data$paths)) {
      softlink_paths <- vapply(record$paths_data$paths, function(value) {
        if (identical(as.character(value$path_type), "softlink")) {
          as.character(value$`_path`)
        } else ""
      }, character(1))
      softlink_paths <- unique(gsub("\\\\", "/", softlink_paths[nzchar(softlink_paths)]))
      if (any(!vapply(softlink_paths, .remote_safe_relative_path, logical(1)))) {
        .remote_stop("REMOTE_RUNTIME_CONDA_METADATA_PATH_INVALID", basename(path))
      }
    }
    ownership <- if (!length(files)) {
      data.frame(
        relative_path = character(), source_id = character(),
        source_identity_sha256 = character(), stringsAsFactors = FALSE
      )
    } else {
      data.frame(
        relative_path = files,
        source_id = paste(as.character(record$name), as.character(record$version),
          as.character(record$build), sep = "="),
        source_identity_sha256 = as.character(record$sha256), stringsAsFactors = FALSE
      )
    }
    list(
      ownership = ownership, files = files, softlink_paths = softlink_paths,
      source_id = paste(as.character(record$name), as.character(record$version),
        as.character(record$build), sep = "="),
      source_identity_sha256 = as.character(record$sha256)
    )
  })
  ownership_records <- lapply(records, `[[`, "ownership")
  ownership_records <- ownership_records[vapply(ownership_records, nrow, integer(1)) > 0L]
  ownership <- if (length(ownership_records)) do.call(rbind, ownership_records) else data.frame(
    relative_path = character(), source_id = character(),
    source_identity_sha256 = character(), stringsAsFactors = FALSE
  )
  if (anyDuplicated(ownership$relative_path)) {
    .remote_stop("REMOTE_RUNTIME_CONDA_FILE_OWNER_DUPLICATE")
  }
  required_paths <- unique(as.character(required_paths))
  if (length(required_paths) && any(!vapply(
      required_paths, .remote_safe_relative_path, logical(1)))) {
    .remote_stop("REMOTE_RUNTIME_CONDA_METADATA_PATH_INVALID")
  }
  missing_paths <- setdiff(required_paths, ownership$relative_path)
  for (relative in missing_paths) {
    target <- file.path(runtime_root, relative)
    if (!file.exists(target) || isTRUE(file.info(target)$isdir) || nzchar(Sys.readlink(target))) next
    target_sha256 <- remote_sha256_file(target)
    candidates <- lapply(records, function(record) {
      under_softlink <- any(vapply(record$softlink_paths, function(prefix) {
        startsWith(relative, paste0(prefix, "/"))
      }, logical(1)))
      if (!under_softlink) return(NULL)
      sources <- file.path(runtime_root, record$files)
      retained <- file.exists(sources) & !file.info(sources)$isdir & !nzchar(Sys.readlink(sources))
      sources <- sources[retained]
      if (!length(sources) || !any(vapply(
          sources, remote_sha256_file, character(1)) == target_sha256)) return(NULL)
      data.frame(
        relative_path = relative, source_id = record$source_id,
        source_identity_sha256 = record$source_identity_sha256,
        stringsAsFactors = FALSE
      )
    })
    candidates <- candidates[vapply(candidates, function(value) !is.null(value), logical(1))]
    if (length(candidates)) {
      candidates <- unique(do.call(rbind, candidates))
      if (nrow(candidates) == 1L) ownership <- rbind(ownership, candidates)
    }
  }
  if (anyDuplicated(ownership$relative_path)) {
    .remote_stop("REMOTE_RUNTIME_CONDA_FILE_OWNER_DUPLICATE")
  }
  ownership
}

.remote_active_protocol_owners <- function(root) {
  index_path <- file.path(root, "config", "contract_index.csv")
  if (!file.exists(index_path)) .remote_stop("REMOTE_CONTRACT_INDEX_MISSING")
  index <- utils::read.csv(index_path, stringsAsFactors = FALSE, check.names = FALSE)
  required <- c("owner_relative_path", "status")
  if (any(!required %in% names(index))) .remote_stop("REMOTE_CONTRACT_INDEX_SCHEMA_INVALID")
  paths <- unique(index$owner_relative_path[index$status == "ACTIVE" & startsWith(index$owner_relative_path, "protocol/")])
  amendment <- "protocol/amendments/MAIN_V43_R00_CONFLICT_SAFE_DRIFT_SAFE_EXACT_CLOSURE_FINAL.json"
  paths <- sort(unique(c(paths, amendment)), method = "radix")
  if (!length(paths) || any(!file.exists(file.path(root, paths)))) {
    .remote_stop("REMOTE_ACTIVE_PROTOCOL_OWNER_MISSING")
  }
  paths
}

collect_remote_code_files <- function(root = ".") {
  root <- normalizePath(root, mustWork = TRUE)
  .remote_builder_git_identity(root)
  tracked <- .remote_builder_git(root, c("ls-files"))
  tracked <- tracked[nzchar(tracked)]
  protocol_owners <- .remote_active_protocol_owners(root)
  ordinary <- tracked[
    tracked %in% .remote_code_root_files() |
      vapply(tracked, function(path) any(startsWith(path, .remote_code_prefixes())), logical(1))
  ]
  files <- sort(unique(c(ordinary, protocol_owners)), method = "radix")
  files <- files[!vapply(files, .remote_code_excluded, logical(1))]
  if (!length(files) || any(!file.exists(file.path(root, files))) ||
      any(file.info(file.path(root, files))$isdir %in% TRUE) ||
      any(nzchar(Sys.readlink(file.path(root, files))))) {
    .remote_stop("REMOTE_CODE_ALLOWLIST_INVALID")
  }
  if (any(!protocol_owners %in% files)) .remote_stop("REMOTE_ACTIVE_PROTOCOL_OWNER_EXCLUDED")
  files
}

.remote_active_protocol_owner_sha256 <- function(root) {
  owners <- .remote_active_protocol_owners(root)
  projection <- paste(owners, vapply(file.path(root, owners), remote_sha256_file, character(1)), sep = "=")
  remote_sha256_text(projection)
}

.remote_copy_bundle_payload <- function(source_root, relative_files, stage_root, role) {
  records <- vector("list", length(relative_files))
  for (index in seq_along(relative_files)) {
    relative <- relative_files[[index]]
    if (!.remote_safe_relative_path(relative)) .remote_stop("REMOTE_BUNDLE_SOURCE_PATH_INVALID", relative)
    source <- file.path(source_root, relative)
    if (!file.exists(source) || isTRUE(file.info(source)$isdir) || nzchar(Sys.readlink(source))) {
      .remote_stop("REMOTE_BUNDLE_SOURCE_FILE_INVALID", relative)
    }
    destination_relative <- file.path("payload", relative)
    destination <- file.path(stage_root, destination_relative)
    dir.create(dirname(destination), recursive = TRUE, showWarnings = FALSE)
    executable <- if (identical(role, "RUNTIME")) {
      bitwAnd(as.integer(file.info(source)$mode), as.integer(as.octmode("0111"))) != 0L
    } else {
      grepl("(^|/)([^/]+[.]sh|R|Rscript|quarto|pandoc)$", relative, perl = TRUE)
    }
    mode <- if (executable) "0555" else "0444"
    # 复制白名单 payload，不继承来源时间或权限。
    if (!file.copy(source, destination, overwrite = FALSE, copy.mode = FALSE, copy.date = FALSE)) {
      .remote_stop("REMOTE_BUNDLE_COPY_FAILED", relative)
    }
    Sys.chmod(destination, mode = mode, use_umask = FALSE)
    records[[index]] <- data.frame(
      relative_path = gsub("\\\\", "/", destination_relative),
      sha256 = remote_sha256_file(destination),
      size_bytes = as.character(file.info(destination)$size),
      mode = .remote_file_mode(destination),
      role = role,
      stringsAsFactors = FALSE
    )
  }
  do.call(rbind, records)
}

.remote_write_bundle_controls <- function(stage_root, manifest, identity) {
  manifest <- manifest[order(manifest$relative_path, method = "radix"), .remote_manifest_fields(), drop = FALSE]
  manifest_path <- file.path(stage_root, "BUNDLE_MANIFEST.csv")
  # 写入 exact bundle manifest。
  utils::write.table(manifest, manifest_path, sep = ",", row.names = FALSE, col.names = TRUE, quote = TRUE, na = "")
  Sys.chmod(manifest_path, mode = "0444", use_umask = FALSE)
  manifest_sha <- remote_sha256_file(manifest_path)
  tree_sha <- .remote_manifest_tree_sha256(.remote_read_manifest(manifest_path))
  identity$manifest_sha256 <- manifest_sha
  identity$content_tree_sha256 <- tree_sha
  identity$file_count <- nrow(manifest)
  identity$bundle_id <- paste(identity$bundle_kind, identity$build_revision, substr(tree_sha, 1L, 16L), sep = "_")
  identity_path <- file.path(stage_root, "BUNDLE_IDENTITY.json")
  # 写入 deterministic bundle identity。
  writeLines(remote_canonical_json(identity), identity_path, useBytes = TRUE)
  Sys.chmod(identity_path, mode = "0444", use_umask = FALSE)
  identity_sha <- remote_sha256_file(identity_path)
  sums <- c(
    paste(manifest_sha, "BUNDLE_MANIFEST.csv", sep = "  "),
    paste(identity_sha, "BUNDLE_IDENTITY.json", sep = "  ")
  )
  sums_path <- file.path(stage_root, "SHA256SUMS.txt")
  # 写入 bundle 根校验和。
  writeLines(sums, sums_path, useBytes = TRUE)
  Sys.chmod(sums_path, mode = "0444", use_umask = FALSE)
  marker_path <- file.path(stage_root, "BUNDLE_COMPLETE")
  # 写入不可变 bundle 完成 marker。
  writeLines(c(
    paste0("BUNDLE_KIND=", identity$bundle_kind),
    paste0("BUNDLE_ID=", identity$bundle_id),
    paste0("MANIFEST_SHA256=", manifest_sha),
    paste0("IDENTITY_SHA256=", identity_sha),
    paste0("SHA256SUMS_SHA256=", remote_sha256_file(sums_path)),
    paste0("CONTENT_TREE_SHA256=", tree_sha)
  ), marker_path, useBytes = TRUE)
  Sys.chmod(marker_path, mode = "0444", use_umask = FALSE)
  c(identity, list(identity_sha256 = identity_sha))
}

.remote_build_bundle <- function(
    source_root, relative_files, output_dir, bundle_kind, role, identity,
    source_date_epoch, upstream_path_receipts = NULL) {
  stage_root <- tempfile("remote-bundle-stage-")
  dir.create(stage_root, recursive = TRUE, mode = "0700")
  on.exit(unlink(stage_root, recursive = TRUE, force = TRUE), add = TRUE)
  .remote_scan_bundle_source(source_root, relative_files, role, upstream_path_receipts)
  manifest <- .remote_copy_bundle_payload(source_root, relative_files, stage_root, role)
  completed_identity <- .remote_write_bundle_controls(stage_root, manifest, identity)
  directories <- list.dirs(stage_root, recursive = TRUE, full.names = TRUE)
  Sys.chmod(directories, mode = "0555", use_umask = FALSE)
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  output_dir <- normalizePath(output_dir, mustWork = TRUE)
  archive_name <- paste0(completed_identity$bundle_id, ".tar.gz")
  archive <- .remote_create_deterministic_archive(
    stage_root, file.path(output_dir, archive_name), source_date_epoch
  )
  archive_sha <- remote_sha256_file(archive)
  sidecar <- paste0(archive, ".sha256")
  # 写入 archive 外部 SHA sidecar；sealed request 使用完整 SHA，不信任文件名短哈希。
  writeLines(paste(archive_sha, basename(archive), sep = "  "), sidecar, useBytes = TRUE)
  verification_root <- tempfile("remote-bundle-roundtrip-")
  on.exit(unlink(verification_root, recursive = TRUE, force = TRUE), add = TRUE)
  verified <- verify_remote_bundle_archive(
    archive, expected_sha256 = archive_sha, expected_kind = bundle_kind,
    extract_root = verification_root
  )
  .remote_scan_bundle_source(
    file.path(verification_root, "payload"),
    sub("^payload/", "", manifest$relative_path),
    role, upstream_path_receipts
  )
  c(
    list(status = "PASS", archive = archive, archive_sha256 = archive_sha),
    completed_identity,
    list(verified_status = verified$status)
  )
}

build_remote_code_bundle <- function(
    root = ".", output_dir, source_date_epoch = 1786579200) {
  root <- normalizePath(root, mustWork = TRUE)
  git <- .remote_builder_git_identity(root)
  files <- collect_remote_code_files(root)
  identity <- list(
    schema_version = "1.0.0",
    bundle_kind = "CODE_BUNDLE",
    execution_revision = "v4.3-r00",
    build_revision = "v4.3-r15",
    source_date_epoch = as.integer(source_date_epoch),
    origin_git_commit = git$commit,
    origin_git_tree = git$tree,
    active_protocol_owner_sha256 = .remote_active_protocol_owner_sha256(root),
    selection_policy = "CLEAN_GIT_EXACT_CONSUMER_SLICE",
    patient_data_embedded = FALSE,
    legacy_freeze_embedded = FALSE
  )
  .remote_build_bundle(
    root, files, output_dir, "CODE_BUNDLE", "CODE", identity, source_date_epoch
  )
}

.remote_nonoperational_test_fixture_member <- function(path) {
  .remote_is_scalar_string(path) &&
    grepl("^library/[A-Za-z][A-Za-z0-9.]*/testme/.+", path, perl = TRUE) &&
    grepl(",", path, fixed = TRUE) &&
    .remote_safe_relative_path(gsub(",", "", path, fixed = TRUE))
}

.remote_runtime_files <- function(runtime_root) {
  runtime_root <- normalizePath(runtime_root, mustWork = TRUE)
  paths <- list.files(runtime_root, recursive = TRUE, full.names = TRUE, all.files = TRUE, no.. = TRUE)
  if (!length(paths) || any(nzchar(Sys.readlink(paths)))) .remote_stop("REMOTE_RUNTIME_LINK_OR_EMPTY_FORBIDDEN")
  files <- paths[file.info(paths)$isdir %in% FALSE]
  files <- normalizePath(files, mustWork = TRUE)
  relative <- sort(gsub("\\\\", "/", substring(files, nchar(runtime_root) + 2L)), method = "radix")
  nonruntime_prefixes <- c("conda-meta/", "pkgs/", "var/cache/", ".cache/")
  relative <- relative[!vapply(
    relative, function(path) any(startsWith(path, nonruntime_prefixes)), logical(1)
  )]
  relative <- relative[!vapply(
    relative, .remote_nonoperational_test_fixture_member, logical(1)
  )]
  if (!length(relative) || any(!vapply(relative, .remote_safe_relative_path, logical(1)))) {
    .remote_stop("REMOTE_RUNTIME_FILE_SET_INVALID")
  }
  required <- c(
    "RUNTIME_IDENTITY.json", "RUNTIME_PACKAGE_INVENTORY.json", "CONDA_EXPLICIT_SPEC.txt", "ASSEMBLY_TOOLCHAIN.txt",
    "R_SYSTEM_PACKAGE_SOURCE_LOCK.csv", "R_SOURCE_COMPATIBILITY_PATCH_LOCK.csv",
    "R_SOURCE_COMPATIBILITY_RECEIPTS/collections.json",
    "R_SOURCE_COMPATIBILITY_RECEIPTS/nanonext.json",
    "FONT_ASSET_LOCK.csv", "etc/fonts/ast-alt-fonts.conf",
    "bin/R", "bin/Rscript", "bin/quarto", "bin/quarto-real", "bin/pandoc"
  )
  if (any(!required %in% relative)) .remote_stop("REMOTE_RUNTIME_REQUIRED_FILE_MISSING")
  relative
}

.remote_measure_runtime_versions <- function(runtime_root) {
  rscript <- file.path(runtime_root, "bin", "Rscript")
  expression <- paste(
    "cat(as.character(getRversion()),",
    "as.character(utils::packageVersion('renv')),",
    "as.character(utils::packageVersion('targets')),",
    "as.character(utils::packageVersion('crew')),",
    "R.version$platform, R.version$arch, .Platform$OS.type, capabilities('cairo'), sep='|')"
  )
  observed <- suppressWarnings(system2(
    rscript, c("--vanilla", "-e", shQuote(expression)), stdout = TRUE, stderr = TRUE,
    env = paste0("R_LIBS_USER=", file.path(runtime_root, "library"))
  ))
  status <- attr(observed, "status")
  if (!is.null(status) && status != 0L) .remote_stop("REMOTE_RUNTIME_MEASUREMENT_FAILED", "Rscript")
  fields <- strsplit(trimws(paste(observed, collapse = "")), "|", fixed = TRUE)[[1L]]
  if (length(fields) != 8L || any(!nzchar(fields))) .remote_stop("REMOTE_RUNTIME_MEASUREMENT_INVALID", "Rscript")
  version_run <- tempfile("ast-alt-runtime-measurement-")
  dir.create(version_run, recursive = TRUE, mode = "0700")
  on.exit(unlink(version_run, recursive = TRUE, force = TRUE), add = TRUE)
  version_command <- function(path, pattern, environment = character()) {
    output <- suppressWarnings(system2(path, "--version", stdout = TRUE, stderr = TRUE,
      env = environment))
    command_status <- attr(output, "status")
    if (!is.null(command_status) && command_status != 0L) .remote_stop("REMOTE_RUNTIME_MEASUREMENT_FAILED", basename(path))
    text <- paste(output, collapse = " ")
    match <- regexec(pattern, text, perl = TRUE)
    value <- regmatches(text, match)[[1L]]
    if (length(value) < 2L) .remote_stop("REMOTE_RUNTIME_MEASUREMENT_INVALID", basename(path))
    value[[2L]]
  }
  abi_payload <- list(
    platform = fields[[5L]], arch = fields[[6L]], os_type = fields[[7L]],
    cairo = identical(fields[[8L]], "TRUE")
  )
  list(
    r_version = fields[[1L]], renv_version = fields[[2L]],
    targets_version = fields[[3L]], crew_version = fields[[4L]],
    system_abi_sha256 = remote_sha256_text(remote_canonical_json(abi_payload)),
    quarto_version = version_command(file.path(runtime_root, "bin", "quarto"),
      "([0-9]+[.][0-9]+[.][0-9]+)", paste0("AST_ALT_RUN_ROOT=", version_run)),
    pandoc_version = version_command(file.path(runtime_root, "bin", "pandoc"), "([0-9]+[.][0-9]+[.][0-9]+)")
  )
}

.remote_validate_runtime_inventory <- function(
    inventory, identity, runtime_root, project_root, runtime_files) {
  required <- c(
    "schema_version", "runtime_profile_id", "execution_revision", "build_revision", "source_date_epoch", "platform", "owner_policy",
    "lockfile_sha256", "conda_explicit_spec_sha256", "conda_artifact_count",
    "r_system_package_source_lock_sha256", "r_source_compatibility_patch_lock_sha256",
    "r_source_compatibility_receipt_set_sha256",
    "font_asset_lock_sha256", "font_asset_tree_sha256",
    "assembly_toolchain_sha256", "runtime_path_normalization_receipt_sha256",
    "runtime_private_path_findings_sha256", "runtime_private_path_post_findings_sha256",
    "runtime_historical_instance_transform_contract_sha256",
    "lock_package_count", "system_package_count", "total_package_count",
    "font_asset_count", "upstream_path_receipt_count", "system_abi_sha256", "tools", "packages",
    "font_assets", "upstream_path_receipts"
  )
  if (!is.list(inventory) || !identical(sort(names(inventory)), sort(required)) ||
      !identical(inventory$schema_version, "1.0.0") ||
      !identical(inventory$runtime_profile_id, "AUTODL_UBUNTU2204_V43") ||
      !identical(inventory$execution_revision, "v4.3-r00") ||
      !identical(inventory$build_revision, "v4.3-r15") ||
      !is.numeric(inventory$source_date_epoch) || as.numeric(inventory$source_date_epoch) <= 0 ||
      !identical(inventory$platform, "linux-64") ||
      !identical(inventory$owner_policy, "PINNED_R_SOURCE_SYSTEM_RUNTIME__CONDA_SUPPORT__RENV_LOCK_135_PROJECT_LIBRARY_FIRST") ||
      !identical(as.integer(inventory$lock_package_count), 135L) ||
      !identical(as.integer(inventory$conda_artifact_count), 120L) ||
      as.integer(inventory$system_package_count) < 6L ||
      !identical(as.integer(inventory$total_package_count), nrow(inventory$packages)) ||
      !identical(as.integer(inventory$total_package_count), 135L + as.integer(inventory$system_package_count)) ||
      !identical(as.integer(inventory$font_asset_count), 5L) ||
      !identical(as.integer(inventory$upstream_path_receipt_count),
        if (is.data.frame(inventory$upstream_path_receipts)) nrow(inventory$upstream_path_receipts) else 0L) ||
      any(!vapply(c(
        inventory$runtime_path_normalization_receipt_sha256,
        inventory$runtime_private_path_findings_sha256,
        inventory$runtime_private_path_post_findings_sha256,
        inventory$runtime_historical_instance_transform_contract_sha256
      ), .remote_is_sha256, logical(1L))) ||
      !identical(inventory$system_abi_sha256, identity$system_abi_sha256) ||
      !is.data.frame(inventory$tools) || !is.data.frame(inventory$packages) ||
      !is.data.frame(inventory$font_assets) ||
      !(is.data.frame(inventory$upstream_path_receipts) ||
        (is.list(inventory$upstream_path_receipts) && !length(inventory$upstream_path_receipts)))) {
    .remote_stop("REMOTE_RUNTIME_INVENTORY_SCHEMA_INVALID")
  }
  tool_fields <- c("tool_id", "version", "relative_path", "sha256")
  package_fields <- c(
    "package", "version", "owner", "source_kind", "source", "source_identity_sha256",
    "description_relative_path", "description_sha256", "package_tree_sha256"
  )
  if (!identical(sort(names(inventory$tools)), sort(tool_fields)) ||
      !identical(sort(names(inventory$packages)), sort(package_fields)) ||
      nrow(inventory$tools) != 4L || nrow(inventory$packages) < 137L ||
      anyDuplicated(inventory$tools$tool_id) ||
      anyDuplicated(paste(inventory$packages$owner, inventory$packages$package, sep = "|")) ||
      any(!inventory$packages$owner %in% c("RENV_LOCK", "SYSTEM_RUNTIME", "SYSTEM_RUNTIME_SUPPORT")) ||
      any(!inventory$packages$source_kind %in% c(
        "RENV_LOCK_RECORD", "PINNED_CRAN_ARCHIVE",
        "PINNED_CRAN_ARCHIVE_COMPAT_PATCHED", "CONDA_EXPLICIT_ARTIFACT"
      )) ||
      any(!vapply(inventory$packages$source_identity_sha256, .remote_is_sha256, logical(1))) ||
      any(!vapply(inventory$packages$package_tree_sha256, .remote_is_sha256, logical(1)))) {
    .remote_stop("REMOTE_RUNTIME_INVENTORY_CARDINALITY_INVALID")
  }
  lock_path <- file.path(project_root, "renv.lock")
  if (!identical(remote_sha256_file(lock_path), inventory$lockfile_sha256)) {
    .remote_stop("REMOTE_RUNTIME_LOCKFILE_IDENTITY_MISMATCH")
  }
  explicit_spec <- file.path(runtime_root, "CONDA_EXPLICIT_SPEC.txt")
  project_explicit_spec <- file.path(project_root, "remote", "conda-linux-64-explicit.lock")
  if (!file.exists(explicit_spec) || !file.exists(project_explicit_spec) ||
      !identical(remote_sha256_file(explicit_spec), inventory$conda_explicit_spec_sha256) ||
      !identical(remote_sha256_file(project_explicit_spec), inventory$conda_explicit_spec_sha256) ||
      !identical(readBin(explicit_spec, "raw", n = file.info(explicit_spec)$size),
        readBin(project_explicit_spec, "raw", n = file.info(project_explicit_spec)$size))) {
    .remote_stop("REMOTE_RUNTIME_CONDA_EXPLICIT_SPEC_IDENTITY_MISMATCH")
  }
  source_lock_path <- file.path(project_root, "remote", "r-system-package-source-lock.csv")
  runtime_source_lock_path <- file.path(runtime_root, "R_SYSTEM_PACKAGE_SOURCE_LOCK.csv")
  compatibility_lock_path <- file.path(project_root, "remote", "r-source-compatibility-patch-lock.csv")
  runtime_compatibility_lock_path <- file.path(runtime_root, "R_SOURCE_COMPATIBILITY_PATCH_LOCK.csv")
  historical_contract_path <- file.path(
    project_root, "remote", "runtime-historical-instance-transform-contract.csv"
  )
  runtime_historical_contract_path <- file.path(
    runtime_root, "RUNTIME_HISTORICAL_INSTANCE_TRANSFORM_CONTRACT.csv"
  )
  font_lock_path <- file.path(project_root, "remote", "font-asset-lock.csv")
  runtime_font_lock_path <- file.path(runtime_root, "FONT_ASSET_LOCK.csv")
  if (any(!file.exists(c(
        source_lock_path, runtime_source_lock_path,
        compatibility_lock_path, runtime_compatibility_lock_path,
        historical_contract_path, runtime_historical_contract_path,
        font_lock_path, runtime_font_lock_path
      ))) ||
      !identical(remote_sha256_file(source_lock_path), inventory$r_system_package_source_lock_sha256) ||
      !identical(remote_sha256_file(runtime_source_lock_path), inventory$r_system_package_source_lock_sha256) ||
      !identical(remote_sha256_file(compatibility_lock_path),
        inventory$r_source_compatibility_patch_lock_sha256) ||
      !identical(remote_sha256_file(runtime_compatibility_lock_path),
        inventory$r_source_compatibility_patch_lock_sha256) ||
      !identical(remote_sha256_file(historical_contract_path),
        inventory$runtime_historical_instance_transform_contract_sha256) ||
      !identical(remote_sha256_file(runtime_historical_contract_path),
        inventory$runtime_historical_instance_transform_contract_sha256) ||
      !identical(remote_sha256_file(font_lock_path), inventory$font_asset_lock_sha256) ||
      !identical(remote_sha256_file(runtime_font_lock_path), inventory$font_asset_lock_sha256)) {
    .remote_stop("REMOTE_RUNTIME_AUXILIARY_LOCK_IDENTITY_MISMATCH")
  }
  source_lock <- utils::read.csv(source_lock_path, stringsAsFactors = FALSE, check.names = FALSE)
  compatibility_provenance <- .r_source_patch_expected_provenance(project_root)
  font_lock <- utils::read.csv(font_lock_path, stringsAsFactors = FALSE, check.names = FALSE)
  toolchain <- file.path(runtime_root, "ASSEMBLY_TOOLCHAIN.txt")
  toolchain_lines <- if (file.exists(toolchain)) readLines(toolchain, warn = FALSE) else character()
  runtime_path_receipt <- file.path(runtime_root, "RUNTIME_PATH_NORMALIZATION_RECEIPT.csv")
  tryCatch(
    validate_runtime_path_receipt_v43(
      runtime_root, runtime_path_receipt,
      transform_contract_path = historical_contract_path
    ),
    error = function(condition) .remote_stop(
      "REMOTE_RUNTIME_PATH_NORMALIZATION_RECEIPT_INVALID", conditionMessage(condition)
    )
  )
  runtime_path_receipt_sha256 <- remote_sha256_file(runtime_path_receipt)
  runtime_path_findings_sha256 <- remote_sha256_file(
    file.path(runtime_root, "RUNTIME_PRIVATE_PATH_FINDINGS.csv")
  )
  runtime_path_post_findings_sha256 <- remote_sha256_file(
    file.path(runtime_root, "RUNTIME_PRIVATE_PATH_POST_FINDINGS.csv")
  )
  if (!identical(runtime_path_receipt_sha256, inventory$runtime_path_normalization_receipt_sha256) ||
      !identical(runtime_path_findings_sha256, inventory$runtime_private_path_findings_sha256) ||
      !identical(runtime_path_post_findings_sha256,
        inventory$runtime_private_path_post_findings_sha256)) {
    .remote_stop("REMOTE_RUNTIME_PATH_EVIDENCE_IDENTITY_MISMATCH")
  }
  expected_capability_spec_sha <- remote_sha256_file(file.path(project_root, "remote", "conda-linux-64-spec.txt"))
  # 中文备注：按 assembly producer 的冻结顺序验证完整 25 行合同；外部 source SHA 以键名和形状闭包。
  expected_toolchain_lines <- c(
    NA_character_,
    NA_character_,
    paste0("capability_spec_sha256=", expected_capability_spec_sha),
    paste0("conda_exact_lock_sha256=", inventory$conda_explicit_spec_sha256),
    "conda_exact_artifact_count=120",
    NA_character_,
    NA_character_,
    NA_character_,
    "conda_install_policy=FILE_EXPLICIT_LOCK_ONLY_OFFLINE_NO_RETRY",
    paste0("r_system_package_source_lock_sha256=", inventory$r_system_package_source_lock_sha256),
    NA_character_,
    "offline_r_restore_policy=FILE_REPOSITORY_ONLY_NO_HTTP_OR_HTTPS",
    paste0("r_source_compatibility_patch_lock_sha256=",
      inventory$r_source_compatibility_patch_lock_sha256),
    paste0("font_asset_lock_sha256=", inventory$font_asset_lock_sha256),
    paste0("font_deb_sha256=", unique(font_lock$archive_sha256)),
    "quarto_conda_launcher_sha256=72632b5b855ffec9db28a098cf62b9b83a80c57174bfa733b2b399a7bdef037f",
    "quarto_layout=RELATIVE_WRAPPER_WITH_EXPLICIT_SHARE_PATH",
    "runtime_relocation=RELATIVE_R_RSCRIPT_QUARTO_WRAPPERS",
    "public_upstream_path_policy=TOKEN_AWARE_EXEC_ELF_EQUAL_LENGTH_NORMALIZATION__NONEXEC_EXACT_ARTIFACT_RECEIPTS",
    paste0("runtime_path_normalization_receipt_sha256=", runtime_path_receipt_sha256),
    paste0("runtime_private_path_findings_sha256=", runtime_path_findings_sha256),
    paste0("runtime_private_path_post_findings_sha256=", runtime_path_post_findings_sha256),
    paste0("runtime_historical_instance_transform_contract_sha256=",
      inventory$runtime_historical_instance_transform_contract_sha256),
    "font_extractor_contract=DPKG_DEB_OUTPUT_VERIFIED_BY_EXACT_MEMBER_SHA256",
    paste0("source_date_epoch=", as.integer(inventory$source_date_epoch))
  )
  provenance_sha_positions <- c(6L, 7L, 8L, 11L)
  provenance_sha_patterns <- c(
    "^offline_runtime_source_manifest_sha256=[0-9a-f]{64}$",
    "^offline_runtime_source_identity_sha256=[0-9a-f]{64}$",
    "^offline_runtime_source_materializer_sha256=[0-9a-f]{64}$",
    "^offline_r_source_manifest_sha256=[0-9a-f]{64}$"
  )
  exact_toolchain_positions <- which(!is.na(expected_toolchain_lines))
  if (!file.exists(toolchain) ||
      !identical(remote_sha256_file(toolchain), inventory$assembly_toolchain_sha256) ||
      length(toolchain_lines) != length(expected_toolchain_lines) ||
      !grepl("^micromamba_version=[^[:space:]]+$", toolchain_lines[[1L]]) ||
      !grepl("^micromamba_sha256=[0-9a-f]{64}$", toolchain_lines[[2L]]) ||
      !identical(
        toolchain_lines[exact_toolchain_positions],
        expected_toolchain_lines[exact_toolchain_positions]
      ) ||
      !all(vapply(seq_along(provenance_sha_positions), function(index) {
        grepl(
          provenance_sha_patterns[[index]],
          toolchain_lines[[provenance_sha_positions[[index]]]],
          perl = TRUE
        )
      }, logical(1)))) {
    .remote_stop("REMOTE_RUNTIME_ASSEMBLY_TOOLCHAIN_IDENTITY_MISMATCH")
  }
  explicit_lines <- readLines(explicit_spec, warn = FALSE)
  artifacts <- explicit_lines[grepl("^https://", explicit_lines)]
  if (!identical(explicit_lines[1:2], c("# platform: linux-64", "@EXPLICIT")) ||
      length(artifacts) != 120L || anyDuplicated(artifacts) ||
      any(!grepl("^https://conda[.]anaconda[.]org/conda-forge/(linux-64|noarch)/[^#[:space:]]+#[0-9a-f]{64}$",
        artifacts, perl = TRUE))) {
    .remote_stop("REMOTE_RUNTIME_CONDA_EXPLICIT_SPEC_NOT_HASHED")
  }
  r_base_artifact <- artifacts[grepl("/r-base-4[.]6[.]0-[^#]+#[0-9a-f]{64}$", artifacts, perl = TRUE)]
  if (length(r_base_artifact) != 1L) .remote_stop("REMOTE_RUNTIME_R_BASE_ARTIFACT_INVALID")
  r_base_artifact_url <- sub("#[0-9a-f]{64}$", "", r_base_artifact)
  r_base_artifact_sha256 <- sub("^.*#", "", r_base_artifact)
  receipt_fields <- c(
    "relative_path", "file_sha256", "source_kind", "source_id",
    "source_identity_sha256", "pattern_class", "executable"
  )
  receipts <- inventory$upstream_path_receipts
  if (is.list(receipts) && !is.data.frame(receipts) && !length(receipts)) {
    receipts <- data.frame()
  }
  if (nrow(receipts)) {
    if (!identical(sort(names(receipts)), sort(receipt_fields)) ||
        anyDuplicated(receipts$relative_path) ||
        any(!vapply(receipts$relative_path, .remote_safe_relative_path, logical(1))) ||
        any(!vapply(receipts$file_sha256, .remote_is_sha256, logical(1))) ||
        any(!vapply(receipts$source_identity_sha256, .remote_is_sha256, logical(1))) ||
        any(!receipts$source_kind %in% c(
          "RENV_LOCK_RECORD", "PINNED_CRAN_ARCHIVE",
          "PINNED_CRAN_ARCHIVE_COMPAT_PATCHED", "CONDA_EXPLICIT_ARTIFACT"
        )) || any(!nzchar(receipts$source_id)) ||
        any(!grepl(
          paste0(
            "^(INSTANCE_REQUEST_ROOT|PUBLIC_MAC_USERS_EXAMPLE_PATH|PUBLIC_UNIX_HOME_EXAMPLE_PATH)",
            "([+](INSTANCE_REQUEST_ROOT|PUBLIC_MAC_USERS_EXAMPLE_PATH|PUBLIC_UNIX_HOME_EXAMPLE_PATH)){0,2}$"
          ),
          receipts$pattern_class, perl = TRUE
        )) || any(receipts$executable != FALSE)) {
      .remote_stop("REMOTE_RUNTIME_UPSTREAM_PATH_RECEIPT_INVALID")
    }
    conda_rows <- receipts$source_kind == "CONDA_EXPLICIT_ARTIFACT"
    conda_ownership <- if (any(conda_rows)) {
      .remote_runtime_conda_ownership(
        runtime_root, artifacts, receipts$relative_path[conda_rows]
      )
    } else {
      data.frame()
    }
    if (any(conda_rows)) {
      ownership_hits <- match(receipts$relative_path[conda_rows], conda_ownership$relative_path)
      if (anyNA(ownership_hits)) {
        .remote_stop("REMOTE_RUNTIME_UPSTREAM_PATH_RECEIPT_PROVENANCE_MISMATCH")
      }
      receipt_source_id <- receipts$source_id[conda_rows]
      receipt_source_sha256 <- receipts$source_identity_sha256[conda_rows]
      physical_source_id <- conda_ownership$source_id[ownership_hits]
      physical_source_sha256 <- conda_ownership$source_identity_sha256[ownership_hits]
      package_hits <- match(receipt_source_id, inventory$packages$package)
      package_alias_matches <- rep(FALSE, length(package_hits))
      package_rows <- which(!is.na(package_hits))
      if (length(package_rows)) {
        package_indices <- package_hits[package_rows]
        package_alias_matches[package_rows] <-
          inventory$packages$source_kind[package_indices] == "CONDA_EXPLICIT_ARTIFACT" &
          inventory$packages$source_identity_sha256[package_indices] ==
            physical_source_sha256[package_rows] &
          startsWith(
            receipts$relative_path[conda_rows][package_rows],
            paste0("lib/R/library/", receipt_source_id[package_rows], "/")
          )
      }
      if (!identical(receipt_source_sha256, physical_source_sha256) ||
          any(!(receipt_source_id == physical_source_id | package_alias_matches))) {
        .remote_stop("REMOTE_RUNTIME_UPSTREAM_PATH_RECEIPT_PROVENANCE_MISMATCH")
      }
    }
    artifact_hashes <- sub("^.*#", "", artifacts)
    for (index in seq_len(nrow(receipts))) {
      relative <- receipts$relative_path[[index]]
      path <- file.path(runtime_root, relative)
      if (!file.exists(path) || nzchar(Sys.readlink(path)) ||
          bitwAnd(as.integer(file.info(path)$mode), strtoi("111", base = 8L)) != 0L ||
          !identical(remote_sha256_file(path), receipts$file_sha256[[index]])) {
        .remote_stop("REMOTE_RUNTIME_UPSTREAM_PATH_RECEIPT_FILE_MISMATCH", relative)
      }
      package_index <- match(receipts$source_id[[index]], inventory$packages$package)
      if (!is.na(package_index)) {
        if (!identical(receipts$source_kind[[index]], inventory$packages$source_kind[[package_index]]) ||
            !identical(receipts$source_identity_sha256[[index]],
              inventory$packages$source_identity_sha256[[package_index]])) {
          .remote_stop("REMOTE_RUNTIME_UPSTREAM_PATH_RECEIPT_PROVENANCE_MISMATCH", relative)
        }
      } else if (identical(receipts$source_kind[[index]], "CONDA_EXPLICIT_ARTIFACT")) {
        if (!receipts$source_identity_sha256[[index]] %in% artifact_hashes ||
            !grepl("^[^=]+=[^=]+=[^=]+$", receipts$source_id[[index]])) {
          .remote_stop("REMOTE_RUNTIME_UPSTREAM_PATH_RECEIPT_PROVENANCE_MISMATCH", relative)
        }
      } else {
        .remote_stop("REMOTE_RUNTIME_UPSTREAM_PATH_RECEIPT_PROVENANCE_MISMATCH", relative)
      }
    }
  }
  # 中文备注：在昂贵 package-tree 遍历前，仅扫描已验证 receipt 路径被结构化遮蔽的 inventory 元数据。
  .remote_scan_bundle_source(
    runtime_root,
    runtime_files,
    "RUNTIME", receipts, scan_files = "RUNTIME_PACKAGE_INVENTORY.json"
  )
  # 加载 lock 原始 record 形状，避免 simplifyVector 改变 source identity。
  lock <- jsonlite::read_json(lock_path, simplifyVector = FALSE)
  locked <- vapply(lock$Packages, function(record) as.character(record$Version), character(1))
  lock_rows <- inventory$packages$owner == "RENV_LOCK"
  system_rows <- inventory$packages$owner == "SYSTEM_RUNTIME"
  observed_lock <- setNames(inventory$packages$version[lock_rows], inventory$packages$package[lock_rows])
  observed_system <- setNames(inventory$packages$version[system_rows], inventory$packages$package[system_rows])
  source_indices <- match(source_lock$package, inventory$packages$package)
  if (!identical(sort(names(observed_lock)), sort(names(locked))) ||
      !all(observed_lock[names(locked)] == locked) ||
      !identical(sort(names(observed_system)), c("crew", "renv")) ||
      !identical(unname(observed_system[c("crew", "renv")]), c(identity$crew_version, identity$renv_version)) ||
      anyNA(source_indices) || !identical(inventory$packages$version[source_indices], source_lock$version) ||
      !identical(inventory$packages$owner[source_indices], source_lock$owner) ||
      !identical(inventory$packages$source_kind[source_indices], compatibility_provenance$source_kind) ||
      !identical(inventory$packages$source[source_indices], compatibility_provenance$source) ||
      !identical(inventory$packages$source_identity_sha256[source_indices],
        compatibility_provenance$source_identity_sha256)) {
    .remote_stop("REMOTE_RUNTIME_PACKAGE_OWNER_OR_VERSION_MISMATCH")
  }
  system_root_candidates <- c(
    file.path(runtime_root, "lib", "R", "library"),
    file.path(runtime_root, "system_library")
  )
  system_root_candidates <- system_root_candidates[dir.exists(system_root_candidates)]
  if (length(system_root_candidates) != 1L) .remote_stop("REMOTE_RUNTIME_SYSTEM_LIBRARY_CARDINALITY_INVALID")
  compatibility_receipts <- tryCatch(
    .r_source_patch_read_receipt_set(
      project_root, file.path(runtime_root, "R_SOURCE_COMPATIBILITY_RECEIPTS"),
      system_root_candidates[[1L]]
    ),
    error = function(condition) .remote_stop(
      "REMOTE_RUNTIME_COMPATIBILITY_RECEIPT_INVALID", conditionMessage(condition)
    )
  )
  if (!identical(attr(compatibility_receipts, "sha256"),
      inventory$r_source_compatibility_receipt_set_sha256)) {
    .remote_stop("REMOTE_RUNTIME_COMPATIBILITY_RECEIPT_SET_SHA_MISMATCH")
  }
  system_descriptions <- list.files(system_root_candidates[[1L]], pattern = "^DESCRIPTION$",
    recursive = TRUE, full.names = TRUE, all.files = TRUE)
  system_descriptions <- system_descriptions[
    dirname(dirname(system_descriptions)) == normalizePath(system_root_candidates[[1L]])
  ]
  actual_system_packages <- unname(sort(vapply(system_descriptions, function(path) {
    value <- read.dcf(path, fields = "Package")
    if (!length(value) || !nzchar(value[[1L]])) .remote_stop("REMOTE_RUNTIME_SYSTEM_DESCRIPTION_INVALID")
    value[[1L]]
  }, character(1)), method = "radix"))
  inventory_system_packages <- unname(sort(inventory$packages$package[!lock_rows], method = "radix"))
  if (!identical(actual_system_packages, inventory_system_packages)) {
    .remote_stop("REMOTE_RUNTIME_SYSTEM_PACKAGE_INVENTORY_NOT_EXACT")
  }
  receipt_packages <- vapply(compatibility_receipts, `[[`, character(1L), "package")
  receipt_indices <- match(receipt_packages, inventory$packages$package)
  if (anyNA(receipt_indices) || !identical(
      inventory$packages$package_tree_sha256[receipt_indices],
      vapply(compatibility_receipts, `[[`, character(1L), "installed_package_tree_sha256")
    )) {
    .remote_stop("REMOTE_RUNTIME_COMPATIBILITY_RECEIPT_PACKAGE_TREE_MISMATCH")
  }
  for (index in seq_len(nrow(inventory$packages))) {
    relative <- inventory$packages$description_relative_path[[index]]
    if (!.remote_safe_relative_path(relative)) .remote_stop("REMOTE_RUNTIME_INVENTORY_PATH_INVALID")
    path <- file.path(runtime_root, relative)
    if (!file.exists(path) || nzchar(Sys.readlink(path)) ||
        !identical(remote_sha256_file(path), inventory$packages$description_sha256[[index]])) {
      .remote_stop("REMOTE_RUNTIME_PACKAGE_FILE_IDENTITY_MISMATCH", inventory$packages$package[[index]])
    }
    if (!identical(.remote_package_tree_sha256(dirname(path)),
        inventory$packages$package_tree_sha256[[index]])) {
      .remote_stop("REMOTE_RUNTIME_PACKAGE_TREE_IDENTITY_MISMATCH", inventory$packages$package[[index]])
    }
    source_lock_index <- match(inventory$packages$package[[index]], source_lock$package)
    if (identical(inventory$packages$owner[[index]], "RENV_LOCK")) {
      record <- lock$Packages[[inventory$packages$package[[index]]]]
      expected_source_kind <- "RENV_LOCK_RECORD"
      fields <- c("Source", "Repository", "RemoteType", "RemoteHost", "RemoteRepo", "RemoteRef", "RemoteSha")
      present <- fields[fields %in% names(record)]
      expected_source <- if (!length(present)) "LOCK_RECORD_UNSPECIFIED" else {
        paste(vapply(present, function(field) paste0(field, "=", as.character(record[[field]])), character(1)),
          collapse = ";")
      }
      expected_source_sha <- remote_sha256_text(remote_canonical_json(record))
    } else if (!is.na(source_lock_index)) {
      expected_source_kind <- compatibility_provenance$source_kind[[source_lock_index]]
      expected_source <- compatibility_provenance$source[[source_lock_index]]
      expected_source_sha <- compatibility_provenance$source_identity_sha256[[source_lock_index]]
    } else {
      expected_source_kind <- "CONDA_EXPLICIT_ARTIFACT"
      expected_source <- paste0("CONDA_ARTIFACT:", r_base_artifact_url)
      expected_source_sha <- r_base_artifact_sha256
    }
    if (!identical(inventory$packages$source_kind[[index]], expected_source_kind) ||
        !identical(inventory$packages$source[[index]], expected_source) ||
        !identical(inventory$packages$source_identity_sha256[[index]], expected_source_sha)) {
      .remote_stop("REMOTE_RUNTIME_PACKAGE_SOURCE_IDENTITY_MISMATCH", inventory$packages$package[[index]])
    }
  }
  font_fields <- c(
    "asset_id", "package", "version", "source_kind", "archive_sha256",
    "runtime_relative_path", "sha256", "size_bytes", "role", "font_family", "font_style"
  )
  if (!identical(sort(names(inventory$font_assets)), sort(font_fields)) ||
      nrow(inventory$font_assets) != 5L || anyDuplicated(inventory$font_assets$asset_id) ||
      anyDuplicated(inventory$font_assets$runtime_relative_path)) {
    .remote_stop("REMOTE_RUNTIME_FONT_ASSET_INVENTORY_INVALID")
  }
  font_indices <- match(font_lock$asset_id, inventory$font_assets$asset_id)
  if (anyNA(font_indices) ||
      !identical(inventory$font_assets$package[font_indices], font_lock$package) ||
      !identical(inventory$font_assets$version[font_indices], font_lock$version) ||
      !identical(inventory$font_assets$source_kind[font_indices], font_lock$source_kind) ||
      !identical(inventory$font_assets$archive_sha256[font_indices], font_lock$archive_sha256) ||
      !identical(inventory$font_assets$runtime_relative_path[font_indices], font_lock$runtime_relative_path) ||
      !identical(inventory$font_assets$sha256[font_indices], font_lock$sha256) ||
      !identical(inventory$font_assets$role[font_indices], font_lock$role) ||
      !identical(inventory$font_assets$font_family[font_indices], font_lock$font_family) ||
      !identical(inventory$font_assets$font_style[font_indices], font_lock$font_style)) {
    .remote_stop("REMOTE_RUNTIME_FONT_LOCK_CLOSURE_MISMATCH")
  }
  font_projection <- vapply(seq_len(nrow(inventory$font_assets)), function(index) {
    relative <- inventory$font_assets$runtime_relative_path[[index]]
    if (!.remote_safe_relative_path(relative)) .remote_stop("REMOTE_RUNTIME_FONT_ASSET_PATH_INVALID")
    path <- file.path(runtime_root, relative)
    if (!file.exists(path) || nzchar(Sys.readlink(path)) ||
        !identical(remote_sha256_file(path), inventory$font_assets$sha256[[index]]) ||
        !identical(as.character(file.info(path)$size), as.character(inventory$font_assets$size_bytes[[index]]))) {
      .remote_stop("REMOTE_RUNTIME_FONT_ASSET_FILE_MISMATCH", inventory$font_assets$asset_id[[index]])
    }
    paste(relative, inventory$font_assets$sha256[[index]],
      as.character(inventory$font_assets$size_bytes[[index]]), sep = "\t")
  }, character(1))
  font_order <- order(inventory$font_assets$runtime_relative_path, method = "radix")
  if (!identical(remote_sha256_text(font_projection[font_order]), inventory$font_asset_tree_sha256)) {
    .remote_stop("REMOTE_RUNTIME_FONT_ASSET_TREE_MISMATCH")
  }
  expected_tools <- c(R = "bin/R", Rscript = "bin/Rscript", quarto = "bin/quarto", pandoc = "bin/pandoc")
  if (!identical(sort(inventory$tools$tool_id), sort(names(expected_tools)))) {
    .remote_stop("REMOTE_RUNTIME_TOOL_SET_INVALID")
  }
  for (tool in names(expected_tools)) {
    row <- inventory$tools[inventory$tools$tool_id == tool, , drop = FALSE]
    path <- file.path(runtime_root, expected_tools[[tool]])
    expected_version <- switch(tool,
      R = identity$r_version, Rscript = identity$r_version,
      quarto = identity$quarto_version, pandoc = identity$pandoc_version
    )
    if (!identical(row$relative_path[[1L]], expected_tools[[tool]]) ||
        !identical(row$sha256[[1L]], remote_sha256_file(path)) ||
        !identical(as.character(row$version[[1L]]), as.character(expected_version))) {
      .remote_stop("REMOTE_RUNTIME_TOOL_FILE_IDENTITY_MISMATCH", tool)
    }
  }
  invisible(TRUE)
}

.remote_validate_runtime_identity <- function(
    identity, runtime_root, project_root, runtime_files) {
  required <- c(
    "schema_version", "runtime_profile_id", "execution_revision", "build_revision", "source_date_epoch", "platform",
    "r_version", "quarto_version", "pandoc_version", "renv_version",
    "targets_version", "crew_version", "package_inventory_sha256",
    "system_abi_sha256", "conda_explicit_spec_sha256",
    "r_system_package_source_lock_sha256", "r_source_compatibility_patch_lock_sha256",
    "r_source_compatibility_receipt_set_sha256",
    "font_asset_lock_sha256", "font_asset_tree_sha256",
    "runtime_path_normalization_receipt_sha256",
    "runtime_private_path_findings_sha256", "runtime_private_path_post_findings_sha256",
    "runtime_historical_instance_transform_contract_sha256",
    "network_restore_allowed"
  )
  if (!is.list(identity) || !identical(sort(names(identity)), sort(required)) ||
      !identical(identity$schema_version, "1.0.0") ||
      !identical(identity$runtime_profile_id, "AUTODL_UBUNTU2204_V43") ||
      !identical(identity$execution_revision, "v4.3-r00") ||
      !identical(identity$build_revision, "v4.3-r15") ||
      !is.numeric(identity$source_date_epoch) || as.numeric(identity$source_date_epoch) <= 0 ||
      !identical(identity$platform, "linux-64") ||
      !identical(identity$network_restore_allowed, FALSE) ||
      !.remote_is_sha256(identity$package_inventory_sha256) ||
      !.remote_is_sha256(identity$system_abi_sha256) ||
      any(!vapply(identity[c(
        "conda_explicit_spec_sha256", "r_system_package_source_lock_sha256",
        "r_source_compatibility_patch_lock_sha256",
        "r_source_compatibility_receipt_set_sha256",
        "font_asset_lock_sha256", "font_asset_tree_sha256",
        "runtime_path_normalization_receipt_sha256",
        "runtime_private_path_findings_sha256", "runtime_private_path_post_findings_sha256",
        "runtime_historical_instance_transform_contract_sha256"
      )], .remote_is_sha256, logical(1))) ||
      any(!vapply(identity[c(
        "r_version", "quarto_version", "pandoc_version", "renv_version",
        "targets_version", "crew_version"
      )], .remote_is_scalar_string, logical(1)))) {
    .remote_stop("REMOTE_RUNTIME_IDENTITY_INVALID")
  }
  registry <- utils::read.csv(
    file.path(project_root, "config", "runtime_profile_registry.csv"),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  row <- registry[registry$runtime_profile_id == identity$runtime_profile_id, , drop = FALSE]
  version_fields <- c(
    "r_version", "quarto_version", "pandoc_version", "renv_version",
    "targets_version", "crew_version"
  )
  if (nrow(row) != 1L || any(!vapply(version_fields, function(field) {
    identical(as.character(identity[[field]]), as.character(row[[field]][[1L]]))
  }, logical(1)))) .remote_stop("REMOTE_RUNTIME_DECLARED_VERSION_MISMATCH")
  measured <- .remote_measure_runtime_versions(runtime_root)
  if (any(!vapply(version_fields, function(field) {
    identical(as.character(identity[[field]]), as.character(measured[[field]]))
  }, logical(1)))) .remote_stop("REMOTE_RUNTIME_MEASURED_VERSION_MISMATCH")
  if (!identical(identity$system_abi_sha256, measured$system_abi_sha256)) {
    .remote_stop("REMOTE_RUNTIME_MEASURED_ABI_MISMATCH")
  }
  inventory_path <- file.path(runtime_root, "RUNTIME_PACKAGE_INVENTORY.json")
  if (!identical(remote_sha256_file(inventory_path), identity$package_inventory_sha256)) {
    .remote_stop("REMOTE_RUNTIME_INVENTORY_SHA_MISMATCH")
  }
  inventory <- .remote_read_json(inventory_path)
  .remote_validate_runtime_inventory(
    inventory, identity, runtime_root, project_root, runtime_files
  )
  if (!identical(identity$conda_explicit_spec_sha256, inventory$conda_explicit_spec_sha256) ||
      !identical(as.integer(identity$source_date_epoch), as.integer(inventory$source_date_epoch)) ||
      !identical(identity$r_system_package_source_lock_sha256, inventory$r_system_package_source_lock_sha256) ||
      !identical(identity$r_source_compatibility_patch_lock_sha256,
        inventory$r_source_compatibility_patch_lock_sha256) ||
      !identical(identity$r_source_compatibility_receipt_set_sha256,
        inventory$r_source_compatibility_receipt_set_sha256) ||
      !identical(identity$font_asset_lock_sha256, inventory$font_asset_lock_sha256) ||
      !identical(identity$font_asset_tree_sha256, inventory$font_asset_tree_sha256) ||
      !identical(identity$runtime_path_normalization_receipt_sha256,
        inventory$runtime_path_normalization_receipt_sha256) ||
      !identical(identity$runtime_private_path_findings_sha256,
        inventory$runtime_private_path_findings_sha256) ||
      !identical(identity$runtime_private_path_post_findings_sha256,
        inventory$runtime_private_path_post_findings_sha256) ||
      !identical(identity$runtime_historical_instance_transform_contract_sha256,
        inventory$runtime_historical_instance_transform_contract_sha256)) {
    .remote_stop("REMOTE_RUNTIME_IDENTITY_LOCK_PROJECTION_MISMATCH")
  }
  invisible(inventory)
}

build_remote_runtime_bundle <- function(
    runtime_root, output_dir, source_date_epoch = 1786579200) {
  runtime_root <- normalizePath(runtime_root, mustWork = TRUE)
  if (length(source_date_epoch) != 1L || !is.numeric(source_date_epoch) ||
      !is.finite(source_date_epoch) || source_date_epoch <= 0 ||
      source_date_epoch != as.integer(source_date_epoch)) {
    .remote_stop("REMOTE_RUNTIME_SOURCE_DATE_EPOCH_INVALID")
  }
  files <- .remote_runtime_files(runtime_root)
  supplied <- .remote_read_json(file.path(runtime_root, "RUNTIME_IDENTITY.json"))
  project_root <- .remote_builder_project_root()
  inventory <- .remote_validate_runtime_identity(
    supplied, runtime_root, project_root, files
  )
  if (!identical(as.integer(supplied$source_date_epoch), as.integer(source_date_epoch))) {
    .remote_stop("REMOTE_RUNTIME_SOURCE_DATE_EPOCH_MISMATCH")
  }
  receipts <- inventory$upstream_path_receipts
  if (is.list(receipts) && !is.data.frame(receipts) && !length(receipts)) receipts <- data.frame()
  .remote_scan_bundle_source(runtime_root, files, "RUNTIME", receipts)
  identity <- list(
    schema_version = "1.0.0",
    bundle_kind = "RUNTIME_BUNDLE",
    execution_revision = "v4.3-r00",
    build_revision = "v4.3-r15",
    source_date_epoch = as.integer(source_date_epoch),
    runtime_profile_id = supplied$runtime_profile_id,
    platform = supplied$platform,
    runtime_identity_sha256 = remote_sha256_text(remote_canonical_json(supplied)),
    package_inventory_sha256 = supplied$package_inventory_sha256,
    conda_explicit_spec_sha256 = supplied$conda_explicit_spec_sha256,
    r_system_package_source_lock_sha256 = supplied$r_system_package_source_lock_sha256,
    r_source_compatibility_patch_lock_sha256 =
      supplied$r_source_compatibility_patch_lock_sha256,
    r_source_compatibility_receipt_set_sha256 =
      supplied$r_source_compatibility_receipt_set_sha256,
    font_asset_lock_sha256 = supplied$font_asset_lock_sha256,
    font_asset_tree_sha256 = supplied$font_asset_tree_sha256,
    runtime_path_normalization_receipt_sha256 =
      supplied$runtime_path_normalization_receipt_sha256,
    runtime_private_path_findings_sha256 = supplied$runtime_private_path_findings_sha256,
    runtime_private_path_post_findings_sha256 =
      supplied$runtime_private_path_post_findings_sha256,
    runtime_historical_instance_transform_contract_sha256 =
      supplied$runtime_historical_instance_transform_contract_sha256,
    system_abi_sha256 = supplied$system_abi_sha256,
    network_restore_allowed = FALSE,
    restore_policy = "VERIFY_PRESEALED_RUNTIME_ONLY"
  )
  .remote_build_bundle(
    runtime_root, files, output_dir, "RUNTIME_BUNDLE", "RUNTIME", identity,
    source_date_epoch, receipts
  )
}

build_remote_execution_package <- function(
    root = ".", output_dir = file.path(root, "remote_build"), runtime_root = "",
    revision = "v4.3-r00", source_date_epoch = 1786579200, dry_run = FALSE) {
  if (!identical(revision, "v4.3-r00")) .remote_stop("REMOTE_EXECUTION_REVISION_INVALID")
  if (isTRUE(dry_run)) {
    files <- collect_remote_code_files(root)
    return(list(
      status = "PASS", dry_run = TRUE, revision = revision,
      code_file_count = length(files),
      runtime_payload_status = if (nzchar(runtime_root)) "SUPPLIED_NOT_BUILT" else "EXTERNAL_INPUT_BLOCKED",
      production_authorized = FALSE
    ))
  }
  if (!nzchar(runtime_root)) .remote_stop("REMOTE_LINUX64_RUNTIME_ROOT_REQUIRED")
  code <- build_remote_code_bundle(root, file.path(output_dir, "code"), source_date_epoch)
  runtime <- build_remote_runtime_bundle(runtime_root, file.path(output_dir, "runtime"), source_date_epoch)
  package_set <- list(
    schema_version = "1.0.0",
    execution_revision = "v4.3-r00",
    code_bundle = remote_bundle_request_identity(code),
    runtime_bundle = remote_bundle_request_identity(runtime),
    restricted_input_embedded = FALSE,
    production_authorized = FALSE
  )
  package_set_path <- file.path(output_dir, "REMOTE_PACKAGE_SET.json")
  if (file.exists(package_set_path)) .remote_stop("REMOTE_PACKAGE_SET_EXISTS")
  # 写入不含数据、凭据或绝对路径的双 bundle 描述文件。
  .remote_write_atomic(package_set_path, remote_canonical_json(package_set), mode = "0444")
  package_set_sha256 <- remote_sha256_file(package_set_path)
  package_set_sidecar <- paste0(package_set_path, ".sha256")
  # 写入本地 package set SHA sidecar。
  writeLines(
    paste(package_set_sha256, basename(package_set_path), sep = "  "),
    package_set_sidecar, useBytes = TRUE
  )
  c(package_set, list(
    status = "PASS", dry_run = FALSE, revision = revision,
    code_archive = code$archive,
    runtime_archive = runtime$archive,
    package_set_path = package_set_path,
    package_set_sha256 = package_set_sha256
  ))
}

.remote_cli_spec <- function(command) {
  switch(
    command,
    "build-package" = c("--root", "--runtime-root", "--output-dir", "--source-date-epoch"),
    "build-code" = c("--root", "--output-dir", "--source-date-epoch"),
    "build-runtime" = c("--runtime-root", "--output-dir", "--source-date-epoch"),
    "verify" = c("--archive", "--expected-sha256", "--kind", "--extract-root"),
    .remote_stop("REMOTE_CLI_UNKNOWN_COMMAND", command)
  )
}

parse_remote_builder_args <- function(args) {
  if (!length(args) || startsWith(args[[1L]], "--")) .remote_stop("REMOTE_CLI_COMMAND_REQUIRED")
  command <- args[[1L]]
  allowed <- .remote_cli_spec(command)
  values <- list()
  index <- 2L
  while (index <= length(args)) {
    flag <- args[[index]]
    if (!startsWith(flag, "--") || !flag %in% allowed) .remote_stop("REMOTE_CLI_UNKNOWN_ARGUMENT", flag)
    if (flag %in% names(values)) .remote_stop("REMOTE_CLI_DUPLICATE_ARGUMENT", flag)
    if (index == length(args) || startsWith(args[[index + 1L]], "--")) {
      .remote_stop("REMOTE_CLI_MISSING_VALUE", flag)
    }
    values[[flag]] <- args[[index + 1L]]
    index <- index + 2L
  }
  list(command = command, values = values)
}

.remote_cli_value <- function(parsed, flag, default = NULL, required = FALSE) {
  value <- parsed$values[[flag]]
  if (is.null(value)) value <- default
  if (isTRUE(required) && (is.null(value) || !nzchar(value))) .remote_stop("REMOTE_CLI_REQUIRED_ARGUMENT", flag)
  value
}

run_remote_builder_cli <- function(args) {
  parsed <- parse_remote_builder_args(args)
  epoch <- as.numeric(.remote_cli_value(parsed, "--source-date-epoch", "1786579200"))
  result <- switch(
    parsed$command,
    "build-package" = build_remote_execution_package(
      root = .remote_cli_value(parsed, "--root", "."),
      runtime_root = .remote_cli_value(parsed, "--runtime-root", required = TRUE),
      output_dir = .remote_cli_value(parsed, "--output-dir", required = TRUE),
      source_date_epoch = epoch
    ),
    "build-code" = build_remote_code_bundle(
      root = .remote_cli_value(parsed, "--root", "."),
      output_dir = .remote_cli_value(parsed, "--output-dir", required = TRUE),
      source_date_epoch = epoch
    ),
    "build-runtime" = build_remote_runtime_bundle(
      runtime_root = .remote_cli_value(parsed, "--runtime-root", required = TRUE),
      output_dir = .remote_cli_value(parsed, "--output-dir", required = TRUE),
      source_date_epoch = epoch
    ),
    "verify" = verify_remote_bundle_archive(
      archive = .remote_cli_value(parsed, "--archive", required = TRUE),
      expected_sha256 = .remote_cli_value(parsed, "--expected-sha256", required = TRUE),
      expected_kind = .remote_cli_value(parsed, "--kind", required = TRUE),
      extract_root = .remote_cli_value(parsed, "--extract-root", NULL)
    )
  )
  safe_result <- result
  for (field in intersect(
    names(safe_result),
    c("archive", "code_archive", "runtime_archive", "package_set_path")
  )) {
    safe_result[[field]] <- basename(safe_result[[field]])
  }
  if ("root" %in% names(safe_result)) safe_result$root <- ""
  # 输出不含本机绝对路径的最小 CLI 摘要。
  print(safe_result)
  invisible(result)
}

if (sys.nframe() == 0L) {
  run_remote_builder_cli(commandArgs(trailingOnly = TRUE))
}
