# 旧连续执行入口永久封停；正式计算只允许 mainctl 的单 request、单阶段路线。
stop("LEGACY_CONTINUOUS_PIPELINE_DISABLED_USE_MAINCTL_STATELESS_STAGES", call. = FALSE)
