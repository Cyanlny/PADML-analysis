# Registry 升级脚本：机械补齐生产追溯字段，不改变冻结科学问题。
root <- normalizePath(".")

# 加载并升级输出 registry。
output <- utils::read.csv(file.path(root, "config", "output_registry.csv"), stringsAsFactors = FALSE, check.names = FALSE)
output$file_name[output$output_id == "MF02"] <- "Main_Figure2_KM_AST_ALT_Tertiles.svg"
output$file_name[output$output_id == "MF04"] <- "Main_Figure4_Continuous_Per1SD_TimeVarying_HR.svg"

source_map <- c(
  MT01 = "table1_results.csv", MT02 = "fixed_cox_results.csv", MT03 = "tve_results.csv", MT04 = "tve_results.csv",
  MT05 = "imputation_qc_results.csv", MT06 = "sensitivity_results.csv",
  MF01 = "exposure_identity_summary.csv", MF02 = "km_curve_results.csv", MF03 = "tve_results.csv", MF04 = "tve_results.csv", MF05 = "rcs_curve_results.csv", MF06 = "subgroup_results.csv",
  ST01 = "endpoint_registry.csv", ST02 = "exposure_scale_lock.csv", ST03 = "model_registry.csv", ST04 = "imputation_qc_results.csv",
  ST05 = "imputation_qc_results.csv", ST06 = "imputation_qc_results.csv", ST07 = "sensitivity_results.csv", ST08 = "ph_per_imputation_term_results.csv",
  ST09 = "ph_trigger_summary.csv", ST10 = "design_matrix_qc.csv", ST11 = "tve_model_diagnostics.csv", ST12 = "tve_results.csv",
  ST13 = "tve_results.csv", ST14 = "tve_results.csv", ST15 = "tve_results.csv", ST16 = "rcs_curve_results.csv", ST17 = "rcs_qc_results.csv",
  ST18 = "subgroup_results.csv", ST19 = "subgroup_interaction_results.csv", ST20 = "subgroup_information_audit.csv",
  ST21 = "sensitivity_results.csv", ST22 = "sensitivity_results.csv", ST23 = "sensitivity_results.csv", ST24 = "loio_results.csv", ST25 = "loco_results.csv",
  ST26 = "sensitivity_results.csv", ST27 = "sensitivity_results.csv", ST28 = "sensitivity_results.csv", ST29 = "sensitivity_results.csv", ST30 = "secondary_endpoint_results.csv",
  ST31 = "fixed_cox_diagnostics.csv", ST32 = "output_completeness.csv",
  SF01 = "imputation_qc_results.csv", SF02 = "imputation_qc_results.csv", SF03 = "imputation_qc_results.csv", SF04 = "imputation_qc_results.csv", SF05 = "imputation_qc_results.csv",
  SF06 = "sensitivity_results.csv", SF07 = "ph_per_imputation_term_results.csv", SF08 = "ph_dummy_direction_summary.csv", SF09 = "tve_results.csv", SF10 = "tve_results.csv",
  SF11 = "rcs_curve_results.csv", SF12 = "riskset_results.csv", SF13 = "loco_results.csv", SF14 = "sensitivity_results.csv", SF15 = "tve_results.csv",
  SF16 = "sensitivity_results.csv", SF17 = "secondary_endpoint_results.csv", SF18 = "fixed_cox_diagnostics.csv"
)
producer_map <- c(
  "table1_results.csv" = "A01", "exposure_identity_summary.csv" = "A01", "exposure_scale_lock.csv" = "A01", "riskset_results.csv" = "A01", "km_curve_results.csv" = "A01",
  "imputation_qc_results.csv" = "A02", "fixed_cox_results.csv" = "A03", "ph_per_imputation_term_results.csv" = "A03", "ph_trigger_summary.csv" = "A03", "design_matrix_qc.csv" = "A03", "ph_dummy_direction_summary.csv" = "A03", "fixed_cox_diagnostics.csv" = "A03",
  "tve_results.csv" = "A04", "tve_model_diagnostics.csv" = "A04", "rcs_curve_results.csv" = "A04", "rcs_qc_results.csv" = "A04",
  "subgroup_results.csv" = "A05", "subgroup_interaction_results.csv" = "A05", "subgroup_information_audit.csv" = "A05",
  "sensitivity_results.csv" = "A06", "loio_results.csv" = "A06", "loco_results.csv" = "A06", "secondary_endpoint_results.csv" = "A06",
  "endpoint_registry.csv" = "A07", "model_registry.csv" = "A07", "output_completeness.csv" = "A07"
)
output$schema_id <- ifelse(output$format == "CSV", "PUBLICATION_TABLE_V1", "PUBLICATION_FIGURE_V1")
output$source_cache <- "approved_cache/public/{producer_stage}"
output$source_canonical_file <- unname(source_map[output$output_id])
output$analysis_id <- output$output_id
output$estimand_id <- "REGISTRY_FILTER"
output$model_signature_sha256 <- "FROM_CANONICAL_LAYER"
output$figure_data_csv <- ifelse(output$format == "SVG", paste0(tools::file_path_sans_ext(output$file_name), "_data.csv"), "")
output$figure_data_hash_sidecar <- ifelse(output$format == "SVG", paste0(tools::file_path_sans_ext(output$file_name), "_data.sha256"), "")
output$width_in <- ifelse(output$format == "SVG", 7, NA)
output$height_in <- ifelse(output$format == "SVG", 5, NA)
output$font <- ifelse(output$format == "SVG", "Arial_or_Liberation_Sans", "")
output$annotation_rule <- ifelse(output$format == "SVG", "read_canonical_annotation_columns_only", "not_applicable")
output$producer_stage <- unname(producer_map[output$source_canonical_file])
output$producer_stage[is.na(output$producer_stage)] <- "A07"
output$publication_stage <- "A07"
output$stage <- output$producer_stage
# 输出升级后的 registry。
utils::write.csv(output, file.path(root, "config", "output_registry.csv"), row.names = FALSE, na = "")

# 生成 warning registry，明确自动继续和人工审核边界。
warning_registry <- data.frame(
  warning_code = c(
    "W_INFO_NOTE", "W_NONBLOCKING_SUPPLEMENT_LOW_INFO", "W_BLOCKING_LATE_TIME_SPARSE", "W_BLOCKING_MAIN_MODEL_INCOMPLETE",
    "W_BLOCKING_NEW_NUISANCE_TVE", "W_BLOCKING_RCS_TAIL", "W_BLOCKING_LOCO_DIRECTION", "W_BLOCKING_LOIO_DEPENDENCE",
    "W_BLOCKING_COVARIANCE", "W_BLOCKING_OUTPUT_MISSING", "W_BLOCKING_LOGGED_EVENT", "W_RESOURCE_GATE"
  ),
  domain = c("general", "supplement", "riskset", "model", "ph", "rcs", "sensitivity", "sensitivity", "numeric", "output", "imputation", "runtime"),
  stage = c("ALL", "A05|A06", "A04", "A03", "A03", "A04", "A06", "A06", "A03|A04", "A07", "A02", "P00"),
  condition_expression = c("informational_only", "supplementary_events_or_df_low", "late_time_support_below_registry", "M1_M5_valid_imputation_n_lt_20", "new_nuisance_tve_triggered", "tail_ci_or_grid_instability", "loco_direction_reversal", "loio_single_imputation_dependence", "covariance_near_singular", "required_output_absent", "unresolved_logged_event", "resource_budget_not_met"),
  class = c("INFO", "NONBLOCKING_WARNING", rep("BLOCKING_WARNING", 10)),
  required_action = c("record", "retain_and_label_exploratory", rep("human_review", 10)),
  continuation_rule = c("continue", "continue", rep("pause", 10)),
  human_review_required = c(FALSE, FALSE, rep(TRUE, 10)),
  result_retention_rule = c("retain", "retain", rep("retain_structured", 10)),
  interpretation_text_cn = c("信息记录", "补充结果信息量有限，仅作探索性解释", "晚期风险集不足", "正文模型链不完整", "发现新的nuisance TVE候选", "RCS尾部不稳定", "LOCO方向反转", "结果依赖单套插补", "协方差近奇异", "正式输出缺失", "插补事件尚未解释", "运行资源不足"),
  stringsAsFactors = FALSE
)
utils::write.csv(warning_registry, file.path(root, "config", "warning_registry.csv"), row.names = FALSE)

# 逐变量锁定 Table 1 展示和检验方法。
continuous_mean <- c("Age", "BMI", "SBP", "DBP", "HR", "RBC", "HGB", "HCT", "MCV", "MCH", "MCHC", "PLT", "MPV", "ALB", "ALT", "AST")
continuous_median <- c("WBC", "RDW_CV", "RDW_SD", "PDW", "ESO", "BASO", "NEUT", "LYMPH", "MONO", "Creatinine", "eGFR_calc", "FBG", "D_Dimer", "PT", "PT_Activity", "INR", "FIB", "APTT", "AST_ALT")
categorical <- c("Sex", "Rutherford_cat", "Smoking", "DM", "HTN_bin", "Heart_Disease", "HF_NYHA_bin", "CVD", "CKD_bin", "Dyslipidemia", "COPD", "Anemia", "Hyperhcy", "Hyperuricemia", "Antihypertensive", "Lipid_Lowering", "Antiplatelet", "Prior_LE_Surgery_cat", "Anesthesia_cat", "Surgery_Type_cat")
table1 <- rbind(
  data.frame(variable = continuous_mean, variable_type = "continuous", display_method = "mean_sd", primary_test = "ANOVA", fallback_method = "Kruskal_Wallis", reference = "not_applicable", decimals = 2L),
  data.frame(variable = continuous_median, variable_type = "continuous", display_method = "median_iqr", primary_test = "Kruskal_Wallis", fallback_method = "none", reference = "not_applicable", decimals = 2L),
  data.frame(variable = categorical, variable_type = "categorical", display_method = "n_percent", primary_test = "Pearson_chisq", fallback_method = "Monte_Carlo_Fisher", reference = "registry_level_1", decimals = 1L)
)
table1$method_lock_reason <- "prespecified_before_outcome_results"
table1$fallback_trigger <- ifelse(table1$variable_type == "categorical", "any_expected_cell_lt_5_or_chisq_failure", "calculation_failure_only")
table1$monte_carlo_seed <- 43001L
utils::write.csv(table1, file.path(root, "config", "table1_method_registry.csv"), row.names = FALSE)

# 建立 canonical 文件 registry。
canonical <- unique(output[c("source_canonical_file", "producer_stage")])
canonical <- canonical[nzchar(canonical$source_canonical_file), , drop = FALSE]
canonical$canonical_schema_id <- paste0(toupper(gsub("\\.csv$", "", canonical$source_canonical_file)), "_V1")
canonical$primary_key <- "registry_defined_composite_key"
canonical$patient_level_allowed <- FALSE
canonical$required_model_signature <- grepl("cox|tve|rcs|subgroup|sensitivity|secondary", canonical$source_canonical_file)
canonical$scientific_config_revision <- "r01"
utils::write.csv(canonical, file.path(root, "config", "canonical_file_registry.csv"), row.names = FALSE)

# 补充 D1 时间交互规则。
pooling <- utils::read.csv(file.path(root, "config", "multiparameter_pooling_registry.csv"), stringsAsFactors = FALSE, check.names = FALSE)
if (!"time_interaction" %in% pooling$analysis_type) {
  template <- pooling[pooling$analysis_type == "subgroup_interaction", , drop = FALSE]
  template$analysis_type <- "time_interaction"
  pooling <- rbind(pooling, template)
}
utils::write.csv(pooling, file.path(root, "config", "multiparameter_pooling_registry.csv"), row.names = FALSE)

# 扩展 QC gate registry 到生产链关键接口。
qc <- utils::read.csv(file.path(root, "config", "qc_gate_registry.csv"), stringsAsFactors = FALSE, check.names = FALSE)
extra <- data.frame(
  qc_id = sprintf("QC%03d", 19:42),
  stage = c("P00", "P00", "P01", "P01", "P02", "A01", "A01", "A01", "A02", "A03", "A03", "A03", "A03", "A04", "A04", "A04", "A05", "A06", "A06", "A07", "A07", "A07", "A07", "A07"),
  check = c("upstream_expected_sha_fields", "safe_restricted_path", "model_formula_expansion", "registry_cross_reference", "real_structure_canary", "patient_order_sha", "exposure_join_one_to_one", "riskset_source_lock", "logged_events_resolved", "d1_term_order", "rubin_df_valid", "ph_parent_joint", "model_signature_present", "beta_gamma_covariance", "riskset_support", "rcs_reference_identity", "interaction_family_fdr", "loio_drop_one_dataset", "loco_center_excluded_not_adjusted", "canonical_source_traceability", "figure_data_sidecar", "p_numeric_display_pair", "review_package_privacy", "release_restricted_path_scan"),
  severity = "hard_stop",
  pass_rule = c("present", "restricted_cache_only", "all_parse", "all_ids_resolve", "pass_without_model_fit", "identical", "unmatched_and_duplicate_zero", "imp0_only", "all_resolved_or_approved", "identical", "finite_positive_or_pos_inf_when_between_variance_exact_zero_per_RUBIN_DF_1A", "multilevel_parent_rule", "nonempty", "used", "registry_threshold", "hr_equal_one", "families_separate", "20_rounds_19_retained", "center_absent_from_formula", "all_outputs_mapped", "all_svg_have_data_and_hash", "numeric_and_display", "no_identifier_or_absolute_path", "zero_restricted_files"),
  fail_state = "FAIL",
  stringsAsFactors = FALSE
)
qc <- rbind(qc, extra)
utils::write.csv(qc, file.path(root, "config", "qc_gate_registry.csv"), row.names = FALSE)

# 补充结构化不可估计原因。
ne <- utils::read.csv(file.path(root, "config", "not_estimable_reason_registry.csv"), stringsAsFactors = FALSE, check.names = FALSE)
new_codes <- data.frame(
  reason_code = c("NE_PROTOCOL_DEFINED_DEFERRED", "NE_D1_TERM_ORDER_MISMATCH", "NE_RISKSET_SPARSE", "NE_REVIEW_NOT_APPROVED"),
  description = c("Registered task deferred by explicit protocol state", "D1 parameter order mismatch", "Risk set does not support requested time point", "Required human approval is absent"),
  default_severity = c("NONBLOCKING_WARNING", "BLOCKING_IF_REQUIRED", "NONBLOCKING_IF_SUPPLEMENTARY", "BLOCKING_IF_REQUIRED"),
  stringsAsFactors = FALSE
)
new_codes <- new_codes[!new_codes$reason_code %in% ne$reason_code, , drop = FALSE]
if (nrow(new_codes)) ne <- rbind(ne, new_codes[names(ne)])
utils::write.csv(ne, file.path(root, "config", "not_estimable_reason_registry.csv"), row.names = FALSE)

message("r01 registries upgraded")
