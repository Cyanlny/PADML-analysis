# AutoDL 无状态入口：只执行请求中登记的一个阶段，不审核、不批准、不发布下一阶段。

args <- commandArgs(trailingOnly = TRUE)
allowed <- c("--project-root", "--run-root", "--input-root", "--request")
if (length(args) != 8L || any(args[seq(1L, 8L, by = 2L)] != allowed) || any(!nzchar(args[seq(2L, 8L, by = 2L)]))) {
  stop("STATELESS_STAGE_ARGUMENT_CONTRACT_INVALID", call. = FALSE)
}
value <- setNames(args[seq(2L, 8L, by = 2L)], allowed)
project_root <- normalizePath(value[["--project-root"]], mustWork = TRUE)
run_root <- normalizePath(value[["--run-root"]], mustWork = TRUE)
input_root <- normalizePath(value[["--input-root"]], mustWork = TRUE)
request_path <- normalizePath(value[["--request"]], mustWork = TRUE)

# 加载 JSON 包并读取已由 worker 校验的单阶段请求。
if (!requireNamespace("jsonlite", quietly = TRUE)) stop("STATELESS_JSONLITE_MISSING", call. = FALSE)
request <- jsonlite::read_json(request_path, simplifyVector = TRUE)
remote_stages <- c("P00", "A01", "A02", "A03", "A04", "A05", "A06")
formal_control <- identical(request$execution_purpose, "STAGE_COMPUTE") &&
  identical(request$stage, "CONTROL")
permission_names <- c("retry", "approve", "publish", "freeze", "create_next_request")
permissions_valid <- is.list(request$permissions) &&
  setequal(names(request$permissions), permission_names) &&
  all(vapply(request$permissions[permission_names], function(value) identical(value, FALSE), logical(1)))
if (!identical(request$execution_purpose, "STAGE_COMPUTE") ||
    !identical(request$execution_profile, "production") ||
    !identical(request$execution_mode, "SINGLE_TRANSACTION") ||
    (!formal_control && !request$stage %in% remote_stages) || identical(request$stage, "A07") ||
    !permissions_valid) {
  stop("STATELESS_STAGE_REQUEST_SCOPE_INVALID", call. = FALSE)
}
if (!identical(Sys.getenv("AST_ALT_STATELESS_COMPUTE_NODE", unset = ""), "TRUE")) {
  stop("STATELESS_COMPUTE_NODE_FLAG_REQUIRED", call. = FALSE)
}
runtime_admission_identity <- Sys.getenv("AST_ALT_VERIFIED_RUNTIME_IDENTITY_SHA256", unset = "")
if (!grepl("^[0-9a-f]{64}$", runtime_admission_identity)) {
  stop("STATELESS_RUNTIME_ADMISSION_IDENTITY_REQUIRED", call. = FALSE)
}

Sys.setenv(
  AST_ALT_PROJECT_ROOT = project_root,
  AST_ALT_RUN_ROOT = run_root,
  AST_ALT_EXECUTION_PROFILE = "production",
  AST_ALT_RUN_ID = request$run_id,
  AST_ALT_REMOTE_REQUEST_SHA256 = request$request_semantic_sha256,
  OMP_NUM_THREADS = "1", OPENBLAS_NUM_THREADS = "1", MKL_NUM_THREADS = "1",
  BLIS_NUM_THREADS = "1", RCPP_PARALLEL_NUM_THREADS = "1"
)

.run_stateless_formal_mice_control <- function(
    project_root, run_root, input_root, request) {
  required_root <- c(
    "source.xlsx", "formal_request.json", "formal_authorization.json"
  )
  root_files <- list.files(input_root, recursive = FALSE, full.names = FALSE, all.files = TRUE, no.. = TRUE)
  audit_roots <- root_files[grepl("^source_audit_[0-9a-f]{64}_[0-9a-f]{64}$", root_files)]
  if (!identical(sort(setdiff(root_files, audit_roots)), sort(required_root)) || length(audit_roots) != 1L) {
    stop("STATELESS_FORMAL_INPUT_MEMBER_SET_INVALID", call. = FALSE)
  }
  all_input <- list.files(input_root, recursive = TRUE, full.names = TRUE, all.files = TRUE, no.. = TRUE)
  if (any(nzchar(Sys.readlink(all_input))) || any(file.info(all_input)$mode %% 512L != 384L)) {
    stop("STATELESS_FORMAL_INPUT_MODE_INVALID", call. = FALSE)
  }

  # 中文备注：加载唯一 control kernel 以提供原子写入和规范身份函数。
  source(file.path(project_root, "R", "control_kernel.R"))
  # 中文备注：加载既有 source adapter 以核验并构建同一 A2 handoff。
  source(file.path(project_root, "R", "source_input_adapter.R"))
  # 中文备注：加载既有 H1 authority owner，不建立第二授权面。
  source(file.path(project_root, "R", "authorization_engine.R"))
  # 中文备注：加载唯一 V22 predictor-policy recipe compiler。
  source(file.path(project_root, "R", "mi_recipe_engine.R"))
  # 中文备注：加载同 request checkpoint transaction owner。
  source(file.path(project_root, "R", "mi_transaction_engine.R"))
  # 中文备注：加载唯一 formal MICE execution owner。
  source(file.path(project_root, "R", "formal_mice_engine.R"))
  # 中文备注：加载既有 formal runner 接口，由当前 stateless stage 唯一调用。
  source(file.path(project_root, "scripts", "run_formal_mice_handoff.R"))

  candidate_root <- file.path(run_root, "restricted_cache", "formal_mice")
  dir.create(candidate_root, recursive = TRUE, mode = "0700")
  audit_target <- file.path(candidate_root, audit_roots[[1L]])
  if (!dir.create(audit_target, mode = "0700")) {
    stop("STATELESS_FORMAL_AUDIT_STAGING_FAILED", call. = FALSE)
  }
  audit_source <- file.path(input_root, audit_roots[[1L]])
  # 中文备注：保存 request-bound aggregate source audit 到唯一受限计算根。
  copied <- file.copy(
    list.files(audit_source, full.names = TRUE, all.files = TRUE, no.. = TRUE),
    audit_target, copy.mode = TRUE, copy.date = FALSE
  )
  if (!length(copied) || !all(copied)) stop("STATELESS_FORMAL_AUDIT_STAGING_FAILED", call. = FALSE)

  proposal_path <- file.path(input_root, "formal_request.json")
  authorization_path <- file.path(input_root, "formal_authorization.json")
  proposal <- .formal_runner_normalize_request_v43(
    jsonlite::read_json(proposal_path, simplifyVector = TRUE)
  )
  admission_identity <- Sys.getenv("AST_ALT_VERIFIED_RUNTIME_IDENTITY_SHA256", unset = "")
  if (!identical(proposal$runtime_admission_identity_sha256, admission_identity)) {
    stop("STATELESS_FORMAL_RUNTIME_IDENTITY_MISMATCH", call. = FALSE)
  }
  authorization_sha <- .mi_tx_sha256_file(authorization_path)
  authorization <- load_formal_mice_authorization_v43(
    authorization_path, authorization_sha, request = proposal
  )
  audit_receipt <- jsonlite::read_json(
    file.path(audit_target, "source_candidate_receipt.json"), simplifyVector = TRUE
  )
  audit_identity <- source_candidate_receipt_identity_v43(audit_receipt)
  current <- .formal_runner_normalize_request_v43(
    build_mi_transaction_request_proposal_v43(audit_receipt, project_root)
  )
  if (!identical(current, proposal)) stop("STATELESS_FORMAL_REQUEST_IDENTITY_MISMATCH", call. = FALSE)
  transaction_root <- file.path(candidate_root, "mi_transactions")
  final_build <- NULL
  plan <- c(30L, 40L, 50L, 100L, 200L)
  expected_continuation <- c(
    `30` = "FORMAL_MICE_CONTINUATION_TO_40_REQUIRED",
    `40` = "FORMAL_MICE_CONTINUATION_TO_50_REQUIRED",
    `50` = "FORMAL_MICE_CONTINUATION_TO_100_REQUIRED",
    `100` = "FORMAL_MICE_CONTINUATION_TO_200_REQUIRED"
  )
  for (iteration in plan) {
    # 中文备注：在 accepted V3 上执行唯一 formal MICE initial/continuation；同 request 不重放 checkpoint。
    execution <- run_formal_mice_handoff_main(c(
      "--mode", "execute",
      "--source-xlsx", file.path(input_root, "source.xlsx"),
      "--candidate-root", candidate_root,
      "--source-epoch", audit_receipt$source_epoch,
      "--source-receipt-sha256", audit_identity,
      "--authorization-receipt", authorization_path,
      "--authorization-file-sha256", authorization_sha,
      "--transaction-root", transaction_root,
      "--desired-iteration", as.character(iteration)
    ), project_root = project_root, print_flag = FALSE)
    if (!execution$status %in% c("CHECKPOINTED", "REUSE_CHECKPOINT")) {
      stop("STATELESS_FORMAL_CHECKPOINT_TERMINAL_INVALID", call. = FALSE)
    }
    transaction_path <- file.path(transaction_root, proposal$request_sha256)
    state <- inspect_mi_transaction_v43(transaction_path, proposal)
    checkpoint <- tail(state$checkpoints, 1L)[[1L]]
    if (!identical(as.integer(checkpoint$iteration), iteration)) {
      stop("STATELESS_FORMAL_CHECKPOINT_IDENTITY_MISMATCH", call. = FALSE)
    }
    # 中文备注：在每个 checkpoint 后执行既有 U04/U05 builder；只有 typed CONTINUE 才进入下一迭代。
    built <- prepare_source_handoff_main(c(
      "--mode", "build-candidate", "--source-id", proposal$source_id,
      "--source-xlsx", file.path(input_root, "source.xlsx"),
      "--candidate-root", candidate_root,
      "--approval-id", authorization$decision_id,
      "--source-epoch", audit_receipt$source_epoch,
      "--source-receipt-sha256", audit_identity,
      "--authorization-receipt", authorization_path,
      "--authorization-file-sha256", authorization_sha
    ), project_root)
    if (identical(built$status, "CANDIDATE_SEALED_PENDING_EXTERNAL_APPROVAL")) {
      final_build <- built
      break
    }
    if (iteration == 200L || !identical(
      built$reason_code, unname(expected_continuation[[as.character(iteration)]])
    )) {
      stop(as.character(built$reason_code %||% "MI_QC_TERMINAL_UNKNOWN"), call. = FALSE)
    }
  }
  if (is.null(final_build)) {
    stop("STATELESS_FORMAL_RESULT_INCOMPLETE", call. = FALSE)
  }

  public <- file.path(run_root, "candidate_cache", "public", "CONTROL")
  restricted <- file.path(run_root, "candidate_cache", "restricted", "CONTROL")
  dir.create(public, recursive = TRUE, mode = "0755")
  dir.create(restricted, recursive = TRUE, mode = "0700")
  candidate_paths <- list.files(
    file.path(candidate_root, "handoff_candidates"), pattern = "source_handoff_candidate[.]zip$",
    recursive = TRUE, full.names = TRUE
  )
  if (length(candidate_paths) != 1L) stop("STATELESS_FORMAL_CANDIDATE_CARDINALITY_INVALID", call. = FALSE)
  candidate_dir <- dirname(candidate_paths[[1L]])
  # 中文备注：保存已通过 U04/U05 的唯一候选及其受限 receipts。
  if (!all(file.copy(
    list.files(candidate_dir, full.names = TRUE, all.files = TRUE, no.. = TRUE),
    restricted, copy.mode = TRUE, copy.date = FALSE
  ))) stop("STATELESS_FORMAL_RESULT_COPY_FAILED", call. = FALSE)
  final_state <- inspect_mi_transaction_v43(
    file.path(transaction_root, proposal$request_sha256), proposal
  )
  final_checkpoint <- tail(final_state$checkpoints, 1L)[[1L]]
  formal_receipt <- list(
    schema_version = "1.0.0", status = "PASS", request_sha256 = proposal$request_sha256,
    final_iteration = as.integer(final_state$frozen$final_iteration),
    final_checkpoint_sha256 = final_state$frozen$final_checkpoint_sha256,
    mi_qc_receipt_sha256 = final_state$frozen$mi_qc_receipt_sha256,
    handoff_candidate_sha256 = final_state$frozen$handoff_candidate_sha256,
    predictor_policy_sha256 = proposal$predictor_policy_sha256,
    candidate_projection_sha256 = proposal$candidate_projection_sha256,
    candidate_edge_n = as.integer(proposal$candidate_edge_n),
    predictor_matrix_sha256 = final_checkpoint$predictor_matrix_sha256,
    predictor_edge_n = as.integer(final_checkpoint$predictor_edge_n),
    scientific_generation_id = proposal$scientific_generation_id,
    rng_kind = proposal$rng_kind,
    chain_count = as.integer(proposal$chain_count),
    worker_pool_capacity = as.integer(proposal$worker_pool_capacity),
    chain_stream_policy = proposal$chain_stream_policy,
    chain_merge_order = proposal$chain_merge_order,
    retry_performed = FALSE, next_request_created = FALSE
  )
  formal_receipt$receipt_sha256 <- .control_sha256_text(canonical_json(formal_receipt))
  # 中文备注：原子保存不含患者值的 formal terminal receipt，供本地 sole validator 接纳。
  .control_write_atomic(
    file.path(restricted, "FORMAL_MICE_RESULT_RECEIPT.json"),
    canonical_json(formal_receipt), mode = "0600"
  )
  # 中文备注：写出 aggregate local-gate QC 候选，远端 PASS 不构成业务批准。
  utils::write.csv(data.frame(
    qc_id = "FORMAL_MICE_U04_U05", stage = "CONTROL", check = "formal_handoff_candidate",
    observed = "PASS", expected = "PASS", status = "PASS", severity = "INFO",
    details = "approved V22 predictor policy and formal handoff candidate satisfied",
    stringsAsFactors = FALSE
  ), file.path(public, "LOCAL_GATE_QC.csv"), row.names = FALSE)
  # 中文备注：写出空 warning 表以保持既有 local review 契约。
  utils::write.csv(data.frame(
    warning_code = character(), stage = character(), class = character(),
    message_cn = character(), required_action = character(), stringsAsFactors = FALSE
  ), file.path(public, "LOCAL_GATE_WARNINGS.csv"), row.names = FALSE)
  # 中文备注：写出候选 stage lock；最终业务接纳仍由本地 validator/state_events 完成。
  jsonlite::write_json(list(
    stage = "CONTROL", stage_status = "PASS_AUTO_CONTINUE",
    approval_basis = "AUTO_GATE_PASS", human_review_required = FALSE,
    data_classification = "PUBLIC_AGGREGATE"
  ), file.path(public, "stage_lock.json"), auto_unbox = TRUE)
  invisible(TRUE)
}

`%||%` <- function(value, fallback) {
  if (is.null(value) || length(value) != 1L || is.na(value) || !nzchar(value)) fallback else value
}

if (formal_control) {
  .run_stateless_formal_mice_control(project_root, run_root, input_root, request)
  quit(save = "no", status = 0L)
}

# 仅定位已由本地 registry SHA 和 capsule manifest 接纳的一个 handoff ZIP；不建立第二输入适配器。
handoff_candidates <- list.files(input_root, pattern = "\\.zip$", recursive = FALSE, full.names = TRUE)
if (length(handoff_candidates) != 1L || isTRUE(file.info(handoff_candidates[[1L]])$isdir)) {
  stop("STATELESS_PRODUCTION_HANDOFF_SET_INVALID", call. = FALSE)
}
Sys.setenv(AST_ALT_HANDOFF_ZIP = normalizePath(handoff_candidates[[1L]], mustWork = TRUE))

source(file.path(project_root, "R", "runner_control.R"))
source(file.path(project_root, "R", "bundle_manager.R"))
source(file.path(project_root, "R", "epoch_guard.R"))
dir.create(run_root, recursive = TRUE, showWarnings = FALSE)

.stateless_bounded_failure_code <- function(stage_result, run_root) {
  failure_path <- stage_result$failure_envelope
  if (!is.character(failure_path) || length(failure_path) != 1L || !nzchar(failure_path) ||
      nzchar(Sys.readlink(failure_path)) || !file.exists(failure_path) ||
      isTRUE(file.info(failure_path)$isdir)) {
    return("STATELESS_FAILURE_ENVELOPE_INVALID")
  }
  envelope_root <- normalizePath(
    file.path(run_root, "runtime", "failure_envelopes"), mustWork = TRUE
  )
  normalized_path <- normalizePath(failure_path, mustWork = TRUE)
  if (!startsWith(normalized_path, paste0(envelope_root, .Platform$file.sep))) {
    return("STATELESS_FAILURE_ENVELOPE_INVALID")
  }
  # 加载 JSON 包并只提取有界失败码；不得向外层终端传播原始消息或路径。
  envelope <- tryCatch(
    jsonlite::read_json(normalized_path, simplifyVector = TRUE),
    error = function(condition) NULL
  )
  if (!is.list(envelope) ||
      !identical(envelope$envelope_schema_version, "STAGE_FAILURE_ENVELOPE_V43_V1") ||
      !identical(envelope$stage, stage_result$stage) ||
      !identical(envelope$stage_status, stage_result$stage_status) ||
      !is.character(envelope$failure_code) || length(envelope$failure_code) != 1L ||
      !grepl("^[A-Z][A-Z0-9_]{4,127}$", envelope$failure_code) ||
      !is.character(envelope$canonical_message) || length(envelope$canonical_message) != 1L ||
      !is.character(envelope$failure_signature_sha256) ||
      length(envelope$failure_signature_sha256) != 1L ||
      !grepl("^[0-9a-f]{64}$", envelope$failure_signature_sha256)) {
    return("STATELESS_FAILURE_ENVELOPE_INVALID")
  }
  matches <- regmatches(
    envelope$canonical_message,
    gregexpr(
      "(?<![A-Z0-9_])[A-Z][A-Z0-9_]{4,127}(?![A-Z0-9_])",
      envelope$canonical_message, perl = TRUE
    )
  )[[1L]]
  suffixes <- c(
    "_FAILED", "_INVALID", "_MISSING", "_MISMATCH", "_REQUIRED", "_FORBIDDEN",
    "_UNAVAILABLE", "_INCOMPLETE", "_CONFLICT", "_EXHAUSTED",
    "_WAITING_FOR_HUMAN_REVIEW"
  )
  causal <- matches[vapply(matches, function(value) {
    any(endsWith(value, suffixes))
  }, logical(1))]
  if (length(causal)) tail(causal, 1L) else envelope$failure_code
}

# 初始化本请求唯一控制状态；每阶段 request 只读取已批准直接前驱，不自动继续下一阶段。
initialize_pipeline_control(
  project_root = project_root,
  run_root = run_root,
  profile = "production",
  run_id = request$run_id,
  handoff_zip = Sys.getenv("AST_ALT_HANDOFF_ZIP"),
  dry_run = FALSE
)

# 开始当前唯一科学阶段；不得调用 run_stage_sequence 或创建下一阶段请求。
stage_result <- run_one_stage(
  stage = request$stage,
  project_root = project_root,
  run_root = run_root,
  profile = "production",
  run_id = request$run_id
)
if (!is.list(stage_result) || !identical(stage_result$stage, request$stage) ||
    !stage_result$stage_status %in% c(
      "PASS_AUTO_CONTINUE",
      "PASS_WITH_NONBLOCKING_WARNINGS",
      "WARNING_WAITING_FOR_HUMAN_REVIEW",
      "SCIENTIFIC_CONFIG_CANDIDATE_WAITING_FOR_HUMAN_REVIEW",
      "RESOURCE_GATE_WAITING_FOR_HUMAN_REVIEW",
      "FAIL_WAITING_FOR_HUMAN_REVIEW",
      "STOP_PROJECT"
    )) {
  stop("STATELESS_STAGE_TERMINAL_INVALID", call. = FALSE)
}
candidate_statuses <- c(
  "PASS_AUTO_CONTINUE",
  "PASS_WITH_NONBLOCKING_WARNINGS",
  "WARNING_WAITING_FOR_HUMAN_REVIEW",
  "SCIENTIFIC_CONFIG_CANDIDATE_WAITING_FOR_HUMAN_REVIEW",
  "RESOURCE_GATE_WAITING_FOR_HUMAN_REVIEW"
)
if (stage_result$stage_status %in% candidate_statuses) {
  if (!is.character(stage_result$public_bundle) || length(stage_result$public_bundle) != 1L ||
      !nzchar(stage_result$public_bundle) || !startsWith(
        normalizePath(stage_result$public_bundle, mustWork = TRUE),
        normalizePath(file.path(run_root, "candidate_cache"), mustWork = TRUE)
      )) {
    stop("STATELESS_PUBLIC_CANDIDATE_MISSING", call. = FALSE)
  }
} else {
  stop(.stateless_bounded_failure_code(stage_result, run_root), call. = FALSE)
}
