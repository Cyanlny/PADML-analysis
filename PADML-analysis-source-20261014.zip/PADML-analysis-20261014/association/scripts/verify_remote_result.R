# v4.3 本地独立结果验证器：sealed request 是唯一信任根，不信任远端 sidecar。

args <- commandArgs(trailingOnly = TRUE)
project_root <- normalizePath(if (file.exists("AGENTS.md")) "." else "..", mustWork = TRUE)
source(file.path(project_root, "R", "control_kernel.R"))
source(file.path(project_root, "remote", "remote_contract.R"))
parsed <- remote_parse_strict_named_args(
  args,
  allowed = c("--sealed-request", "--egress-archive", "--expected-sha256"),
  required = c("--sealed-request", "--egress-archive", "--expected-sha256")
)
request_path <- normalizePath(parsed[["--sealed-request"]], mustWork = TRUE)
archive_path <- normalizePath(parsed[["--egress-archive"]], mustWork = TRUE)
request <- .remote_read_json(request_path)
result <- verify_remote_egress_archive(
  archive = archive_path,
  sealed_request = request,
  expected_sha256 = parsed[["--expected-sha256"]]
)
cat(paste(
  "status=PASS",
  paste0("request_sha256=", result$request_sha256),
  paste0("archive_sha256=", result$archive_sha256),
  paste0("publication_outputs=", result$publication_output_count),
  paste0("tables=", result$table_count),
  paste0("svg=", result$svg_count),
  paste0("figure_data=", result$figure_data_count),
  sep = "\n"
), "\n", sep = "")
