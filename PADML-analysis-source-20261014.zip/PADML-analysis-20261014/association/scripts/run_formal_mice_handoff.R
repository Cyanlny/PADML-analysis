# v4.3 formal MICE 唯一顶层入口：先验证 exact aggregate receipt 与 H1，再允许读取指定源并执行一个 checkpoint。

.formal_runner_stop <- function(code, detail = "") {
  message <- if (nzchar(detail)) paste(code, detail, sep = ": ") else code
  stop(message, call. = FALSE)
}

.formal_runner_assert_remote_context <- function() {
  required <- c(
    AST_ALT_VERIFIED_RUNTIME_IDENTITY_SHA256 = "^[0-9a-f]{64}$",
    AST_ALT_REMOTE_REQUEST_SHA256 = "^[0-9a-f]{64}$",
    AST_ALT_STATELESS_SOURCE_GIT_COMMIT = "^[0-9a-f]{40}$",
    AST_ALT_STATELESS_SOURCE_GIT_TREE = "^[0-9a-f]{40}$",
    AST_ALT_STATELESS_CODE_CONTENT_TREE_SHA256 = "^[0-9a-f]{64}$"
  )
  values <- Sys.getenv(names(required), unset = "")
  valid <- identical(Sys.getenv("AST_ALT_STATELESS_COMPUTE_NODE", unset = ""), "TRUE") &&
    identical(Sys.getenv("AST_ALT_EXECUTION_PROFILE", unset = ""), "production") &&
    identical(suppressWarnings(as.integer(Sys.getenv("AST_ALT_WORKERS", unset = ""))), 24L) &&
    all(vapply(names(required), function(name) {
      grepl(required[[name]], values[[name]])
    }, logical(1)))
  if (!isTRUE(valid)) .formal_runner_stop("FORMAL_MICE_REMOTE_CONTEXT_REQUIRED")
  invisible(TRUE)
}

parse_formal_mice_runner_args <- function(args = commandArgs(trailingOnly = TRUE)) {
  flags <- c(
    "--mode",
    "--source-xlsx", "--candidate-root", "--source-epoch", "--source-receipt-sha256",
    "--authorization-receipt", "--authorization-file-sha256", "--transaction-root",
    "--desired-iteration", "--request-proposal-output", "--recover-lease-sha256",
    "--recover-failure-signature"
  )
  values <- setNames(vector("list", length(flags)), flags)
  index <- 1L
  while (index <= length(args)) {
    flag <- args[[index]]
    if (!flag %in% flags) .formal_runner_stop("FORMAL_MICE_CLI_UNKNOWN_ARGUMENT", flag)
    if (!is.null(values[[flag]])) .formal_runner_stop("FORMAL_MICE_CLI_DUPLICATE_ARGUMENT", flag)
    if (index == length(args) || startsWith(args[[index + 1L]], "--")) {
      .formal_runner_stop("FORMAL_MICE_CLI_MISSING_VALUE", flag)
    }
    values[[flag]] <- args[[index + 1L]]
    index <- index + 2L
  }
  mode <- if (is.null(values[["--mode"]])) "execute" else values[["--mode"]]
  if (!mode %in% c("propose", "execute", "status", "recover")) {
    .formal_runner_stop("FORMAL_MICE_CLI_MODE_INVALID")
  }
  common <- c("--candidate-root", "--source-epoch", "--source-receipt-sha256")
  mode_required <- switch(mode,
    propose = "--request-proposal-output",
    execute = c(
      "--source-xlsx", "--authorization-receipt", "--authorization-file-sha256",
      "--transaction-root", "--desired-iteration"
    ),
    status = c("--authorization-receipt", "--authorization-file-sha256", "--transaction-root"),
    recover = c("--authorization-receipt", "--authorization-file-sha256", "--transaction-root")
  )
  required <- c(common, mode_required)
  missing <- required[vapply(values[required], is.null, logical(1))]
  if (length(missing)) .formal_runner_stop("FORMAL_MICE_CLI_REQUIRED_ARGUMENT", paste(missing, collapse = "|"))
  recovery_flag <- character()
  if (identical(mode, "recover")) {
    supplied <- c("--recover-lease-sha256", "--recover-failure-signature")
    recovery_flag <- supplied[!vapply(values[supplied], is.null, logical(1))]
    if (length(recovery_flag) != 1L) {
      .formal_runner_stop("FORMAL_MICE_CLI_RECOVERY_IDENTITY_REQUIRED")
    }
  }
  allowed <- c("--mode", common, mode_required, recovery_flag)
  extra <- setdiff(names(values)[!vapply(values, is.null, logical(1))], allowed)
  if (length(extra)) .formal_runner_stop("FORMAL_MICE_CLI_ARGUMENT_NOT_ALLOWED", paste(extra, collapse = "|"))
  sha_flags <- intersect(
    c(
      "--source-epoch", "--source-receipt-sha256", "--authorization-file-sha256",
      "--recover-lease-sha256", "--recover-failure-signature"
    ),
    c(required, recovery_flag)
  )
  if (any(!vapply(values[sha_flags], function(value) grepl("^[0-9a-f]{64}$", value), logical(1)))) {
    .formal_runner_stop("FORMAL_MICE_CLI_SHA256_INVALID")
  }
  desired <- NA_integer_
  if (identical(mode, "execute")) {
    desired <- suppressWarnings(as.integer(values[["--desired-iteration"]]))
    if (is.na(desired) || !desired %in% c(30L, 40L, 50L, 100L, 200L) ||
        !identical(as.character(desired), values[["--desired-iteration"]])) {
      .formal_runner_stop("FORMAL_MICE_CLI_ITERATION_INVALID")
    }
  }
  list(
    mode = mode,
    source_xlsx = values[["--source-xlsx"]],
    candidate_root = values[["--candidate-root"]],
    source_epoch = values[["--source-epoch"]],
    source_receipt_sha256 = values[["--source-receipt-sha256"]],
    authorization_receipt = values[["--authorization-receipt"]],
    authorization_file_sha256 = values[["--authorization-file-sha256"]],
    transaction_root = values[["--transaction-root"]],
    desired_iteration = desired,
    request_proposal_output = values[["--request-proposal-output"]],
    recover_lease_sha256 = values[["--recover-lease-sha256"]],
    recover_failure_signature = values[["--recover-failure-signature"]]
  )
}

.formal_runner_path <- function(path, project_root, must_work = TRUE) {
  candidate <- if (grepl("^/|^[A-Za-z]:[/\\\\]", path)) path else file.path(project_root, path)
  normalizePath(candidate, mustWork = must_work)
}

.formal_runner_normalize_request_v43 <- function(request) {
  validate_mi_transaction_request_v43(request)
  request[c(.mi_tx_request_payload_fields(), "request_sha256")]
}

run_formal_mice_handoff_main <- function(
    args = commandArgs(trailingOnly = TRUE), project_root = ".", print_flag = TRUE) {
  parsed <- parse_formal_mice_runner_args(args)
  if (parsed$mode %in% c("execute", "recover")) {
    # 中文备注：真实拟合和恢复在任何路径解析、source 读取或事务写入前必须证明来自唯一远端执行面。
    .formal_runner_assert_remote_context()
  }
  project_root <- normalizePath(project_root, mustWork = TRUE)
  source(file.path(project_root, "R", "control_kernel.R"))
  source(file.path(project_root, "R", "source_input_adapter.R"))
  source(file.path(project_root, "R", "authorization_engine.R"))
  source(file.path(project_root, "R", "mi_recipe_engine.R"))
  source(file.path(project_root, "R", "mi_transaction_engine.R"))
  source(file.path(project_root, "R", "formal_mice_engine.R"))

  candidate_root <- .formal_runner_path(parsed$candidate_root, project_root, must_work = TRUE)
  registry <- read_source_dataset_registry(project_root)
  registry_row <- select_source_registry_row(registry, "SRC_A_XLSX_V43")
  selected <- select_source_candidate_receipt_v43(
    candidate_root = candidate_root,
    source_epoch = parsed$source_epoch,
    receipt_identity_sha256 = parsed$source_receipt_sha256,
    expected_source_sha256 = registry_row$expected_sha256[[1L]],
    project_root = project_root
  )
  current_request <- .formal_runner_normalize_request_v43(
    build_mi_transaction_request_proposal_v43(selected$receipt, project_root)
  )
  if (identical(parsed$mode, "propose")) {
    output <- .formal_runner_path(parsed$request_proposal_output, project_root, must_work = FALSE)
    if (file.exists(output) || !dir.exists(dirname(output))) {
      .formal_runner_stop("FORMAL_MICE_REQUEST_PROPOSAL_OUTPUT_INVALID")
    }
    # 中文备注：原子写出不含患者值的 exact request proposal，供用户签发 request-bound H1。
    .control_write_atomic(output, canonical_json(current_request), mode = "0600")
    message("FORMAL_MICE_STATUS=REQUEST_PROPOSAL_READY_WAITING_FOR_H1")
    message("FORMAL_MICE_REQUEST_SHA256=", current_request$request_sha256)
    return(invisible(list(
      status = "REQUEST_PROPOSAL_READY_WAITING_FOR_H1",
      request_sha256 = current_request$request_sha256,
      request_proposal_path = output
    )))
  }
  authorization_path <- .formal_runner_path(parsed$authorization_receipt, project_root, must_work = TRUE)
  authorization <- load_formal_mice_authorization_v43(
    authorization_path,
    expected_file_sha256 = parsed$authorization_file_sha256,
    source_receipt = selected$receipt
  )
  transaction_root <- .formal_runner_path(parsed$transaction_root, project_root, must_work = FALSE)
  resolved <- .resolve_formal_mice_authorized_request_v43(
    transaction_root, authorization, current_request, selected$receipt
  )
  request <- resolved$request
  transaction_path <- resolved$transaction_path
  if (identical(parsed$mode, "status")) {
    if (!dir.exists(transaction_path)) .formal_runner_stop("FORMAL_MICE_TRANSACTION_NOT_FOUND")
    validate_mi_transaction_authorization_v43(
      transaction_path, request, authorization, parsed$authorization_file_sha256, project_root
    )
    state <- inspect_mi_transaction_v43(transaction_path, request)
    message("FORMAL_MICE_STATUS=", state$status)
    message("FORMAL_MICE_REQUEST_SHA256=", request$request_sha256)
    return(invisible(list(
      status = state$status,
      request_sha256 = request$request_sha256,
      desired_iteration = if (is.null(state$lease)) NA_integer_ else state$lease$desired_iteration,
      lease_sha256 = if (is.null(state$lease)) "" else state$lease$receipt_sha256,
      highest_iteration = state$highest_iteration
    )))
  }
  if (identical(parsed$mode, "recover")) {
    if (!dir.exists(transaction_path)) .formal_runner_stop("FORMAL_MICE_TRANSACTION_NOT_FOUND")
    recovered <- if (!is.null(parsed$recover_failure_signature)) {
      .validate_formal_mice_repair_delta_v43(
        request, current_request, project_root
      )
      recover_mi_chain_identity_failure_v43(
        transaction_path, request, authorization, parsed$authorization_file_sha256,
        parsed$recover_failure_signature, project_root
      )
    } else {
      recover_mi_transaction_lease_v43(
        transaction_path, request, authorization, parsed$authorization_file_sha256,
        parsed$recover_lease_sha256, project_root
      )
    }
    message("FORMAL_MICE_STATUS=", recovered$status)
    message("FORMAL_MICE_REQUEST_SHA256=", request$request_sha256)
    return(invisible(recovered))
  }

  # H1 已精确绑定 aggregate proposal 后，才允许读取并复核指定源工作簿。
  source_path <- .formal_runner_path(parsed$source_xlsx, project_root, must_work = TRUE)
  audit <- audit_source_workbook(selected$receipt$source_id, source_path, project_root)
  if (!identical(source_candidate_receipt_identity_v43(audit$receipt), selected$receipt_identity_sha256)) {
    .formal_runner_stop("FORMAL_MICE_SOURCE_REAUDIT_IDENTITY_MISMATCH")
  }
  owner <- read_mi_contract_v43(project_root)
  projection <- compile_mi_projection_v43(project_root, owner, audit$mapping)
  runtime <- build_mi_runtime_spec_v43(audit$canonical, projection, owner, audit$mapping)
  observed_request <- build_mi_transaction_request_v43(
    audit$receipt, runtime, projection, owner, audit$mapping, project_root
  )
  if (!identical(observed_request, current_request)) {
    .formal_runner_stop("FORMAL_MICE_REQUEST_PROPOSAL_MISMATCH")
  }
  if (!identical(request, current_request)) {
    validate_formal_mice_repair_bridge_v43(
      request, current_request, transaction_path, project_root
    )
  }
  result <- run_formal_mice_transaction_step_v43(
    transaction_root = transaction_root,
    source_receipt = audit$receipt,
    runtime = runtime,
    projection = projection,
    owner = owner,
    mapping = audit$mapping,
    desired_iteration = parsed$desired_iteration,
    execution_profile = "production",
    authorization = authorization,
    authorization_file_sha256 = parsed$authorization_file_sha256,
    request = request,
    print_flag = print_flag,
    project_root = project_root
  )
  safe <- result[intersect(
    names(result),
    c("status", "request_sha256", "desired_iteration", "iteration", "continuation_count", "checkpoint_sha256")
  )]
  message("FORMAL_MICE_STATUS=", safe$status)
  if (!is.null(request$request_sha256)) message("FORMAL_MICE_REQUEST_SHA256=", request$request_sha256)
  invisible(result)
}

if (sys.nframe() == 0L) {
  run_formal_mice_handoff_main(commandArgs(trailingOnly = TRUE), project_root = ".")
}
