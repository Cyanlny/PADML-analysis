#!/usr/bin/env Rscript

# v4.3 MI compiled projection 工具：默认只校验，显式 --write 才更新 tracked CSV。
args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1L || !args[[1L]] %in% c("--check", "--write")) {
  stop("Usage: Rscript scripts/compile_mi_recipe_v43.R --check|--write", call. = FALSE)
}

project_root <- normalizePath(if (file.exists("R/mi_recipe_engine.R")) "." else "..", mustWork = TRUE)
source(file.path(project_root, "R", "source_input_adapter.R"))
source(file.path(project_root, "R", "mi_recipe_engine.R"))

projection_files <- c(
  "source_mi_recipe_registry.csv",
  "source_mi_method_registry.csv",
  "source_mi_predictor_edges.csv",
  "source_mi_block_registry.csv"
)

if (identical(args[[1L]], "--write")) {
  write_mi_recipe_projection_v43(project_root, file.path(project_root, "config"))
  message("MI_RECIPE_PROJECTION_WRITE_PASS")
} else {
  staging <- tempfile("mi-recipe-projection-v43-")
  dir.create(staging)
  on.exit(unlink(staging, recursive = TRUE), add = TRUE)
  write_mi_recipe_projection_v43(project_root, staging)
  tracked <- file.path(project_root, "config", projection_files)
  generated <- file.path(staging, projection_files)
  if (any(!file.exists(tracked))) stop("MI_RECIPE_PROJECTION_TRACKED_FILE_MISSING", call. = FALSE)
  same <- vapply(seq_along(tracked), function(index) {
    identical(.mi_sha256_file(tracked[[index]]), .mi_sha256_file(generated[[index]]))
  }, logical(1))
  if (!all(same)) {
    stop("MI_RECIPE_PROJECTION_DRIFT: ", paste(projection_files[!same], collapse = "|"), call. = FALSE)
  }
  load_compiled_mi_recipe_v43(project_root, read_source_column_mapping_registry(project_root)$target_name)
  message("MI_RECIPE_PROJECTION_CHECK_PASS")
}
