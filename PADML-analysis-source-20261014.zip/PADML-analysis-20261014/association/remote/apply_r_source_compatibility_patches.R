# r10 R 4.6 source compatibility controller: exact inputs, literal transforms, no resolver.

.r_source_patch_stop <- function(code, detail = NULL) {
  message <- if (is.null(detail) || !nzchar(as.character(detail))) code else {
    paste(code, as.character(detail), sep = ":")
  }
  stop(message, call. = FALSE)
}

.r_source_patch_require_packages <- function() {
  # 加载 JSON 与 SHA 实现，仅用于技术性 source/runtime 身份验证。
  if (!requireNamespace("jsonlite", quietly = TRUE) ||
      !requireNamespace("digest", quietly = TRUE)) {
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_DEPENDENCY_MISSING")
  }
}

.r_source_patch_is_sha256 <- function(value) {
  is.character(value) && length(value) == 1L && !is.na(value) &&
    grepl("^[0-9a-f]{64}$", value)
}

.r_source_patch_safe_relative <- function(value) {
  is.character(value) && length(value) == 1L && !is.na(value) && nzchar(value) &&
    !startsWith(value, "/") && !startsWith(value, "\\") &&
    !grepl("^[A-Za-z]:", value) && !grepl("(^|/)[.][.](/|$)", value) &&
    !grepl("[\r\n,\"\t]", value) && !grepl("//", value, fixed = TRUE) &&
    !startsWith(value, "./") && !endsWith(value, "/")
}

.r_source_patch_sha256_file <- function(path) {
  .r_source_patch_require_packages()
  if (!file.exists(path) || isTRUE(file.info(path)$isdir) || nzchar(Sys.readlink(path))) {
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_FILE_INVALID", basename(path))
  }
  digest::digest(file = path, algo = "sha256", serialize = FALSE)
}

.r_source_patch_sha256_text <- function(value) {
  .r_source_patch_require_packages()
  digest::digest(enc2utf8(value), algo = "sha256", serialize = FALSE)
}

.r_source_patch_tree_sha256 <- function(root) {
  root <- normalizePath(root, mustWork = TRUE)
  paths <- list.files(root, recursive = TRUE, full.names = TRUE, all.files = TRUE,
    no.. = TRUE, include.dirs = FALSE)
  if (!length(paths) || any(nzchar(Sys.readlink(paths))) || any(file.info(paths)$isdir)) {
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_SOURCE_TREE_INVALID", basename(root))
  }
  relative <- gsub("\\\\", "/", substring(paths, nchar(root) + 2L))
  ordering <- order(relative, method = "radix")
  projection <- vapply(ordering, function(index) paste(
    relative[[index]], .r_source_patch_sha256_file(paths[[index]]),
    as.character(file.info(paths[[index]])$size), sep = "\t"
  ), character(1L))
  .r_source_patch_sha256_text(paste(projection, collapse = "\n"))
}

.r_source_patch_read_bytes <- function(path) {
  connection <- file(path, open = "rb")
  on.exit(close(connection), add = TRUE)
  bytes <- readBin(connection, what = "raw", n = file.info(path)$size)
  if (any(bytes == as.raw(0L))) {
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_TARGET_NOT_TEXT", basename(path))
  }
  rawToChar(bytes)
}

.r_source_patch_write_atomic <- function(path, value) {
  mode <- file.info(path)$mode
  temporary <- tempfile(pattern = paste0(".", basename(path), "."), tmpdir = dirname(path))
  on.exit(unlink(temporary, force = TRUE), add = TRUE)
  connection <- file(temporary, open = "wb")
  on.exit(try(close(connection), silent = TRUE), add = TRUE)
  # 原子写入已通过 exact pre/post identity 检查的兼容源码文件。
  writeBin(charToRaw(value), connection)
  close(connection)
  Sys.chmod(temporary, mode = mode, use_umask = FALSE)
  if (!file.rename(temporary, path)) {
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_ATOMIC_REPLACE_FAILED", basename(path))
  }
  invisible(path)
}

.r_source_patch_fixed_count <- function(text, needle) {
  hits <- gregexpr(needle, text, fixed = TRUE, useBytes = TRUE)[[1L]]
  if (length(hits) == 1L && hits[[1L]] == -1L) 0L else length(hits)
}

.r_source_patch_scalar_character <- function(value) {
  is.character(value) && length(value) == 1L && !is.na(value) && nzchar(value)
}

.r_source_patch_scalar_integer <- function(value, minimum = 0L) {
  is.numeric(value) && length(value) == 1L && !is.na(value) && is.finite(value) &&
    value == as.integer(value) && value >= minimum
}

.r_source_patch_effective_identity <- function(row) {
  projection <- c(
    "AST_ALT_R_SOURCE_COMPATIBILITY_IDENTITY_V1",
    paste0("patch_id=", row$patch_id),
    paste0("package=", row$package),
    paste0("version=", row$version),
    paste0("upstream_archive_sha256=", row$upstream_archive_sha256),
    paste0("patch_sha256=", row$patch_sha256),
    paste0("patched_source_tree_sha256=", row$patched_source_tree_sha256)
  )
  .r_source_patch_sha256_text(paste(projection, collapse = "\n"))
}

.r_source_patch_validate_document <- function(document) {
  required <- c(
    "schema_version", "patch_id", "package", "version", "upstream_archive_sha256",
    "patched_source_tree_sha256", "patched_file_count", "legacy_call_count",
    "compatibility_contract", "files"
  )
  if (!is.list(document) || !identical(sort(names(document)), sort(required)) ||
      !identical(document$schema_version, "1.0.0") ||
      !grepl("^[A-Z0-9_]+$", document$patch_id) ||
      !document$package %in% c("collections", "nanonext") ||
      !.r_source_patch_scalar_character(document$version) ||
      !.r_source_patch_is_sha256(document$upstream_archive_sha256) ||
      !.r_source_patch_is_sha256(document$patched_source_tree_sha256) ||
      !.r_source_patch_scalar_integer(document$patched_file_count, 1L) ||
      !.r_source_patch_scalar_integer(document$legacy_call_count, 1L) ||
      !identical(document$compatibility_contract,
        "R_4_6_PUBLIC_API_SEMANTIC_PRESERVING_EXACT_LITERAL_V1") ||
      !is.list(document$files) ||
      length(document$files) != as.integer(document$patched_file_count)) {
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_PATCH_SCHEMA_INVALID")
  }
  file_required <- c(
    "relative_path", "preimage_sha256", "postimage_sha256", "legacy_call_count", "operations"
  )
  operation_required <- c("operation_id", "old_text", "new_text", "expected_count")
  paths <- character(length(document$files))
  observed_legacy_calls <- 0L
  for (index in seq_along(document$files)) {
    record <- document$files[[index]]
    if (!is.list(record) || !identical(sort(names(record)), sort(file_required)) ||
        !.r_source_patch_safe_relative(record$relative_path) ||
        !grepl("^(MD5|src/[^/].*[.](c|h))$", record$relative_path) ||
        !.r_source_patch_is_sha256(record$preimage_sha256) ||
        !.r_source_patch_is_sha256(record$postimage_sha256) ||
        identical(record$preimage_sha256, record$postimage_sha256) ||
        !.r_source_patch_scalar_integer(record$legacy_call_count, 0L) ||
        !is.list(record$operations) || !length(record$operations)) {
      .r_source_patch_stop("R_SOURCE_COMPATIBILITY_PATCH_SCHEMA_INVALID", paste0("file_", index))
    }
    paths[[index]] <- record$relative_path
    operation_ids <- character(length(record$operations))
    operation_legacy_calls <- 0L
    for (operation_index in seq_along(record$operations)) {
      operation <- record$operations[[operation_index]]
      if (!is.list(operation) || !identical(sort(names(operation)), sort(operation_required)) ||
          !grepl("^[A-Z0-9_]+$", operation$operation_id) ||
          !.r_source_patch_scalar_character(operation$old_text) ||
          !.r_source_patch_scalar_character(operation$new_text) ||
          identical(operation$old_text, operation$new_text) ||
          !.r_source_patch_scalar_integer(operation$expected_count, 1L) ||
          grepl("ENABLE_LEGACY_NONAPI", operation$new_text, fixed = TRUE) ||
          grepl("Rf_findVar(", operation$new_text, fixed = TRUE) ||
          grepl("Rf_findVarInFrame(", operation$new_text, fixed = TRUE) ||
          grepl("ATTRIB(", operation$new_text, fixed = TRUE)) {
        .r_source_patch_stop("R_SOURCE_COMPATIBILITY_PATCH_SCHEMA_INVALID",
          paste0("operation_", index, "_", operation_index))
      }
      operation_ids[[operation_index]] <- operation$operation_id
      legacy_operation <- any(vapply(
        c("Rf_findVar(", "Rf_findVarInFrame(", "ATTRIB("),
        grepl, logical(1L), x = operation$old_text, fixed = TRUE
      ))
      if (legacy_operation) {
        operation_legacy_calls <- operation_legacy_calls + as.integer(operation$expected_count)
      }
    }
    if (anyDuplicated(operation_ids) ||
        operation_legacy_calls != as.integer(record$legacy_call_count)) {
      .r_source_patch_stop("R_SOURCE_COMPATIBILITY_PATCH_CALL_COUNT_MISMATCH", record$relative_path)
    }
    observed_legacy_calls <- observed_legacy_calls + as.integer(record$legacy_call_count)
  }
  if (anyDuplicated(paths) || observed_legacy_calls != as.integer(document$legacy_call_count)) {
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_PATCH_CALL_COUNT_MISMATCH", document$package)
  }
  invisible(document)
}

.r_source_patch_read_document <- function(path) {
  .r_source_patch_require_packages()
  document <- tryCatch(
    jsonlite::read_json(path, simplifyVector = FALSE),
    error = function(condition) .r_source_patch_stop("R_SOURCE_COMPATIBILITY_PATCH_JSON_INVALID")
  )
  .r_source_patch_validate_document(document)
  document
}

.r_source_patch_read_lock <- function(project_root) {
  project_root <- normalizePath(project_root, mustWork = TRUE)
  lock_path <- file.path(project_root, "remote", "r-source-compatibility-patch-lock.csv")
  source_lock_path <- file.path(project_root, "remote", "r-system-package-source-lock.csv")
  if (!file.exists(lock_path) || nzchar(Sys.readlink(lock_path)) ||
      !file.exists(source_lock_path) || nzchar(Sys.readlink(source_lock_path))) {
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_PATCH_LOCK_MISSING")
  }
  lock <- utils::read.csv(lock_path, stringsAsFactors = FALSE, check.names = FALSE,
    colClasses = "character")
  source_lock <- utils::read.csv(source_lock_path, stringsAsFactors = FALSE, check.names = FALSE,
    colClasses = "character")
  required <- c(
    "patch_order", "patch_id", "package", "version", "upstream_archive_sha256",
    "patch_kind", "patch_relative_path", "patch_sha256", "patched_source_tree_sha256",
    "effective_source_identity_sha256", "patched_file_count", "legacy_call_count",
    "compatibility_contract"
  )
  expected_paths <- c(
    "remote/patches/collections_0.3.9-r-4.6.0.patch.json",
    "remote/patches/nanonext_1.7.0-r-4.6.0.patch.json"
  )
  if (!identical(names(lock), required) || nrow(lock) != 2L ||
      !identical(lock$patch_order, c("1", "2")) ||
      !identical(lock$package, c("collections", "nanonext")) ||
      !identical(lock$version, c("0.3.9", "1.7.0")) ||
      anyDuplicated(lock$patch_id) || anyDuplicated(lock$package) ||
      any(lock$patch_kind != "EXACT_LITERAL_REPLACEMENT_JSON_V1") ||
      !identical(lock$patch_relative_path, expected_paths) ||
      any(!vapply(lock$patch_relative_path, .r_source_patch_safe_relative, logical(1L))) ||
      any(!vapply(lock$upstream_archive_sha256, .r_source_patch_is_sha256, logical(1L))) ||
      any(!vapply(lock$patch_sha256, .r_source_patch_is_sha256, logical(1L))) ||
      any(!vapply(lock$patched_source_tree_sha256, .r_source_patch_is_sha256, logical(1L))) ||
      any(!vapply(lock$effective_source_identity_sha256, .r_source_patch_is_sha256, logical(1L))) ||
      !identical(lock$patched_file_count, c("4", "6")) ||
      !identical(lock$legacy_call_count, c("5", "29")) ||
      any(lock$compatibility_contract !=
        "R_4_6_PUBLIC_API_SEMANTIC_PRESERVING_EXACT_LITERAL_V1")) {
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_PATCH_LOCK_INVALID")
  }
  source_indices <- match(lock$package, source_lock$package)
  if (anyNA(source_indices) ||
      !identical(lock$version, source_lock$version[source_indices]) ||
      !identical(lock$upstream_archive_sha256, source_lock$archive_sha256[source_indices])) {
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_UPSTREAM_IDENTITY_MISMATCH")
  }
  documents <- vector("list", nrow(lock))
  for (index in seq_len(nrow(lock))) {
    patch_path <- file.path(project_root, lock$patch_relative_path[[index]])
    if (!file.exists(patch_path) || nzchar(Sys.readlink(patch_path)) ||
        !identical(.r_source_patch_sha256_file(patch_path), lock$patch_sha256[[index]])) {
      .r_source_patch_stop("R_SOURCE_COMPATIBILITY_PATCH_SHA_MISMATCH", lock$package[[index]])
    }
    document <- .r_source_patch_read_document(patch_path)
    expected_document_paths <- if (identical(lock$package[[index]], "collections")) {
      c("MD5", "src/dict.c", "src/utils.c", "src/xxh.c")
    } else {
      c("MD5", "src/nanonext.h", "src/ncurl.c", "src/thread.c", "src/aio.c", "src/sync.c")
    }
    if (!identical(document$patch_id, lock$patch_id[[index]]) ||
        !identical(document$package, lock$package[[index]]) ||
        !identical(document$version, lock$version[[index]]) ||
        !identical(document$upstream_archive_sha256, lock$upstream_archive_sha256[[index]]) ||
        !identical(document$patched_source_tree_sha256, lock$patched_source_tree_sha256[[index]]) ||
        as.integer(document$patched_file_count) != as.integer(lock$patched_file_count[[index]]) ||
        as.integer(document$legacy_call_count) != as.integer(lock$legacy_call_count[[index]]) ||
        !identical(vapply(document$files, `[[`, character(1L), "relative_path"),
          expected_document_paths) ||
        !identical(document$compatibility_contract, lock$compatibility_contract[[index]])) {
      .r_source_patch_stop("R_SOURCE_COMPATIBILITY_PATCH_LOCK_DOCUMENT_MISMATCH",
        lock$package[[index]])
    }
    if (!identical(.r_source_patch_effective_identity(as.list(lock[index, , drop = FALSE])),
        lock$effective_source_identity_sha256[[index]])) {
      .r_source_patch_stop("R_SOURCE_COMPATIBILITY_EFFECTIVE_IDENTITY_MISMATCH",
        lock$package[[index]])
    }
    documents[[index]] <- document
  }
  attr(lock, "documents") <- documents
  attr(lock, "sha256") <- .r_source_patch_sha256_file(lock_path)
  lock
}

.r_source_patch_expected_provenance <- function(project_root) {
  lock <- .r_source_patch_read_lock(project_root)
  source_lock <- utils::read.csv(
    file.path(project_root, "remote", "r-system-package-source-lock.csv"),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  patch_indices <- match(source_lock$package, lock$package)
  patched <- !is.na(patch_indices)
  data.frame(
    package = source_lock$package,
    source_kind = ifelse(patched,
      "PINNED_CRAN_ARCHIVE_COMPAT_PATCHED", "PINNED_CRAN_ARCHIVE"),
    source = ifelse(patched,
      paste0("CRAN_ARCHIVE_COMPAT_PATCH:", source_lock$archive_relative_path,
        "#", lock$patch_id[patch_indices]),
      paste0("CRAN_ARCHIVE:", source_lock$archive_relative_path)),
    source_identity_sha256 = ifelse(patched,
      lock$effective_source_identity_sha256[patch_indices], source_lock$archive_sha256),
    stringsAsFactors = FALSE
  )
}

.r_source_patch_receipt_fields <- function() {
  c(
    "schema_version", "receipt_kind", "package", "version",
    "upstream_archive_sha256", "patch_sha256", "patched_source_tree_sha256",
    "install_input_tree_sha256", "effective_source_identity_sha256",
    "installed_package_tree_sha256"
  )
}

.r_source_patch_validate_receipt_shape <- function(receipt) {
  fields <- .r_source_patch_receipt_fields()
  if (!is.list(receipt) || !identical(names(receipt), fields) ||
      !identical(receipt$schema_version, "1.0.0") ||
      !identical(receipt$receipt_kind, "R_SOURCE_COMPATIBILITY_INSTALL_PROVENANCE") ||
      !receipt$package %in% c("collections", "nanonext") ||
      !.r_source_patch_scalar_character(receipt$version) ||
      any(!vapply(receipt[c(
        "upstream_archive_sha256", "patch_sha256", "patched_source_tree_sha256",
        "install_input_tree_sha256", "effective_source_identity_sha256",
        "installed_package_tree_sha256"
      )], .r_source_patch_is_sha256, logical(1L)))) {
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_RECEIPT_SCHEMA_INVALID")
  }
  invisible(receipt)
}

.r_source_patch_receipt_set_sha256 <- function(receipts) {
  if (!is.list(receipts) || length(receipts) != 2L) {
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_RECEIPT_SET_INVALID")
  }
  invisible(lapply(receipts, .r_source_patch_validate_receipt_shape))
  packages <- vapply(receipts, `[[`, character(1L), "package")
  order_index <- match(c("collections", "nanonext"), packages)
  if (anyNA(order_index) || anyDuplicated(packages)) {
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_RECEIPT_SET_INVALID")
  }
  receipts <- receipts[order_index]
  projection <- "AST_ALT_R_SOURCE_COMPATIBILITY_RECEIPT_SET_V1"
  for (receipt in receipts) {
    projection <- c(projection, vapply(.r_source_patch_receipt_fields(), function(field) {
      paste0("receipt.", receipt$package, ".", field, "=", receipt[[field]])
    }, character(1L)))
  }
  .r_source_patch_sha256_text(paste(projection, collapse = "\n"))
}

.r_source_patch_write_new_atomic <- function(path, value) {
  if (file.exists(path) || !dir.exists(dirname(path)) || nzchar(Sys.readlink(dirname(path)))) {
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_RECEIPT_ATOMIC_WRITE_INVALID", basename(path))
  }
  temporary <- tempfile(pattern = paste0(".", basename(path), "."), tmpdir = dirname(path))
  on.exit(unlink(temporary, force = TRUE), add = TRUE)
  connection <- file(temporary, open = "wb")
  on.exit(try(close(connection), silent = TRUE), add = TRUE)
  # 原子写入只读的逐包 source/install provenance receipt。
  writeBin(charToRaw(enc2utf8(value)), connection)
  close(connection)
  Sys.chmod(temporary, mode = "0444", use_umask = FALSE)
  if (!file.rename(temporary, path)) {
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_RECEIPT_ATOMIC_RENAME_FAILED", basename(path))
  }
  invisible(path)
}

.r_source_patch_read_receipt_set <- function(project_root, receipt_root, installed_library) {
  lock <- .r_source_patch_read_lock(project_root)
  receipt_root <- normalizePath(receipt_root, mustWork = TRUE)
  installed_library <- normalizePath(installed_library, mustWork = TRUE)
  if (nzchar(Sys.readlink(receipt_root))) {
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_RECEIPT_SET_INVALID")
  }
  paths <- list.files(receipt_root, recursive = TRUE, full.names = TRUE, all.files = TRUE,
    no.. = TRUE, include.dirs = TRUE)
  relative <- gsub("\\\\", "/", substring(paths, nchar(receipt_root) + 2L))
  expected_relative <- paste0(c("collections", "nanonext"), ".json")
  if (!identical(sort(relative, method = "radix"), expected_relative) ||
      any(file.info(paths)$isdir) || any(nzchar(Sys.readlink(paths))) ||
      any(bitwAnd(as.integer(file.info(paths)$mode), strtoi("222", base = 8L)) != 0L)) {
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_RECEIPT_SET_INVALID")
  }
  receipts <- vector("list", 2L)
  for (index in seq_len(2L)) {
    path <- file.path(receipt_root, expected_relative[[index]])
    receipt <- tryCatch(
      jsonlite::read_json(path, simplifyVector = FALSE),
      error = function(condition) .r_source_patch_stop(
        "R_SOURCE_COMPATIBILITY_RECEIPT_JSON_INVALID", lock$package[[index]]
      )
    )
    .r_source_patch_validate_receipt_shape(receipt)
    if (!identical(receipt$package, lock$package[[index]]) ||
        !identical(receipt$version, lock$version[[index]]) ||
        !identical(receipt$upstream_archive_sha256, lock$upstream_archive_sha256[[index]]) ||
        !identical(receipt$patch_sha256, lock$patch_sha256[[index]]) ||
        !identical(receipt$patched_source_tree_sha256,
          lock$patched_source_tree_sha256[[index]]) ||
        !identical(receipt$effective_source_identity_sha256,
          lock$effective_source_identity_sha256[[index]])) {
      .r_source_patch_stop("R_SOURCE_COMPATIBILITY_RECEIPT_PROVENANCE_MISMATCH",
        lock$package[[index]])
    }
    if (!identical(receipt$install_input_tree_sha256,
        lock$patched_source_tree_sha256[[index]])) {
      .r_source_patch_stop("R_SOURCE_COMPATIBILITY_RECEIPT_INPUT_TREE_MISMATCH",
        lock$package[[index]])
    }
    package_root <- file.path(installed_library, lock$package[[index]])
    description <- file.path(package_root, "DESCRIPTION")
    if (!dir.exists(package_root) || nzchar(Sys.readlink(package_root)) ||
        !file.exists(description) || nzchar(Sys.readlink(description))) {
      .r_source_patch_stop("R_SOURCE_COMPATIBILITY_RECEIPT_INSTALLED_PACKAGE_INVALID",
        lock$package[[index]])
    }
    values <- tryCatch(read.dcf(description, fields = c("Package", "Version")),
      error = function(condition) NULL)
    if (is.null(values) || !identical(unname(values[1L, ]),
        c(lock$package[[index]], lock$version[[index]]))) {
      .r_source_patch_stop("R_SOURCE_COMPATIBILITY_RECEIPT_INSTALLED_PACKAGE_INVALID",
        lock$package[[index]])
    }
    observed_tree <- .r_source_patch_tree_sha256(package_root)
    if (!identical(receipt$installed_package_tree_sha256, observed_tree)) {
      .r_source_patch_stop("R_SOURCE_COMPATIBILITY_RECEIPT_INSTALLED_TREE_MISMATCH",
        lock$package[[index]])
    }
    receipts[[index]] <- receipt
  }
  attr(receipts, "sha256") <- .r_source_patch_receipt_set_sha256(receipts)
  receipts
}

.r_source_patch_validate_input_set <- function(project_root, patched_source_root) {
  lock <- .r_source_patch_read_lock(project_root)
  patched_source_root <- normalizePath(patched_source_root, mustWork = TRUE)
  if (nzchar(Sys.readlink(patched_source_root))) {
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_RECEIPT_INPUT_SET_INVALID")
  }
  source_members <- list.files(patched_source_root, recursive = FALSE, all.files = TRUE,
    no.. = TRUE)
  if (!identical(sort(source_members, method = "radix"), c("collections", "nanonext"))) {
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_RECEIPT_INPUT_SET_INVALID")
  }
  observed <- vapply(seq_len(nrow(lock)), function(index) {
    source_root <- file.path(patched_source_root, lock$package[[index]])
    if (!dir.exists(source_root) || nzchar(Sys.readlink(source_root))) {
      .r_source_patch_stop("R_SOURCE_COMPATIBILITY_RECEIPT_INPUT_SET_INVALID",
        lock$package[[index]])
    }
    .r_source_patch_tree_sha256(source_root)
  }, character(1L))
  if (!identical(unname(observed), lock$patched_source_tree_sha256)) {
    mismatch <- which(unname(observed) != lock$patched_source_tree_sha256)[[1L]]
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_RECEIPT_INPUT_TREE_MISMATCH",
      lock$package[[mismatch]])
  }
  names(observed) <- lock$package
  list(lock = lock, root = patched_source_root, tree_sha256 = observed)
}

.r_source_patch_seal_receipt_set <- function(
    project_root, patched_source_root, installed_library, receipt_root) {
  inputs <- .r_source_patch_validate_input_set(project_root, patched_source_root)
  lock <- inputs$lock
  patched_source_root <- inputs$root
  installed_library <- normalizePath(installed_library, mustWork = TRUE)
  if (file.exists(receipt_root)) {
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_RECEIPT_DESTINATION_EXISTS")
  }
  parent <- normalizePath(dirname(receipt_root), mustWork = TRUE)
  receipt_root <- file.path(parent, basename(receipt_root))
  receipts <- lapply(seq_len(2L), function(index) {
    observed_source_tree <- unname(inputs$tree_sha256[[lock$package[[index]]]])
    installed_root <- file.path(installed_library, lock$package[[index]])
    if (!dir.exists(installed_root) || nzchar(Sys.readlink(installed_root))) {
      .r_source_patch_stop("R_SOURCE_COMPATIBILITY_RECEIPT_INSTALLED_PACKAGE_INVALID",
        lock$package[[index]])
    }
    list(
      schema_version = "1.0.0",
      receipt_kind = "R_SOURCE_COMPATIBILITY_INSTALL_PROVENANCE",
      package = lock$package[[index]],
      version = lock$version[[index]],
      upstream_archive_sha256 = lock$upstream_archive_sha256[[index]],
      patch_sha256 = lock$patch_sha256[[index]],
      patched_source_tree_sha256 = lock$patched_source_tree_sha256[[index]],
      install_input_tree_sha256 = observed_source_tree,
      effective_source_identity_sha256 = lock$effective_source_identity_sha256[[index]],
      installed_package_tree_sha256 = .r_source_patch_tree_sha256(installed_root)
    )
  })
  staging <- tempfile(pattern = paste0(".", basename(receipt_root), "."), tmpdir = parent)
  dir.create(staging, recursive = FALSE, mode = "0700")
  on.exit(unlink(staging, recursive = TRUE, force = TRUE), add = TRUE)
  for (receipt in receipts) {
    json <- as.character(jsonlite::toJSON(
      receipt, auto_unbox = TRUE, null = "null", na = "null", digits = 17, pretty = FALSE
    ))
    .r_source_patch_write_new_atomic(
      file.path(staging, paste0(receipt$package, ".json")), json
    )
  }
  verified <- .r_source_patch_read_receipt_set(project_root, staging, installed_library)
  if (!identical(attr(verified, "sha256"), .r_source_patch_receipt_set_sha256(receipts))) {
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_RECEIPT_SET_SHA_MISMATCH")
  }
  Sys.chmod(staging, mode = "0555", use_umask = FALSE)
  if (!file.rename(staging, receipt_root)) {
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_RECEIPT_SET_ATOMIC_RENAME_FAILED")
  }
  on.exit(NULL, add = FALSE)
  verified
}

.r_source_patch_apply_document <- function(document, package_root) {
  .r_source_patch_validate_document(document)
  package_root <- normalizePath(package_root, mustWork = TRUE)
  prepared <- vector("list", length(document$files))
  for (index in seq_along(document$files)) {
    record <- document$files[[index]]
    path <- file.path(package_root, record$relative_path)
    if (!file.exists(path) || isTRUE(file.info(path)$isdir) || nzchar(Sys.readlink(path))) {
      .r_source_patch_stop("R_SOURCE_COMPATIBILITY_PATCH_TARGET_INVALID", record$relative_path)
    }
    observed_sha <- .r_source_patch_sha256_file(path)
    if (identical(observed_sha, record$postimage_sha256)) {
      .r_source_patch_stop("R_SOURCE_COMPATIBILITY_PATCH_ALREADY_APPLIED", record$relative_path)
    }
    if (!identical(observed_sha, record$preimage_sha256)) {
      .r_source_patch_stop("R_SOURCE_COMPATIBILITY_PREIMAGE_MISMATCH", record$relative_path)
    }
    text <- .r_source_patch_read_bytes(path)
    for (operation in record$operations) {
      observed_count <- .r_source_patch_fixed_count(text, operation$old_text)
      if (observed_count != as.integer(operation$expected_count) ||
          .r_source_patch_fixed_count(text, operation$new_text) != 0L) {
        .r_source_patch_stop("R_SOURCE_COMPATIBILITY_MATCH_COUNT_MISMATCH",
          paste0(record$relative_path, "#", operation$operation_id))
      }
      pieces <- strsplit(text, operation$old_text, fixed = TRUE, useBytes = TRUE)[[1L]]
      text <- paste(pieces, collapse = operation$new_text)
      if (.r_source_patch_fixed_count(text, operation$old_text) != 0L ||
          .r_source_patch_fixed_count(text, operation$new_text) !=
            as.integer(operation$expected_count)) {
        .r_source_patch_stop("R_SOURCE_COMPATIBILITY_POSTIMAGE_CLOSURE_FAILED",
          record$relative_path)
      }
    }
    temporary <- tempfile(pattern = ".r-source-postimage-")
    on.exit(unlink(temporary, force = TRUE), add = TRUE)
    connection <- file(temporary, open = "wb")
    writeBin(charToRaw(text), connection)
    close(connection)
    if (!identical(.r_source_patch_sha256_file(temporary), record$postimage_sha256)) {
      .r_source_patch_stop("R_SOURCE_COMPATIBILITY_POSTIMAGE_MISMATCH", record$relative_path)
    }
    prepared[[index]] <- list(path = path, text = text)
  }
  for (record in prepared) .r_source_patch_write_atomic(record$path, record$text)
  source_files <- list.files(package_root, pattern = "[.](c|h)$", recursive = TRUE,
    full.names = TRUE, all.files = TRUE)
  forbidden <- c("ENABLE_LEGACY_NONAPI", "Rf_findVar(", "Rf_findVarInFrame(", "ATTRIB(")
  for (path in source_files) {
    text <- .r_source_patch_read_bytes(path)
    if (any(vapply(forbidden, grepl, logical(1L), x = text, fixed = TRUE))) {
      .r_source_patch_stop("R_SOURCE_COMPATIBILITY_LEGACY_API_REMAINS",
        substring(path, nchar(package_root) + 2L))
    }
  }
  if ("MD5" %in% vapply(document$files, `[[`, character(1L), "relative_path")) {
    md5_ok <- tryCatch(
      withCallingHandlers(
        tools::checkMD5sums(document$package, package_root),
        warning = function(condition) .r_source_patch_stop(
          "R_SOURCE_COMPATIBILITY_MD5_CLOSURE_MISMATCH", document$package
        )
      ),
      error = function(condition) .r_source_patch_stop(
        "R_SOURCE_COMPATIBILITY_MD5_CLOSURE_MISMATCH", document$package
      )
    )
    if (!isTRUE(md5_ok)) {
      .r_source_patch_stop("R_SOURCE_COMPATIBILITY_MD5_CLOSURE_MISMATCH", document$package)
    }
  }
  observed_tree <- .r_source_patch_tree_sha256(package_root)
  if (!identical(observed_tree, document$patched_source_tree_sha256)) {
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_PATCHED_TREE_MISMATCH", document$package)
  }
  invisible(observed_tree)
}

.r_source_patch_materialize <- function(project_root, source_cache, destination_root) {
  project_root <- normalizePath(project_root, mustWork = TRUE)
  source_cache <- normalizePath(source_cache, mustWork = TRUE)
  if (file.exists(destination_root)) {
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_DESTINATION_EXISTS")
  }
  parent <- normalizePath(dirname(destination_root), mustWork = TRUE)
  destination_root <- file.path(parent, basename(destination_root))
  lock <- .r_source_patch_read_lock(project_root)
  documents <- attr(lock, "documents")
  staging <- tempfile(pattern = paste0(".", basename(destination_root), "."), tmpdir = parent)
  dir.create(staging, recursive = FALSE, mode = "0700")
  on.exit(unlink(staging, recursive = TRUE, force = TRUE), add = TRUE)
  for (index in seq_len(nrow(lock))) {
    archive <- file.path(source_cache, paste0(lock$package[[index]], "_", lock$version[[index]], ".tar.gz"))
    if (!file.exists(archive) || nzchar(Sys.readlink(archive)) ||
        !identical(.r_source_patch_sha256_file(archive), lock$upstream_archive_sha256[[index]])) {
      .r_source_patch_stop("R_SOURCE_COMPATIBILITY_ARCHIVE_IDENTITY_MISMATCH",
        lock$package[[index]])
    }
    entries <- tryCatch(utils::untar(archive, list = TRUE), error = function(condition) character())
    expected_root <- lock$package[[index]]
    expected_prefix <- paste0(expected_root, "/")
    normalized_entries <- sub("/$", "", entries)
    if (!length(entries) || anyDuplicated(entries) ||
        any(!vapply(normalized_entries, .r_source_patch_safe_relative, logical(1L))) ||
        any(!(normalized_entries == expected_root | startsWith(normalized_entries, expected_prefix)))) {
      .r_source_patch_stop("R_SOURCE_COMPATIBILITY_ARCHIVE_LAYOUT_INVALID",
        lock$package[[index]])
    }
    status <- utils::untar(archive, exdir = staging)
    if (!identical(as.integer(status), 0L)) {
      .r_source_patch_stop("R_SOURCE_COMPATIBILITY_ARCHIVE_EXTRACT_FAILED",
        lock$package[[index]])
    }
    package_root <- file.path(staging, lock$package[[index]])
    extracted <- list.files(package_root, recursive = TRUE, full.names = TRUE, all.files = TRUE,
      no.. = TRUE, include.dirs = TRUE)
    links <- extracted[nzchar(Sys.readlink(extracted))]
    if (length(links)) {
      resolved <- normalizePath(links, mustWork = FALSE)
      prefix <- paste0(normalizePath(package_root, mustWork = TRUE), .Platform$file.sep)
      if (any(!startsWith(resolved, prefix)) || any(!file.exists(resolved))) {
        .r_source_patch_stop("R_SOURCE_COMPATIBILITY_ARCHIVE_LINK_ESCAPE",
          lock$package[[index]])
      }
    }
    .r_source_patch_apply_document(documents[[index]], package_root)
  }
  if (!file.rename(staging, destination_root)) {
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_MATERIALIZE_ATOMIC_RENAME_FAILED")
  }
  on.exit(NULL, add = FALSE)
  invisible(lock)
}

.r_source_patch_parse_cli <- function(arguments) {
  commands <- c(
    "validate", "materialize", "validate-inputs", "seal-receipts", "validate-receipts"
  )
  if (!length(arguments) || !arguments[[1L]] %in% commands) {
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_CLI_INVALID")
  }
  command <- arguments[[1L]]
  values <- list(command = command)
  arguments <- arguments[-1L]
  allowed <- switch(command,
    validate = "--project-root",
    materialize = c("--project-root", "--source-cache", "--destination-root"),
    `validate-inputs` = c("--project-root", "--patched-source-root"),
    `seal-receipts` = c(
      "--project-root", "--patched-source-root", "--installed-library", "--receipt-root"
    ),
    `validate-receipts` = c("--project-root", "--installed-library", "--receipt-root")
  )
  while (length(arguments)) {
    flag <- arguments[[1L]]
    if (!flag %in% allowed || length(arguments) < 2L || flag %in% names(values)) {
      .r_source_patch_stop("R_SOURCE_COMPATIBILITY_CLI_INVALID", flag)
    }
    values[[flag]] <- arguments[[2L]]
    arguments <- arguments[-c(1L, 2L)]
  }
  if (!identical(sort(names(values)[-1L]), sort(allowed))) {
    .r_source_patch_stop("R_SOURCE_COMPATIBILITY_CLI_INVALID")
  }
  values
}

.r_source_patch_main <- function() {
  values <- .r_source_patch_parse_cli(commandArgs(trailingOnly = TRUE))
  lock <- .r_source_patch_read_lock(values[["--project-root"]])
  receipt_set_sha256 <- NULL
  if (identical(values$command, "validate")) {
    invisible(lock)
  } else if (identical(values$command, "materialize")) {
    lock <- .r_source_patch_materialize(
      values[["--project-root"]], values[["--source-cache"]], values[["--destination-root"]]
    )
  } else if (identical(values$command, "validate-inputs")) {
    inputs <- .r_source_patch_validate_input_set(
      values[["--project-root"]], values[["--patched-source-root"]]
    )
    lock <- inputs$lock
  } else if (identical(values$command, "seal-receipts")) {
    receipts <- .r_source_patch_seal_receipt_set(
      values[["--project-root"]], values[["--patched-source-root"]],
      values[["--installed-library"]], values[["--receipt-root"]]
    )
    receipt_set_sha256 <- attr(receipts, "sha256")
  } else {
    receipts <- .r_source_patch_read_receipt_set(
      values[["--project-root"]], values[["--receipt-root"]],
      values[["--installed-library"]]
    )
    receipt_set_sha256 <- attr(receipts, "sha256")
  }
  cat(
    "status=PASS\n",
    "patch_lock_sha256=", attr(lock, "sha256"), "\n",
    "patched_package_count=", nrow(lock), "\n",
    "patched_file_count=", sum(as.integer(lock$patched_file_count)), "\n",
    "legacy_call_count=", sum(as.integer(lock$legacy_call_count)), "\n",
    if (!is.null(receipt_set_sha256)) "receipt_set_sha256=" else "",
    if (!is.null(receipt_set_sha256)) receipt_set_sha256 else "",
    if (!is.null(receipt_set_sha256)) "\n" else "",
    sep = ""
  )
}

if (sys.nframe() == 0L) .r_source_patch_main()
