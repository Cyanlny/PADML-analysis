# v4.3 离线依赖核验器：只核对预封装 library，不调用 install 或 renv::restore。

args <- commandArgs(trailingOnly = TRUE)
if (!length(args) || length(args) %% 2L != 0L) stop("REMOTE_OFFLINE_RUNTIME_CLI_INVALID", call. = FALSE)
flags <- args[seq.int(1L, length(args), by = 2L)]
values <- args[seq.int(2L, length(args), by = 2L)]
required <- c("--project-root", "--library-root", "--audit-path")
if (any(!startsWith(flags, "--")) || anyDuplicated(flags) ||
    !identical(sort(flags), sort(required)) || any(!nzchar(values)) || any(startsWith(values, "--"))) {
  stop("REMOTE_OFFLINE_RUNTIME_CLI_INVALID", call. = FALSE)
}
parsed <- as.list(setNames(values, flags))
project_root <- normalizePath(parsed[["--project-root"]], mustWork = TRUE)
library_root <- normalizePath(parsed[["--library-root"]], mustWork = TRUE)
audit_path <- parsed[["--audit-path"]]
if (!file.exists(file.path(project_root, "renv.lock"))) stop("REMOTE_RENV_LOCK_MISSING", call. = FALSE)
runtime_payload_root <- normalizePath(file.path(library_root, ".."), mustWork = TRUE)
base_library <- normalizePath(.Library, mustWork = TRUE)
if (!startsWith(base_library, paste0(runtime_payload_root, .Platform$file.sep))) {
  stop("REMOTE_BASE_LIBRARY_OUTSIDE_PRESEALED_RUNTIME", call. = FALSE)
}
runtime_libraries <- unique(c(library_root, base_library))
.libPaths(runtime_libraries)
# 加载 jsonlite 包以读取冻结 renv lock 并写入版本审计。
if (!requireNamespace("jsonlite", quietly = TRUE)) stop("REMOTE_JSONLITE_MISSING", call. = FALSE)
# 加载摘要包以绑定离线 runtime package inventory 的精确文件身份。
if (!requireNamespace("digest", quietly = TRUE)) stop("REMOTE_DIGEST_MISSING", call. = FALSE)
# 中文备注：加载内容寻址的 R 4.6 源码兼容补丁合同以核验离线 runtime provenance。
source(file.path(project_root, "remote", "apply_r_source_compatibility_patches.R"),
  local = environment())
# 中文备注：加载唯一的 runtime executable/ELF 路径回执验证器。
source(file.path(project_root, "remote", "normalize_runtime_paths.R"),
  local = environment())
compatibility_provenance <- .r_source_patch_expected_provenance(project_root)
lock <- jsonlite::read_json(file.path(project_root, "renv.lock"), simplifyVector = FALSE)
locked <- vapply(lock$Packages, function(record) as.character(record$Version), character(1))
if (!identical(length(locked), 135L) || any(c("renv", "crew") %in% names(locked))) {
  stop("REMOTE_RUNTIME_PACKAGE_OWNER_BOUNDARY_INVALID", call. = FALSE)
}
inventory_path <- file.path(runtime_payload_root, "RUNTIME_PACKAGE_INVENTORY.json")
if (!file.exists(inventory_path)) stop("REMOTE_RUNTIME_PACKAGE_INVENTORY_MISSING", call. = FALSE)
inventory <- jsonlite::read_json(inventory_path, simplifyVector = TRUE)
identity_path <- file.path(runtime_payload_root, "RUNTIME_IDENTITY.json")
if (!file.exists(identity_path)) stop("REMOTE_RUNTIME_IDENTITY_MISSING", call. = FALSE)
identity <- jsonlite::read_json(identity_path, simplifyVector = TRUE)
inventory_sha256 <- digest::digest(file = inventory_path, algo = "sha256", serialize = FALSE)
identity_fields <- c(
  "schema_version", "runtime_profile_id", "execution_revision", "build_revision", "source_date_epoch",
  "platform", "r_version", "quarto_version", "pandoc_version", "renv_version", "targets_version",
  "crew_version", "package_inventory_sha256", "system_abi_sha256", "conda_explicit_spec_sha256",
  "r_system_package_source_lock_sha256", "r_source_compatibility_patch_lock_sha256",
  "r_source_compatibility_receipt_set_sha256",
  "font_asset_lock_sha256", "font_asset_tree_sha256",
  "runtime_path_normalization_receipt_sha256", "runtime_private_path_findings_sha256",
  "runtime_private_path_post_findings_sha256",
  "runtime_historical_instance_transform_contract_sha256",
  "network_restore_allowed"
)
inventory_fields <- c(
  "schema_version", "runtime_profile_id", "execution_revision", "build_revision", "source_date_epoch",
  "platform", "owner_policy", "lockfile_sha256", "conda_explicit_spec_sha256", "conda_artifact_count",
  "r_system_package_source_lock_sha256", "r_source_compatibility_patch_lock_sha256",
  "r_source_compatibility_receipt_set_sha256",
  "font_asset_lock_sha256", "font_asset_tree_sha256",
  "assembly_toolchain_sha256", "runtime_path_normalization_receipt_sha256",
  "runtime_private_path_findings_sha256", "runtime_private_path_post_findings_sha256",
  "runtime_historical_instance_transform_contract_sha256",
  "lock_package_count", "system_package_count", "total_package_count",
  "font_asset_count", "upstream_path_receipt_count", "system_abi_sha256", "tools", "packages",
  "font_assets", "upstream_path_receipts"
)
if (!identical(identity$execution_revision, "v4.3-r00") ||
    !identical(identity$build_revision, "v4.3-r15") ||
    !identical(sort(names(identity)), sort(identity_fields)) ||
    !identical(sort(names(inventory)), sort(inventory_fields)) ||
    !identical(identity$package_inventory_sha256, inventory_sha256) ||
    !is.data.frame(inventory$packages) || nrow(inventory$packages) < 137L ||
    !identical(as.integer(inventory$lock_package_count), 135L) ||
    !identical(as.integer(inventory$conda_artifact_count), 120L) ||
    as.integer(inventory$system_package_count) < 6L ||
    !identical(as.integer(inventory$total_package_count), nrow(inventory$packages)) ||
    !identical(as.integer(inventory$total_package_count), 135L + as.integer(inventory$system_package_count)) ||
    !identical(as.integer(inventory$font_asset_count), 5L) ||
    !identical(as.integer(identity$source_date_epoch), as.integer(inventory$source_date_epoch)) ||
    !identical(identity$conda_explicit_spec_sha256, inventory$conda_explicit_spec_sha256) ||
    !identical(identity$r_system_package_source_lock_sha256, inventory$r_system_package_source_lock_sha256) ||
    !identical(identity$r_source_compatibility_patch_lock_sha256,
      inventory$r_source_compatibility_patch_lock_sha256) ||
    !identical(identity$r_source_compatibility_receipt_set_sha256,
      inventory$r_source_compatibility_receipt_set_sha256) ||
    !identical(identity$font_asset_lock_sha256, inventory$font_asset_lock_sha256) ||
    !identical(identity$font_asset_tree_sha256, inventory$font_asset_tree_sha256) ||
    !identical(identity$runtime_path_normalization_receipt_sha256,
      inventory$runtime_path_normalization_receipt_sha256) ||
    !identical(identity$runtime_private_path_findings_sha256,
      inventory$runtime_private_path_findings_sha256) ||
    !identical(identity$runtime_private_path_post_findings_sha256,
      inventory$runtime_private_path_post_findings_sha256) ||
    !identical(identity$runtime_historical_instance_transform_contract_sha256,
      inventory$runtime_historical_instance_transform_contract_sha256)) {
  stop("REMOTE_RUNTIME_PACKAGE_INVENTORY_INVALID", call. = FALSE)
}
sha256_file <- function(path) digest::digest(file = path, algo = "sha256", serialize = FALSE)
runtime_path_receipt <- file.path(runtime_payload_root, "RUNTIME_PATH_NORMALIZATION_RECEIPT.csv")
tryCatch(
  validate_runtime_path_receipt_v43(
    runtime_payload_root, runtime_path_receipt,
    transform_contract_path = file.path(
      project_root, "remote", "runtime-historical-instance-transform-contract.csv"
    )
  ),
  error = function(condition) stop(
    paste("REMOTE_RUNTIME_PATH_NORMALIZATION_RECEIPT_INVALID", conditionMessage(condition), sep = ":"),
    call. = FALSE
  )
)
toolchain_path <- file.path(runtime_payload_root, "ASSEMBLY_TOOLCHAIN.txt")
toolchain_lines <- if (file.exists(toolchain_path)) readLines(toolchain_path, warn = FALSE) else character()
path_receipt_line <- paste0(
  "runtime_path_normalization_receipt_sha256=", sha256_file(runtime_path_receipt)
)
path_findings_line <- paste0(
  "runtime_private_path_findings_sha256=",
  sha256_file(file.path(runtime_payload_root, "RUNTIME_PRIVATE_PATH_FINDINGS.csv"))
)
path_post_findings_line <- paste0(
  "runtime_private_path_post_findings_sha256=",
  sha256_file(file.path(runtime_payload_root, "RUNTIME_PRIVATE_PATH_POST_FINDINGS.csv"))
)
historical_contract_line <- paste0(
  "runtime_historical_instance_transform_contract_sha256=",
  inventory$runtime_historical_instance_transform_contract_sha256
)
if (!file.exists(toolchain_path) ||
    !identical(sha256_file(toolchain_path), inventory$assembly_toolchain_sha256) ||
    sum(toolchain_lines == path_receipt_line) != 1L ||
    sum(toolchain_lines == path_findings_line) != 1L ||
    sum(toolchain_lines == path_post_findings_line) != 1L ||
    sum(toolchain_lines == historical_contract_line) != 1L) {
  stop("REMOTE_RUNTIME_PATH_NORMALIZATION_TOOLCHAIN_MISMATCH", call. = FALSE)
}
explicit_path <- file.path(runtime_payload_root, "CONDA_EXPLICIT_SPEC.txt")
source_lock_path <- file.path(project_root, "remote", "r-system-package-source-lock.csv")
runtime_source_lock_path <- file.path(runtime_payload_root, "R_SYSTEM_PACKAGE_SOURCE_LOCK.csv")
compatibility_lock_path <- file.path(project_root, "remote", "r-source-compatibility-patch-lock.csv")
runtime_compatibility_lock_path <- file.path(runtime_payload_root, "R_SOURCE_COMPATIBILITY_PATCH_LOCK.csv")
historical_contract_path <- file.path(
  project_root, "remote", "runtime-historical-instance-transform-contract.csv"
)
runtime_historical_contract_path <- file.path(
  runtime_payload_root, "RUNTIME_HISTORICAL_INSTANCE_TRANSFORM_CONTRACT.csv"
)
font_lock_path <- file.path(project_root, "remote", "font-asset-lock.csv")
runtime_font_lock_path <- file.path(runtime_payload_root, "FONT_ASSET_LOCK.csv")
if (any(!file.exists(c(
      explicit_path, source_lock_path, runtime_source_lock_path,
      compatibility_lock_path, runtime_compatibility_lock_path,
      historical_contract_path, runtime_historical_contract_path,
      font_lock_path, runtime_font_lock_path
    ))) ||
    !identical(sha256_file(explicit_path), inventory$conda_explicit_spec_sha256) ||
    !identical(sha256_file(source_lock_path), inventory$r_system_package_source_lock_sha256) ||
    !identical(sha256_file(runtime_source_lock_path), inventory$r_system_package_source_lock_sha256) ||
    !identical(sha256_file(compatibility_lock_path),
      inventory$r_source_compatibility_patch_lock_sha256) ||
    !identical(sha256_file(runtime_compatibility_lock_path),
      inventory$r_source_compatibility_patch_lock_sha256) ||
    !identical(sha256_file(historical_contract_path),
      inventory$runtime_historical_instance_transform_contract_sha256) ||
    !identical(sha256_file(runtime_historical_contract_path),
      inventory$runtime_historical_instance_transform_contract_sha256) ||
    !identical(sha256_file(font_lock_path), inventory$font_asset_lock_sha256) ||
    !identical(sha256_file(runtime_font_lock_path), inventory$font_asset_lock_sha256)) {
  stop("REMOTE_RUNTIME_AUXILIARY_LOCK_IDENTITY_MISMATCH", call. = FALSE)
}
source_lock <- utils::read.csv(source_lock_path, stringsAsFactors = FALSE, check.names = FALSE)
font_lock <- utils::read.csv(font_lock_path, stringsAsFactors = FALSE, check.names = FALSE)
compatibility_receipts <- tryCatch(
  .r_source_patch_read_receipt_set(
    project_root, file.path(runtime_payload_root, "R_SOURCE_COMPATIBILITY_RECEIPTS"),
    base_library
  ),
  error = function(condition) stop(
    paste("REMOTE_RUNTIME_COMPATIBILITY_RECEIPT_INVALID", conditionMessage(condition), sep = ":"),
    call. = FALSE
  )
)
if (!identical(attr(compatibility_receipts, "sha256"),
    inventory$r_source_compatibility_receipt_set_sha256)) {
  stop("REMOTE_RUNTIME_COMPATIBILITY_RECEIPT_SET_SHA_MISMATCH", call. = FALSE)
}
installed <- vapply(names(locked), function(package) {
  package_path <- find.package(package, lib.loc = runtime_libraries, quiet = TRUE)
  if (!nzchar(package_path)) return(NA_character_)
  # 加载预封装 library 内的 namespace，禁止借用外部用户库满足冻结依赖。
  tryCatch({
    loadNamespace(package, lib.loc = runtime_libraries)
    as.character(utils::packageVersion(package, lib.loc = runtime_libraries))
  }, error = function(condition) NA_character_)
}, character(1))
mismatch <- names(locked)[is.na(installed) | installed != locked]
lock_inventory <- inventory$packages[inventory$packages$owner == "RENV_LOCK", , drop = FALSE]
system_inventory <- inventory$packages[inventory$packages$owner == "SYSTEM_RUNTIME", , drop = FALSE]
inventory_versions <- setNames(lock_inventory$version, lock_inventory$package)
inventory_mismatch <- names(locked)[
  !names(locked) %in% names(inventory_versions) |
    inventory_versions[names(locked)] != locked
]
system_expected <- c(crew = "1.3.0", renv = "1.2.3")
system_observed <- vapply(names(system_expected), function(package) {
  tryCatch(as.character(utils::packageVersion(package, lib.loc = runtime_libraries)), error = function(condition) NA_character_)
}, character(1))
system_inventory_versions <- setNames(system_inventory$version, system_inventory$package)
system_mismatch <- names(system_expected)[
  is.na(system_observed) | system_observed != system_expected |
    !names(system_expected) %in% names(system_inventory_versions) |
    system_inventory_versions[names(system_expected)] != system_expected
]
support_inventory <- inventory$packages[inventory$packages$owner == "SYSTEM_RUNTIME_SUPPORT", , drop = FALSE]
all_system_inventory <- rbind(system_inventory, support_inventory)
receipt_packages <- vapply(compatibility_receipts, `[[`, character(1L), "package")
receipt_indices <- match(receipt_packages, all_system_inventory$package)
if (anyNA(receipt_indices) || !identical(
    all_system_inventory$package_tree_sha256[receipt_indices],
    vapply(compatibility_receipts, `[[`, character(1L), "installed_package_tree_sha256")
  )) {
  stop("REMOTE_RUNTIME_COMPATIBILITY_RECEIPT_PACKAGE_TREE_MISMATCH", call. = FALSE)
}
actual_system_packages <- sort(rownames(utils::installed.packages(lib.loc = base_library)), method = "radix")
inventory_system_packages <- sort(all_system_inventory$package, method = "radix")
if (!identical(actual_system_packages, inventory_system_packages)) {
  stop("REMOTE_RUNTIME_SYSTEM_PACKAGE_INVENTORY_NOT_EXACT", call. = FALSE)
}
all_system_observed <- vapply(seq_len(nrow(all_system_inventory)), function(index) {
  tryCatch(as.character(utils::packageVersion(
    all_system_inventory$package[[index]], lib.loc = base_library
  )), error = function(condition) NA_character_)
}, character(1))
all_system_mismatch <- all_system_inventory$package[
  is.na(all_system_observed) | all_system_observed != all_system_inventory$version
]
source_indices <- match(source_lock$package, all_system_inventory$package)
source_closure_mismatch <- if (anyNA(source_indices)) source_lock$package[is.na(source_indices)] else {
  source_lock$package[
      all_system_inventory$version[source_indices] != source_lock$version |
      all_system_inventory$owner[source_indices] != source_lock$owner |
      all_system_inventory$source_kind[source_indices] != compatibility_provenance$source_kind |
      all_system_inventory$source[source_indices] != compatibility_provenance$source |
      all_system_inventory$source_identity_sha256[source_indices] !=
        compatibility_provenance$source_identity_sha256
  ]
}
if (!is.data.frame(inventory$font_assets) || nrow(inventory$font_assets) != 5L) {
  stop("REMOTE_RUNTIME_FONT_ASSET_INVENTORY_INVALID", call. = FALSE)
}
font_indices <- match(font_lock$asset_id, inventory$font_assets$asset_id)
font_mismatch <- character()
if (anyNA(font_indices) ||
    !identical(inventory$font_assets$runtime_relative_path[font_indices], font_lock$runtime_relative_path) ||
    !identical(inventory$font_assets$sha256[font_indices], font_lock$sha256)) {
  font_mismatch <- font_lock$asset_id
} else {
  font_mismatch <- font_lock$asset_id[vapply(seq_len(nrow(font_lock)), function(index) {
    path <- file.path(runtime_payload_root, font_lock$runtime_relative_path[[index]])
    !file.exists(path) || !identical(sha256_file(path), font_lock$sha256[[index]])
  }, logical(1))]
}
audit <- list(
  schema_version = "1.0.0",
  status = if (length(c(mismatch, inventory_mismatch, system_mismatch, all_system_mismatch,
    source_closure_mismatch, font_mismatch))) "FAIL" else "PASS",
  runtime_install_policy = "OFFLINE_PRESEALED_ONLY",
  network_restore_attempted = FALSE,
  lock_package_count = length(locked),
  verified_package_count = sum(!is.na(installed) & installed == locked),
  system_package_count = nrow(all_system_inventory),
  font_asset_count = nrow(inventory$font_assets),
  inventory_package_count = nrow(inventory$packages),
  mismatch_packages = sort(unique(c(mismatch, inventory_mismatch, system_mismatch, all_system_mismatch,
    source_closure_mismatch))),
  mismatch_font_assets = sort(unique(font_mismatch)),
  package_inventory_sha256 = inventory_sha256,
  conda_explicit_spec_sha256 = inventory$conda_explicit_spec_sha256,
  r_system_package_source_lock_sha256 = inventory$r_system_package_source_lock_sha256,
  r_source_compatibility_patch_lock_sha256 =
    inventory$r_source_compatibility_patch_lock_sha256,
  r_source_compatibility_receipt_set_sha256 =
    inventory$r_source_compatibility_receipt_set_sha256,
  runtime_historical_instance_transform_contract_sha256 =
    inventory$runtime_historical_instance_transform_contract_sha256,
  font_asset_lock_sha256 = inventory$font_asset_lock_sha256,
  font_asset_tree_sha256 = inventory$font_asset_tree_sha256
)
dir.create(dirname(audit_path), recursive = TRUE, showWarnings = FALSE, mode = "0700")
# 写入不含本机路径的离线依赖核验审计。
jsonlite::write_json(audit, audit_path, auto_unbox = TRUE, pretty = TRUE)
if (length(c(mismatch, inventory_mismatch, system_mismatch, all_system_mismatch,
    source_closure_mismatch, font_mismatch))) {
  stop("REMOTE_OFFLINE_LIBRARY_MISMATCH", call. = FALSE)
}
