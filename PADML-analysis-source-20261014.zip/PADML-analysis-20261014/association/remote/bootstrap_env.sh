#!/usr/bin/env bash
set -euo pipefail

script_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)
# 加载公共函数，只验证预封装 runtime，禁止联网安装。
source "$script_dir/lib/common.sh"
AST_ALT_SEEN_ARGS=()

code_root=""
runtime_root=""
request_path=""
run_root=""
while [[ $# -gt 0 ]]; do
  flag=$1
  case "$flag" in
    --code-root|--runtime-root|--request|--run-root)
      ast_alt_mark_arg_once "$flag"
      ast_alt_require_arg_value "$flag" "${2:-}"
      case "$flag" in
        --code-root) code_root=$2 ;;
        --runtime-root) runtime_root=$2 ;;
        --request) request_path=$2 ;;
        --run-root) run_root=$2 ;;
      esac
      shift 2
      ;;
    *) ast_alt_die "unknown bootstrap argument: $flag" "REMOTE_CLI_UNKNOWN_ARGUMENT" 64 ;;
  esac
done

for pair in "code_root:$code_root" "runtime_root:$runtime_root" "request:$request_path" "run_root:$run_root"; do
  ast_alt_validate_runtime_path "${pair#*:}" "${pair%%:*}"
done
runtime_rscript="$runtime_root/payload/bin/Rscript"
[[ -x "$runtime_rscript" ]] || ast_alt_die "presealed runtime lacks executable Rscript" "REMOTE_RUNTIME_RSCRIPT_MISSING" 43
[[ -f "$request_path" && ! -L "$request_path" ]] || ast_alt_die "sealed request is missing" "REMOTE_REQUEST_MISSING" 45
[[ -f "$code_root/payload/remote/remote_contract.R" ]] || ast_alt_die "code contract is missing" "REMOTE_CODE_CONTRACT_MISSING" 45

marker="$run_root/control/OFFLINE_RUNTIME_VERIFIED"
mkdir -p "$run_root/control"
PATH="$runtime_root/payload/bin:/usr/bin:/bin" \
R_LIBS_USER="$runtime_root/payload/library" \
"$runtime_rscript" --vanilla -e '
  a <- commandArgs(TRUE); source(a[[1L]]); q <- .remote_read_json(a[[2L]]);
  validate_remote_execution_request(q, require_authorization_file=FALSE);
  runtime <- verify_remote_bundle_directory(a[[3L]], "RUNTIME_BUNDLE");
  code <- verify_remote_bundle_directory(a[[4L]], "CODE_BUNDLE");
  checks <- c(
    runtime_identity = identical(runtime$identity_sha256, q$runtime_bundle$identity_sha256),
    runtime_manifest = identical(runtime$manifest_sha256, q$runtime_bundle$manifest_sha256),
    runtime_tree = identical(runtime$content_tree_sha256, q$runtime_bundle$content_tree_sha256),
    runtime_semantic = identical(runtime$runtime_identity_sha256, q$runtime_bundle$runtime_identity_sha256),
    code_identity = identical(code$identity_sha256, q$code_bundle$identity_sha256),
    code_manifest = identical(code$manifest_sha256, q$code_bundle$manifest_sha256),
    code_tree = identical(code$content_tree_sha256, q$code_bundle$content_tree_sha256)
  );
  if (!all(checks)) .remote_stop("REMOTE_PRESEALED_BUNDLE_IDENTITY_MISMATCH", paste(names(checks)[!checks], collapse="|"));
  text <- paste(c(
    paste0("request_sha256=", q$request_sha256),
    paste0("runtime_identity_sha256=", runtime$runtime_identity_sha256),
    "network_restore_allowed=FALSE"
  ), collapse="\n");
  if (file.exists(a[[5L]])) {
    observed <- paste(readLines(a[[5L]], warn=FALSE), collapse="\n");
    if (!identical(observed, text)) .remote_stop("REMOTE_OFFLINE_RUNTIME_MARKER_CONFLICT")
  } else {
    .remote_write_atomic(a[[5L]], text, mode="0600")
  }
' "$code_root/payload/remote/remote_contract.R" "$request_path" "$runtime_root" "$code_root" "$marker"

printf 'OFFLINE_RUNTIME_VERIFY_PASS\n'
