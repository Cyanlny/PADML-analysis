# Upstream Handoff Contract

本目录只保存文件名、allowlist 和预期 identity，不保存本机绝对路径或患者数据。生产运行由本地私有配置解析 handoff 实际位置。

build validation 只验证 ZIP member 名称和 manifest 字段，不解压或读取患者级对象。正式 production 必须只读挂载，并验证 semantic identity、Patient_ID 顺序、列顺序和 factor levels。

