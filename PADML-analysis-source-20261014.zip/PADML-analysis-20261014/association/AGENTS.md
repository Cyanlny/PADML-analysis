# Main v4.3 V22 Compute Boundary

- Apply `guard-engineering-closure` before `karpathy-guidelines`; mutate only the explicitly frozen frontier.
- `mainctl` remains the sole launcher with exactly `prepare`, `run-stage`, `status`, `collect`, and `approve-next`; the only purposes are `RUNTIME_ADMIT` and `STAGE_COMPUTE`.
- SQLite `state_events` is the sole business-state authority. OSS objects, projections, lease metadata, SSH, and SSH-MCP never arbitrate state.
- Sealed bulk transfer uses OSS. SSH/SSH-MCP is observation and reconciliation only; it cannot launch, edit, retry, or approve work.
- The remote supervisor alone holds `/root/autodl-tmp/.project-heavy-lease`; the regular lock inode is never removed or replaced, and `.owner.json` remains diagnostic.
- Every stage ends at local human review. `approve-next` records one of `APPROVE_NEXT_STAGE`, `REPAIR_REQUIRED`, `PROTOCOL_REVIEW_REQUIRED`, or `STOP_PROJECT` and never launches a successor.

## Formal MICE

- Every real MICE fit, continuation, checkpoint recovery, or reconciliation runs only on the AutoDL Main instance with the accepted V3 runtime and its exact `R_LIBS_SITE`; local code may only prepare, seal, upload, observe, collect, validate, and review.
- The active v4.3 A2 recipe uses the V22 target-specific full-cohort `ANALYSIS` policy: 37 targets in V22 visit order, one all-TRUE training mask, 12 predictor groups, 11 global exclusions, and the frozen target rules.
- Candidate predictors are required plus optional groups, minus global/target/self exclusions, followed by the registered Main auxiliaries. Factor/character predictors survive only when every locked level has at least five rows among rows where the target is observed; numeric predictors remain eligible.
- There is exactly one request-bound named predictor matrix for the A2 cohort. No folds, `APPLICATION` view, `quickpred`, runtime predictor deletion, compatibility matrix, local MICE fallback, or second formal request is allowed.
- Preserve `m=20`, master seed `123`, PMM donors/matchtype/ridge/QR settings, mapping, preprocessing, passive rules, factor domains, and U04 thresholds. Formal MICE uses exactly 20 deterministic independent `L'Ecuyer-CMRG` streams, merges and resumes strictly by ascending `chain_id`, and advances only `30→40→50→100→200` after the exact prior U04 continuation terminal.

## Scientific and privacy invariants

- All scientific endpoints, exposures, models, estimands, stages, thresholds, seeds, QC, tables, and figures remain registry-first. Runtime additions or scientific fallback are forbidden.
- Production analyses consume only the approved frozen handoff. Frozen completed data and `.imp=0` retain their registered origins; no patient-level or raw material may enter public, review, protocol, or release bundles.
- P00→A01→…→A06 uses one request and one remote writer at a time. The sole compute pool has capacity exactly 24 workers; formal MICE assigns its 20 chains to that pool, targets uses 24 outer workers, and BLAS/OpenMP remain one thread with no nested workers.
- A03 performs exactly 40 branches × M1–M5 = 200 first fits; PH, VIF/GVIF, and design diagnostics reuse those fits and never alter selection or formulas.
- A04 schedules exactly 200 TVE and 60 RCS Cox fits as targets dynamic branches; formulas, fit counts, pooling, and QC remain unchanged.
- Layer 1 model objects remain restricted; Layer 2 holds canonical aggregate numbers; Layer 3 publication outputs derive only from Layer 2. A07 is local-only and reads approved aggregates, never patient data, SSH, OSS, or the lease.
- Review/release artifacts must exclude patient identifiers, raw/restricted objects, credentials, usernames, hostnames, and absolute paths. Any scientific, input, factor, model, QC, privacy, authority, lease, or terminal ambiguity stops for human review.
